import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=01f90aba"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/React_test_19_05_2026/src/App.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=01f90aba"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const createContext = __vite__cjsImport3_react["createContext"]; const useContext = __vite__cjsImport3_react["useContext"];
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=01f90aba";
import Landing from "/src/components/Landing.jsx";
import Login from "/src/components/Login.jsx";
import Register from "/src/components/Register.jsx";
import Dashboard from "/src/components/Dashboard.jsx";
import Contact from "/src/components/Contact.jsx";
export const AuthContext = createContext(null);
export function useAuth() {
  _s();
  return useContext(AuthContext);
}
_s(useAuth, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
function ProtectedRoute({ children }) {
  _s2();
  const { isLoggedIn } = useAuth();
  const location = useLocation();
  if (!isLoggedIn) {
    return /* @__PURE__ */ jsxDEV(Navigate, { to: "/login", state: { from: location }, replace: true }, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/App.jsx",
      lineNumber: 41,
      columnNumber: 12
    }, this);
  }
  return children;
}
_s2(ProtectedRoute, "6Jx8VSuTEnEolnWz5UXLwjSRRNo=", false, function() {
  return [useAuth, useLocation];
});
_c = ProtectedRoute;
function GuestRoute({ children }) {
  _s3();
  const { isLoggedIn } = useAuth();
  if (isLoggedIn) {
    return /* @__PURE__ */ jsxDEV(Navigate, { to: "/dashboard", replace: true }, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/App.jsx",
      lineNumber: 51,
      columnNumber: 12
    }, this);
  }
  return children;
}
_s3(GuestRoute, "Jbx0LrCfdz/EDenJV2YbpvzQ6CY=", false, function() {
  return [useAuth];
});
_c2 = GuestRoute;
function App() {
  _s4();
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem("user");
    return saved ? JSON.parse(saved) : null;
  });
  const isLoggedIn = !!user;
  const [visitCount, setVisitCount] = useState(0);
  const [language, setLanguageState] = useState(() => {
    return localStorage.getItem("app_language") || "en";
  });
  const setLanguage = (lang) => {
    localStorage.setItem("app_language", lang);
    setLanguageState(lang);
  };
  useEffect(() => {
    const stored = localStorage.getItem("visit_count");
    let count = 14250;
    if (stored) {
      count = parseInt(stored, 10) + 1;
    }
    localStorage.setItem("visit_count", count.toString());
    setVisitCount(count);
  }, []);
  useEffect(() => {
    const handleStorage = (e) => {
      if (e.key === "user") {
        setUser(e.newValue ? JSON.parse(e.newValue) : null);
      } else if (e.key === "app_language") {
        setLanguageState(e.newValue || "en");
      }
    };
    window.addEventListener("storage", handleStorage);
    return () => window.removeEventListener("storage", handleStorage);
  }, []);
  const login = (userData) => {
    localStorage.setItem("user", JSON.stringify(userData));
    setUser(userData);
  };
  const logout = () => {
    localStorage.removeItem("user");
    setUser(null);
  };
  return /* @__PURE__ */ jsxDEV(AuthContext.Provider, { value: { user, isLoggedIn, login, logout, visitCount, language, setLanguage }, children: /* @__PURE__ */ jsxDEV(Router, { children: /* @__PURE__ */ jsxDEV(Routes, { children: [
    /* @__PURE__ */ jsxDEV(Route, { path: "/", element: /* @__PURE__ */ jsxDEV(Landing, {}, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/App.jsx",
      lineNumber: 112,
      columnNumber: 36
    }, this) }, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/App.jsx",
      lineNumber: 112,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/login", element: /* @__PURE__ */ jsxDEV(GuestRoute, { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "bg-shape shape1" }, void 0, false, {
        fileName: "D:/React_test_19_05_2026/src/App.jsx",
        lineNumber: 116,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-shape shape2" }, void 0, false, {
        fileName: "D:/React_test_19_05_2026/src/App.jsx",
        lineNumber: 117,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV(Login, {}, void 0, false, {
        fileName: "D:/React_test_19_05_2026/src/App.jsx",
        lineNumber: 118,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "D:/React_test_19_05_2026/src/App.jsx",
      lineNumber: 115,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/App.jsx",
      lineNumber: 114,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/register", element: /* @__PURE__ */ jsxDEV(GuestRoute, { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "bg-shape shape1" }, void 0, false, {
        fileName: "D:/React_test_19_05_2026/src/App.jsx",
        lineNumber: 124,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-shape shape2" }, void 0, false, {
        fileName: "D:/React_test_19_05_2026/src/App.jsx",
        lineNumber: 125,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV(Register, {}, void 0, false, {
        fileName: "D:/React_test_19_05_2026/src/App.jsx",
        lineNumber: 126,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "D:/React_test_19_05_2026/src/App.jsx",
      lineNumber: 123,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/App.jsx",
      lineNumber: 122,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/dashboard", element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(Dashboard, {}, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/App.jsx",
      lineNumber: 132,
      columnNumber: 15
    }, this) }, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/App.jsx",
      lineNumber: 131,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/App.jsx",
      lineNumber: 130,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/contact", element: /* @__PURE__ */ jsxDEV(Contact, {}, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/App.jsx",
      lineNumber: 136,
      columnNumber: 43
    }, this) }, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/App.jsx",
      lineNumber: 136,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "*", element: /* @__PURE__ */ jsxDEV(Navigate, { to: "/contact", replace: true }, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/App.jsx",
      lineNumber: 139,
      columnNumber: 36
    }, this) }, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/App.jsx",
      lineNumber: 139,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "D:/React_test_19_05_2026/src/App.jsx",
    lineNumber: 111,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "D:/React_test_19_05_2026/src/App.jsx",
    lineNumber: 110,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "D:/React_test_19_05_2026/src/App.jsx",
    lineNumber: 109,
    columnNumber: 5
  }, this);
}
_s4(App, "O1/5DXOBNSCHr4clPC6EAcnStlw=");
_c3 = App;
export default App;
var _c, _c2, _c3;
$RefreshReg$(_c, "ProtectedRoute");
$RefreshReg$(_c2, "GuestRoute");
$RefreshReg$(_c3, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/React_test_19_05_2026/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/React_test_19_05_2026/src/App.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJXOzs7Ozs7Ozs7Ozs7Ozs7OztBQXJCWCxTQUFTQSxVQUFVQyxXQUFXQyxlQUFlQyxrQkFBa0I7QUFDL0QsU0FBU0MsaUJBQWlCQyxRQUFRQyxRQUFRQyxPQUFPQyxVQUFVQyxtQkFBbUI7QUFDOUUsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLGNBQWM7QUFDckIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxhQUFhO0FBR2IsYUFBTUMsY0FBY2IsY0FBYyxJQUFJO0FBRXRDLGdCQUFTYyxVQUFVO0FBQUFDLEtBQUE7QUFDeEIsU0FBT2QsV0FBV1ksV0FBVztBQUMvQjtBQUVBRSxHQUpnQkQsU0FBTztBQUt2QixTQUFTRSxlQUFlLEVBQUVDLFNBQVMsR0FBRztBQUFBQyxNQUFBO0FBQ3BDLFFBQU0sRUFBRUMsV0FBVyxJQUFJTCxRQUFRO0FBQy9CLFFBQU1NLFdBQVdiLFlBQVk7QUFFN0IsTUFBSSxDQUFDWSxZQUFZO0FBQ2YsV0FBTyx1QkFBQyxZQUFTLElBQUcsVUFBUyxPQUFPLEVBQUVFLE1BQU1ELFNBQVMsR0FBRyxTQUFPLFFBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0Q7QUFBQSxFQUNqRTtBQUNBLFNBQU9IO0FBQ1Q7QUFFQUMsSUFWU0YsZ0JBQWM7QUFBQSxVQUNFRixTQUNOUCxXQUFXO0FBQUE7QUFBQSxLQUZyQlM7QUFXVCxTQUFTTSxXQUFXLEVBQUVMLFNBQVMsR0FBRztBQUFBTSxNQUFBO0FBQ2hDLFFBQU0sRUFBRUosV0FBVyxJQUFJTCxRQUFRO0FBRS9CLE1BQUlLLFlBQVk7QUFDZCxXQUFPLHVCQUFDLFlBQVMsSUFBRyxjQUFhLFNBQU8sUUFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpQztBQUFBLEVBQzFDO0FBQ0EsU0FBT0Y7QUFDVDtBQUFDTSxJQVBRRCxZQUFVO0FBQUEsVUFDTVIsT0FBTztBQUFBO0FBQUEsTUFEdkJRO0FBU1QsU0FBU0UsTUFBTTtBQUFBQyxNQUFBO0FBQ2IsUUFBTSxDQUFDQyxNQUFNQyxPQUFPLElBQUk3QixTQUFTLE1BQU07QUFDckMsVUFBTThCLFFBQVFDLGFBQWFDLFFBQVEsTUFBTTtBQUN6QyxXQUFPRixRQUFRRyxLQUFLQyxNQUFNSixLQUFLLElBQUk7QUFBQSxFQUNyQyxDQUFDO0FBRUQsUUFBTVQsYUFBYSxDQUFDLENBQUNPO0FBRXJCLFFBQU0sQ0FBQ08sWUFBWUMsYUFBYSxJQUFJcEMsU0FBUyxDQUFDO0FBQzlDLFFBQU0sQ0FBQ3FDLFVBQVVDLGdCQUFnQixJQUFJdEMsU0FBUyxNQUFNO0FBQ2xELFdBQU8rQixhQUFhQyxRQUFRLGNBQWMsS0FBSztBQUFBLEVBQ2pELENBQUM7QUFFRCxRQUFNTyxjQUFjQSxDQUFDQyxTQUFTO0FBQzVCVCxpQkFBYVUsUUFBUSxnQkFBZ0JELElBQUk7QUFDekNGLHFCQUFpQkUsSUFBSTtBQUFBLEVBQ3ZCO0FBRUF2QyxZQUFVLE1BQU07QUFDZCxVQUFNeUMsU0FBU1gsYUFBYUMsUUFBUSxhQUFhO0FBQ2pELFFBQUlXLFFBQVE7QUFDWixRQUFJRCxRQUFRO0FBQ1ZDLGNBQVFDLFNBQVNGLFFBQVEsRUFBRSxJQUFJO0FBQUEsSUFDakM7QUFDQVgsaUJBQWFVLFFBQVEsZUFBZUUsTUFBTUUsU0FBUyxDQUFDO0FBQ3BEVCxrQkFBY08sS0FBSztBQUFBLEVBQ3JCLEdBQUcsRUFBRTtBQUdMMUMsWUFBVSxNQUFNO0FBQ2QsVUFBTTZDLGdCQUFnQkEsQ0FBQ0MsTUFBTTtBQUMzQixVQUFJQSxFQUFFQyxRQUFRLFFBQVE7QUFDcEJuQixnQkFBUWtCLEVBQUVFLFdBQVdoQixLQUFLQyxNQUFNYSxFQUFFRSxRQUFRLElBQUksSUFBSTtBQUFBLE1BQ3BELFdBQVdGLEVBQUVDLFFBQVEsZ0JBQWdCO0FBQ25DVix5QkFBaUJTLEVBQUVFLFlBQVksSUFBSTtBQUFBLE1BQ3JDO0FBQUEsSUFDRjtBQUNBQyxXQUFPQyxpQkFBaUIsV0FBV0wsYUFBYTtBQUNoRCxXQUFPLE1BQU1JLE9BQU9FLG9CQUFvQixXQUFXTixhQUFhO0FBQUEsRUFDbEUsR0FBRyxFQUFFO0FBR0wsUUFBTU8sUUFBUUEsQ0FBQ0MsYUFBYTtBQUMxQnZCLGlCQUFhVSxRQUFRLFFBQVFSLEtBQUtzQixVQUFVRCxRQUFRLENBQUM7QUFDckR6QixZQUFReUIsUUFBUTtBQUFBLEVBQ2xCO0FBRUEsUUFBTUUsU0FBU0EsTUFBTTtBQUNuQnpCLGlCQUFhMEIsV0FBVyxNQUFNO0FBQzlCNUIsWUFBUSxJQUFJO0FBQUEsRUFDZDtBQUVBLFNBQ0UsdUJBQUMsWUFBWSxVQUFaLEVBQXFCLE9BQU8sRUFBRUQsTUFBTVAsWUFBWWdDLE9BQU9HLFFBQVFyQixZQUFZRSxVQUFVRSxZQUFZLEdBQ2hHLGlDQUFDLFVBQ0MsaUNBQUMsVUFDQztBQUFBLDJCQUFDLFNBQU0sTUFBSyxLQUFJLFNBQVMsdUJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVEsS0FBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxQztBQUFBLElBRXJDLHVCQUFDLFNBQU0sTUFBSyxVQUFTLFNBQ25CLHVCQUFDLGNBQ0M7QUFBQSw2QkFBQyxTQUFJLFdBQVUscUJBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQztBQUFBLE1BQ2pDLHVCQUFDLFNBQUksV0FBVSxxQkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlDO0FBQUEsTUFDakMsdUJBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQU07QUFBQSxTQUhSO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQSxLQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQztBQUFBLElBRUQsdUJBQUMsU0FBTSxNQUFLLGFBQVksU0FDdEIsdUJBQUMsY0FDQztBQUFBLDZCQUFDLFNBQUksV0FBVSxxQkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlDO0FBQUEsTUFDakMsdUJBQUMsU0FBSSxXQUFVLHFCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUM7QUFBQSxNQUNqQyx1QkFBQyxjQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUztBQUFBLFNBSFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBLEtBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1DO0FBQUEsSUFFRCx1QkFBQyxTQUFNLE1BQUssY0FBYSxTQUN2Qix1QkFBQyxrQkFDQyxpQ0FBQyxlQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBVSxLQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQztBQUFBLElBRUQsdUJBQUMsU0FBTSxNQUFLLFlBQVcsU0FBUyx1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUSxLQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRDO0FBQUEsSUFHNUMsdUJBQUMsU0FBTSxNQUFLLEtBQUksU0FBUyx1QkFBQyxZQUFTLElBQUcsWUFBVyxTQUFPLFFBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0IsS0FBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE0RDtBQUFBLE9BNUI5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNkJBLEtBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErQkEsS0FoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlDQTtBQUVKO0FBQUNaLElBeEZRRCxLQUFHO0FBQUEsTUFBSEE7QUEwRlQsZUFBZUE7QUFBSSxJQUFBZ0MsSUFBQUMsS0FBQUM7QUFBQSxhQUFBRixJQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFDLEtBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsImNyZWF0ZUNvbnRleHQiLCJ1c2VDb250ZXh0IiwiQnJvd3NlclJvdXRlciIsIlJvdXRlciIsIlJvdXRlcyIsIlJvdXRlIiwiTmF2aWdhdGUiLCJ1c2VMb2NhdGlvbiIsIkxhbmRpbmciLCJMb2dpbiIsIlJlZ2lzdGVyIiwiRGFzaGJvYXJkIiwiQ29udGFjdCIsIkF1dGhDb250ZXh0IiwidXNlQXV0aCIsIl9zIiwiUHJvdGVjdGVkUm91dGUiLCJjaGlsZHJlbiIsIl9zMiIsImlzTG9nZ2VkSW4iLCJsb2NhdGlvbiIsImZyb20iLCJHdWVzdFJvdXRlIiwiX3MzIiwiQXBwIiwiX3M0IiwidXNlciIsInNldFVzZXIiLCJzYXZlZCIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJKU09OIiwicGFyc2UiLCJ2aXNpdENvdW50Iiwic2V0VmlzaXRDb3VudCIsImxhbmd1YWdlIiwic2V0TGFuZ3VhZ2VTdGF0ZSIsInNldExhbmd1YWdlIiwibGFuZyIsInNldEl0ZW0iLCJzdG9yZWQiLCJjb3VudCIsInBhcnNlSW50IiwidG9TdHJpbmciLCJoYW5kbGVTdG9yYWdlIiwiZSIsImtleSIsIm5ld1ZhbHVlIiwid2luZG93IiwiYWRkRXZlbnRMaXN0ZW5lciIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCJsb2dpbiIsInVzZXJEYXRhIiwic3RyaW5naWZ5IiwibG9nb3V0IiwicmVtb3ZlSXRlbSIsIl9jIiwiX2MyIiwiX2MzIl0sInNvdXJjZXMiOlsiQXBwLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCBjcmVhdGVDb250ZXh0LCB1c2VDb250ZXh0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgQnJvd3NlclJvdXRlciBhcyBSb3V0ZXIsIFJvdXRlcywgUm91dGUsIE5hdmlnYXRlLCB1c2VMb2NhdGlvbiB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IExhbmRpbmcgZnJvbSAnLi9jb21wb25lbnRzL0xhbmRpbmcnO1xuaW1wb3J0IExvZ2luIGZyb20gJy4vY29tcG9uZW50cy9Mb2dpbic7XG5pbXBvcnQgUmVnaXN0ZXIgZnJvbSAnLi9jb21wb25lbnRzL1JlZ2lzdGVyJztcbmltcG9ydCBEYXNoYm9hcmQgZnJvbSAnLi9jb21wb25lbnRzL0Rhc2hib2FyZCc7XG5pbXBvcnQgQ29udGFjdCBmcm9tICcuL2NvbXBvbmVudHMvQ29udGFjdCc7XG5cbi8vIEF1dGggQ29udGV4dCDigJQgc2luZ2xlIHNvdXJjZSBvZiB0cnV0aCBmb3IgbG9naW4gc3RhdGUgYWNyb3NzIHRoZSBhcHBcbmV4cG9ydCBjb25zdCBBdXRoQ29udGV4dCA9IGNyZWF0ZUNvbnRleHQobnVsbCk7XG5cbmV4cG9ydCBmdW5jdGlvbiB1c2VBdXRoKCkge1xuICByZXR1cm4gdXNlQ29udGV4dChBdXRoQ29udGV4dCk7XG59XG5cbi8vIFByb3RlY3RlZCBSb3V0ZTogcmVkaXJlY3RzIHRvIC9sb2dpbiBpZiBub3QgYXV0aGVudGljYXRlZFxuZnVuY3Rpb24gUHJvdGVjdGVkUm91dGUoeyBjaGlsZHJlbiB9KSB7XG4gIGNvbnN0IHsgaXNMb2dnZWRJbiB9ID0gdXNlQXV0aCgpO1xuICBjb25zdCBsb2NhdGlvbiA9IHVzZUxvY2F0aW9uKCk7XG5cbiAgaWYgKCFpc0xvZ2dlZEluKSB7XG4gICAgcmV0dXJuIDxOYXZpZ2F0ZSB0bz1cIi9sb2dpblwiIHN0YXRlPXt7IGZyb206IGxvY2F0aW9uIH19IHJlcGxhY2UgLz47XG4gIH1cbiAgcmV0dXJuIGNoaWxkcmVuO1xufVxuXG4vLyBHdWVzdCBSb3V0ZTogcmVkaXJlY3RzIGxvZ2dlZC1pbiB1c2VycyBhd2F5IGZyb20gbG9naW4vcmVnaXN0ZXJcbmZ1bmN0aW9uIEd1ZXN0Um91dGUoeyBjaGlsZHJlbiB9KSB7XG4gIGNvbnN0IHsgaXNMb2dnZWRJbiB9ID0gdXNlQXV0aCgpO1xuXG4gIGlmIChpc0xvZ2dlZEluKSB7XG4gICAgcmV0dXJuIDxOYXZpZ2F0ZSB0bz1cIi9kYXNoYm9hcmRcIiByZXBsYWNlIC8+O1xuICB9XG4gIHJldHVybiBjaGlsZHJlbjtcbn1cblxuZnVuY3Rpb24gQXBwKCkge1xuICBjb25zdCBbdXNlciwgc2V0VXNlcl0gPSB1c2VTdGF0ZSgoKSA9PiB7XG4gICAgY29uc3Qgc2F2ZWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgndXNlcicpO1xuICAgIHJldHVybiBzYXZlZCA/IEpTT04ucGFyc2Uoc2F2ZWQpIDogbnVsbDtcbiAgfSk7XG5cbiAgY29uc3QgaXNMb2dnZWRJbiA9ICEhdXNlcjtcblxuICBjb25zdCBbdmlzaXRDb3VudCwgc2V0VmlzaXRDb3VudF0gPSB1c2VTdGF0ZSgwKTtcbiAgY29uc3QgW2xhbmd1YWdlLCBzZXRMYW5ndWFnZVN0YXRlXSA9IHVzZVN0YXRlKCgpID0+IHtcbiAgICByZXR1cm4gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2FwcF9sYW5ndWFnZScpIHx8ICdlbic7XG4gIH0pO1xuXG4gIGNvbnN0IHNldExhbmd1YWdlID0gKGxhbmcpID0+IHtcbiAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnYXBwX2xhbmd1YWdlJywgbGFuZyk7XG4gICAgc2V0TGFuZ3VhZ2VTdGF0ZShsYW5nKTtcbiAgfTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IHN0b3JlZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKCd2aXNpdF9jb3VudCcpO1xuICAgIGxldCBjb3VudCA9IDE0MjUwO1xuICAgIGlmIChzdG9yZWQpIHtcbiAgICAgIGNvdW50ID0gcGFyc2VJbnQoc3RvcmVkLCAxMCkgKyAxO1xuICAgIH1cbiAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgndmlzaXRfY291bnQnLCBjb3VudC50b1N0cmluZygpKTtcbiAgICBzZXRWaXNpdENvdW50KGNvdW50KTtcbiAgfSwgW10pO1xuXG4gIC8vIExpc3RlbiBmb3IgbG9jYWxTdG9yYWdlIGNoYW5nZXMgZnJvbSBvdGhlciB0YWJzIG9yIG1hbnVhbCB1cGRhdGVzXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgaGFuZGxlU3RvcmFnZSA9IChlKSA9PiB7XG4gICAgICBpZiAoZS5rZXkgPT09ICd1c2VyJykge1xuICAgICAgICBzZXRVc2VyKGUubmV3VmFsdWUgPyBKU09OLnBhcnNlKGUubmV3VmFsdWUpIDogbnVsbCk7XG4gICAgICB9IGVsc2UgaWYgKGUua2V5ID09PSAnYXBwX2xhbmd1YWdlJykge1xuICAgICAgICBzZXRMYW5ndWFnZVN0YXRlKGUubmV3VmFsdWUgfHwgJ2VuJyk7XG4gICAgICB9XG4gICAgfTtcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignc3RvcmFnZScsIGhhbmRsZVN0b3JhZ2UpO1xuICAgIHJldHVybiAoKSA9PiB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcignc3RvcmFnZScsIGhhbmRsZVN0b3JhZ2UpO1xuICB9LCBbXSk7XG5cbiAgLy8gUmVhY3RpdmUgbG9naW4vbG9nb3V0IGhlbHBlcnMgdGhhdCB1cGRhdGUgYm90aCBsb2NhbFN0b3JhZ2UgQU5EIHN0YXRlXG4gIGNvbnN0IGxvZ2luID0gKHVzZXJEYXRhKSA9PiB7XG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3VzZXInLCBKU09OLnN0cmluZ2lmeSh1c2VyRGF0YSkpO1xuICAgIHNldFVzZXIodXNlckRhdGEpO1xuICB9O1xuXG4gIGNvbnN0IGxvZ291dCA9ICgpID0+IHtcbiAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgndXNlcicpO1xuICAgIHNldFVzZXIobnVsbCk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8QXV0aENvbnRleHQuUHJvdmlkZXIgdmFsdWU9e3sgdXNlciwgaXNMb2dnZWRJbiwgbG9naW4sIGxvZ291dCwgdmlzaXRDb3VudCwgbGFuZ3VhZ2UsIHNldExhbmd1YWdlIH19PlxuICAgICAgPFJvdXRlcj5cbiAgICAgICAgPFJvdXRlcz5cbiAgICAgICAgICA8Um91dGUgcGF0aD1cIi9cIiBlbGVtZW50PXs8TGFuZGluZyAvPn0gLz5cblxuICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL2xvZ2luXCIgZWxlbWVudD17XG4gICAgICAgICAgICA8R3Vlc3RSb3V0ZT5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zaGFwZSBzaGFwZTFcIj48L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zaGFwZSBzaGFwZTJcIj48L2Rpdj5cbiAgICAgICAgICAgICAgPExvZ2luIC8+XG4gICAgICAgICAgICA8L0d1ZXN0Um91dGU+XG4gICAgICAgICAgfSAvPlxuXG4gICAgICAgICAgPFJvdXRlIHBhdGg9XCIvcmVnaXN0ZXJcIiBlbGVtZW50PXtcbiAgICAgICAgICAgIDxHdWVzdFJvdXRlPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNoYXBlIHNoYXBlMVwiPjwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNoYXBlIHNoYXBlMlwiPjwvZGl2PlxuICAgICAgICAgICAgICA8UmVnaXN0ZXIgLz5cbiAgICAgICAgICAgIDwvR3Vlc3RSb3V0ZT5cbiAgICAgICAgICB9IC8+XG5cbiAgICAgICAgICA8Um91dGUgcGF0aD1cIi9kYXNoYm9hcmRcIiBlbGVtZW50PXtcbiAgICAgICAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cbiAgICAgICAgICAgICAgPERhc2hib2FyZCAvPlxuICAgICAgICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cbiAgICAgICAgICB9IC8+XG5cbiAgICAgICAgICA8Um91dGUgcGF0aD1cIi9jb250YWN0XCIgZWxlbWVudD17PENvbnRhY3QgLz59IC8+XG5cbiAgICAgICAgICB7LyogQ2F0Y2gtYWxsOiByZWRpcmVjdCB1bmtub3duIHJvdXRlcyB0byBsYW5kaW5nICovfVxuICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiKlwiIGVsZW1lbnQ9ezxOYXZpZ2F0ZSB0bz1cIi9jb250YWN0XCIgcmVwbGFjZSAvPn0gLz5cbiAgICAgICAgPC9Sb3V0ZXM+XG4gICAgICA8L1JvdXRlcj5cbiAgICA8L0F1dGhDb250ZXh0LlByb3ZpZGVyPlxuICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBBcHA7XG4iXSwiZmlsZSI6IkQ6L1JlYWN0X3Rlc3RfMTlfMDVfMjAyNi9zcmMvQXBwLmpzeCJ9