import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Register.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=01f90aba"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/React_test_19_05_2026/src/components/Register.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=01f90aba"; const useState = __vite__cjsImport3_react["useState"];
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=01f90aba";
import { Mail, Lock, UserPlus, User } from "/node_modules/.vite/deps/lucide-react.js?v=01f90aba";
const Register = () => {
  _s();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const navigate = useNavigate();
  const [error, setError] = useState("");
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    if (password !== confirmPassword) {
      setError("Passwords do not match!");
      return;
    }
    try {
      const response = await fetch("http://localhost:5000/api/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, password })
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Registration failed");
      }
      console.log("Register successful:", data);
      navigate("/login");
    } catch (err) {
      setError(err.message);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "auth-page-wrapper", children: /* @__PURE__ */ jsxDEV("div", { className: "auth-container", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "auth-header", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "auth-icon-container", children: /* @__PURE__ */ jsxDEV(UserPlus, { size: 28 }, void 0, false, {
        fileName: "D:/React_test_19_05_2026/src/components/Register.jsx",
        lineNumber: 67,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "D:/React_test_19_05_2026/src/components/Register.jsx",
        lineNumber: 66,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { className: "auth-title", children: "Create Account" }, void 0, false, {
        fileName: "D:/React_test_19_05_2026/src/components/Register.jsx",
        lineNumber: 69,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "auth-subtitle", children: "Join us to start your journey" }, void 0, false, {
        fileName: "D:/React_test_19_05_2026/src/components/Register.jsx",
        lineNumber: 70,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/React_test_19_05_2026/src/components/Register.jsx",
      lineNumber: 65,
      columnNumber: 9
    }, this),
    error && /* @__PURE__ */ jsxDEV("div", { style: { color: "#ef4444", backgroundColor: "rgba(239, 68, 68, 0.1)", padding: "0.75rem", borderRadius: "8px", marginBottom: "1rem", fontSize: "0.9rem", border: "1px solid rgba(239, 68, 68, 0.3)" }, children: error }, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/components/Register.jsx",
      lineNumber: 73,
      columnNumber: 19
    }, this),
    /* @__PURE__ */ jsxDEV("form", { className: "auth-form", onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "form-label", htmlFor: "name", children: "Full Name" }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Register.jsx",
          lineNumber: 77,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "input-wrapper", children: [
          /* @__PURE__ */ jsxDEV(User, { className: "input-icon", size: 20 }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Register.jsx",
            lineNumber: 79,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              id: "name",
              className: "form-input",
              placeholder: "John Doe",
              value: name,
              onChange: (e) => setName(e.target.value),
              required: true
            },
            void 0,
            false,
            {
              fileName: "D:/React_test_19_05_2026/src/components/Register.jsx",
              lineNumber: 80,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Register.jsx",
          lineNumber: 78,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Register.jsx",
        lineNumber: 76,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "form-label", htmlFor: "email", children: "Email Address" }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Register.jsx",
          lineNumber: 93,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "input-wrapper", children: [
          /* @__PURE__ */ jsxDEV(Mail, { className: "input-icon", size: 20 }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Register.jsx",
            lineNumber: 95,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "email",
              id: "email",
              className: "form-input",
              placeholder: "name@example.com",
              value: email,
              onChange: (e) => setEmail(e.target.value),
              required: true
            },
            void 0,
            false,
            {
              fileName: "D:/React_test_19_05_2026/src/components/Register.jsx",
              lineNumber: 96,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Register.jsx",
          lineNumber: 94,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Register.jsx",
        lineNumber: 92,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "form-label", htmlFor: "password", children: "Password" }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Register.jsx",
          lineNumber: 109,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "input-wrapper", children: [
          /* @__PURE__ */ jsxDEV(Lock, { className: "input-icon", size: 20 }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Register.jsx",
            lineNumber: 111,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "password",
              id: "password",
              className: "form-input",
              placeholder: "••••••••",
              value: password,
              onChange: (e) => setPassword(e.target.value),
              required: true
            },
            void 0,
            false,
            {
              fileName: "D:/React_test_19_05_2026/src/components/Register.jsx",
              lineNumber: 112,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Register.jsx",
          lineNumber: 110,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Register.jsx",
        lineNumber: 108,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "form-label", htmlFor: "confirmPassword", children: "Confirm Password" }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Register.jsx",
          lineNumber: 125,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "input-wrapper", children: [
          /* @__PURE__ */ jsxDEV(Lock, { className: "input-icon", size: 20 }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Register.jsx",
            lineNumber: 127,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "password",
              id: "confirmPassword",
              className: "form-input",
              placeholder: "••••••••",
              value: confirmPassword,
              onChange: (e) => setConfirmPassword(e.target.value),
              required: true
            },
            void 0,
            false,
            {
              fileName: "D:/React_test_19_05_2026/src/components/Register.jsx",
              lineNumber: 128,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Register.jsx",
          lineNumber: 126,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Register.jsx",
        lineNumber: 124,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "submit-btn", children: "Register" }, void 0, false, {
        fileName: "D:/React_test_19_05_2026/src/components/Register.jsx",
        lineNumber: 140,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/React_test_19_05_2026/src/components/Register.jsx",
      lineNumber: 75,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "auth-footer", children: [
      "Already have an account?",
      /* @__PURE__ */ jsxDEV(Link, { to: "/login", className: "auth-link", children: "Sign In" }, void 0, false, {
        fileName: "D:/React_test_19_05_2026/src/components/Register.jsx",
        lineNumber: 147,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/React_test_19_05_2026/src/components/Register.jsx",
      lineNumber: 145,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "D:/React_test_19_05_2026/src/components/Register.jsx",
    lineNumber: 64,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "D:/React_test_19_05_2026/src/components/Register.jsx",
    lineNumber: 63,
    columnNumber: 5
  }, this);
};
_s(Register, "A7M8eGhIsys7ctUUc0elImwNBGo=", false, function() {
  return [useNavigate];
});
_c = Register;
export default Register;
var _c;
$RefreshReg$(_c, "Register");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/React_test_19_05_2026/src/components/Register.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/React_test_19_05_2026/src/components/Register.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0NZOzs7Ozs7Ozs7Ozs7Ozs7OztBQS9DWixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsTUFBTUMsbUJBQW1CO0FBQ2xDLFNBQVNDLE1BQU1DLE1BQU1DLFVBQVVDLFlBQVk7QUFFM0MsTUFBTUMsV0FBV0EsTUFBTTtBQUFBQyxLQUFBO0FBQ3JCLFFBQU0sQ0FBQ0MsTUFBTUMsT0FBTyxJQUFJVixTQUFTLEVBQUU7QUFDbkMsUUFBTSxDQUFDVyxPQUFPQyxRQUFRLElBQUlaLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNhLFVBQVVDLFdBQVcsSUFBSWQsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ2UsaUJBQWlCQyxrQkFBa0IsSUFBSWhCLFNBQVMsRUFBRTtBQUN6RCxRQUFNaUIsV0FBV2YsWUFBWTtBQUU3QixRQUFNLENBQUNnQixPQUFPQyxRQUFRLElBQUluQixTQUFTLEVBQUU7QUFFckMsUUFBTW9CLGVBQWUsT0FBT0MsTUFBTTtBQUNoQ0EsTUFBRUMsZUFBZTtBQUNqQkgsYUFBUyxFQUFFO0FBRVgsUUFBSU4sYUFBYUUsaUJBQWlCO0FBQ2hDSSxlQUFTLHlCQUF5QjtBQUNsQztBQUFBLElBQ0Y7QUFFQSxRQUFJO0FBQ0YsWUFBTUksV0FBVyxNQUFNQyxNQUFNLHNDQUFzQztBQUFBLFFBQ2pFQyxRQUFRO0FBQUEsUUFDUkMsU0FBUyxFQUFFLGdCQUFnQixtQkFBbUI7QUFBQSxRQUM5Q0MsTUFBTUMsS0FBS0MsVUFBVSxFQUFFcEIsTUFBTUUsT0FBT0UsU0FBUyxDQUFDO0FBQUEsTUFDaEQsQ0FBQztBQUVELFlBQU1pQixPQUFPLE1BQU1QLFNBQVNRLEtBQUs7QUFFakMsVUFBSSxDQUFDUixTQUFTUyxJQUFJO0FBQ2hCLGNBQU0sSUFBSUMsTUFBTUgsS0FBS1osU0FBUyxxQkFBcUI7QUFBQSxNQUNyRDtBQUVBZ0IsY0FBUUMsSUFBSSx3QkFBd0JMLElBQUk7QUFDeENiLGVBQVMsUUFBUTtBQUFBLElBQ25CLFNBQVNtQixLQUFLO0FBQ1pqQixlQUFTaUIsSUFBSUMsT0FBTztBQUFBLElBQ3RCO0FBQUEsRUFDRjtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLHFCQUNiLGlDQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHVCQUNiLGlDQUFDLFlBQVMsTUFBTSxNQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1CLEtBRHJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsUUFBRyxXQUFVLGNBQWEsOEJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUM7QUFBQSxNQUN6Qyx1QkFBQyxPQUFFLFdBQVUsaUJBQWdCLDZDQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBEO0FBQUEsU0FMNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BO0FBQUEsSUFFQ25CLFNBQVMsdUJBQUMsU0FBSSxPQUFPLEVBQUVvQixPQUFPLFdBQVdDLGlCQUFpQiwwQkFBMEJDLFNBQVMsV0FBV0MsY0FBYyxPQUFPQyxjQUFjLFFBQVFDLFVBQVUsVUFBVUMsUUFBUSxtQ0FBbUMsR0FBSTFCLG1CQUE3TTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1OO0FBQUEsSUFFN04sdUJBQUMsVUFBSyxXQUFVLGFBQVksVUFBVUUsY0FDcEM7QUFBQSw2QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLCtCQUFDLFdBQU0sV0FBVSxjQUFhLFNBQVEsUUFBTyx5QkFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRDtBQUFBLFFBQ3RELHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLGlDQUFDLFFBQUssV0FBVSxjQUFhLE1BQU0sTUFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0M7QUFBQSxVQUN0QztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsSUFBRztBQUFBLGNBQ0gsV0FBVTtBQUFBLGNBQ1YsYUFBWTtBQUFBLGNBQ1osT0FBT1g7QUFBQUEsY0FDUCxVQUFVLENBQUNZLE1BQU1YLFFBQVFXLEVBQUV3QixPQUFPQyxLQUFLO0FBQUEsY0FDdkMsVUFBUTtBQUFBO0FBQUEsWUFQVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPVTtBQUFBLGFBVFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsV0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBY0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsK0JBQUMsV0FBTSxXQUFVLGNBQWEsU0FBUSxTQUFRLDZCQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJEO0FBQUEsUUFDM0QsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsaUNBQUMsUUFBSyxXQUFVLGNBQWEsTUFBTSxNQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzQztBQUFBLFVBQ3RDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxJQUFHO0FBQUEsY0FDSCxXQUFVO0FBQUEsY0FDVixhQUFZO0FBQUEsY0FDWixPQUFPbkM7QUFBQUEsY0FDUCxVQUFVLENBQUNVLE1BQU1ULFNBQVNTLEVBQUV3QixPQUFPQyxLQUFLO0FBQUEsY0FDeEMsVUFBUTtBQUFBO0FBQUEsWUFQVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPVTtBQUFBLGFBVFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsV0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBY0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsK0JBQUMsV0FBTSxXQUFVLGNBQWEsU0FBUSxZQUFXLHdCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlEO0FBQUEsUUFDekQsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsaUNBQUMsUUFBSyxXQUFVLGNBQWEsTUFBTSxNQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzQztBQUFBLFVBQ3RDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxJQUFHO0FBQUEsY0FDSCxXQUFVO0FBQUEsY0FDVixhQUFZO0FBQUEsY0FDWixPQUFPakM7QUFBQUEsY0FDUCxVQUFVLENBQUNRLE1BQU1QLFlBQVlPLEVBQUV3QixPQUFPQyxLQUFLO0FBQUEsY0FDM0MsVUFBUTtBQUFBO0FBQUEsWUFQVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPVTtBQUFBLGFBVFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsV0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBY0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsK0JBQUMsV0FBTSxXQUFVLGNBQWEsU0FBUSxtQkFBa0IsZ0NBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0U7QUFBQSxRQUN4RSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxpQ0FBQyxRQUFLLFdBQVUsY0FBYSxNQUFNLE1BQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNDO0FBQUEsVUFDdEM7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLElBQUc7QUFBQSxjQUNILFdBQVU7QUFBQSxjQUNWLGFBQVk7QUFBQSxjQUNaLE9BQU8vQjtBQUFBQSxjQUNQLFVBQVUsQ0FBQ00sTUFBTUwsbUJBQW1CSyxFQUFFd0IsT0FBT0MsS0FBSztBQUFBLGNBQ2xELFVBQVE7QUFBQTtBQUFBLFlBUFY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT1U7QUFBQSxhQVRaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFdBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWNBO0FBQUEsTUFFQSx1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLGNBQVksd0JBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBbkVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvRUE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxlQUFhO0FBQUE7QUFBQSxNQUUxQix1QkFBQyxRQUFLLElBQUcsVUFBUyxXQUFVLGFBQVksdUJBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0M7QUFBQSxTQUZqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxPQXBGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBcUZBLEtBdEZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1RkE7QUFFSjtBQUFFdEMsR0FoSUlELFVBQVE7QUFBQSxVQUtLTCxXQUFXO0FBQUE7QUFBQSxLQUx4Qks7QUFrSU4sZUFBZUE7QUFBUyxJQUFBd0M7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJMaW5rIiwidXNlTmF2aWdhdGUiLCJNYWlsIiwiTG9jayIsIlVzZXJQbHVzIiwiVXNlciIsIlJlZ2lzdGVyIiwiX3MiLCJuYW1lIiwic2V0TmFtZSIsImVtYWlsIiwic2V0RW1haWwiLCJwYXNzd29yZCIsInNldFBhc3N3b3JkIiwiY29uZmlybVBhc3N3b3JkIiwic2V0Q29uZmlybVBhc3N3b3JkIiwibmF2aWdhdGUiLCJlcnJvciIsInNldEVycm9yIiwiaGFuZGxlU3VibWl0IiwiZSIsInByZXZlbnREZWZhdWx0IiwicmVzcG9uc2UiLCJmZXRjaCIsIm1ldGhvZCIsImhlYWRlcnMiLCJib2R5IiwiSlNPTiIsInN0cmluZ2lmeSIsImRhdGEiLCJqc29uIiwib2siLCJFcnJvciIsImNvbnNvbGUiLCJsb2ciLCJlcnIiLCJtZXNzYWdlIiwiY29sb3IiLCJiYWNrZ3JvdW5kQ29sb3IiLCJwYWRkaW5nIiwiYm9yZGVyUmFkaXVzIiwibWFyZ2luQm90dG9tIiwiZm9udFNpemUiLCJib3JkZXIiLCJ0YXJnZXQiLCJ2YWx1ZSIsIl9jIl0sInNvdXJjZXMiOlsiUmVnaXN0ZXIuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgTGluaywgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IE1haWwsIExvY2ssIFVzZXJQbHVzLCBVc2VyIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcblxuY29uc3QgUmVnaXN0ZXIgPSAoKSA9PiB7XG4gIGNvbnN0IFtuYW1lLCBzZXROYW1lXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2VtYWlsLCBzZXRFbWFpbF0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtwYXNzd29yZCwgc2V0UGFzc3dvcmRdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbY29uZmlybVBhc3N3b3JkLCBzZXRDb25maXJtUGFzc3dvcmRdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG5cbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZSgnJyk7XG5cbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgc2V0RXJyb3IoJycpO1xuXG4gICAgaWYgKHBhc3N3b3JkICE9PSBjb25maXJtUGFzc3dvcmQpIHtcbiAgICAgIHNldEVycm9yKFwiUGFzc3dvcmRzIGRvIG5vdCBtYXRjaCFcIik7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIFxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKCdodHRwOi8vbG9jYWxob3N0OjUwMDAvYXBpL3JlZ2lzdGVyJywge1xuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgbmFtZSwgZW1haWwsIHBhc3N3b3JkIH0pXG4gICAgICB9KTtcblxuICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcblxuICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoZGF0YS5lcnJvciB8fCAnUmVnaXN0cmF0aW9uIGZhaWxlZCcpO1xuICAgICAgfVxuXG4gICAgICBjb25zb2xlLmxvZygnUmVnaXN0ZXIgc3VjY2Vzc2Z1bDonLCBkYXRhKTtcbiAgICAgIG5hdmlnYXRlKCcvbG9naW4nKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNldEVycm9yKGVyci5tZXNzYWdlKTtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImF1dGgtcGFnZS13cmFwcGVyXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImF1dGgtY29udGFpbmVyXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXV0aC1oZWFkZXJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImF1dGgtaWNvbi1jb250YWluZXJcIj5cbiAgICAgICAgICAgIDxVc2VyUGx1cyBzaXplPXsyOH0gLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwiYXV0aC10aXRsZVwiPkNyZWF0ZSBBY2NvdW50PC9oMT5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJhdXRoLXN1YnRpdGxlXCI+Sm9pbiB1cyB0byBzdGFydCB5b3VyIGpvdXJuZXk8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHtlcnJvciAmJiA8ZGl2IHN0eWxlPXt7IGNvbG9yOiAnI2VmNDQ0NCcsIGJhY2tncm91bmRDb2xvcjogJ3JnYmEoMjM5LCA2OCwgNjgsIDAuMSknLCBwYWRkaW5nOiAnMC43NXJlbScsIGJvcmRlclJhZGl1czogJzhweCcsIG1hcmdpbkJvdHRvbTogJzFyZW0nLCBmb250U2l6ZTogJzAuOXJlbScsIGJvcmRlcjogJzFweCBzb2xpZCByZ2JhKDIzOSwgNjgsIDY4LCAwLjMpJyB9fT57ZXJyb3J9PC9kaXY+fVxuXG4gICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cImF1dGgtZm9ybVwiIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cFwiPlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvcm0tbGFiZWxcIiBodG1sRm9yPVwibmFtZVwiPkZ1bGwgTmFtZTwvbGFiZWw+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlucHV0LXdyYXBwZXJcIj5cbiAgICAgICAgICAgICAgPFVzZXIgY2xhc3NOYW1lPVwiaW5wdXQtaWNvblwiIHNpemU9ezIwfSAvPlxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgaWQ9XCJuYW1lXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb3JtLWlucHV0XCJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkpvaG4gRG9lXCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17bmFtZX1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE5hbWUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cFwiPlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvcm0tbGFiZWxcIiBodG1sRm9yPVwiZW1haWxcIj5FbWFpbCBBZGRyZXNzPC9sYWJlbD5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5wdXQtd3JhcHBlclwiPlxuICAgICAgICAgICAgICA8TWFpbCBjbGFzc05hbWU9XCJpbnB1dC1pY29uXCIgc2l6ZT17MjB9IC8+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJlbWFpbFwiXG4gICAgICAgICAgICAgICAgaWQ9XCJlbWFpbFwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1pbnB1dFwiXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJuYW1lQGV4YW1wbGUuY29tXCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17ZW1haWx9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRFbWFpbChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9ybS1sYWJlbFwiIGh0bWxGb3I9XCJwYXNzd29yZFwiPlBhc3N3b3JkPC9sYWJlbD5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5wdXQtd3JhcHBlclwiPlxuICAgICAgICAgICAgICA8TG9jayBjbGFzc05hbWU9XCJpbnB1dC1pY29uXCIgc2l6ZT17MjB9IC8+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgaWQ9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1pbnB1dFwiXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCLigKLigKLigKLigKLigKLigKLigKLigKJcIlxuICAgICAgICAgICAgICAgIHZhbHVlPXtwYXNzd29yZH1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFBhc3N3b3JkKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXBcIj5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmb3JtLWxhYmVsXCIgaHRtbEZvcj1cImNvbmZpcm1QYXNzd29yZFwiPkNvbmZpcm0gUGFzc3dvcmQ8L2xhYmVsPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbnB1dC13cmFwcGVyXCI+XG4gICAgICAgICAgICAgIDxMb2NrIGNsYXNzTmFtZT1cImlucHV0LWljb25cIiBzaXplPXsyMH0gLz5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICBpZD1cImNvbmZpcm1QYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1pbnB1dFwiXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCLigKLigKLigKLigKLigKLigKLigKLigKJcIlxuICAgICAgICAgICAgICAgIHZhbHVlPXtjb25maXJtUGFzc3dvcmR9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDb25maXJtUGFzc3dvcmQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIGNsYXNzTmFtZT1cInN1Ym1pdC1idG5cIj5cbiAgICAgICAgICAgIFJlZ2lzdGVyXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZm9ybT5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImF1dGgtZm9vdGVyXCI+XG4gICAgICAgICAgQWxyZWFkeSBoYXZlIGFuIGFjY291bnQ/IFxuICAgICAgICAgIDxMaW5rIHRvPVwiL2xvZ2luXCIgY2xhc3NOYW1lPVwiYXV0aC1saW5rXCI+U2lnbiBJbjwvTGluaz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IFJlZ2lzdGVyO1xuIl0sImZpbGUiOiJEOi9SZWFjdF90ZXN0XzE5XzA1XzIwMjYvc3JjL2NvbXBvbmVudHMvUmVnaXN0ZXIuanN4In0=