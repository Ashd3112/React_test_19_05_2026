import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Landing.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=01f90aba"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/React_test_19_05_2026/src/components/Landing.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=01f90aba"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=01f90aba";
import {
  ArrowRight,
  ShieldCheck,
  Zap,
  Activity,
  CreditCard,
  HandCoins,
  Wrench,
  Play,
  CheckCircle,
  Menu,
  X,
  Lock,
  Check,
  Users,
  Search,
  Phone,
  FileText,
  MapPin,
  ChevronLeft,
  ChevronRight,
  Download,
  Smartphone,
  Info,
  HelpCircle,
  TrendingUp,
  Percent,
  Sparkles,
  Landmark
} from "/node_modules/.vite/deps/lucide-react.js?v=01f90aba";
import { useAuth } from "/src/App.jsx";
import { translations } from "/src/utils/translations.js";
import __vite__cjsImport8_qrcode from "/node_modules/.vite/deps/qrcode.js?v=01f90aba"; const QRCode = __vite__cjsImport8_qrcode.__esModule ? __vite__cjsImport8_qrcode.default : __vite__cjsImport8_qrcode;
import "/src/landing.css";
const Landing = () => {
  _s();
  const { isLoggedIn, user, visitCount, language, setLanguage } = useAuth();
  const t = translations[language] || translations.en;
  const [qrCodeUrl, setQrCodeUrl] = useState("");
  useEffect(() => {
    QRCode.toDataURL("https://bankdash.com/install-app", { margin: 1, width: 150 }).then((url) => setQrCodeUrl(url)).catch((err) => console.error(err));
  }, []);
  const [searchQuery, setSearchQuery] = useState("");
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [searchResult, setSearchResult] = useState(null);
  const searchInputRef = useRef(null);
  const [activeModal, setActiveModal] = useState(null);
  const [applyProduct, setApplyProduct] = useState("");
  const [applySuccess, setApplySuccess] = useState(false);
  const [applyForm, setApplyForm] = useState({ name: "", email: "", phone: "", income: "" });
  const [currentSlide, setCurrentSlide] = useState(0);
  const slides = [
    {
      title: language === "en" ? "Gold Loan @ 7.20% interest rate" : "स्वर्ण ऋण @ 7.20% ब्याज दर",
      desc: language === "en" ? "Instant approval with minimal paperwork. Safeguard your gold while unlocking its value." : "न्यूनतम कागजी कार्रवाई के साथ तत्काल स्वीकृति। अपने सोने को सुरक्षित रखते हुए उसका मूल्य अनलॉक करें।",
      badge: language === "en" ? "FESTIVE OFFER" : "उत्सव ऑफर",
      btnText: language === "en" ? "Apply Gold Loan" : "स्वर्ण ऋण के लिए आवेदन करें",
      bgGradient: "linear-gradient(135deg, #f59e0b 0%, #b45309 100%)",
      target: "Gold Loan"
    },
    {
      title: language === "en" ? "100% Paperless Digital Personal Loan" : "100% पेपरलेस डिजिटल पर्सनल लोन",
      desc: language === "en" ? "Get credit up to $25,000 instantly in your savings account within 5 minutes." : "5 मिनट के भीतर अपने बचत खाते में $25,000 तक का तत्काल ऋण प्राप्त करें।",
      badge: language === "en" ? "DIGITAL EXCLUSIVE" : "डिजिटल विशेष",
      btnText: language === "en" ? "Check Eligibility" : "पात्रता जांचें",
      bgGradient: "linear-gradient(135deg, #4f46e5 0%, #312e81 100%)",
      target: "Digital Personal Loan"
    },
    {
      title: language === "en" ? "BankDash World Mobile App Launch" : "BankDash World मोबाइल ऐप लॉन्च",
      desc: language === "en" ? "Experience next-gen banking on your phone. Scan, transfer, pay bills & invest on the go." : "अपने फोन पर अगली पीढ़ी की बैंकिंग का अनुभव करें। स्कैन, ट्रांसफर, बिल भुगतान और निवेश करें।",
      badge: language === "en" ? "NEW RELEASE" : "नया रिलीज",
      btnText: language === "en" ? "Download App" : "ऐप डाउनलोड करें",
      bgGradient: "linear-gradient(135deg, #0ea5e9 0%, #0369a1 100%)",
      target: "BankDash App"
    }
  ];
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 6e3);
    return () => clearInterval(timer);
  }, [slides.length]);
  const [activeTab, setActiveTab] = useState("Accounts");
  const products = {
    Accounts: [
      { name: "Advantage Savings Account", desc: "Premium interest rates up to 4.2% p.a. with zero balance option for students.", benefit: "Free Debit Card & Unlimited ATM withdrawals" },
      { name: "Platinum Prestige Account", desc: "Designed for high-net-worth individuals. Multi-currency support & private manager.", benefit: "Complimentary Airport Lounge access & zero fee transfers" }
    ],
    Loans: [
      { name: "Home Loan", desc: "Build or buy your dream home. Interest rates starting from 7.20% p.a.", benefit: "Zero processing fees & flexible repayment tenure" },
      { name: "Car Loan", desc: "Drive home your dream car. Fast processing and competitive interest rates.", benefit: "Up to 90% on-road financing" },
      { name: "Gold Loan", desc: "Unlock value of your gold instantly. Minimal documentation and secure vaults.", benefit: "Low interest rates starting @ 7.20%" }
    ],
    Cards: [
      { name: "Visa Signature Credit Card", desc: "Earn premium reward points on every dining, travel, and online purchase.", benefit: "10% instant discount with key retail partners" },
      { name: "RuPay Select Card", desc: "Domestic lounge access and wellness benefits with zero annual fee.", benefit: "Cashback up to 5% on utility bills" }
    ],
    Deposits: [
      { name: "Double Dhamaka FD", desc: "Double your principal amount in a fixed term under secure government guarantees.", benefit: "Higher interest rates for senior citizens (+0.50%)" },
      { name: "Recurring Deposit Saver", desc: "Build your savings systematically with monthly deposits starting from just $10.", benefit: "Compounded quarterly interest rates" }
    ]
  };
  const [calcAmount, setCalcAmount] = useState("10000");
  const [calcRate, setCalcRate] = useState("7.2");
  const [calcTerm, setCalcTerm] = useState("36");
  const calculateInstallment = () => {
    const P = parseFloat(calcAmount);
    const r = parseFloat(calcRate) / 1200;
    const n = parseFloat(calcTerm);
    if (isNaN(P) || isNaN(r) || isNaN(n) || P <= 0 || r <= 0 || n <= 0) {
      return "0.00";
    }
    const installment = P * r * Math.pow(1 + r, n) / (Math.pow(1 + r, n) - 1);
    return installment.toFixed(2);
  };
  const handleRateCardClick = (rate, typicalAmount, label) => {
    setCalcRate(rate.toString());
    setCalcAmount(typicalAmount.toString());
    const section = document.getElementById("calculator");
    if (section) {
      section.scrollIntoView({ behavior: "smooth" });
    }
  };
  const handlePillClick = (term) => {
    setSearchQuery(term);
    triggerSearch(term);
  };
  const triggerSearch = (query) => {
    if (!query)
      return;
    const q = query.toLowerCase();
    let result = null;
    if (q.includes("loan") || q.includes("home") || q.includes("gold") || q.includes("car")) {
      result = {
        title: language === "en" ? "Related Loan Products Found" : "संबंधित ऋण उत्पाद मिले",
        desc: language === "en" ? "We offer Home Loans (7.20%), Gold Loans (7.20%), Car Loans (7.80%), and Personal Loans (10.15%). You can calculate rates and apply." : "हम होम लोन (7.20%), गोल्ड लोन (7.20%), कार लोन (7.80%) और पर्सनल लोन (10.15%) प्रदान करते हैं।",
        action: () => {
          setActiveTab("Loans");
          document.getElementById("products-section")?.scrollIntoView({ behavior: "smooth" });
        },
        btnText: language === "en" ? "View Loan Products" : "ऋण उत्पाद देखें"
      };
    } else if (q.includes("account") || q.includes("saving") || q.includes("current")) {
      result = {
        title: language === "en" ? "Savings & Current Accounts" : "बचत और चालू खाते",
        desc: language === "en" ? "BOB Advantage and Platinum Savings accounts offer dynamic interest, custom debit cards, and multi-currency wallets." : "बीओबी एडवांटेज और प्लेटिनम बचत खाते गतिशील ब्याज और कस्टम डेबिट कार्ड प्रदान करते हैं।",
        action: () => {
          setActiveTab("Accounts");
          document.getElementById("products-section")?.scrollIntoView({ behavior: "smooth" });
        },
        btnText: language === "en" ? "View Accounts" : "खाते देखें"
      };
    } else if (q.includes("offer") || q.includes("discount") || q.includes("cashback")) {
      result = {
        title: language === "en" ? "Active Promotional Offers" : "सक्रिय प्रचार ऑफर",
        desc: language === "en" ? "Get instant 10% discount on dining, cashback on grocery, or free 3 months OTT subscriptions with BankDash cards." : "बैंकडैश कार्ड के साथ डाइनिंग पर तत्काल 10% छूट, किराना पर कैशबैक या मुफ्त 3 महीने का ओटीटी सब्सक्रिप्शन प्राप्त करें।",
        action: () => {
          document.getElementById("offers-section")?.scrollIntoView({ behavior: "smooth" });
        },
        btnText: language === "en" ? "View Special Offers" : "विशेष ऑफर देखें"
      };
    } else if (q.includes("rate") || q.includes("interest")) {
      result = {
        title: language === "en" ? "Live Interest Rates Finder" : "लाइव ब्याज दर खोजक",
        desc: language === "en" ? "Check our dynamic interest rate grid. Starting from 7.20% for Gold/Home loans and up to 10.15% for Personal Loans." : "हमारी गतिशील ब्याज दर ग्रिड की जाँच करें। गोल्ड/होम लोन के लिए 7.20% से शुरू होकर पर्सनल लोन के लिए 10.15% तक।",
        action: () => {
          document.getElementById("rates-section")?.scrollIntoView({ behavior: "smooth" });
        },
        btnText: language === "en" ? "View Interest Rates" : "ब्याज दरें देखें"
      };
    } else {
      result = {
        title: language === "en" ? "Search Results" : "खोज परिणाम",
        desc: language === "en" ? `Looking for '${query}'? Explore our online banking services by opening an account today.` : `'${query}' की तलाश है? आज ही खाता खोलकर हमारी ऑनलाइन बैंकिंग सेवाओं का अन्वेषण करें।`,
        action: () => {
          setActiveModal("apply");
          setApplyProduct("General Digital Account");
        },
        btnText: language === "en" ? "Open Free Account" : "मुफ़्त खाता खोलें"
      };
    }
    setSearchResult(result);
    setShowSuggestions(false);
  };
  const handleApplySubmit = (e) => {
    e.preventDefault();
    if (!applyForm.name || !applyForm.email || !applyForm.phone) {
      alert(language === "en" ? "Please fill in all required fields." : "कृपया सभी आवश्यक फ़ील्ड भरें।");
      return;
    }
    fetch("http://localhost:5000/api/applications", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        name: applyForm.name,
        email: applyForm.email,
        phone: applyForm.phone,
        income: applyForm.income,
        product: applyProduct
      })
    }).then((res) => {
      if (!res.ok)
        throw new Error("Failed to submit application");
      return res.json();
    }).then(() => {
      setApplySuccess(true);
      setTimeout(() => {
        setActiveModal(null);
        setApplySuccess(false);
        setApplyForm({ name: "", email: "", phone: "", income: "" });
      }, 3e3);
    }).catch((err) => {
      console.error("Error submitting application:", err);
      alert(language === "en" ? "Failed to submit application. Please try again." : "आवेदन जमा करने में विफल। कृपया पुन: प्रयास करें।");
    });
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "landing-body animate-fade", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "landing-bg-decor decor-purple" }, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
      lineNumber: 275,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "landing-bg-decor decor-cyan" }, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
      lineNumber: 276,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "landing-bg-decor decor-amber" }, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
      lineNumber: 277,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "top-utility-bar", children: /* @__PURE__ */ jsxDEV("div", { className: "top-utility-container", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "utility-left", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "utility-item", children: [
          /* @__PURE__ */ jsxDEV(Phone, { size: 13 }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 283,
            columnNumber: 44
          }, this),
          " ",
          t.toll_free
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 283,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "utility-item cursor-pointer", onClick: () => setActiveModal("locator"), children: [
          /* @__PURE__ */ jsxDEV(MapPin, { size: 13 }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 284,
            columnNumber: 101
          }, this),
          " ",
          language === "en" ? "Branch Locator" : "शाखा खोजक"
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 284,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "utility-item cursor-pointer", onClick: () => setActiveModal("forms"), children: [
          /* @__PURE__ */ jsxDEV(Download, { size: 13 }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 285,
            columnNumber: 99
          }, this),
          " ",
          t.download_forms
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 285,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 282,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "utility-right", children: [
        /* @__PURE__ */ jsxDEV("a", { href: "#rates-section", className: "utility-link", children: [
          /* @__PURE__ */ jsxDEV(TrendingUp, { size: 13 }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 288,
            columnNumber: 63
          }, this),
          " ",
          t.rates_cards
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 288,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Link, { to: "/contact", className: "utility-link", children: [
          /* @__PURE__ */ jsxDEV(HelpCircle, { size: 13 }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 289,
            columnNumber: 58
          }, this),
          " ",
          t.cust_care
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 289,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "language-selector-wrapper", children: /* @__PURE__ */ jsxDEV(
          "select",
          {
            value: language,
            onChange: (e) => setLanguage(e.target.value),
            className: "lang-select-utility",
            children: [
              /* @__PURE__ */ jsxDEV("option", { value: "en", children: "English 🇬🇧" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
                lineNumber: 296,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "hi", children: "हिंदी 🇮🇳" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
                lineNumber: 297,
                columnNumber: 17
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 291,
            columnNumber: 15
          },
          this
        ) }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 290,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 287,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
      lineNumber: 281,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
      lineNumber: 280,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("header", { className: "landing-header", children: /* @__PURE__ */ jsxDEV("div", { className: "landing-nav-container", children: [
      /* @__PURE__ */ jsxDEV(Link, { to: "/", className: "landing-logo", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "logo-icon-box", children: /* @__PURE__ */ jsxDEV(Zap, { size: 22, fill: "white" }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 309,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 308,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: "BankDash" }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 311,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 307,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("nav", { className: "mega-nav", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "nav-item-dropdown", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "nav-drop-label", children: t.nav_personal }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 317,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "nav-dropdown-content", children: [
            /* @__PURE__ */ jsxDEV("a", { href: "#products-section", onClick: () => setActiveTab("Accounts"), children: "Savings Accounts" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 319,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("a", { href: "#products-section", onClick: () => setActiveTab("Loans"), children: "Home Loans" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 320,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("a", { href: "#products-section", onClick: () => setActiveTab("Cards"), children: "Credit Cards" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 321,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 318,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 316,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "nav-item-dropdown", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "nav-drop-label", children: t.nav_business }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 325,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "nav-dropdown-content", children: [
            /* @__PURE__ */ jsxDEV("a", { href: "#products-section", onClick: () => setActiveTab("Accounts"), children: "Current Accounts" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 327,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("a", { href: "#products-section", onClick: () => setActiveTab("Deposits"), children: "Fixed Term Deposits" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 328,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("a", { href: "#products-section", onClick: () => setActiveTab("Loans"), children: "Business Overdrafts" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 329,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 326,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 324,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "nav-item-dropdown", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "nav-drop-label", children: t.nav_agri }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 333,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "nav-dropdown-content", children: [
            /* @__PURE__ */ jsxDEV("a", { href: "#products-section", onClick: () => setActiveTab("Loans"), children: "Crop Gold Loans" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 335,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("a", { href: "#products-section", onClick: () => setActiveTab("Loans"), children: "Tractor Finance" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 336,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 334,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 332,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Link, { to: "/contact", className: "nav-direct-link", children: t.nav_about }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 339,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 315,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "header-search-container", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "search-input-wrapper", children: [
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              ref: searchInputRef,
              type: "text",
              placeholder: t.search_placeholder,
              value: searchQuery,
              onChange: (e) => {
                setSearchQuery(e.target.value);
                setShowSuggestions(e.target.value.length > 0);
              },
              onFocus: () => {
                if (searchQuery.length > 0)
                  setShowSuggestions(true);
              },
              onKeyDown: (e) => {
                if (e.key === "Enter")
                  triggerSearch(searchQuery);
              },
              className: "header-search-input"
            },
            void 0,
            false,
            {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 345,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(Search, { size: 16, className: "search-icon", onClick: () => triggerSearch(searchQuery) }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 362,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 344,
          columnNumber: 13
        }, this),
        showSuggestions && /* @__PURE__ */ jsxDEV("div", { className: "search-suggestions-overlay", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "suggestion-item", onClick: () => handlePillClick("Gold Loan"), children: "Gold Loan Rates" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 367,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "suggestion-item", onClick: () => handlePillClick("Savings Account"), children: "Savings Account Details" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 368,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "suggestion-item", onClick: () => handlePillClick("Special Offers"), children: "Special Cashback Offers" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 369,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "suggestion-item", onClick: () => handlePillClick("Home Loan"), children: "Home Loan Calculator" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 370,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 366,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 343,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "landing-nav-actions", children: isLoggedIn ? /* @__PURE__ */ jsxDEV(Link, { to: "/dashboard", className: "btn-nav-signup", children: t.dashboard }, void 0, false, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 377,
        columnNumber: 13
      }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(Link, { to: "/login", className: "btn-nav-login", children: t.login }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 380,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Link, { to: "/register", className: "btn-nav-signup", children: t.signup }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 381,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 379,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 375,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
      lineNumber: 306,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
      lineNumber: 305,
      columnNumber: 7
    }, this),
    searchResult && /* @__PURE__ */ jsxDEV("div", { className: "search-result-banner-container", children: /* @__PURE__ */ jsxDEV("div", { className: "search-result-banner animate-slide", children: [
      /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "flex-start" }, children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("span", { className: "search-result-badge", children: [
            /* @__PURE__ */ jsxDEV(Sparkles, { size: 12 }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 394,
              columnNumber: 55
            }, this),
            " ",
            language === "en" ? "Match Found" : "मैच मिला"
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 394,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("h4", { className: "search-result-title", children: searchResult.title }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 395,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "search-result-desc", children: searchResult.desc }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 396,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 393,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "btn-close-search", onClick: () => setSearchResult(null), children: /* @__PURE__ */ jsxDEV(X, { size: 18 }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 398,
          columnNumber: 90
        }, this) }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 398,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 392,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { marginTop: "1rem", display: "flex", gap: "1rem" }, children: [
        /* @__PURE__ */ jsxDEV("button", { className: "btn-primary", style: { padding: "0.6rem 1.25rem", fontSize: "0.9rem" }, onClick: () => {
          searchResult.action();
          setSearchResult(null);
        }, children: searchResult.btnText }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 401,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "btn-secondary", style: { padding: "0.6rem 1.25rem", fontSize: "0.9rem" }, onClick: () => setSearchResult(null), children: language === "en" ? "Clear Search" : "खोज साफ़ करें" }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 404,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 400,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
      lineNumber: 391,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
      lineNumber: 390,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "quick-suggestions-bar", children: /* @__PURE__ */ jsxDEV("div", { className: "quick-suggestions-container", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "suggestion-label", children: [
        /* @__PURE__ */ jsxDEV(Info, { size: 14 }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 415,
          columnNumber: 46
        }, this),
        " ",
        t.quick_suggestions,
        ":"
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 415,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "suggestion-pills", children: [
        /* @__PURE__ */ jsxDEV("button", { className: "pill-btn", onClick: () => handlePillClick("Digital Savings Account"), children: language === "en" ? "Digital Savings" : "डिजिटल बचत" }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 417,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "pill-btn", onClick: () => handlePillClick("Gold Loan"), children: language === "en" ? "Gold Loan @ 7.20%" : "गोल्ड लोन @ 7.20%" }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 418,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "pill-btn", onClick: () => handlePillClick("Home Loan"), children: language === "en" ? "Home Loan 7.20%" : "होम लोन 7.20%" }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 419,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "pill-btn", onClick: () => handlePillClick("Offers"), children: language === "en" ? "Special Offers" : "विशेष ऑफर" }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 420,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "pill-btn", onClick: () => handlePillClick("Interest Rates"), children: language === "en" ? "Interest Rates" : "ब्याज दरें" }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 421,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 416,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
      lineNumber: 414,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
      lineNumber: 413,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "whats-new-section animate-fade", children: /* @__PURE__ */ jsxDEV("div", { className: "whats-new-container", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "whats-new-header", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "section-title", children: [
          /* @__PURE__ */ jsxDEV(Sparkles, { size: 20, color: "var(--ld-primary)", style: { marginRight: "0.5rem" } }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 430,
            columnNumber: 43
          }, this),
          t.whats_new_title
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 430,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "carousel-nav", children: [
          /* @__PURE__ */ jsxDEV("button", { className: "carousel-nav-btn", onClick: () => setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length), children: /* @__PURE__ */ jsxDEV(ChevronLeft, { size: 20 }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 432,
            columnNumber: 138
          }, this) }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 432,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: "carousel-nav-btn", onClick: () => setCurrentSlide((prev) => (prev + 1) % slides.length), children: /* @__PURE__ */ jsxDEV(ChevronRight, { size: 20 }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 433,
            columnNumber: 122
          }, this) }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 433,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 431,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 429,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "carousel-viewport", children: slides.map(
        (slide, idx) => /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: `carousel-slide ${idx === currentSlide ? "active" : ""}`,
            style: { background: slide.bgGradient },
            children: [
              /* @__PURE__ */ jsxDEV("div", { className: "slide-content", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "slide-badge", children: slide.badge }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
                  lineNumber: 445,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("h3", { className: "slide-title", children: slide.title }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
                  lineNumber: 446,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "slide-desc", children: slide.desc }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
                  lineNumber: 447,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("button", { className: "btn-slide-action", onClick: () => {
                  setActiveModal("apply");
                  setApplyProduct(slide.target);
                }, children: [
                  slide.btnText,
                  " ",
                  /* @__PURE__ */ jsxDEV(ArrowRight, { size: 16 }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
                    lineNumber: 452,
                    columnNumber: 37
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
                  lineNumber: 448,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
                lineNumber: 444,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "slide-visual", children: /* @__PURE__ */ jsxDEV("div", { className: "visual-circle-decor", children: /* @__PURE__ */ jsxDEV(TrendingUp, { size: 80, color: "rgba(255,255,255,0.15)" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
                lineNumber: 457,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
                lineNumber: 456,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
                lineNumber: 455,
                columnNumber: 17
              }, this)
            ]
          },
          idx,
          true,
          {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 439,
            columnNumber: 13
          },
          this
        )
      ) }, void 0, false, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 437,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "carousel-indicators", children: slides.map(
        (_, idx) => /* @__PURE__ */ jsxDEV(
          "span",
          {
            className: `indicator-dot ${idx === currentSlide ? "active" : ""}`,
            onClick: () => setCurrentSlide(idx)
          },
          idx,
          false,
          {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 466,
            columnNumber: 13
          },
          this
        )
      ) }, void 0, false, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 464,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
      lineNumber: 428,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
      lineNumber: 427,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "hero-section", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "hero-content animate-slide", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "hero-tag", children: [
          /* @__PURE__ */ jsxDEV(Zap, { size: 14 }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 480,
            columnNumber: 13
          }, this),
          " ",
          t.hero_tag
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 479,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("h1", { className: "hero-title", children: [
          t.hero_title_1,
          " ",
          /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 483,
            columnNumber: 30
          }, this),
          t.hero_title_2
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 482,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "hero-desc", children: t.hero_desc }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 486,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "hero-ctas", children: isLoggedIn ? /* @__PURE__ */ jsxDEV(Link, { to: "/dashboard", className: "btn-primary", children: [
          t.dashboard,
          " ",
          /* @__PURE__ */ jsxDEV(ArrowRight, { size: 18 }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 492,
            columnNumber: 31
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 491,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV(Link, { to: "/register", className: "btn-primary", children: [
            t.open_account,
            " ",
            /* @__PURE__ */ jsxDEV(ArrowRight, { size: 18 }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 497,
              columnNumber: 36
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 496,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Link, { to: "/login", className: "btn-secondary", children: [
            /* @__PURE__ */ jsxDEV(Play, { size: 16, fill: "currentColor" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 500,
              columnNumber: 19
            }, this),
            " ",
            t.sign_in
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 499,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 495,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 489,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 478,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "hero-media", children: /* @__PURE__ */ jsxDEV("div", { className: "visual-cards-container", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "hero-main-card", children: [
          /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center" }, children: [
            /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.8rem", color: "#c084fc", letterSpacing: "0.1em", fontWeight: 600 }, children: t.platinum_prestige }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 512,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Zap, { size: 22, color: "#c084fc" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 513,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 511,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "1.4rem", fontWeight: 700, color: "#fff", margin: "1rem 0" }, children: "$48,950.00" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 515,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.75rem", color: "#a78bfa" }, children: t.card_holder }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 517,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.9rem", fontWeight: 600, color: "#fff" }, children: "ALEX RAHMAN" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 518,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 516,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 510,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "hero-sub-card", children: [
          /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center" }, children: [
            /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.8rem", color: "#e0f2fe", letterSpacing: "0.1em", fontWeight: 600 }, children: t.business_smart }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 525,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(CreditCard, { size: 22, color: "#38bdf8" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 526,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 524,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "1.25rem", fontWeight: 700, color: "#fff", margin: "0.8rem 0" }, children: "$12,400.00" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 528,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.75rem", color: "#7dd3fc" }, children: t.card_holder }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 530,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.9rem", fontWeight: 600, color: "#fff" }, children: "ATIQUR R." }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 531,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 529,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 523,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "glass-widget widget-balance", children: /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: "0.75rem", alignItems: "center" }, children: [
          /* @__PURE__ */ jsxDEV("div", { style: { width: "10px", height: "10px", borderRadius: "50%", background: "#10b981" } }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 538,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.7rem", color: "var(--ld-text-muted)" }, children: t.income_stream }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 540,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.9rem", fontWeight: 700, color: "var(--ld-text-main)" }, children: "+$5,230.00" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 541,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 539,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 537,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 536,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "glass-widget widget-activity", children: /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: "0.75rem", alignItems: "center" }, children: [
          /* @__PURE__ */ jsxDEV("div", { style: { padding: "0.4rem", borderRadius: "8px", background: "rgba(6, 182, 212, 0.1)", color: "#06b6d4" }, children: /* @__PURE__ */ jsxDEV(Activity, { size: 16 }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 549,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 548,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.7rem", color: "var(--ld-text-muted)" }, children: t.transactions_status }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 552,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.85rem", fontWeight: 600, color: "var(--ld-text-main)" }, children: [
              "99.98% ",
              t.approved
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 553,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 551,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 547,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 546,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 508,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 507,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
      lineNumber: 477,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { id: "products-section", className: "features-section", style: { background: "rgba(255, 255, 255, 0.02)", borderTop: "1px solid var(--ld-border)", borderBottom: "1px solid var(--ld-border)" }, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "section-head", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "section-tag", children: language === "en" ? "BROWSE OUR PORTFOLIO" : "हमारे पोर्टफोलियो ब्राउज़ करें" }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 564,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { className: "section-title", children: language === "en" ? "Explore Banking Products" : "बैंकिंग उत्पादों का अन्वेषण करें" }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 565,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "section-desc", children: language === "en" ? "Choose from our wide range of tailored financial solutions designed to serve your direct personal or business needs." : "अपनी व्यक्तिगत या व्यावसायिक आवश्यकताओं को पूरा करने के लिए हमारे व्यापक वित्तीय समाधानों में से चुनें।" }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 566,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 563,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "product-tab-headers", children: Object.keys(products).map(
        (tabName) => /* @__PURE__ */ jsxDEV(
          "button",
          {
            className: `product-tab-btn ${activeTab === tabName ? "active" : ""}`,
            onClick: () => setActiveTab(tabName),
            children: [
              tabName === "Accounts" && /* @__PURE__ */ jsxDEV(Landmark, { size: 16 }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
                lineNumber: 579,
                columnNumber: 42
              }, this),
              tabName === "Loans" && /* @__PURE__ */ jsxDEV(HandCoins, { size: 16 }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
                lineNumber: 580,
                columnNumber: 39
              }, this),
              tabName === "Cards" && /* @__PURE__ */ jsxDEV(CreditCard, { size: 16 }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
                lineNumber: 581,
                columnNumber: 39
              }, this),
              tabName === "Deposits" && /* @__PURE__ */ jsxDEV(Activity, { size: 16 }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
                lineNumber: 582,
                columnNumber: 42
              }, this),
              /* @__PURE__ */ jsxDEV("span", { style: { marginLeft: "0.5rem" }, children: t[`product_${tabName.toLowerCase()}`] || tabName }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
                lineNumber: 583,
                columnNumber: 15
              }, this)
            ]
          },
          tabName,
          true,
          {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 574,
            columnNumber: 11
          },
          this
        )
      ) }, void 0, false, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 572,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "product-cards-grid animate-fade", children: products[activeTab].map(
        (p, idx) => /* @__PURE__ */ jsxDEV("div", { className: "product-showcase-card", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "product-card-header", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "product-tag-badge", children: [
              /* @__PURE__ */ jsxDEV(Sparkles, { size: 12 }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
                lineNumber: 593,
                columnNumber: 53
              }, this),
              " ",
              activeTab
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 593,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("h4", { className: "product-card-title", children: p.name }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 594,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 592,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "product-card-desc", children: p.desc }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 596,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "product-card-benefit", children: [
            /* @__PURE__ */ jsxDEV(CheckCircle, { size: 14, color: "#10b981" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 598,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: p.benefit }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 599,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 597,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "product-card-actions", children: [
            /* @__PURE__ */ jsxDEV("button", { className: "btn-primary", style: { padding: "0.5rem 1rem", fontSize: "0.85rem" }, onClick: () => {
              setActiveModal("apply");
              setApplyProduct(p.name);
            }, children: t.apply_now }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 602,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("button", { className: "btn-secondary", style: { padding: "0.5rem 1rem", fontSize: "0.85rem" }, onClick: () => handlePillClick(p.name), children: t.know_more }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 608,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 601,
            columnNumber: 15
          }, this)
        ] }, idx, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 591,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 589,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
      lineNumber: 562,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { id: "rates-section", className: "features-section", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "section-head", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "section-tag", children: [
          /* @__PURE__ */ jsxDEV(Percent, { size: 14, style: { marginRight: "0.3rem" } }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 620,
            columnNumber: 41
          }, this),
          language === "en" ? "BEST IN MARKET RATES" : "बाजार में सर्वोत्तम दरें"
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 620,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { className: "section-title", children: t.interest_rates_title }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 621,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "section-desc", children: t.interest_rates_desc }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 622,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 619,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "interest-rates-grid", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "rate-card-item cursor-pointer", onClick: () => handleRateCardClick(7.2, 5e4, "Home Loan"), children: [
          /* @__PURE__ */ jsxDEV("div", { className: "rate-card-head", children: [
            /* @__PURE__ */ jsxDEV(Landmark, { size: 20, color: "var(--ld-primary)" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 629,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("h5", { children: language === "en" ? "Home Loan" : "होम लोन" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 630,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 628,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "rate-card-body", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "rate-number", children: [
              "7.20% ",
              /* @__PURE__ */ jsxDEV("span", { className: "rate-suffix", children: "p.a." }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
                lineNumber: 633,
                columnNumber: 51
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 633,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "rate-desc", children: language === "en" ? "Starting interest rate. Click to prefill calculator." : "प्रारंभिक ब्याज दर। कैलकुलेटर भरने के लिए क्लिक करें।" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 634,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 632,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 627,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "rate-card-item cursor-pointer", onClick: () => handleRateCardClick(7.8, 2e4, "Car Loan"), children: [
          /* @__PURE__ */ jsxDEV("div", { className: "rate-card-head", children: [
            /* @__PURE__ */ jsxDEV(Zap, { size: 20, color: "var(--ld-secondary)" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 641,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("h5", { children: language === "en" ? "Car Loan" : "कार लोन" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 642,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 640,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "rate-card-body", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "rate-number", children: [
              "7.80% ",
              /* @__PURE__ */ jsxDEV("span", { className: "rate-suffix", children: "p.a." }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
                lineNumber: 645,
                columnNumber: 51
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 645,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "rate-desc", children: language === "en" ? "For brand new vehicles. Click to prefill calculator." : "वाहनों के लिए। कैलकुलेटर भरने के लिए क्लिक करें।" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 646,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 644,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 639,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "rate-card-item cursor-pointer", onClick: () => handleRateCardClick(8.85, 3e4, "Education Loan"), children: [
          /* @__PURE__ */ jsxDEV("div", { className: "rate-card-head", children: [
            /* @__PURE__ */ jsxDEV(Users, { size: 20, color: "var(--ld-accent)" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 653,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("h5", { children: language === "en" ? "Education Loan" : "शिक्षा ऋण" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 654,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 652,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "rate-card-body", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "rate-number", children: [
              "8.85% ",
              /* @__PURE__ */ jsxDEV("span", { className: "rate-suffix", children: "p.a." }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
                lineNumber: 657,
                columnNumber: 51
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 657,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "rate-desc", children: language === "en" ? "For higher studies worldwide. Click to prefill calculator." : "उच्च शिक्षा के लिए। कैलकुलेटर भरने के लिए क्लिक करें।" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 658,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 656,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 651,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "rate-card-item cursor-pointer", onClick: () => handleRateCardClick(10.15, 1e4, "Personal Loan"), children: [
          /* @__PURE__ */ jsxDEV("div", { className: "rate-card-head", children: [
            /* @__PURE__ */ jsxDEV(CreditCard, { size: 20, color: "#ec4899" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 665,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("h5", { children: language === "en" ? "Personal Loan" : "व्यक्तिगत ऋण" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 666,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 664,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "rate-card-body", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "rate-number", children: [
              "10.15% ",
              /* @__PURE__ */ jsxDEV("span", { className: "rate-suffix", children: "p.a." }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
                lineNumber: 669,
                columnNumber: 52
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 669,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "rate-desc", children: language === "en" ? "Quick digital personal credit. Click to prefill calculator." : "त्वरित डिजिटल क्रेडिट। कैलकुलेटर भरने के लिए क्लिक करें।" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 670,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 668,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 663,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 625,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
      lineNumber: 618,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { id: "calculator", className: "features-section", style: { background: "rgba(255, 255, 255, 0.01)", borderTop: "1px solid var(--ld-border)", borderBottom: "1px solid var(--ld-border)" }, children: /* @__PURE__ */ jsxDEV("div", { style: { maxWidth: "1100px", margin: "0 auto", display: "grid", gridTemplateColumns: "1fr 1fr", gap: "4rem", alignItems: "center" }, children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("span", { className: "section-tag", children: t.calc_section_tag }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 680,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { className: "section-title", children: t.calc_section_title }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 681,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "section-desc", style: { marginBottom: "2rem" }, children: t.calc_section_desc }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 682,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", flexDirection: "column", gap: "1rem" }, children: [
          /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: "0.75rem", alignItems: "center" }, children: [
            /* @__PURE__ */ jsxDEV(CheckCircle, { size: 18, color: "#10b981" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 687,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.95rem", fontWeight: 500 }, children: t.calc_item_1 }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 688,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 686,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: "0.75rem", alignItems: "center" }, children: [
            /* @__PURE__ */ jsxDEV(CheckCircle, { size: 18, color: "#10b981" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 691,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.95rem", fontWeight: 500 }, children: t.calc_item_2 }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 692,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 690,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: "0.75rem", alignItems: "center" }, children: [
            /* @__PURE__ */ jsxDEV(CheckCircle, { size: 18, color: "#10b981" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 695,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.95rem", fontWeight: 500 }, children: t.calc_item_3 }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 696,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 694,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 685,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 679,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("div", { className: "calc-card", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "calc-title", children: t.calc_card_title }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 703,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "calc-group", children: [
          /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between" }, children: [
            /* @__PURE__ */ jsxDEV("label", { children: t.calc_label_principal }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 707,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "calc-val-indicator", children: [
              "$",
              Number(calcAmount).toLocaleString()
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 708,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 706,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "range",
              min: "5000",
              max: "250000",
              step: "5000",
              className: "calc-range-slider",
              value: calcAmount,
              onChange: (e) => setCalcAmount(e.target.value)
            },
            void 0,
            false,
            {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 710,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 705,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "calc-group", children: [
          /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between" }, children: [
            /* @__PURE__ */ jsxDEV("label", { children: t.calc_label_rate }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 723,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "calc-val-indicator", children: [
              calcRate,
              "%"
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 724,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 722,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "range",
              min: "5",
              max: "18",
              step: "0.1",
              className: "calc-range-slider",
              value: calcRate,
              onChange: (e) => setCalcRate(e.target.value)
            },
            void 0,
            false,
            {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 726,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 721,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "calc-group", children: [
          /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between" }, children: [
            /* @__PURE__ */ jsxDEV("label", { children: t.calc_label_duration }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 739,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "calc-val-indicator", children: [
              calcTerm,
              " Months"
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 740,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 738,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "range",
              min: "12",
              max: "120",
              step: "12",
              className: "calc-range-slider",
              value: calcTerm,
              onChange: (e) => setCalcTerm(e.target.value)
            },
            void 0,
            false,
            {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 742,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 737,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "calc-result", children: [
          /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.8rem", color: "var(--ld-text-muted)", marginBottom: "0.25rem" }, children: t.calc_monthly_payment }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 754,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "calc-val", children: [
            "$",
            calculateInstallment(),
            " ",
            /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "1rem", fontWeight: 500, color: "var(--ld-text-muted)" }, children: t.per_month }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 755,
              columnNumber: 69
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 755,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 753,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 702,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 701,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
      lineNumber: 678,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
      lineNumber: 677,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { id: "offers-section", className: "features-section", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "section-head", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "section-tag", children: [
          /* @__PURE__ */ jsxDEV(Sparkles, { size: 14, style: { marginRight: "0.3rem" } }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 765,
            columnNumber: 41
          }, this),
          language === "en" ? "PROMOTIONS & REWARDS" : "प्रचार और पुरस्कार"
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 765,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { className: "section-title", children: t.special_offers_title }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 766,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "section-desc", children: t.special_offers_desc }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 767,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 764,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "special-offers-grid", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "offer-card-item", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "offer-badge", children: "10% OFF" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 773,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("h4", { className: "offer-title", children: language === "en" ? "Instant Discount on Travel & Flights" : "यात्रा और उड़ानों पर त्वरित छूट" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 774,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "offer-desc", children: language === "en" ? "Get 10% instant discount up to $100 on flight bookings using BankDash Signature Cards." : "बैंकडैश सिग्नेचर कार्ड्स का उपयोग करके फ्लाइट बुकिंग पर $100 तक 10% त्वरित छूट प्राप्त करें।" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 775,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "offer-footer", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "coupon-code", children: [
              "CODE: ",
              /* @__PURE__ */ jsxDEV("b", { children: "DASHTRAVEL" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
                lineNumber: 777,
                columnNumber: 51
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 777,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("button", { className: "btn-secondary", style: { padding: "0.4rem 0.8rem", fontSize: "0.8rem" }, onClick: () => handlePillClick("Offers"), children: t.apply_now }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 778,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 776,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 772,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "offer-card-item", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "offer-badge", children: "15% CASHBACK" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 784,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("h4", { className: "offer-title", children: language === "en" ? "Buy 2 Products & Get Grocery Cashback" : "2 उत्पाद खरीदें और किराना कैशबैक प्राप्त करें" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 785,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "offer-desc", children: language === "en" ? "Shop on partnered supermarkets and unlock flat 15% cashback credited directly to savings." : "साझेदार सुपरमार्केट में खरीदारी करें और बचत खाते में सीधे जमा किए गए 15% कैशबैक को अनलॉक करें।" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 786,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "offer-footer", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "coupon-code", children: [
              "CODE: ",
              /* @__PURE__ */ jsxDEV("b", { children: "DASHMART15" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
                lineNumber: 788,
                columnNumber: 51
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 788,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("button", { className: "btn-secondary", style: { padding: "0.4rem 0.8rem", fontSize: "0.8rem" }, onClick: () => handlePillClick("Offers"), children: t.apply_now }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 789,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 787,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 783,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "offer-card-item", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "offer-badge", children: "3 MONTHS FREE" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 795,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("h4", { className: "offer-title", children: language === "en" ? "Entertainment & OTT Subscription" : "मनोरंजन और ओटीटी सदस्यता" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 796,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "offer-desc", children: language === "en" ? "Get 3 months complimentary subscription to premier media partners with new accounts." : "नए खातों के साथ प्रमुख मीडिया भागीदारों के लिए 3 महीने की मानार्थ सदस्यता प्राप्त करें।" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 797,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "offer-footer", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "coupon-code", children: [
              "CODE: ",
              /* @__PURE__ */ jsxDEV("b", { children: "DASHSTREAM" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
                lineNumber: 799,
                columnNumber: 51
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 799,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("button", { className: "btn-secondary", style: { padding: "0.4rem 0.8rem", fontSize: "0.8rem" }, onClick: () => handlePillClick("Offers"), children: t.apply_now }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 800,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 798,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 794,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 770,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
      lineNumber: 763,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "app-promo-section", children: /* @__PURE__ */ jsxDEV("div", { className: "app-promo-card", children: /* @__PURE__ */ jsxDEV("div", { className: "app-promo-grid", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "app-promo-content", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "app-badge-new", children: "NEW LOOK" }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 811,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("h3", { children: t.app_promo_title }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 812,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: t.app_promo_desc }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 813,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: "1.5rem", flexWrap: "wrap", marginTop: "1.5rem" }, children: [
          /* @__PURE__ */ jsxDEV("div", { style: { background: "#fff", padding: "0.6rem", borderRadius: "12px", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 4px 12px rgba(0,0,0,0.08)" }, children: qrCodeUrl ? /* @__PURE__ */ jsxDEV(
            "img",
            {
              src: qrCodeUrl,
              alt: "Scan QR code to install BankDash",
              style: { width: "80px", height: "80px", display: "block", imageRendering: "pixelated" }
            },
            void 0,
            false,
            {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 818,
              columnNumber: 19
            },
            this
          ) : /* @__PURE__ */ jsxDEV("div", { className: "premium-spinner", style: { width: "32px", height: "32px" } }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 824,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 815,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", flexDirection: "column", justifyContent: "center", gap: "0.5rem" }, children: [
            /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.85rem", fontWeight: 600, color: "rgba(255,255,255,0.8)" }, children: language === "en" ? "Scan QR code to install" : "इंस्टॉल करने के लिए क्यूआर कोड स्कैन करें" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 828,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "app-buttons", children: [
              /* @__PURE__ */ jsxDEV("button", { className: "btn-app-store", children: [
                /* @__PURE__ */ jsxDEV(Smartphone, { size: 14 }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
                  lineNumber: 830,
                  columnNumber: 55
                }, this),
                " App Store"
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
                lineNumber: 830,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("button", { className: "btn-app-store", children: [
                /* @__PURE__ */ jsxDEV(Play, { size: 14 }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
                  lineNumber: 831,
                  columnNumber: 55
                }, this),
                " Google Play"
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
                lineNumber: 831,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 829,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 827,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 814,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 810,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "app-promo-visual", children: /* @__PURE__ */ jsxDEV("div", { className: "app-phone-mockup", children: /* @__PURE__ */ jsxDEV("div", { className: "phone-screen", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "phone-header", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "phone-time", children: "09:41" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 840,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "phone-camera" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 841,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 839,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "phone-app-content", children: [
          /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1rem" }, children: [
            /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.65rem", fontWeight: 600 }, children: "Dash World" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 845,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV(Zap, { size: 14, color: "#f59e0b", fill: "#f59e0b" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 846,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 844,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { background: "rgba(255,255,255,0.1)", padding: "0.75rem", borderRadius: "10px", marginBottom: "1rem" }, children: [
            /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.5rem", opacity: 0.8 }, children: "Available Balance" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 849,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "1rem", fontWeight: 700 }, children: "$14,925.80" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 850,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 848,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "0.5rem" }, children: [
            /* @__PURE__ */ jsxDEV("div", { style: { background: "rgba(255,255,255,0.05)", padding: "0.5rem", borderRadius: "8px", textAlign: "center", fontSize: "0.45rem" }, children: [
              /* @__PURE__ */ jsxDEV(SendIcon, { size: 12 }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
                lineNumber: 854,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: "Send" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
                lineNumber: 855,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 853,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { background: "rgba(255,255,255,0.05)", padding: "0.5rem", borderRadius: "8px", textAlign: "center", fontSize: "0.45rem" }, children: [
              /* @__PURE__ */ jsxDEV(Percent, { size: 12 }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
                lineNumber: 858,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: "Loans" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
                lineNumber: 859,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 857,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { background: "rgba(255,255,255,0.05)", padding: "0.5rem", borderRadius: "8px", textAlign: "center", fontSize: "0.45rem" }, children: [
              /* @__PURE__ */ jsxDEV(CreditCard, { size: 12 }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
                lineNumber: 862,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: "Cards" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
                lineNumber: 863,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 861,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 852,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 843,
          columnNumber: 19
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 838,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 837,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 836,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
      lineNumber: 809,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
      lineNumber: 808,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
      lineNumber: 807,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("footer", { className: "landing-footer", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "footer-grid", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "footer-brand", children: [
          /* @__PURE__ */ jsxDEV(Link, { to: "/", className: "landing-logo", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "logo-icon-box", children: /* @__PURE__ */ jsxDEV(Zap, { size: 22, fill: "white" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 880,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 879,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: "BankDash" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 882,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 878,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "footer-desc", children: t.footer_desc }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 884,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 877,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "footer-col", children: [
          /* @__PURE__ */ jsxDEV("h5", { children: t.col_product }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 890,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("ul", { className: "footer-links", children: [
            /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV("a", { href: "#features", children: t.features }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 892,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 892,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV("a", { href: "#calculator", children: t.calculator }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 893,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 893,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(Link, { to: "/login", children: [
              t.dashboard,
              " Preview"
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 894,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 894,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 891,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 889,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "footer-col", children: [
          /* @__PURE__ */ jsxDEV("h5", { children: t.col_security }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 899,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("ul", { className: "footer-links", children: [
            /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV("a", { href: "#", children: "Encryption Standards" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 901,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 901,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV("a", { href: "#", children: "Access Management" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 902,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 902,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV("a", { href: "#", children: "Privacy Policy" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 903,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 903,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 900,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 898,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "footer-col", children: [
          /* @__PURE__ */ jsxDEV("h5", { children: t.col_company }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 908,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("ul", { className: "footer-links", children: [
            /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV("a", { href: "#", children: "About Us" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 910,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 910,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV("a", { href: "#", children: "Careers" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 911,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 911,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(Link, { to: "/contact", children: t.support }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 912,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 912,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 909,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 907,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 876,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "footer-bottom", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          "© ",
          (/* @__PURE__ */ new Date()).getFullYear(),
          " BankDash. All rights reserved."
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 918,
          columnNumber: 11
        }, this),
        visitCount > 0 && /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", gap: "0.5rem", background: "rgba(0,0,0,0.03)", padding: "0.4rem 0.8rem", borderRadius: "20px", border: "1px solid var(--ld-border)", fontSize: "0.85rem" }, children: [
          /* @__PURE__ */ jsxDEV("span", { style: { width: "8px", height: "8px", borderRadius: "50%", backgroundColor: "#10b981", boxShadow: "0 0 8px #10b981", display: "inline-block" } }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 922,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ld-text-muted)", fontWeight: 500 }, children: [
            t.visit_count,
            " ",
            /* @__PURE__ */ jsxDEV("strong", { style: { color: "var(--ld-text-main)" }, children: visitCount.toLocaleString() }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 923,
              columnNumber: 96
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 923,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 921,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: "1.5rem" }, children: [
          /* @__PURE__ */ jsxDEV("a", { href: "#", style: { color: "var(--ld-text-muted)", textDecoration: "none" }, children: t.terms }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 928,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("a", { href: "#", style: { color: "var(--ld-text-muted)", textDecoration: "none" }, children: t.privacy }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 929,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 927,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 917,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
      lineNumber: 875,
      columnNumber: 7
    }, this),
    activeModal === "apply" && /* @__PURE__ */ jsxDEV("div", { className: "modal-backdrop", children: /* @__PURE__ */ jsxDEV("div", { className: "modal-container animate-slide", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "modal-header", children: [
        /* @__PURE__ */ jsxDEV("h3", { children: language === "en" ? "Apply for Products" : "उत्पाद के लिए आवेदन करें" }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 941,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "btn-close-modal", onClick: () => setActiveModal(null), children: /* @__PURE__ */ jsxDEV(X, { size: 20 }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 942,
          columnNumber: 88
        }, this) }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 942,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 940,
        columnNumber: 13
      }, this),
      applySuccess ? /* @__PURE__ */ jsxDEV("div", { className: "apply-success-box", children: [
        /* @__PURE__ */ jsxDEV(CheckCircle, { size: 48, color: "#10b981" }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 946,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("h4", { children: language === "en" ? "Application Submitted Successfully!" : "आवेदन सफलतापूर्वक जमा किया गया!" }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 947,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: language === "en" ? `Your interest in ${applyProduct} has been registered. Our representative will call you within 24 hours.` : `आपकी ${applyProduct} में रुचि दर्ज कर ली गई है। हमारे प्रतिनिधि 24 घंटे के भीतर आपसे संपर्क करेंगे।` }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 948,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 945,
        columnNumber: 11
      }, this) : /* @__PURE__ */ jsxDEV("form", { onSubmit: handleApplySubmit, className: "modal-form", children: [
        /* @__PURE__ */ jsxDEV("div", { style: { background: "rgba(79, 70, 229, 0.08)", padding: "0.75rem", borderRadius: "10px", marginBottom: "1.25rem", fontSize: "0.9rem", border: "1px solid var(--ld-border)" }, children: [
          language === "en" ? "Product Selected: " : "चयनित उत्पाद: ",
          " ",
          /* @__PURE__ */ jsxDEV("b", { children: applyProduct }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 953,
            columnNumber: 81
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 952,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "form-group-modal", children: [
          /* @__PURE__ */ jsxDEV("label", { children: [
            t.label_name,
            " *"
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 957,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              required: true,
              placeholder: t.placeholder_name,
              value: applyForm.name,
              onChange: (e) => setApplyForm({ ...applyForm, name: e.target.value })
            },
            void 0,
            false,
            {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 958,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 956,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "form-group-modal", children: [
          /* @__PURE__ */ jsxDEV("label", { children: [
            t.label_email,
            " *"
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 968,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "email",
              required: true,
              placeholder: t.placeholder_email,
              value: applyForm.email,
              onChange: (e) => setApplyForm({ ...applyForm, email: e.target.value })
            },
            void 0,
            false,
            {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 969,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 967,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "form-group-modal", children: [
          /* @__PURE__ */ jsxDEV("label", { children: language === "en" ? "Mobile Phone Number *" : "मोबाइल फोन नंबर *" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 979,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "tel",
              required: true,
              placeholder: "e.g. +91 9999999999",
              value: applyForm.phone,
              onChange: (e) => setApplyForm({ ...applyForm, phone: e.target.value })
            },
            void 0,
            false,
            {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 980,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 978,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "form-group-modal", children: [
          /* @__PURE__ */ jsxDEV("label", { children: language === "en" ? "Approximate Annual Income ($)" : "अनुमानित वार्षिक आय ($)" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 990,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "number",
              placeholder: "e.g. 50000",
              value: applyForm.income,
              onChange: (e) => setApplyForm({ ...applyForm, income: e.target.value })
            },
            void 0,
            false,
            {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 991,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 989,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "btn-primary", style: { width: "100%", padding: "0.85rem", display: "flex", justifyContent: "center" }, children: language === "en" ? "Submit Secure Application" : "सुरक्षित आवेदन जमा करें" }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 999,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 951,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
      lineNumber: 939,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
      lineNumber: 938,
      columnNumber: 7
    }, this),
    activeModal === "forms" && /* @__PURE__ */ jsxDEV("div", { className: "modal-backdrop", children: /* @__PURE__ */ jsxDEV("div", { className: "modal-container animate-slide", style: { maxWidth: "500px" }, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "modal-header", children: [
        /* @__PURE__ */ jsxDEV("h3", { children: t.download_forms }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 1013,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "btn-close-modal", onClick: () => setActiveModal(null), children: /* @__PURE__ */ jsxDEV(X, { size: 20 }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 1014,
          columnNumber: 88
        }, this) }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 1014,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 1012,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "forms-list", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "form-download-item", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { style: { fontWeight: 600, fontSize: "0.95rem" }, children: "Savings Account Opening Form" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 1019,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.75rem", color: "var(--ld-text-muted)" }, children: "PDF | 240 KB" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 1020,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 1018,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: "btn-secondary", style: { padding: "0.4rem 0.8rem", fontSize: "0.8rem" }, onClick: () => alert("Downloading Savings Account Opening Form..."), children: /* @__PURE__ */ jsxDEV(Download, { size: 14 }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 1022,
            columnNumber: 177
          }, this) }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 1022,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 1017,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "form-download-item", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { style: { fontWeight: 600, fontSize: "0.95rem" }, children: "Retail Loan Application Form" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 1026,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.75rem", color: "var(--ld-text-muted)" }, children: "PDF | 580 KB" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 1027,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 1025,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: "btn-secondary", style: { padding: "0.4rem 0.8rem", fontSize: "0.8rem" }, onClick: () => alert("Downloading Retail Loan Application Form..."), children: /* @__PURE__ */ jsxDEV(Download, { size: 14 }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 1029,
            columnNumber: 177
          }, this) }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 1029,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 1024,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "form-download-item", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { style: { fontWeight: 600, fontSize: "0.95rem" }, children: "KYC Updation Form" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 1033,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.75rem", color: "var(--ld-text-muted)" }, children: "PDF | 120 KB" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
              lineNumber: 1034,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 1032,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: "btn-secondary", style: { padding: "0.4rem 0.8rem", fontSize: "0.8rem" }, onClick: () => alert("Downloading KYC Updation Form..."), children: /* @__PURE__ */ jsxDEV(Download, { size: 14 }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 1036,
            columnNumber: 166
          }, this) }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 1036,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 1031,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 1016,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
      lineNumber: 1011,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
      lineNumber: 1010,
      columnNumber: 7
    }, this),
    activeModal === "locator" && /* @__PURE__ */ jsxDEV("div", { className: "modal-backdrop", children: /* @__PURE__ */ jsxDEV("div", { className: "modal-container animate-slide", style: { maxWidth: "600px" }, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "modal-header", children: [
        /* @__PURE__ */ jsxDEV("h3", { children: t.branch_locator_title }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 1048,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "btn-close-modal", onClick: () => setActiveModal(null), children: /* @__PURE__ */ jsxDEV(X, { size: 20 }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 1049,
          columnNumber: 88
        }, this) }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 1049,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 1047,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { style: { fontSize: "0.9rem", color: "var(--ld-text-muted)", marginBottom: "1rem" }, children: t.branch_locator_desc }, void 0, false, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 1051,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "locator-search-box", children: [
        /* @__PURE__ */ jsxDEV("input", { type: "text", placeholder: "Enter city or zip code...", style: { width: "100%", padding: "0.6rem 1rem", borderRadius: "10px", border: "1px solid var(--ld-border)", background: "var(--ld-bg)", outline: "none" } }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 1053,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "btn-primary", style: { padding: "0.6rem 1.25rem" }, onClick: () => alert("Searching nearby branches..."), children: language === "en" ? "Search" : "खोजें" }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 1054,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 1052,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "branches-list", style: { marginTop: "1rem", display: "flex", flexDirection: "column", gap: "0.75rem", maxHeight: "250px", overflowY: "auto" }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: { border: "1px solid var(--ld-border)", padding: "0.75rem", borderRadius: "12px" }, children: [
          /* @__PURE__ */ jsxDEV("div", { style: { fontWeight: 700, fontSize: "0.95rem" }, children: "Connaught Place Branch" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 1058,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.85rem", color: "var(--ld-text-muted)", marginTop: "0.25rem" }, children: "E-Block, Inner Circle, New Delhi, 110001" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 1059,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.78rem", color: "var(--ld-primary)", fontWeight: 600, marginTop: "0.4rem" }, children: [
            t.branch_hours,
            ": 10:00 AM - 4:00 PM"
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 1060,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 1057,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { border: "1px solid var(--ld-border)", padding: "0.75rem", borderRadius: "12px" }, children: [
          /* @__PURE__ */ jsxDEV("div", { style: { fontWeight: 700, fontSize: "0.95rem" }, children: "Mumbai Main Branch" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 1063,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.85rem", color: "var(--ld-text-muted)", marginTop: "0.25rem" }, children: "Heritage building, Fort, Mumbai, 400001" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 1064,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.78rem", color: "var(--ld-primary)", fontWeight: 600, marginTop: "0.4rem" }, children: [
            t.branch_hours,
            ": 10:00 AM - 4:00 PM"
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
            lineNumber: 1065,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
          lineNumber: 1062,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
        lineNumber: 1056,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
      lineNumber: 1046,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
      lineNumber: 1045,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
    lineNumber: 273,
    columnNumber: 5
  }, this);
};
_s(Landing, "Hf6Y0gNW750qSQExwrFAzyLReKs=", false, function() {
  return [useAuth];
});
_c = Landing;
const SendIcon = ({ size }) => /* @__PURE__ */ jsxDEV("svg", { xmlns: "http://www.w3.org/2000/svg", width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [
  /* @__PURE__ */ jsxDEV("line", { x1: "22", y1: "2", x2: "11", y2: "13" }, void 0, false, {
    fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
    lineNumber: 1078,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("polygon", { points: "22 2 15 22 11 13 2 9 22 2" }, void 0, false, {
    fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
    lineNumber: 1079,
    columnNumber: 5
  }, this)
] }, void 0, true, {
  fileName: "D:/React_test_19_05_2026/src/components/Landing.jsx",
  lineNumber: 1077,
  columnNumber: 1
}, this);
_c2 = SendIcon;
export default Landing;
var _c, _c2;
$RefreshReg$(_c, "Landing");
$RefreshReg$(_c2, "SendIcon");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/React_test_19_05_2026/src/components/Landing.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/React_test_19_05_2026/src/components/Landing.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK1BNLFNBd0dRLFVBeEdSOzs7Ozs7Ozs7Ozs7Ozs7OztBQS9QTixTQUFTQSxVQUFVQyxXQUFXQyxjQUFjO0FBQzVDLFNBQVNDLFlBQVk7QUFDckI7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxvQkFBb0I7QUFDN0IsT0FBT0MsWUFBWTtBQUNuQixPQUFPO0FBRVAsTUFBTUMsVUFBVUEsTUFBTTtBQUFBQyxLQUFBO0FBQ3BCLFFBQU0sRUFBRUMsWUFBWUMsTUFBTUMsWUFBWUMsVUFBVUMsWUFBWSxJQUFJVCxRQUFRO0FBQ3hFLFFBQU1VLElBQUlULGFBQWFPLFFBQVEsS0FBS1AsYUFBYVU7QUFHakQsUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUk3QyxTQUFTLEVBQUU7QUFDN0NDLFlBQVUsTUFBTTtBQUNkaUMsV0FBT1ksVUFBVSxvQ0FBb0MsRUFBRUMsUUFBUSxHQUFHQyxPQUFPLElBQUksQ0FBQyxFQUMzRUMsS0FBSyxDQUFBQyxRQUFPTCxhQUFhSyxHQUFHLENBQUMsRUFDN0JDLE1BQU0sQ0FBQUMsUUFBT0MsUUFBUUMsTUFBTUYsR0FBRyxDQUFDO0FBQUEsRUFDcEMsR0FBRyxFQUFFO0FBR0wsUUFBTSxDQUFDRyxhQUFhQyxjQUFjLElBQUl4RCxTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDeUQsaUJBQWlCQyxrQkFBa0IsSUFBSTFELFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUMyRCxjQUFjQyxlQUFlLElBQUk1RCxTQUFTLElBQUk7QUFDckQsUUFBTTZELGlCQUFpQjNELE9BQU8sSUFBSTtBQUdsQyxRQUFNLENBQUM0RCxhQUFhQyxjQUFjLElBQUkvRCxTQUFTLElBQUk7QUFDbkQsUUFBTSxDQUFDZ0UsY0FBY0MsZUFBZSxJQUFJakUsU0FBUyxFQUFFO0FBQ25ELFFBQU0sQ0FBQ2tFLGNBQWNDLGVBQWUsSUFBSW5FLFNBQVMsS0FBSztBQUN0RCxRQUFNLENBQUNvRSxXQUFXQyxZQUFZLElBQUlyRSxTQUFTLEVBQUVzRSxNQUFNLElBQUlDLE9BQU8sSUFBSUMsT0FBTyxJQUFJQyxRQUFRLEdBQUcsQ0FBQztBQUd6RixRQUFNLENBQUNDLGNBQWNDLGVBQWUsSUFBSTNFLFNBQVMsQ0FBQztBQUNsRCxRQUFNNEUsU0FBUztBQUFBLElBQ2I7QUFBQSxNQUNFQyxPQUFPckMsYUFBYSxPQUFPLG9DQUFvQztBQUFBLE1BQy9Ec0MsTUFBTXRDLGFBQWEsT0FBTyw0RkFBNEY7QUFBQSxNQUN0SHVDLE9BQU92QyxhQUFhLE9BQU8sa0JBQWtCO0FBQUEsTUFDN0N3QyxTQUFTeEMsYUFBYSxPQUFPLG9CQUFvQjtBQUFBLE1BQ2pEeUMsWUFBWTtBQUFBLE1BQ1pDLFFBQVE7QUFBQSxJQUNWO0FBQUEsSUFDQTtBQUFBLE1BQ0VMLE9BQU9yQyxhQUFhLE9BQU8seUNBQXlDO0FBQUEsTUFDcEVzQyxNQUFNdEMsYUFBYSxPQUFPLGlGQUFpRjtBQUFBLE1BQzNHdUMsT0FBT3ZDLGFBQWEsT0FBTyxzQkFBc0I7QUFBQSxNQUNqRHdDLFNBQVN4QyxhQUFhLE9BQU8sc0JBQXNCO0FBQUEsTUFDbkR5QyxZQUFZO0FBQUEsTUFDWkMsUUFBUTtBQUFBLElBQ1Y7QUFBQSxJQUNBO0FBQUEsTUFDRUwsT0FBT3JDLGFBQWEsT0FBTyxxQ0FBcUM7QUFBQSxNQUNoRXNDLE1BQU10QyxhQUFhLE9BQU8sNkZBQTZGO0FBQUEsTUFDdkh1QyxPQUFPdkMsYUFBYSxPQUFPLGdCQUFnQjtBQUFBLE1BQzNDd0MsU0FBU3hDLGFBQWEsT0FBTyxpQkFBaUI7QUFBQSxNQUM5Q3lDLFlBQVk7QUFBQSxNQUNaQyxRQUFRO0FBQUEsSUFDVjtBQUFBLEVBQUM7QUFHSGpGLFlBQVUsTUFBTTtBQUNkLFVBQU1rRixRQUFRQyxZQUFZLE1BQU07QUFDOUJULHNCQUFnQixDQUFBVSxVQUFTQSxPQUFPLEtBQUtULE9BQU9VLE1BQU07QUFBQSxJQUNwRCxHQUFHLEdBQUk7QUFDUCxXQUFPLE1BQU1DLGNBQWNKLEtBQUs7QUFBQSxFQUNsQyxHQUFHLENBQUNQLE9BQU9VLE1BQU0sQ0FBQztBQUdsQixRQUFNLENBQUNFLFdBQVdDLFlBQVksSUFBSXpGLFNBQVMsVUFBVTtBQUNyRCxRQUFNMEYsV0FBVztBQUFBLElBQ2ZDLFVBQVU7QUFBQSxNQUNSLEVBQUVyQixNQUFNLDZCQUE2QlEsTUFBTSxpRkFBaUZjLFNBQVMsOENBQThDO0FBQUEsTUFDbkwsRUFBRXRCLE1BQU0sNkJBQTZCUSxNQUFNLHNGQUFzRmMsU0FBUywyREFBMkQ7QUFBQSxJQUFDO0FBQUEsSUFFeE1DLE9BQU87QUFBQSxNQUNMLEVBQUV2QixNQUFNLGFBQWFRLE1BQU0seUVBQXlFYyxTQUFTLG1EQUFtRDtBQUFBLE1BQ2hLLEVBQUV0QixNQUFNLFlBQVlRLE1BQU0sOEVBQThFYyxTQUFTLDhCQUE4QjtBQUFBLE1BQy9JLEVBQUV0QixNQUFNLGFBQWFRLE1BQU0saUZBQWlGYyxTQUFTLHNDQUFzQztBQUFBLElBQUM7QUFBQSxJQUU5SkUsT0FBTztBQUFBLE1BQ0wsRUFBRXhCLE1BQU0sOEJBQThCUSxNQUFNLDRFQUE0RWMsU0FBUyxnREFBZ0Q7QUFBQSxNQUNqTCxFQUFFdEIsTUFBTSxxQkFBcUJRLE1BQU0sc0VBQXNFYyxTQUFTLHFDQUFxQztBQUFBLElBQUM7QUFBQSxJQUUxSkcsVUFBVTtBQUFBLE1BQ1IsRUFBRXpCLE1BQU0scUJBQXFCUSxNQUFNLG9GQUFvRmMsU0FBUyxxREFBcUQ7QUFBQSxNQUNyTCxFQUFFdEIsTUFBTSwyQkFBMkJRLE1BQU0sbUZBQW1GYyxTQUFTLHNDQUFzQztBQUFBLElBQUM7QUFBQSxFQUVoTDtBQUdBLFFBQU0sQ0FBQ0ksWUFBWUMsYUFBYSxJQUFJakcsU0FBUyxPQUFPO0FBQ3BELFFBQU0sQ0FBQ2tHLFVBQVVDLFdBQVcsSUFBSW5HLFNBQVMsS0FBSztBQUM5QyxRQUFNLENBQUNvRyxVQUFVQyxXQUFXLElBQUlyRyxTQUFTLElBQUk7QUFFN0MsUUFBTXNHLHVCQUF1QkEsTUFBTTtBQUNqQyxVQUFNQyxJQUFJQyxXQUFXUixVQUFVO0FBQy9CLFVBQU1TLElBQUlELFdBQVdOLFFBQVEsSUFBSTtBQUNqQyxVQUFNUSxJQUFJRixXQUFXSixRQUFRO0FBRTdCLFFBQUlPLE1BQU1KLENBQUMsS0FBS0ksTUFBTUYsQ0FBQyxLQUFLRSxNQUFNRCxDQUFDLEtBQUtILEtBQUssS0FBS0UsS0FBSyxLQUFLQyxLQUFLLEdBQUc7QUFDbEUsYUFBTztBQUFBLElBQ1Q7QUFFQSxVQUFNRSxjQUFlTCxJQUFJRSxJQUFJSSxLQUFLQyxJQUFJLElBQUlMLEdBQUdDLENBQUMsS0FBTUcsS0FBS0MsSUFBSSxJQUFJTCxHQUFHQyxDQUFDLElBQUk7QUFDekUsV0FBT0UsWUFBWUcsUUFBUSxDQUFDO0FBQUEsRUFDOUI7QUFFQSxRQUFNQyxzQkFBc0JBLENBQUNDLE1BQU1DLGVBQWVDLFVBQVU7QUFDMURoQixnQkFBWWMsS0FBS0csU0FBUyxDQUFDO0FBQzNCbkIsa0JBQWNpQixjQUFjRSxTQUFTLENBQUM7QUFDdEMsVUFBTUMsVUFBVUMsU0FBU0MsZUFBZSxZQUFZO0FBQ3BELFFBQUlGLFNBQVM7QUFDWEEsY0FBUUcsZUFBZSxFQUFFQyxVQUFVLFNBQVMsQ0FBQztBQUFBLElBQy9DO0FBQUEsRUFDRjtBQUdBLFFBQU1DLGtCQUFrQkEsQ0FBQ0MsU0FBUztBQUNoQ25FLG1CQUFlbUUsSUFBSTtBQUNuQkMsa0JBQWNELElBQUk7QUFBQSxFQUNwQjtBQUdBLFFBQU1DLGdCQUFnQkEsQ0FBQ0MsVUFBVTtBQUMvQixRQUFJLENBQUNBO0FBQU87QUFFWixVQUFNQyxJQUFJRCxNQUFNRSxZQUFZO0FBQzVCLFFBQUlDLFNBQVM7QUFFYixRQUFJRixFQUFFRyxTQUFTLE1BQU0sS0FBS0gsRUFBRUcsU0FBUyxNQUFNLEtBQUtILEVBQUVHLFNBQVMsTUFBTSxLQUFLSCxFQUFFRyxTQUFTLEtBQUssR0FBRztBQUN2RkQsZUFBUztBQUFBLFFBQ1BuRCxPQUFPckMsYUFBYSxPQUFPLGdDQUFnQztBQUFBLFFBQzNEc0MsTUFBTXRDLGFBQWEsT0FBTyx3SUFBd0k7QUFBQSxRQUNsSzBGLFFBQVFBLE1BQU07QUFDWnpDLHVCQUFhLE9BQU87QUFDcEI2QixtQkFBU0MsZUFBZSxrQkFBa0IsR0FBR0MsZUFBZSxFQUFFQyxVQUFVLFNBQVMsQ0FBQztBQUFBLFFBQ3BGO0FBQUEsUUFDQXpDLFNBQVN4QyxhQUFhLE9BQU8sdUJBQXVCO0FBQUEsTUFDdEQ7QUFBQSxJQUNGLFdBQVdzRixFQUFFRyxTQUFTLFNBQVMsS0FBS0gsRUFBRUcsU0FBUyxRQUFRLEtBQUtILEVBQUVHLFNBQVMsU0FBUyxHQUFHO0FBQ2pGRCxlQUFTO0FBQUEsUUFDUG5ELE9BQU9yQyxhQUFhLE9BQU8sK0JBQStCO0FBQUEsUUFDMURzQyxNQUFNdEMsYUFBYSxPQUFPLHdIQUF3SDtBQUFBLFFBQ2xKMEYsUUFBUUEsTUFBTTtBQUNaekMsdUJBQWEsVUFBVTtBQUN2QjZCLG1CQUFTQyxlQUFlLGtCQUFrQixHQUFHQyxlQUFlLEVBQUVDLFVBQVUsU0FBUyxDQUFDO0FBQUEsUUFDcEY7QUFBQSxRQUNBekMsU0FBU3hDLGFBQWEsT0FBTyxrQkFBa0I7QUFBQSxNQUNqRDtBQUFBLElBQ0YsV0FBV3NGLEVBQUVHLFNBQVMsT0FBTyxLQUFLSCxFQUFFRyxTQUFTLFVBQVUsS0FBS0gsRUFBRUcsU0FBUyxVQUFVLEdBQUc7QUFDbEZELGVBQVM7QUFBQSxRQUNQbkQsT0FBT3JDLGFBQWEsT0FBTyw4QkFBOEI7QUFBQSxRQUN6RHNDLE1BQU10QyxhQUFhLE9BQU8scUhBQXFIO0FBQUEsUUFDL0kwRixRQUFRQSxNQUFNO0FBQ1paLG1CQUFTQyxlQUFlLGdCQUFnQixHQUFHQyxlQUFlLEVBQUVDLFVBQVUsU0FBUyxDQUFDO0FBQUEsUUFDbEY7QUFBQSxRQUNBekMsU0FBU3hDLGFBQWEsT0FBTyx3QkFBd0I7QUFBQSxNQUN2RDtBQUFBLElBQ0YsV0FBV3NGLEVBQUVHLFNBQVMsTUFBTSxLQUFLSCxFQUFFRyxTQUFTLFVBQVUsR0FBRztBQUN2REQsZUFBUztBQUFBLFFBQ1BuRCxPQUFPckMsYUFBYSxPQUFPLCtCQUErQjtBQUFBLFFBQzFEc0MsTUFBTXRDLGFBQWEsT0FBTyx1SEFBdUg7QUFBQSxRQUNqSjBGLFFBQVFBLE1BQU07QUFDWlosbUJBQVNDLGVBQWUsZUFBZSxHQUFHQyxlQUFlLEVBQUVDLFVBQVUsU0FBUyxDQUFDO0FBQUEsUUFDakY7QUFBQSxRQUNBekMsU0FBU3hDLGFBQWEsT0FBTyx3QkFBd0I7QUFBQSxNQUN2RDtBQUFBLElBQ0YsT0FBTztBQUNMd0YsZUFBUztBQUFBLFFBQ1BuRCxPQUFPckMsYUFBYSxPQUFPLG1CQUFtQjtBQUFBLFFBQzlDc0MsTUFBTXRDLGFBQWEsT0FBTyxnQkFBZ0JxRixLQUFLLHdFQUF3RSxJQUFJQSxLQUFLO0FBQUEsUUFDaElLLFFBQVFBLE1BQU07QUFDWm5FLHlCQUFlLE9BQU87QUFDdEJFLDBCQUFnQix5QkFBeUI7QUFBQSxRQUMzQztBQUFBLFFBQ0FlLFNBQVN4QyxhQUFhLE9BQU8sc0JBQXNCO0FBQUEsTUFDckQ7QUFBQSxJQUNGO0FBRUFvQixvQkFBZ0JvRSxNQUFNO0FBQ3RCdEUsdUJBQW1CLEtBQUs7QUFBQSxFQUMxQjtBQUdBLFFBQU15RSxvQkFBb0JBLENBQUNDLE1BQU07QUFDL0JBLE1BQUVDLGVBQWU7QUFDakIsUUFBSSxDQUFDakUsVUFBVUUsUUFBUSxDQUFDRixVQUFVRyxTQUFTLENBQUNILFVBQVVJLE9BQU87QUFDM0Q4RCxZQUFNOUYsYUFBYSxPQUFPLHdDQUF3QywrQkFBK0I7QUFDakc7QUFBQSxJQUNGO0FBRUErRixVQUFNLDBDQUEwQztBQUFBLE1BQzlDQyxRQUFRO0FBQUEsTUFDUkMsU0FBUztBQUFBLFFBQ1AsZ0JBQWdCO0FBQUEsTUFDbEI7QUFBQSxNQUNBQyxNQUFNQyxLQUFLQyxVQUFVO0FBQUEsUUFDbkJ0RSxNQUFNRixVQUFVRTtBQUFBQSxRQUNoQkMsT0FBT0gsVUFBVUc7QUFBQUEsUUFDakJDLE9BQU9KLFVBQVVJO0FBQUFBLFFBQ2pCQyxRQUFRTCxVQUFVSztBQUFBQSxRQUNsQm9FLFNBQVM3RTtBQUFBQSxNQUNYLENBQUM7QUFBQSxJQUNILENBQUMsRUFDRWYsS0FBSyxDQUFBNkYsUUFBTztBQUNYLFVBQUksQ0FBQ0EsSUFBSUM7QUFBSSxjQUFNLElBQUlDLE1BQU0sOEJBQThCO0FBQzNELGFBQU9GLElBQUlHLEtBQUs7QUFBQSxJQUNsQixDQUFDLEVBQ0FoRyxLQUFLLE1BQU07QUFDVmtCLHNCQUFnQixJQUFJO0FBQ3BCK0UsaUJBQVcsTUFBTTtBQUNmbkYsdUJBQWUsSUFBSTtBQUNuQkksd0JBQWdCLEtBQUs7QUFDckJFLHFCQUFhLEVBQUVDLE1BQU0sSUFBSUMsT0FBTyxJQUFJQyxPQUFPLElBQUlDLFFBQVEsR0FBRyxDQUFDO0FBQUEsTUFDN0QsR0FBRyxHQUFJO0FBQUEsSUFDVCxDQUFDLEVBQ0F0QixNQUFNLENBQUFDLFFBQU87QUFDWkMsY0FBUUMsTUFBTSxpQ0FBaUNGLEdBQUc7QUFDbERrRixZQUFNOUYsYUFBYSxPQUFPLG9EQUFvRCxrREFBa0Q7QUFBQSxJQUNsSSxDQUFDO0FBQUEsRUFDTDtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLDZCQUViO0FBQUEsMkJBQUMsU0FBSSxXQUFVLG1DQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0M7QUFBQSxJQUMvQyx1QkFBQyxTQUFJLFdBQVUsaUNBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2QztBQUFBLElBQzdDLHVCQUFDLFNBQUksV0FBVSxrQ0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThDO0FBQUEsSUFHOUMsdUJBQUMsU0FBSSxXQUFVLG1CQUNiLGlDQUFDLFNBQUksV0FBVSx5QkFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBLCtCQUFDLFVBQUssV0FBVSxnQkFBZTtBQUFBLGlDQUFDLFNBQU0sTUFBTSxNQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdCO0FBQUEsVUFBRztBQUFBLFVBQUVFLEVBQUV5RztBQUFBQSxhQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdFO0FBQUEsUUFDaEUsdUJBQUMsVUFBSyxXQUFVLCtCQUE4QixTQUFTLE1BQU1wRixlQUFlLFNBQVMsR0FBRztBQUFBLGlDQUFDLFVBQU8sTUFBTSxNQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlCO0FBQUEsVUFBRztBQUFBLFVBQUV2QixhQUFhLE9BQU8sbUJBQW1CO0FBQUEsYUFBcko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpSztBQUFBLFFBQ2pLLHVCQUFDLFVBQUssV0FBVSwrQkFBOEIsU0FBUyxNQUFNdUIsZUFBZSxPQUFPLEdBQUc7QUFBQSxpQ0FBQyxZQUFTLE1BQU0sTUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUI7QUFBQSxVQUFHO0FBQUEsVUFBRXJCLEVBQUUwRztBQUFBQSxhQUFoSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStIO0FBQUEsV0FIakk7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSwrQkFBQyxPQUFFLE1BQUssa0JBQWlCLFdBQVUsZ0JBQWU7QUFBQSxpQ0FBQyxjQUFXLE1BQU0sTUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUI7QUFBQSxVQUFHO0FBQUEsVUFBRTFHLEVBQUUyRztBQUFBQSxhQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBGO0FBQUEsUUFDMUYsdUJBQUMsUUFBSyxJQUFHLFlBQVcsV0FBVSxnQkFBZTtBQUFBLGlDQUFDLGNBQVcsTUFBTSxNQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxQjtBQUFBLFVBQUc7QUFBQSxVQUFFM0csRUFBRTRHO0FBQUFBLGFBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUY7QUFBQSxRQUNuRix1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU85RztBQUFBQSxZQUNQLFVBQVUsQ0FBQzRGLE1BQU0zRixZQUFZMkYsRUFBRWxELE9BQU9xRSxLQUFLO0FBQUEsWUFDM0MsV0FBVTtBQUFBLFlBRVY7QUFBQSxxQ0FBQyxZQUFPLE9BQU0sTUFBSyw0QkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0I7QUFBQSxjQUMvQix1QkFBQyxZQUFPLE9BQU0sTUFBSywwQkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkI7QUFBQTtBQUFBO0FBQUEsVUFOL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBT0EsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxXQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFhQTtBQUFBLFNBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvQkEsS0FyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNCQTtBQUFBLElBR0EsdUJBQUMsWUFBTyxXQUFVLGtCQUNoQixpQ0FBQyxTQUFJLFdBQVUseUJBQ2I7QUFBQSw2QkFBQyxRQUFLLElBQUcsS0FBSSxXQUFVLGdCQUNyQjtBQUFBLCtCQUFDLFNBQUksV0FBVSxpQkFDYixpQ0FBQyxPQUFJLE1BQU0sSUFBSSxNQUFLLFdBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkIsS0FEN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxVQUFLLHdCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBYztBQUFBLFdBSmhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsa0JBQWtCN0csWUFBRThHLGdCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpRDtBQUFBLFVBQ2pELHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLG1DQUFDLE9BQUUsTUFBSyxxQkFBb0IsU0FBUyxNQUFNL0QsYUFBYSxVQUFVLEdBQUcsZ0NBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFGO0FBQUEsWUFDckYsdUJBQUMsT0FBRSxNQUFLLHFCQUFvQixTQUFTLE1BQU1BLGFBQWEsT0FBTyxHQUFHLDBCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0RTtBQUFBLFlBQzVFLHVCQUFDLE9BQUUsTUFBSyxxQkFBb0IsU0FBUyxNQUFNQSxhQUFhLE9BQU8sR0FBRyw0QkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEU7QUFBQSxlQUhoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsYUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxrQkFBa0IvQyxZQUFFK0csZ0JBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlEO0FBQUEsVUFDakQsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsbUNBQUMsT0FBRSxNQUFLLHFCQUFvQixTQUFTLE1BQU1oRSxhQUFhLFVBQVUsR0FBRyxnQ0FBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUY7QUFBQSxZQUNyRix1QkFBQyxPQUFFLE1BQUsscUJBQW9CLFNBQVMsTUFBTUEsYUFBYSxVQUFVLEdBQUcsbUNBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdGO0FBQUEsWUFDeEYsdUJBQUMsT0FBRSxNQUFLLHFCQUFvQixTQUFTLE1BQU1BLGFBQWEsT0FBTyxHQUFHLG1DQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRjtBQUFBLGVBSHZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLGtCQUFrQi9DLFlBQUVnSCxZQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2QztBQUFBLFVBQzdDLHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLG1DQUFDLE9BQUUsTUFBSyxxQkFBb0IsU0FBUyxNQUFNakUsYUFBYSxPQUFPLEdBQUcsK0JBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlGO0FBQUEsWUFDakYsdUJBQUMsT0FBRSxNQUFLLHFCQUFvQixTQUFTLE1BQU1BLGFBQWEsT0FBTyxHQUFHLCtCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRjtBQUFBLGVBRm5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFFBQ0EsdUJBQUMsUUFBSyxJQUFHLFlBQVcsV0FBVSxtQkFBbUIvQyxZQUFFaUgsYUFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2RDtBQUFBLFdBeEIvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeUJBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsS0FBSzlGO0FBQUFBLGNBQ0wsTUFBSztBQUFBLGNBQ0wsYUFBYW5CLEVBQUVrSDtBQUFBQSxjQUNmLE9BQU9yRztBQUFBQSxjQUNQLFVBQVUsQ0FBQzZFLE1BQU07QUFDZjVFLCtCQUFlNEUsRUFBRWxELE9BQU9xRSxLQUFLO0FBQzdCN0YsbUNBQW1CMEUsRUFBRWxELE9BQU9xRSxNQUFNakUsU0FBUyxDQUFDO0FBQUEsY0FDOUM7QUFBQSxjQUNBLFNBQVMsTUFBTTtBQUNiLG9CQUFJL0IsWUFBWStCLFNBQVM7QUFBRzVCLHFDQUFtQixJQUFJO0FBQUEsY0FDckQ7QUFBQSxjQUNBLFdBQVcsQ0FBQzBFLE1BQU07QUFDaEIsb0JBQUlBLEVBQUV5QixRQUFRO0FBQVNqQyxnQ0FBY3JFLFdBQVc7QUFBQSxjQUNsRDtBQUFBLGNBQ0EsV0FBVTtBQUFBO0FBQUEsWUFmWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFlaUM7QUFBQSxVQUVqQyx1QkFBQyxVQUFPLE1BQU0sSUFBSSxXQUFVLGVBQWMsU0FBUyxNQUFNcUUsY0FBY3JFLFdBQVcsS0FBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Y7QUFBQSxhQWxCdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1CQTtBQUFBLFFBRUNFLG1CQUNDLHVCQUFDLFNBQUksV0FBVSw4QkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxtQkFBa0IsU0FBUyxNQUFNaUUsZ0JBQWdCLFdBQVcsR0FBRywrQkFBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkY7QUFBQSxVQUM3Rix1QkFBQyxTQUFJLFdBQVUsbUJBQWtCLFNBQVMsTUFBTUEsZ0JBQWdCLGlCQUFpQixHQUFHLHVDQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRztBQUFBLFVBQzNHLHVCQUFDLFNBQUksV0FBVSxtQkFBa0IsU0FBUyxNQUFNQSxnQkFBZ0IsZ0JBQWdCLEdBQUcsdUNBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBHO0FBQUEsVUFDMUcsdUJBQUMsU0FBSSxXQUFVLG1CQUFrQixTQUFTLE1BQU1BLGdCQUFnQixXQUFXLEdBQUcsb0NBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtHO0FBQUEsYUFKcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsV0E1Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQThCQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLHVCQUNackYsdUJBQ0MsdUJBQUMsUUFBSyxJQUFHLGNBQWEsV0FBVSxrQkFBa0JLLFlBQUVvSCxhQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThELElBRTlELG1DQUNFO0FBQUEsK0JBQUMsUUFBSyxJQUFHLFVBQVMsV0FBVSxpQkFBaUJwSCxZQUFFcUgsU0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRDtBQUFBLFFBQ3JELHVCQUFDLFFBQUssSUFBRyxhQUFZLFdBQVUsa0JBQWtCckgsWUFBRXNILFVBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEQ7QUFBQSxXQUY1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0EsS0FQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxTQTlFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBK0VBLEtBaEZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpRkE7QUFBQSxJQUdDckcsZ0JBQ0MsdUJBQUMsU0FBSSxXQUFVLGtDQUNiLGlDQUFDLFNBQUksV0FBVSxzQ0FDYjtBQUFBLDZCQUFDLFNBQUksT0FBTyxFQUFFc0csU0FBUyxRQUFRQyxnQkFBZ0IsaUJBQWlCQyxZQUFZLGFBQWEsR0FDdkY7QUFBQSwrQkFBQyxTQUNDO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHVCQUFzQjtBQUFBLG1DQUFDLFlBQVMsTUFBTSxNQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtQjtBQUFBLFlBQUc7QUFBQSxZQUFFM0gsYUFBYSxPQUFPLGdCQUFnQjtBQUFBLGVBQWxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZHO0FBQUEsVUFDN0csdUJBQUMsUUFBRyxXQUFVLHVCQUF1Qm1CLHVCQUFha0IsU0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0Q7QUFBQSxVQUN4RCx1QkFBQyxPQUFFLFdBQVUsc0JBQXNCbEIsdUJBQWFtQixRQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRDtBQUFBLGFBSHZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFFBQ0EsdUJBQUMsWUFBTyxXQUFVLG9CQUFtQixTQUFTLE1BQU1sQixnQkFBZ0IsSUFBSSxHQUFHLGlDQUFDLEtBQUUsTUFBTSxNQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBWSxLQUF2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBGO0FBQUEsV0FONUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsTUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRXdHLFdBQVcsUUFBUUgsU0FBUyxRQUFRSSxLQUFLLE9BQU8sR0FDNUQ7QUFBQSwrQkFBQyxZQUFPLFdBQVUsZUFBYyxPQUFPLEVBQUVDLFNBQVMsa0JBQWtCQyxVQUFVLFNBQVMsR0FBRyxTQUFTLE1BQU07QUFBRTVHLHVCQUFhdUUsT0FBTztBQUFHdEUsMEJBQWdCLElBQUk7QUFBQSxRQUFHLEdBQ3RKRCx1QkFBYXFCLFdBRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsWUFBTyxXQUFVLGlCQUFnQixPQUFPLEVBQUVzRixTQUFTLGtCQUFrQkMsVUFBVSxTQUFTLEdBQUcsU0FBUyxNQUFNM0csZ0JBQWdCLElBQUksR0FDNUhwQix1QkFBYSxPQUFPLGlCQUFpQixtQkFEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxTQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUJBLEtBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtQkE7QUFBQSxJQUlGLHVCQUFDLFNBQUksV0FBVSx5QkFDYixpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSw2QkFBQyxVQUFLLFdBQVUsb0JBQW1CO0FBQUEsK0JBQUMsUUFBSyxNQUFNLE1BQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFlO0FBQUEsUUFBRztBQUFBLFFBQUVFLEVBQUU4SDtBQUFBQSxRQUFrQjtBQUFBLFdBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEU7QUFBQSxNQUM1RSx1QkFBQyxTQUFJLFdBQVUsb0JBQ2I7QUFBQSwrQkFBQyxZQUFPLFdBQVUsWUFBVyxTQUFTLE1BQU05QyxnQkFBZ0IseUJBQXlCLEdBQUlsRix1QkFBYSxPQUFPLG9CQUFvQixnQkFBakk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4STtBQUFBLFFBQzlJLHVCQUFDLFlBQU8sV0FBVSxZQUFXLFNBQVMsTUFBTWtGLGdCQUFnQixXQUFXLEdBQUlsRix1QkFBYSxPQUFPLHNCQUFzQix1QkFBckg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5STtBQUFBLFFBQ3pJLHVCQUFDLFlBQU8sV0FBVSxZQUFXLFNBQVMsTUFBTWtGLGdCQUFnQixXQUFXLEdBQUlsRix1QkFBYSxPQUFPLG9CQUFvQixtQkFBbkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtSTtBQUFBLFFBQ25JLHVCQUFDLFlBQU8sV0FBVSxZQUFXLFNBQVMsTUFBTWtGLGdCQUFnQixRQUFRLEdBQUlsRix1QkFBYSxPQUFPLG1CQUFtQixlQUEvRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJIO0FBQUEsUUFDM0gsdUJBQUMsWUFBTyxXQUFVLFlBQVcsU0FBUyxNQUFNa0YsZ0JBQWdCLGdCQUFnQixHQUFJbEYsdUJBQWEsT0FBTyxtQkFBbUIsZ0JBQXZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0k7QUFBQSxXQUx0STtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUE7QUFBQSxTQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQSxLQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FXQTtBQUFBLElBR0EsdUJBQUMsYUFBUSxXQUFVLGtDQUNqQixpQ0FBQyxTQUFJLFdBQVUsdUJBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsb0JBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsaUJBQWdCO0FBQUEsaUNBQUMsWUFBUyxNQUFNLElBQUksT0FBTSxxQkFBb0IsT0FBTyxFQUFFaUksYUFBYSxTQUFTLEtBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStFO0FBQUEsVUFBSS9ILEVBQUVnSTtBQUFBQSxhQUFuSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1JO0FBQUEsUUFDbkksdUJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEsaUNBQUMsWUFBTyxXQUFVLG9CQUFtQixTQUFTLE1BQU0vRixnQkFBZ0IsQ0FBQVUsVUFBU0EsT0FBTyxJQUFJVCxPQUFPVSxVQUFVVixPQUFPVSxNQUFNLEdBQUcsaUNBQUMsZUFBWSxNQUFNLE1BQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNCLEtBQS9JO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtKO0FBQUEsVUFDbEosdUJBQUMsWUFBTyxXQUFVLG9CQUFtQixTQUFTLE1BQU1YLGdCQUFnQixDQUFBVSxVQUFTQSxPQUFPLEtBQUtULE9BQU9VLE1BQU0sR0FBRyxpQ0FBQyxnQkFBYSxNQUFNLE1BQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVCLEtBQWhJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1JO0FBQUEsYUFGckk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxxQkFDWlYsaUJBQU8rRjtBQUFBQSxRQUFJLENBQUNDLE9BQU9DLFFBQ2xCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFFQyxXQUFXLGtCQUFrQkEsUUFBUW5HLGVBQWUsV0FBVyxFQUFFO0FBQUEsWUFDakUsT0FBTyxFQUFFb0csWUFBWUYsTUFBTTNGLFdBQVc7QUFBQSxZQUV0QztBQUFBLHFDQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSxlQUFlMkYsZ0JBQU03RixTQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyQztBQUFBLGdCQUMzQyx1QkFBQyxRQUFHLFdBQVUsZUFBZTZGLGdCQUFNL0YsU0FBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUM7QUFBQSxnQkFDekMsdUJBQUMsT0FBRSxXQUFVLGNBQWMrRixnQkFBTTlGLFFBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXNDO0FBQUEsZ0JBQ3RDLHVCQUFDLFlBQU8sV0FBVSxvQkFBbUIsU0FBUyxNQUFNO0FBQ2xEZixpQ0FBZSxPQUFPO0FBQ3RCRSxrQ0FBZ0IyRyxNQUFNMUYsTUFBTTtBQUFBLGdCQUM5QixHQUNHMEY7QUFBQUEsd0JBQU01RjtBQUFBQSxrQkFBUTtBQUFBLGtCQUFDLHVCQUFDLGNBQVcsTUFBTSxNQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFxQjtBQUFBLHFCQUp2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsbUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFVQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLGdCQUNiLGlDQUFDLFNBQUksV0FBVSx1QkFDYixpQ0FBQyxjQUFXLE1BQU0sSUFBSSxPQUFNLDRCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvRCxLQUR0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFJQTtBQUFBO0FBQUE7QUFBQSxVQW5CSzZGO0FBQUFBLFVBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQXFCQTtBQUFBLE1BQ0QsS0F4Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXlCQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLHVCQUNaakcsaUJBQU8rRjtBQUFBQSxRQUFJLENBQUNJLEdBQUdGLFFBQ2Q7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUVDLFdBQVcsaUJBQWlCQSxRQUFRbkcsZUFBZSxXQUFXLEVBQUU7QUFBQSxZQUNoRSxTQUFTLE1BQU1DLGdCQUFnQmtHLEdBQUc7QUFBQTtBQUFBLFVBRjdCQTtBQUFBQSxVQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJQztBQUFBLE1BQ0YsS0FQSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxTQTVDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNkNBLEtBOUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0ErQ0E7QUFBQSxJQUdBLHVCQUFDLGFBQVEsV0FBVSxnQkFDakI7QUFBQSw2QkFBQyxTQUFJLFdBQVUsOEJBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsWUFDYjtBQUFBLGlDQUFDLE9BQUksTUFBTSxNQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWM7QUFBQSxVQUFHO0FBQUEsVUFBRW5JLEVBQUVzSTtBQUFBQSxhQUR2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFFBQUcsV0FBVSxjQUNYdEk7QUFBQUEsWUFBRXVJO0FBQUFBLFVBQWE7QUFBQSxVQUFDLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBRztBQUFBLFVBQ25CdkksRUFBRXdJO0FBQUFBLGFBRkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxPQUFFLFdBQVUsYUFDVnhJLFlBQUV5SSxhQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLGFBQ1o5SSx1QkFDQyx1QkFBQyxRQUFLLElBQUcsY0FBYSxXQUFVLGVBQzdCSztBQUFBQSxZQUFFb0g7QUFBQUEsVUFBVTtBQUFBLFVBQUMsdUJBQUMsY0FBVyxNQUFNLE1BQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFCO0FBQUEsYUFEckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBLElBRUEsbUNBQ0U7QUFBQSxpQ0FBQyxRQUFLLElBQUcsYUFBWSxXQUFVLGVBQzVCcEg7QUFBQUEsY0FBRTBJO0FBQUFBLFlBQWE7QUFBQSxZQUFDLHVCQUFDLGNBQVcsTUFBTSxNQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxQjtBQUFBLGVBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFFBQUssSUFBRyxVQUFTLFdBQVUsaUJBQzFCO0FBQUEsbUNBQUMsUUFBSyxNQUFNLElBQUksTUFBSyxrQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUM7QUFBQSxZQUFHO0FBQUEsWUFBRTFJLEVBQUUySTtBQUFBQSxlQUQ1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0EsS0FiSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUE7QUFBQSxXQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMkJBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsY0FDYixpQ0FBQyxTQUFJLFdBQVUsMEJBRWI7QUFBQSwrQkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSxpQ0FBQyxTQUFJLE9BQU8sRUFBRXBCLFNBQVMsUUFBUUMsZ0JBQWdCLGlCQUFpQkMsWUFBWSxTQUFTLEdBQ25GO0FBQUEsbUNBQUMsU0FBSSxPQUFPLEVBQUVJLFVBQVUsVUFBVWUsT0FBTyxXQUFXQyxlQUFlLFNBQVNDLFlBQVksSUFBSSxHQUFJOUksWUFBRStJLHFCQUFsRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvSDtBQUFBLFlBQ3BILHVCQUFDLE9BQUksTUFBTSxJQUFJLE9BQU0sYUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEI7QUFBQSxlQUZoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRWxCLFVBQVUsVUFBVWlCLFlBQVksS0FBS0YsT0FBTyxRQUFRdkksUUFBUSxTQUFTLEdBQUcsMEJBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdHO0FBQUEsVUFDaEcsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFNBQUksT0FBTyxFQUFFd0gsVUFBVSxXQUFXZSxPQUFPLFVBQVUsR0FBSTVJLFlBQUVnSixlQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRTtBQUFBLFlBQ3RFLHVCQUFDLFNBQUksT0FBTyxFQUFFbkIsVUFBVSxVQUFVaUIsWUFBWSxLQUFLRixPQUFPLE9BQU8sR0FBRywyQkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0U7QUFBQSxlQUZqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLGlDQUFDLFNBQUksT0FBTyxFQUFFckIsU0FBUyxRQUFRQyxnQkFBZ0IsaUJBQWlCQyxZQUFZLFNBQVMsR0FDbkY7QUFBQSxtQ0FBQyxTQUFJLE9BQU8sRUFBRUksVUFBVSxVQUFVZSxPQUFPLFdBQVdDLGVBQWUsU0FBU0MsWUFBWSxJQUFJLEdBQUk5SSxZQUFFaUosa0JBQWxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlIO0FBQUEsWUFDakgsdUJBQUMsY0FBVyxNQUFNLElBQUksT0FBTSxhQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxQztBQUFBLGVBRnZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFcEIsVUFBVSxXQUFXaUIsWUFBWSxLQUFLRixPQUFPLFFBQVF2SSxRQUFRLFdBQVcsR0FBRywwQkFBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUc7QUFBQSxVQUNuRyx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsU0FBSSxPQUFPLEVBQUV3SCxVQUFVLFdBQVdlLE9BQU8sVUFBVSxHQUFJNUksWUFBRWdKLGVBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNFO0FBQUEsWUFDdEUsdUJBQUMsU0FBSSxPQUFPLEVBQUVuQixVQUFVLFVBQVVpQixZQUFZLEtBQUtGLE9BQU8sT0FBTyxHQUFHLHlCQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RTtBQUFBLGVBRi9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLCtCQUNiLGlDQUFDLFNBQUksT0FBTyxFQUFFckIsU0FBUyxRQUFRSSxLQUFLLFdBQVdGLFlBQVksU0FBUyxHQUNsRTtBQUFBLGlDQUFDLFNBQUksT0FBTyxFQUFFbkgsT0FBTyxRQUFRNEksUUFBUSxRQUFRQyxjQUFjLE9BQU9mLFlBQVksVUFBVSxLQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRjtBQUFBLFVBQzNGLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxTQUFJLE9BQU8sRUFBRVAsVUFBVSxVQUFVZSxPQUFPLHVCQUF1QixHQUFJNUksWUFBRW9KLGlCQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRjtBQUFBLFlBQ3BGLHVCQUFDLFNBQUksT0FBTyxFQUFFdkIsVUFBVSxVQUFVaUIsWUFBWSxLQUFLRixPQUFPLHNCQUFzQixHQUFHLDBCQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RjtBQUFBLGVBRi9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLGdDQUNiLGlDQUFDLFNBQUksT0FBTyxFQUFFckIsU0FBUyxRQUFRSSxLQUFLLFdBQVdGLFlBQVksU0FBUyxHQUNsRTtBQUFBLGlDQUFDLFNBQUksT0FBTyxFQUFFRyxTQUFTLFVBQVV1QixjQUFjLE9BQU9mLFlBQVksMEJBQTBCUSxPQUFPLFVBQVUsR0FDM0csaUNBQUMsWUFBUyxNQUFNLE1BQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1CLEtBRHJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxTQUFJLE9BQU8sRUFBRWYsVUFBVSxVQUFVZSxPQUFPLHVCQUF1QixHQUFJNUksWUFBRXFKLHVCQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRjtBQUFBLFlBQzFGLHVCQUFDLFNBQUksT0FBTyxFQUFFeEIsVUFBVSxXQUFXaUIsWUFBWSxLQUFLRixPQUFPLHNCQUFzQixHQUFHO0FBQUE7QUFBQSxjQUFRNUksRUFBRXNKO0FBQUFBLGlCQUE5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RztBQUFBLGVBRnpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFdBaERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpREEsS0FsREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1EQTtBQUFBLFNBakZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrRkE7QUFBQSxJQUdBLHVCQUFDLGFBQVEsSUFBRyxvQkFBbUIsV0FBVSxvQkFBbUIsT0FBTyxFQUFFbEIsWUFBWSw2QkFBNkJtQixXQUFXLDhCQUE4QkMsY0FBYyw2QkFBNkIsR0FDaE07QUFBQSw2QkFBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQSwrQkFBQyxVQUFLLFdBQVUsZUFBZTFKLHVCQUFhLE9BQU8seUJBQXlCLG9DQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZHO0FBQUEsUUFDN0csdUJBQUMsUUFBRyxXQUFVLGlCQUFpQkEsdUJBQWEsT0FBTyw2QkFBNkIsc0NBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUg7QUFBQSxRQUNuSCx1QkFBQyxPQUFFLFdBQVUsZ0JBQ1ZBLHVCQUFhLE9BQU8seUhBQXlILDZHQURoSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLHVCQUNaMkosaUJBQU9DLEtBQUsxRyxRQUFRLEVBQUVpRjtBQUFBQSxRQUFJLENBQUEwQixZQUN6QjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBRUMsV0FBVyxtQkFBbUI3RyxjQUFjNkcsVUFBVSxXQUFXLEVBQUU7QUFBQSxZQUNuRSxTQUFTLE1BQU01RyxhQUFhNEcsT0FBTztBQUFBLFlBRWxDQTtBQUFBQSwwQkFBWSxjQUFjLHVCQUFDLFlBQVMsTUFBTSxNQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtQjtBQUFBLGNBQzdDQSxZQUFZLFdBQVcsdUJBQUMsYUFBVSxNQUFNLE1BQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9CO0FBQUEsY0FDM0NBLFlBQVksV0FBVyx1QkFBQyxjQUFXLE1BQU0sTUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUI7QUFBQSxjQUM1Q0EsWUFBWSxjQUFjLHVCQUFDLFlBQVMsTUFBTSxNQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtQjtBQUFBLGNBQzlDLHVCQUFDLFVBQUssT0FBTyxFQUFFQyxZQUFZLFNBQVMsR0FBSTVKLFlBQUUsV0FBVzJKLFFBQVF0RSxZQUFZLENBQUMsRUFBRSxLQUFLc0UsV0FBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUY7QUFBQTtBQUFBO0FBQUEsVUFScEZBO0FBQUFBLFVBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVVBO0FBQUEsTUFDRCxLQWJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFjQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLG1DQUNaM0csbUJBQVNGLFNBQVMsRUFBRW1GO0FBQUFBLFFBQUksQ0FBQzRCLEdBQUcxQixRQUMzQix1QkFBQyxTQUFjLFdBQVUseUJBQ3ZCO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHVCQUNiO0FBQUEsbUNBQUMsVUFBSyxXQUFVLHFCQUFvQjtBQUFBLHFDQUFDLFlBQVMsTUFBTSxNQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtQjtBQUFBLGNBQUc7QUFBQSxjQUFFckY7QUFBQUEsaUJBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNFO0FBQUEsWUFDdEUsdUJBQUMsUUFBRyxXQUFVLHNCQUFzQitHLFlBQUVqSSxRQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyQztBQUFBLGVBRjdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSxxQkFBcUJpSSxZQUFFekgsUUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUM7QUFBQSxVQUN6Qyx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSxtQ0FBQyxlQUFZLE1BQU0sSUFBSSxPQUFNLGFBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNDO0FBQUEsWUFDdEMsdUJBQUMsVUFBTXlILFlBQUUzRyxXQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlCO0FBQUEsZUFGbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsbUNBQUMsWUFBTyxXQUFVLGVBQWMsT0FBTyxFQUFFMEUsU0FBUyxlQUFlQyxVQUFVLFVBQVUsR0FBRyxTQUFTLE1BQU07QUFDckd4Ryw2QkFBZSxPQUFPO0FBQ3RCRSw4QkFBZ0JzSSxFQUFFakksSUFBSTtBQUFBLFlBQ3hCLEdBQ0c1QixZQUFFOEosYUFKTDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsWUFDQSx1QkFBQyxZQUFPLFdBQVUsaUJBQWdCLE9BQU8sRUFBRWxDLFNBQVMsZUFBZUMsVUFBVSxVQUFVLEdBQUcsU0FBUyxNQUFNN0MsZ0JBQWdCNkUsRUFBRWpJLElBQUksR0FDNUg1QixZQUFFK0osYUFETDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsYUFwQlE1QixLQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFxQkE7QUFBQSxNQUNELEtBeEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF5QkE7QUFBQSxTQXBERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcURBO0FBQUEsSUFHQSx1QkFBQyxhQUFRLElBQUcsaUJBQWdCLFdBQVUsb0JBQ3BDO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEsK0JBQUMsVUFBSyxXQUFVLGVBQWM7QUFBQSxpQ0FBQyxXQUFRLE1BQU0sSUFBSSxPQUFPLEVBQUVKLGFBQWEsU0FBUyxLQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRDtBQUFBLFVBQUlqSSxhQUFhLE9BQU8seUJBQXlCO0FBQUEsYUFBbkk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4SjtBQUFBLFFBQzlKLHVCQUFDLFFBQUcsV0FBVSxpQkFBaUJFLFlBQUVnSyx3QkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRDtBQUFBLFFBQ3RELHVCQUFDLE9BQUUsV0FBVSxnQkFBZ0JoSyxZQUFFaUssdUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUQ7QUFBQSxXQUhyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSx1QkFFYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxpQ0FBZ0MsU0FBUyxNQUFNM0Ysb0JBQW9CLEtBQU0sS0FBTyxXQUFXLEdBQ3hHO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsbUNBQUMsWUFBUyxNQUFNLElBQUksT0FBTSx1QkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkM7QUFBQSxZQUM3Qyx1QkFBQyxRQUFJeEUsdUJBQWEsT0FBTyxjQUFjLGFBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlEO0FBQUEsZUFGbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsbUNBQUMsVUFBSyxXQUFVLGVBQWM7QUFBQTtBQUFBLGNBQU0sdUJBQUMsVUFBSyxXQUFVLGVBQWMsb0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtDO0FBQUEsaUJBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZFO0FBQUEsWUFDN0UsdUJBQUMsT0FBRSxXQUFVLGFBQWFBLHVCQUFhLE9BQU8seURBQXlELDJEQUF2RztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErSjtBQUFBLGVBRmpLO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLGlDQUFnQyxTQUFTLE1BQU13RSxvQkFBb0IsS0FBTSxLQUFPLFVBQVUsR0FDdkc7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSxtQ0FBQyxPQUFJLE1BQU0sSUFBSSxPQUFNLHlCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwQztBQUFBLFlBQzFDLHVCQUFDLFFBQUl4RSx1QkFBYSxPQUFPLGFBQWEsYUFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0Q7QUFBQSxlQUZsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsZUFBYztBQUFBO0FBQUEsY0FBTSx1QkFBQyxVQUFLLFdBQVUsZUFBYyxvQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0M7QUFBQSxpQkFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkU7QUFBQSxZQUM3RSx1QkFBQyxPQUFFLFdBQVUsYUFBYUEsdUJBQWEsT0FBTyx5REFBeUQsc0RBQXZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBKO0FBQUEsZUFGNUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsaUNBQWdDLFNBQVMsTUFBTXdFLG9CQUFvQixNQUFNLEtBQU8sZ0JBQWdCLEdBQzdHO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsbUNBQUMsU0FBTSxNQUFNLElBQUksT0FBTSxzQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUM7QUFBQSxZQUN6Qyx1QkFBQyxRQUFJeEUsdUJBQWEsT0FBTyxtQkFBbUIsZUFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0Q7QUFBQSxlQUYxRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsZUFBYztBQUFBO0FBQUEsY0FBTSx1QkFBQyxVQUFLLFdBQVUsZUFBYyxvQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0M7QUFBQSxpQkFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkU7QUFBQSxZQUM3RSx1QkFBQyxPQUFFLFdBQVUsYUFBYUEsdUJBQWEsT0FBTywrREFBK0QsMkRBQTdHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFLO0FBQUEsZUFGdks7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsaUNBQWdDLFNBQVMsTUFBTXdFLG9CQUFvQixPQUFPLEtBQU8sZUFBZSxHQUM3RztBQUFBLGlDQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLG1DQUFDLGNBQVcsTUFBTSxJQUFJLE9BQU0sYUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUM7QUFBQSxZQUNyQyx1QkFBQyxRQUFJeEUsdUJBQWEsT0FBTyxrQkFBa0Isa0JBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBEO0FBQUEsZUFGNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsbUNBQUMsVUFBSyxXQUFVLGVBQWM7QUFBQTtBQUFBLGNBQU8sdUJBQUMsVUFBSyxXQUFVLGVBQWMsb0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtDO0FBQUEsaUJBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThFO0FBQUEsWUFDOUUsdUJBQUMsT0FBRSxXQUFVLGFBQWFBLHVCQUFhLE9BQU8sZ0VBQWdFLDhEQUE5RztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5SztBQUFBLGVBRjNLO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFdBL0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnREE7QUFBQSxTQXZERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBd0RBO0FBQUEsSUFHQSx1QkFBQyxhQUFRLElBQUcsY0FBYSxXQUFVLG9CQUFtQixPQUFPLEVBQUVzSSxZQUFZLDZCQUE2Qm1CLFdBQVcsOEJBQThCQyxjQUFjLDZCQUE2QixHQUMxTCxpQ0FBQyxTQUFJLE9BQU8sRUFBRVUsVUFBVSxVQUFVN0osUUFBUSxVQUFVa0gsU0FBUyxRQUFRNEMscUJBQXFCLFdBQVd4QyxLQUFLLFFBQVFGLFlBQVksU0FBUyxHQUNySTtBQUFBLDZCQUFDLFNBQ0M7QUFBQSwrQkFBQyxVQUFLLFdBQVUsZUFBZXpILFlBQUVvSyxvQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRDtBQUFBLFFBQ2xELHVCQUFDLFFBQUcsV0FBVSxpQkFBaUJwSyxZQUFFcUssc0JBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0Q7QUFBQSxRQUNwRCx1QkFBQyxPQUFFLFdBQVUsZ0JBQWUsT0FBTyxFQUFFQyxjQUFjLE9BQU8sR0FDdkR0SyxZQUFFdUsscUJBREw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRWhELFNBQVMsUUFBUWlELGVBQWUsVUFBVTdDLEtBQUssT0FBTyxHQUNsRTtBQUFBLGlDQUFDLFNBQUksT0FBTyxFQUFFSixTQUFTLFFBQVFJLEtBQUssV0FBV0YsWUFBWSxTQUFTLEdBQ2xFO0FBQUEsbUNBQUMsZUFBWSxNQUFNLElBQUksT0FBTSxhQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzQztBQUFBLFlBQ3RDLHVCQUFDLFVBQUssT0FBTyxFQUFFSSxVQUFVLFdBQVdpQixZQUFZLElBQUksR0FBSTlJLFlBQUV5SyxlQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRTtBQUFBLGVBRnhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFbEQsU0FBUyxRQUFRSSxLQUFLLFdBQVdGLFlBQVksU0FBUyxHQUNsRTtBQUFBLG1DQUFDLGVBQVksTUFBTSxJQUFJLE9BQU0sYUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0M7QUFBQSxZQUN0Qyx1QkFBQyxVQUFLLE9BQU8sRUFBRUksVUFBVSxXQUFXaUIsWUFBWSxJQUFJLEdBQUk5SSxZQUFFMEssZUFBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0U7QUFBQSxlQUZ4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRW5ELFNBQVMsUUFBUUksS0FBSyxXQUFXRixZQUFZLFNBQVMsR0FDbEU7QUFBQSxtQ0FBQyxlQUFZLE1BQU0sSUFBSSxPQUFNLGFBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNDO0FBQUEsWUFDdEMsdUJBQUMsVUFBSyxPQUFPLEVBQUVJLFVBQVUsV0FBV2lCLFlBQVksSUFBSSxHQUFJOUksWUFBRTJLLGVBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNFO0FBQUEsZUFGeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWFBO0FBQUEsV0FuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW9CQTtBQUFBLE1BRUEsdUJBQUMsU0FDQyxpQ0FBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSxjQUFjM0ssWUFBRTRLLG1CQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThDO0FBQUEsUUFFOUMsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxpQ0FBQyxTQUFJLE9BQU8sRUFBRXJELFNBQVMsUUFBUUMsZ0JBQWdCLGdCQUFnQixHQUM3RDtBQUFBLG1DQUFDLFdBQU94SCxZQUFFNkssd0JBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0I7QUFBQSxZQUMvQix1QkFBQyxVQUFLLFdBQVUsc0JBQXFCO0FBQUE7QUFBQSxjQUFFQyxPQUFPeEgsVUFBVSxFQUFFeUgsZUFBZTtBQUFBLGlCQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyRTtBQUFBLGVBRjdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxLQUFJO0FBQUEsY0FDSixLQUFJO0FBQUEsY0FDSixNQUFLO0FBQUEsY0FDTCxXQUFVO0FBQUEsY0FDVixPQUFPekg7QUFBQUEsY0FDUCxVQUFVLENBQUNvQyxNQUFNbkMsY0FBY21DLEVBQUVsRCxPQUFPcUUsS0FBSztBQUFBO0FBQUEsWUFQL0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT2lEO0FBQUEsYUFabkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLGlDQUFDLFNBQUksT0FBTyxFQUFFVSxTQUFTLFFBQVFDLGdCQUFnQixnQkFBZ0IsR0FDN0Q7QUFBQSxtQ0FBQyxXQUFPeEgsWUFBRWdMLG1CQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBCO0FBQUEsWUFDMUIsdUJBQUMsVUFBSyxXQUFVLHNCQUFzQnhIO0FBQUFBO0FBQUFBLGNBQVM7QUFBQSxpQkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0Q7QUFBQSxlQUZsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsS0FBSTtBQUFBLGNBQ0osS0FBSTtBQUFBLGNBQ0osTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQ1YsT0FBT0E7QUFBQUEsY0FDUCxVQUFVLENBQUNrQyxNQUFNakMsWUFBWWlDLEVBQUVsRCxPQUFPcUUsS0FBSztBQUFBO0FBQUEsWUFQN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTytDO0FBQUEsYUFaakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLGlDQUFDLFNBQUksT0FBTyxFQUFFVSxTQUFTLFFBQVFDLGdCQUFnQixnQkFBZ0IsR0FDN0Q7QUFBQSxtQ0FBQyxXQUFPeEgsWUFBRWlMLHVCQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThCO0FBQUEsWUFDOUIsdUJBQUMsVUFBSyxXQUFVLHNCQUFzQnZIO0FBQUFBO0FBQUFBLGNBQVM7QUFBQSxpQkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0Q7QUFBQSxlQUZ4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsS0FBSTtBQUFBLGNBQ0osS0FBSTtBQUFBLGNBQ0osTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQ1YsT0FBT0E7QUFBQUEsY0FDUCxVQUFVLENBQUNnQyxNQUFNL0IsWUFBWStCLEVBQUVsRCxPQUFPcUUsS0FBSztBQUFBO0FBQUEsWUFQN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTytDO0FBQUEsYUFaakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLGlDQUFDLFNBQUksT0FBTyxFQUFFZ0IsVUFBVSxVQUFVZSxPQUFPLHdCQUF3QjBCLGNBQWMsVUFBVSxHQUFJdEssWUFBRWtMLHdCQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvSDtBQUFBLFVBQ3BILHVCQUFDLFNBQUksV0FBVSxZQUFXO0FBQUE7QUFBQSxZQUFFdEgscUJBQXFCO0FBQUEsWUFBRTtBQUFBLFlBQUMsdUJBQUMsVUFBSyxPQUFPLEVBQUVpRSxVQUFVLFFBQVFpQixZQUFZLEtBQUtGLE9BQU8sdUJBQXVCLEdBQUk1SSxZQUFFbUwsYUFBdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0c7QUFBQSxlQUFwSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEySjtBQUFBLGFBRjdKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBdERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF1REEsS0F4REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXlEQTtBQUFBLFNBaEZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpRkEsS0FsRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1GQTtBQUFBLElBR0EsdUJBQUMsYUFBUSxJQUFHLGtCQUFpQixXQUFVLG9CQUNyQztBQUFBLDZCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBLCtCQUFDLFVBQUssV0FBVSxlQUFjO0FBQUEsaUNBQUMsWUFBUyxNQUFNLElBQUksT0FBTyxFQUFFcEQsYUFBYSxTQUFTLEtBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFEO0FBQUEsVUFBSWpJLGFBQWEsT0FBTyx5QkFBeUI7QUFBQSxhQUFwSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlKO0FBQUEsUUFDekosdUJBQUMsUUFBRyxXQUFVLGlCQUFpQkUsWUFBRW9MLHdCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNEO0FBQUEsUUFDdEQsdUJBQUMsT0FBRSxXQUFVLGdCQUFnQnBMLFlBQUVxTCx1QkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRDtBQUFBLFdBSHJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLHVCQUViO0FBQUEsK0JBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGVBQWMsdUJBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9DO0FBQUEsVUFDcEMsdUJBQUMsUUFBRyxXQUFVLGVBQWV2TCx1QkFBYSxPQUFPLHlDQUF5QyxxQ0FBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEg7QUFBQSxVQUM1SCx1QkFBQyxPQUFFLFdBQVUsY0FBY0EsdUJBQWEsT0FBTywyRkFBMkYsa0dBQTFJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlPO0FBQUEsVUFDek8sdUJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEsbUNBQUMsVUFBSyxXQUFVLGVBQWM7QUFBQTtBQUFBLGNBQU0sdUJBQUMsT0FBRSwwQkFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFhO0FBQUEsaUJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFEO0FBQUEsWUFDckQsdUJBQUMsWUFBTyxXQUFVLGlCQUFnQixPQUFPLEVBQUU4SCxTQUFTLGlCQUFpQkMsVUFBVSxTQUFTLEdBQUcsU0FBUyxNQUFNN0MsZ0JBQWdCLFFBQVEsR0FBSWhGLFlBQUU4SixhQUF4STtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrSjtBQUFBLGVBRnBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGVBQWMsNEJBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlDO0FBQUEsVUFDekMsdUJBQUMsUUFBRyxXQUFVLGVBQWVoSyx1QkFBYSxPQUFPLDBDQUEwQyxtREFBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkk7QUFBQSxVQUMzSSx1QkFBQyxPQUFFLFdBQVUsY0FBY0EsdUJBQWEsT0FBTyw4RkFBOEYsb0dBQTdJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThPO0FBQUEsVUFDOU8sdUJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEsbUNBQUMsVUFBSyxXQUFVLGVBQWM7QUFBQTtBQUFBLGNBQU0sdUJBQUMsT0FBRSwwQkFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFhO0FBQUEsaUJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFEO0FBQUEsWUFDckQsdUJBQUMsWUFBTyxXQUFVLGlCQUFnQixPQUFPLEVBQUU4SCxTQUFTLGlCQUFpQkMsVUFBVSxTQUFTLEdBQUcsU0FBUyxNQUFNN0MsZ0JBQWdCLFFBQVEsR0FBSWhGLFlBQUU4SixhQUF4STtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrSjtBQUFBLGVBRnBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGVBQWMsNkJBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBDO0FBQUEsVUFDMUMsdUJBQUMsUUFBRyxXQUFVLGVBQWVoSyx1QkFBYSxPQUFPLHFDQUFxQyw4QkFBdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUg7QUFBQSxVQUNqSCx1QkFBQyxPQUFFLFdBQVUsY0FBY0EsdUJBQWEsT0FBTyx5RkFBeUYsNkZBQXhJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtPO0FBQUEsVUFDbE8sdUJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEsbUNBQUMsVUFBSyxXQUFVLGVBQWM7QUFBQTtBQUFBLGNBQU0sdUJBQUMsT0FBRSwwQkFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFhO0FBQUEsaUJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFEO0FBQUEsWUFDckQsdUJBQUMsWUFBTyxXQUFVLGlCQUFnQixPQUFPLEVBQUU4SCxTQUFTLGlCQUFpQkMsVUFBVSxTQUFTLEdBQUcsU0FBUyxNQUFNN0MsZ0JBQWdCLFFBQVEsR0FBSWhGLFlBQUU4SixhQUF4STtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrSjtBQUFBLGVBRnBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFdBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpQ0E7QUFBQSxTQXhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBeUNBO0FBQUEsSUFHQSx1QkFBQyxhQUFRLFdBQVUscUJBQ2pCLGlDQUFDLFNBQUksV0FBVSxrQkFDYixpQ0FBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSwrQkFBQyxVQUFLLFdBQVUsaUJBQWdCLHdCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdDO0FBQUEsUUFDeEMsdUJBQUMsUUFBSTlKLFlBQUVzTCxtQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVCO0FBQUEsUUFDdkIsdUJBQUMsT0FBR3RMLFlBQUV1TCxrQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFCO0FBQUEsUUFDckIsdUJBQUMsU0FBSSxPQUFPLEVBQUVoRSxTQUFTLFFBQVFJLEtBQUssVUFBVTZELFVBQVUsUUFBUTlELFdBQVcsU0FBUyxHQUNsRjtBQUFBLGlDQUFDLFNBQUksT0FBTyxFQUFFVSxZQUFZLFFBQVFSLFNBQVMsVUFBVXVCLGNBQWMsUUFBUTVCLFNBQVMsUUFBUUUsWUFBWSxVQUFVRCxnQkFBZ0IsVUFBVWlFLFdBQVcsOEJBQThCLEdBRWxMdkwsc0JBQ0M7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLEtBQUtBO0FBQUFBLGNBQ0wsS0FBSTtBQUFBLGNBQ0osT0FBTyxFQUFFSSxPQUFPLFFBQVE0SSxRQUFRLFFBQVEzQixTQUFTLFNBQVNtRSxnQkFBZ0IsWUFBWTtBQUFBO0FBQUEsWUFIeEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBRzBGLElBRzFGLHVCQUFDLFNBQUksV0FBVSxtQkFBa0IsT0FBTyxFQUFFcEwsT0FBTyxRQUFRNEksUUFBUSxPQUFPLEtBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJFLEtBVC9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFM0IsU0FBUyxRQUFRaUQsZUFBZSxVQUFVaEQsZ0JBQWdCLFVBQVVHLEtBQUssU0FBUyxHQUM5RjtBQUFBLG1DQUFDLFNBQUksT0FBTyxFQUFFRSxVQUFVLFdBQVdpQixZQUFZLEtBQUtGLE9BQU8sd0JBQXdCLEdBQUk5SSx1QkFBYSxPQUFPLDRCQUE0QiwrQ0FBdkk7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUw7QUFBQSxZQUNuTCx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLHFDQUFDLFlBQU8sV0FBVSxpQkFBZ0I7QUFBQSx1Q0FBQyxjQUFXLE1BQU0sTUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBcUI7QUFBQSxnQkFBRztBQUFBLG1CQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvRTtBQUFBLGNBQ3BFLHVCQUFDLFlBQU8sV0FBVSxpQkFBZ0I7QUFBQSx1Q0FBQyxRQUFLLE1BQU0sTUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFlO0FBQUEsZ0JBQUc7QUFBQSxtQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0U7QUFBQSxpQkFGbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLGVBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLGFBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvQkE7QUFBQSxXQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeUJBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsb0JBQ2IsaUNBQUMsU0FBSSxXQUFVLG9CQUNiLGlDQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxjQUFhLHFCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrQztBQUFBLFVBQ2xDLHVCQUFDLFNBQUksV0FBVSxrQkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4QjtBQUFBLGFBRmhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEsaUNBQUMsU0FBSSxPQUFPLEVBQUV5SCxTQUFTLFFBQVFDLGdCQUFnQixpQkFBaUJDLFlBQVksVUFBVTZDLGNBQWMsT0FBTyxHQUN6RztBQUFBLG1DQUFDLFNBQUksT0FBTyxFQUFFekMsVUFBVSxXQUFXaUIsWUFBWSxJQUFJLEdBQUcsMEJBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdFO0FBQUEsWUFDaEUsdUJBQUMsT0FBSSxNQUFNLElBQUksT0FBTSxXQUFVLE1BQUssYUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkM7QUFBQSxlQUYvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRVYsWUFBWSx5QkFBeUJSLFNBQVMsV0FBV3VCLGNBQWMsUUFBUW1CLGNBQWMsT0FBTyxHQUNoSDtBQUFBLG1DQUFDLFNBQUksT0FBTyxFQUFFekMsVUFBVSxVQUFVOEQsU0FBUyxJQUFJLEdBQUcsaUNBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1FO0FBQUEsWUFDbkUsdUJBQUMsU0FBSSxPQUFPLEVBQUU5RCxVQUFVLFFBQVFpQixZQUFZLElBQUksR0FBRywwQkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkQ7QUFBQSxlQUYvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRXZCLFNBQVMsUUFBUTRDLHFCQUFxQixrQkFBa0J4QyxLQUFLLFNBQVMsR0FDbEY7QUFBQSxtQ0FBQyxTQUFJLE9BQU8sRUFBRVMsWUFBWSwwQkFBMEJSLFNBQVMsVUFBVXVCLGNBQWMsT0FBT3lDLFdBQVcsVUFBVS9ELFVBQVUsVUFBVSxHQUNuSTtBQUFBLHFDQUFDLFlBQVMsTUFBTSxNQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtQjtBQUFBLGNBQ25CLHVCQUFDLFNBQUksb0JBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBUztBQUFBLGlCQUZYO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFTyxZQUFZLDBCQUEwQlIsU0FBUyxVQUFVdUIsY0FBYyxPQUFPeUMsV0FBVyxVQUFVL0QsVUFBVSxVQUFVLEdBQ25JO0FBQUEscUNBQUMsV0FBUSxNQUFNLE1BQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0I7QUFBQSxjQUNsQix1QkFBQyxTQUFJLHFCQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQVU7QUFBQSxpQkFGWjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRU8sWUFBWSwwQkFBMEJSLFNBQVMsVUFBVXVCLGNBQWMsT0FBT3lDLFdBQVcsVUFBVS9ELFVBQVUsVUFBVSxHQUNuSTtBQUFBLHFDQUFDLGNBQVcsTUFBTSxNQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxQjtBQUFBLGNBQ3JCLHVCQUFDLFNBQUkscUJBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBVTtBQUFBLGlCQUZaO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxlQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUE7QUFBQSxhQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdUJBO0FBQUEsV0E1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTZCQSxLQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBK0JBLEtBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpQ0E7QUFBQSxTQTVERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNkRBLEtBOURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0ErREEsS0FoRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlFQTtBQUFBLElBR0EsdUJBQUMsWUFBTyxXQUFVLGtCQUNoQjtBQUFBLDZCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEsaUNBQUMsUUFBSyxJQUFHLEtBQUksV0FBVSxnQkFDckI7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsaUJBQ2IsaUNBQUMsT0FBSSxNQUFNLElBQUksTUFBSyxXQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyQixLQUQ3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxVQUFLLHdCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWM7QUFBQSxlQUpoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsZUFDVjdILFlBQUU2TCxlQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxpQ0FBQyxRQUFJN0wsWUFBRThMLGVBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUI7QUFBQSxVQUNuQix1QkFBQyxRQUFHLFdBQVUsZ0JBQ1o7QUFBQSxtQ0FBQyxRQUFHLGlDQUFDLE9BQUUsTUFBSyxhQUFhOUwsWUFBRStMLFlBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdDLEtBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdDO0FBQUEsWUFDeEMsdUJBQUMsUUFBRyxpQ0FBQyxPQUFFLE1BQUssZUFBZS9MLFlBQUVnTSxjQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvQyxLQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0QztBQUFBLFlBQzVDLHVCQUFDLFFBQUcsaUNBQUMsUUFBSyxJQUFHLFVBQVVoTTtBQUFBQSxnQkFBRW9IO0FBQUFBLGNBQVU7QUFBQSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUMsS0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0Q7QUFBQSxlQUhwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsYUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsaUNBQUMsUUFBSXBILFlBQUVpTSxnQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvQjtBQUFBLFVBQ3BCLHVCQUFDLFFBQUcsV0FBVSxnQkFDWjtBQUFBLG1DQUFDLFFBQUcsaUNBQUMsT0FBRSxNQUFLLEtBQUksb0NBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0MsS0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0M7QUFBQSxZQUN4Qyx1QkFBQyxRQUFHLGlDQUFDLE9BQUUsTUFBSyxLQUFJLGlDQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZCLEtBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFDO0FBQUEsWUFDckMsdUJBQUMsUUFBRyxpQ0FBQyxPQUFFLE1BQUssS0FBSSw4QkFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwQixLQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrQztBQUFBLGVBSHBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxpQ0FBQyxRQUFJak0sWUFBRWtNLGVBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUI7QUFBQSxVQUNuQix1QkFBQyxRQUFHLFdBQVUsZ0JBQ1o7QUFBQSxtQ0FBQyxRQUFHLGlDQUFDLE9BQUUsTUFBSyxLQUFJLHdCQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9CLEtBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRCO0FBQUEsWUFDNUIsdUJBQUMsUUFBRyxpQ0FBQyxPQUFFLE1BQUssS0FBSSx1QkFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtQixLQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyQjtBQUFBLFlBQzNCLHVCQUFDLFFBQUcsaUNBQUMsUUFBSyxJQUFHLFlBQVlsTSxZQUFFbU0sV0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0IsS0FBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEM7QUFBQSxlQUg1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsYUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxXQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdUNBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSwrQkFBQyxTQUFJO0FBQUE7QUFBQSxXQUFHLG9CQUFJQyxLQUFLLEdBQUVDLFlBQVk7QUFBQSxVQUFFO0FBQUEsYUFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRTtBQUFBLFFBRS9EeE0sYUFBYSxLQUNaLHVCQUFDLFNBQUksT0FBTyxFQUFFMEgsU0FBUyxRQUFRRSxZQUFZLFVBQVVFLEtBQUssVUFBVVMsWUFBWSxvQkFBb0JSLFNBQVMsaUJBQWlCdUIsY0FBYyxRQUFRbUQsUUFBUSw4QkFBOEJ6RSxVQUFVLFVBQVUsR0FDNU07QUFBQSxpQ0FBQyxVQUFLLE9BQU8sRUFBRXZILE9BQU8sT0FBTzRJLFFBQVEsT0FBT0MsY0FBYyxPQUFPb0QsaUJBQWlCLFdBQVdkLFdBQVcsbUJBQW1CbEUsU0FBUyxlQUFlLEtBQW5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNKO0FBQUEsVUFDdEosdUJBQUMsVUFBSyxPQUFPLEVBQUVxQixPQUFPLHdCQUF3QkUsWUFBWSxJQUFJLEdBQUk5STtBQUFBQSxjQUFFd007QUFBQUEsWUFBWTtBQUFBLFlBQUMsdUJBQUMsWUFBTyxPQUFPLEVBQUU1RCxPQUFPLHNCQUFzQixHQUFJL0kscUJBQVdrTCxlQUFlLEtBQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThFO0FBQUEsZUFBL0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0s7QUFBQSxhQUYxSztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUdGLHVCQUFDLFNBQUksT0FBTyxFQUFFeEQsU0FBUyxRQUFRSSxLQUFLLFNBQVMsR0FDM0M7QUFBQSxpQ0FBQyxPQUFFLE1BQUssS0FBSSxPQUFPLEVBQUVpQixPQUFPLHdCQUF3QjZELGdCQUFnQixPQUFPLEdBQUl6TSxZQUFFME0sU0FBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUY7QUFBQSxVQUN2Rix1QkFBQyxPQUFFLE1BQUssS0FBSSxPQUFPLEVBQUU5RCxPQUFPLHdCQUF3QjZELGdCQUFnQixPQUFPLEdBQUl6TSxZQUFFMk0sV0FBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUY7QUFBQSxhQUYzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFjQTtBQUFBLFNBeERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5REE7QUFBQSxJQUtDdkwsZ0JBQWdCLFdBQ2YsdUJBQUMsU0FBSSxXQUFVLGtCQUNiLGlDQUFDLFNBQUksV0FBVSxpQ0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBLCtCQUFDLFFBQUl0Qix1QkFBYSxPQUFPLHVCQUF1Qiw4QkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyRTtBQUFBLFFBQzNFLHVCQUFDLFlBQU8sV0FBVSxtQkFBa0IsU0FBUyxNQUFNdUIsZUFBZSxJQUFJLEdBQUcsaUNBQUMsS0FBRSxNQUFNLE1BQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFZLEtBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0Y7QUFBQSxXQUYxRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNDRyxlQUNDLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLCtCQUFDLGVBQVksTUFBTSxJQUFJLE9BQU0sYUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzQztBQUFBLFFBQ3RDLHVCQUFDLFFBQUkxQix1QkFBYSxPQUFPLHdDQUF3QyxxQ0FBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRztBQUFBLFFBQ25HLHVCQUFDLE9BQUdBLHVCQUFhLE9BQU8sb0JBQW9Cd0IsWUFBWSw0RUFBNEUsUUFBUUEsWUFBWSxxRkFBeEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwTztBQUFBLFdBSDVPO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJQSxJQUVBLHVCQUFDLFVBQUssVUFBVW1FLG1CQUFtQixXQUFVLGNBQzNDO0FBQUEsK0JBQUMsU0FBSSxPQUFPLEVBQUUyQyxZQUFZLDJCQUEyQlIsU0FBUyxXQUFXdUIsY0FBYyxRQUFRbUIsY0FBYyxXQUFXekMsVUFBVSxVQUFVeUUsUUFBUSw2QkFBNkIsR0FDOUt4TTtBQUFBQSx1QkFBYSxPQUFPLHVCQUF1QjtBQUFBLFVBQWlCO0FBQUEsVUFBQyx1QkFBQyxPQUFHd0IsMEJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUI7QUFBQSxhQURqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxvQkFDYjtBQUFBLGlDQUFDLFdBQU90QjtBQUFBQSxjQUFFNE07QUFBQUEsWUFBVztBQUFBLGVBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVCO0FBQUEsVUFDdkI7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMO0FBQUEsY0FDQSxhQUFhNU0sRUFBRTZNO0FBQUFBLGNBQ2YsT0FBT25MLFVBQVVFO0FBQUFBLGNBQ2pCLFVBQVUsQ0FBQzhELE1BQU0vRCxhQUFhLEVBQUUsR0FBR0QsV0FBV0UsTUFBTThELEVBQUVsRCxPQUFPcUUsTUFBTSxDQUFDO0FBQUE7QUFBQSxZQUx0RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLd0U7QUFBQSxhQVAxRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxvQkFDYjtBQUFBLGlDQUFDLFdBQU83RztBQUFBQSxjQUFFOE07QUFBQUEsWUFBWTtBQUFBLGVBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdCO0FBQUEsVUFDeEI7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMO0FBQUEsY0FDQSxhQUFhOU0sRUFBRStNO0FBQUFBLGNBQ2YsT0FBT3JMLFVBQVVHO0FBQUFBLGNBQ2pCLFVBQVUsQ0FBQzZELE1BQU0vRCxhQUFhLEVBQUUsR0FBR0QsV0FBV0csT0FBTzZELEVBQUVsRCxPQUFPcUUsTUFBTSxDQUFDO0FBQUE7QUFBQSxZQUx2RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLeUU7QUFBQSxhQVAzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxvQkFDYjtBQUFBLGlDQUFDLFdBQU8vRyx1QkFBYSxPQUFPLDBCQUEwQix1QkFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEU7QUFBQSxVQUMxRTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0w7QUFBQSxjQUNBLGFBQVk7QUFBQSxjQUNaLE9BQU80QixVQUFVSTtBQUFBQSxjQUNqQixVQUFVLENBQUM0RCxNQUFNL0QsYUFBYSxFQUFFLEdBQUdELFdBQVdJLE9BQU80RCxFQUFFbEQsT0FBT3FFLE1BQU0sQ0FBQztBQUFBO0FBQUEsWUFMdkU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS3lFO0FBQUEsYUFQM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsb0JBQ2I7QUFBQSxpQ0FBQyxXQUFPL0csdUJBQWEsT0FBTyxrQ0FBa0MsNkJBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdGO0FBQUEsVUFDeEY7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLGFBQVk7QUFBQSxjQUNaLE9BQU80QixVQUFVSztBQUFBQSxjQUNqQixVQUFVLENBQUMyRCxNQUFNL0QsYUFBYSxFQUFFLEdBQUdELFdBQVdLLFFBQVEyRCxFQUFFbEQsT0FBT3FFLE1BQU0sQ0FBQztBQUFBO0FBQUEsWUFKeEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSTBFO0FBQUEsYUFONUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsUUFFQSx1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLGVBQWMsT0FBTyxFQUFFdkcsT0FBTyxRQUFRc0gsU0FBUyxXQUFXTCxTQUFTLFFBQVFDLGdCQUFnQixTQUFTLEdBQ2pJMUgsdUJBQWEsT0FBTyw4QkFBOEIsNkJBRHJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBbERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFtREE7QUFBQSxTQS9ESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUVBLEtBbEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtRUE7QUFBQSxJQUlEc0IsZ0JBQWdCLFdBQ2YsdUJBQUMsU0FBSSxXQUFVLGtCQUNiLGlDQUFDLFNBQUksV0FBVSxpQ0FBZ0MsT0FBTyxFQUFFOEksVUFBVSxRQUFRLEdBQ3hFO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEsK0JBQUMsUUFBSWxLLFlBQUUwRyxrQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNCO0FBQUEsUUFDdEIsdUJBQUMsWUFBTyxXQUFVLG1CQUFrQixTQUFTLE1BQU1yRixlQUFlLElBQUksR0FBRyxpQ0FBQyxLQUFFLE1BQU0sTUFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVksS0FBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RjtBQUFBLFdBRjFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsc0JBQ2I7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsU0FBSSxPQUFPLEVBQUV5SCxZQUFZLEtBQUtqQixVQUFVLFVBQVUsR0FBRyw0Q0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0Y7QUFBQSxZQUNsRix1QkFBQyxTQUFJLE9BQU8sRUFBRUEsVUFBVSxXQUFXZSxPQUFPLHVCQUF1QixHQUFHLDRCQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRjtBQUFBLGVBRmxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFlBQU8sV0FBVSxpQkFBZ0IsT0FBTyxFQUFFaEIsU0FBUyxpQkFBaUJDLFVBQVUsU0FBUyxHQUFHLFNBQVMsTUFBTWpDLE1BQU0sNkNBQTZDLEdBQUcsaUNBQUMsWUFBUyxNQUFNLE1BQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1CLEtBQW5MO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNMO0FBQUEsYUFMeEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsc0JBQ2I7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsU0FBSSxPQUFPLEVBQUVrRCxZQUFZLEtBQUtqQixVQUFVLFVBQVUsR0FBRyw0Q0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0Y7QUFBQSxZQUNsRix1QkFBQyxTQUFJLE9BQU8sRUFBRUEsVUFBVSxXQUFXZSxPQUFPLHVCQUF1QixHQUFHLDRCQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRjtBQUFBLGVBRmxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFlBQU8sV0FBVSxpQkFBZ0IsT0FBTyxFQUFFaEIsU0FBUyxpQkFBaUJDLFVBQVUsU0FBUyxHQUFHLFNBQVMsTUFBTWpDLE1BQU0sNkNBQTZDLEdBQUcsaUNBQUMsWUFBUyxNQUFNLE1BQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1CLEtBQW5MO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNMO0FBQUEsYUFMeEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsc0JBQ2I7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsU0FBSSxPQUFPLEVBQUVrRCxZQUFZLEtBQUtqQixVQUFVLFVBQVUsR0FBRyxpQ0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUU7QUFBQSxZQUN2RSx1QkFBQyxTQUFJLE9BQU8sRUFBRUEsVUFBVSxXQUFXZSxPQUFPLHVCQUF1QixHQUFHLDRCQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRjtBQUFBLGVBRmxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFlBQU8sV0FBVSxpQkFBZ0IsT0FBTyxFQUFFaEIsU0FBUyxpQkFBaUJDLFVBQVUsU0FBUyxHQUFHLFNBQVMsTUFBTWpDLE1BQU0sa0NBQWtDLEdBQUcsaUNBQUMsWUFBUyxNQUFNLE1BQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1CLEtBQXhLO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJLO0FBQUEsYUFMN0s7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsV0FyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNCQTtBQUFBLFNBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E0QkEsS0E3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThCQTtBQUFBLElBSUR4RSxnQkFBZ0IsYUFDZix1QkFBQyxTQUFJLFdBQVUsa0JBQ2IsaUNBQUMsU0FBSSxXQUFVLGlDQUFnQyxPQUFPLEVBQUU4SSxVQUFVLFFBQVEsR0FDeEU7QUFBQSw2QkFBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQSwrQkFBQyxRQUFJbEssWUFBRWdOLHdCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEI7QUFBQSxRQUM1Qix1QkFBQyxZQUFPLFdBQVUsbUJBQWtCLFNBQVMsTUFBTTNMLGVBQWUsSUFBSSxHQUFHLGlDQUFDLEtBQUUsTUFBTSxNQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBWSxLQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdGO0FBQUEsV0FGMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxPQUFFLE9BQU8sRUFBRXdHLFVBQVUsVUFBVWUsT0FBTyx3QkFBd0IwQixjQUFjLE9BQU8sR0FBSXRLLFlBQUVpTix1QkFBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4RztBQUFBLE1BQzlHLHVCQUFDLFNBQUksV0FBVSxzQkFDYjtBQUFBLCtCQUFDLFdBQU0sTUFBSyxRQUFPLGFBQVksNkJBQTRCLE9BQU8sRUFBRTNNLE9BQU8sUUFBUXNILFNBQVMsZUFBZXVCLGNBQWMsUUFBUW1ELFFBQVEsOEJBQThCbEUsWUFBWSxnQkFBZ0I4RSxTQUFTLE9BQU8sS0FBbk47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxTjtBQUFBLFFBQ3JOLHVCQUFDLFlBQU8sV0FBVSxlQUFjLE9BQU8sRUFBRXRGLFNBQVMsaUJBQWlCLEdBQUcsU0FBUyxNQUFNaEMsTUFBTSw4QkFBOEIsR0FBSTlGLHVCQUFhLE9BQU8sV0FBVyxXQUE1SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9LO0FBQUEsV0FGdEs7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQWdCLE9BQU8sRUFBRTRILFdBQVcsUUFBUUgsU0FBUyxRQUFRaUQsZUFBZSxVQUFVN0MsS0FBSyxXQUFXd0YsV0FBVyxTQUFTQyxXQUFXLE9BQU8sR0FDeko7QUFBQSwrQkFBQyxTQUFJLE9BQU8sRUFBRWQsUUFBUSw4QkFBOEIxRSxTQUFTLFdBQVd1QixjQUFjLE9BQU8sR0FDM0Y7QUFBQSxpQ0FBQyxTQUFJLE9BQU8sRUFBRUwsWUFBWSxLQUFLakIsVUFBVSxVQUFVLEdBQUcsc0NBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRFO0FBQUEsVUFDNUUsdUJBQUMsU0FBSSxPQUFPLEVBQUVBLFVBQVUsV0FBV2UsT0FBTyx3QkFBd0JsQixXQUFXLFVBQVUsR0FBRyx3REFBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0k7QUFBQSxVQUNsSSx1QkFBQyxTQUFJLE9BQU8sRUFBRUcsVUFBVSxXQUFXZSxPQUFPLHFCQUFxQkUsWUFBWSxLQUFLcEIsV0FBVyxTQUFTLEdBQUkxSDtBQUFBQSxjQUFFcU47QUFBQUEsWUFBYTtBQUFBLGVBQXZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJJO0FBQUEsYUFIN0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRWYsUUFBUSw4QkFBOEIxRSxTQUFTLFdBQVd1QixjQUFjLE9BQU8sR0FDM0Y7QUFBQSxpQ0FBQyxTQUFJLE9BQU8sRUFBRUwsWUFBWSxLQUFLakIsVUFBVSxVQUFVLEdBQUcsa0NBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdFO0FBQUEsVUFDeEUsdUJBQUMsU0FBSSxPQUFPLEVBQUVBLFVBQVUsV0FBV2UsT0FBTyx3QkFBd0JsQixXQUFXLFVBQVUsR0FBRyx1REFBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUk7QUFBQSxVQUNqSSx1QkFBQyxTQUFJLE9BQU8sRUFBRUcsVUFBVSxXQUFXZSxPQUFPLHFCQUFxQkUsWUFBWSxLQUFLcEIsV0FBVyxTQUFTLEdBQUkxSDtBQUFBQSxjQUFFcU47QUFBQUEsWUFBYTtBQUFBLGVBQXZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJJO0FBQUEsYUFIN0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsV0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxTQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0JBLEtBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3QkE7QUFBQSxPQTV4Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTh4QkE7QUFFSjtBQUVBM04sR0ExL0JNRCxTQUFPO0FBQUEsVUFDcURILE9BQU87QUFBQTtBQUFBLEtBRG5FRztBQTIvQk4sTUFBTTZOLFdBQVdBLENBQUMsRUFBRUMsS0FBSyxNQUN2Qix1QkFBQyxTQUFJLE9BQU0sOEJBQTZCLE9BQU9BLE1BQU0sUUFBUUEsTUFBTSxTQUFRLGFBQVksTUFBSyxRQUFPLFFBQU8sZ0JBQWUsYUFBWSxLQUFJLGVBQWMsU0FBUSxnQkFBZSxTQUM1SztBQUFBLHlCQUFDLFVBQUssSUFBRyxNQUFLLElBQUcsS0FBSSxJQUFHLE1BQUssSUFBRyxRQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFDO0FBQUEsRUFDckMsdUJBQUMsYUFBUSxRQUFPLCtCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTRDO0FBQUEsS0FGOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUdBO0FBQ0FDLE1BTElGO0FBT04sZUFBZTdOO0FBQVEsSUFBQWdPLElBQUFEO0FBQUEsYUFBQUMsSUFBQTtBQUFBLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInVzZVJlZiIsIkxpbmsiLCJBcnJvd1JpZ2h0IiwiU2hpZWxkQ2hlY2siLCJaYXAiLCJBY3Rpdml0eSIsIkNyZWRpdENhcmQiLCJIYW5kQ29pbnMiLCJXcmVuY2giLCJQbGF5IiwiQ2hlY2tDaXJjbGUiLCJNZW51IiwiWCIsIkxvY2siLCJDaGVjayIsIlVzZXJzIiwiU2VhcmNoIiwiUGhvbmUiLCJGaWxlVGV4dCIsIk1hcFBpbiIsIkNoZXZyb25MZWZ0IiwiQ2hldnJvblJpZ2h0IiwiRG93bmxvYWQiLCJTbWFydHBob25lIiwiSW5mbyIsIkhlbHBDaXJjbGUiLCJUcmVuZGluZ1VwIiwiUGVyY2VudCIsIlNwYXJrbGVzIiwiTGFuZG1hcmsiLCJ1c2VBdXRoIiwidHJhbnNsYXRpb25zIiwiUVJDb2RlIiwiTGFuZGluZyIsIl9zIiwiaXNMb2dnZWRJbiIsInVzZXIiLCJ2aXNpdENvdW50IiwibGFuZ3VhZ2UiLCJzZXRMYW5ndWFnZSIsInQiLCJlbiIsInFyQ29kZVVybCIsInNldFFyQ29kZVVybCIsInRvRGF0YVVSTCIsIm1hcmdpbiIsIndpZHRoIiwidGhlbiIsInVybCIsImNhdGNoIiwiZXJyIiwiY29uc29sZSIsImVycm9yIiwic2VhcmNoUXVlcnkiLCJzZXRTZWFyY2hRdWVyeSIsInNob3dTdWdnZXN0aW9ucyIsInNldFNob3dTdWdnZXN0aW9ucyIsInNlYXJjaFJlc3VsdCIsInNldFNlYXJjaFJlc3VsdCIsInNlYXJjaElucHV0UmVmIiwiYWN0aXZlTW9kYWwiLCJzZXRBY3RpdmVNb2RhbCIsImFwcGx5UHJvZHVjdCIsInNldEFwcGx5UHJvZHVjdCIsImFwcGx5U3VjY2VzcyIsInNldEFwcGx5U3VjY2VzcyIsImFwcGx5Rm9ybSIsInNldEFwcGx5Rm9ybSIsIm5hbWUiLCJlbWFpbCIsInBob25lIiwiaW5jb21lIiwiY3VycmVudFNsaWRlIiwic2V0Q3VycmVudFNsaWRlIiwic2xpZGVzIiwidGl0bGUiLCJkZXNjIiwiYmFkZ2UiLCJidG5UZXh0IiwiYmdHcmFkaWVudCIsInRhcmdldCIsInRpbWVyIiwic2V0SW50ZXJ2YWwiLCJwcmV2IiwibGVuZ3RoIiwiY2xlYXJJbnRlcnZhbCIsImFjdGl2ZVRhYiIsInNldEFjdGl2ZVRhYiIsInByb2R1Y3RzIiwiQWNjb3VudHMiLCJiZW5lZml0IiwiTG9hbnMiLCJDYXJkcyIsIkRlcG9zaXRzIiwiY2FsY0Ftb3VudCIsInNldENhbGNBbW91bnQiLCJjYWxjUmF0ZSIsInNldENhbGNSYXRlIiwiY2FsY1Rlcm0iLCJzZXRDYWxjVGVybSIsImNhbGN1bGF0ZUluc3RhbGxtZW50IiwiUCIsInBhcnNlRmxvYXQiLCJyIiwibiIsImlzTmFOIiwiaW5zdGFsbG1lbnQiLCJNYXRoIiwicG93IiwidG9GaXhlZCIsImhhbmRsZVJhdGVDYXJkQ2xpY2siLCJyYXRlIiwidHlwaWNhbEFtb3VudCIsImxhYmVsIiwidG9TdHJpbmciLCJzZWN0aW9uIiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsInNjcm9sbEludG9WaWV3IiwiYmVoYXZpb3IiLCJoYW5kbGVQaWxsQ2xpY2siLCJ0ZXJtIiwidHJpZ2dlclNlYXJjaCIsInF1ZXJ5IiwicSIsInRvTG93ZXJDYXNlIiwicmVzdWx0IiwiaW5jbHVkZXMiLCJhY3Rpb24iLCJoYW5kbGVBcHBseVN1Ym1pdCIsImUiLCJwcmV2ZW50RGVmYXVsdCIsImFsZXJ0IiwiZmV0Y2giLCJtZXRob2QiLCJoZWFkZXJzIiwiYm9keSIsIkpTT04iLCJzdHJpbmdpZnkiLCJwcm9kdWN0IiwicmVzIiwib2siLCJFcnJvciIsImpzb24iLCJzZXRUaW1lb3V0IiwidG9sbF9mcmVlIiwiZG93bmxvYWRfZm9ybXMiLCJyYXRlc19jYXJkcyIsImN1c3RfY2FyZSIsInZhbHVlIiwibmF2X3BlcnNvbmFsIiwibmF2X2J1c2luZXNzIiwibmF2X2FncmkiLCJuYXZfYWJvdXQiLCJzZWFyY2hfcGxhY2Vob2xkZXIiLCJrZXkiLCJkYXNoYm9hcmQiLCJsb2dpbiIsInNpZ251cCIsImRpc3BsYXkiLCJqdXN0aWZ5Q29udGVudCIsImFsaWduSXRlbXMiLCJtYXJnaW5Ub3AiLCJnYXAiLCJwYWRkaW5nIiwiZm9udFNpemUiLCJxdWlja19zdWdnZXN0aW9ucyIsIm1hcmdpblJpZ2h0Iiwid2hhdHNfbmV3X3RpdGxlIiwibWFwIiwic2xpZGUiLCJpZHgiLCJiYWNrZ3JvdW5kIiwiXyIsImhlcm9fdGFnIiwiaGVyb190aXRsZV8xIiwiaGVyb190aXRsZV8yIiwiaGVyb19kZXNjIiwib3Blbl9hY2NvdW50Iiwic2lnbl9pbiIsImNvbG9yIiwibGV0dGVyU3BhY2luZyIsImZvbnRXZWlnaHQiLCJwbGF0aW51bV9wcmVzdGlnZSIsImNhcmRfaG9sZGVyIiwiYnVzaW5lc3Nfc21hcnQiLCJoZWlnaHQiLCJib3JkZXJSYWRpdXMiLCJpbmNvbWVfc3RyZWFtIiwidHJhbnNhY3Rpb25zX3N0YXR1cyIsImFwcHJvdmVkIiwiYm9yZGVyVG9wIiwiYm9yZGVyQm90dG9tIiwiT2JqZWN0Iiwia2V5cyIsInRhYk5hbWUiLCJtYXJnaW5MZWZ0IiwicCIsImFwcGx5X25vdyIsImtub3dfbW9yZSIsImludGVyZXN0X3JhdGVzX3RpdGxlIiwiaW50ZXJlc3RfcmF0ZXNfZGVzYyIsIm1heFdpZHRoIiwiZ3JpZFRlbXBsYXRlQ29sdW1ucyIsImNhbGNfc2VjdGlvbl90YWciLCJjYWxjX3NlY3Rpb25fdGl0bGUiLCJtYXJnaW5Cb3R0b20iLCJjYWxjX3NlY3Rpb25fZGVzYyIsImZsZXhEaXJlY3Rpb24iLCJjYWxjX2l0ZW1fMSIsImNhbGNfaXRlbV8yIiwiY2FsY19pdGVtXzMiLCJjYWxjX2NhcmRfdGl0bGUiLCJjYWxjX2xhYmVsX3ByaW5jaXBhbCIsIk51bWJlciIsInRvTG9jYWxlU3RyaW5nIiwiY2FsY19sYWJlbF9yYXRlIiwiY2FsY19sYWJlbF9kdXJhdGlvbiIsImNhbGNfbW9udGhseV9wYXltZW50IiwicGVyX21vbnRoIiwic3BlY2lhbF9vZmZlcnNfdGl0bGUiLCJzcGVjaWFsX29mZmVyc19kZXNjIiwiYXBwX3Byb21vX3RpdGxlIiwiYXBwX3Byb21vX2Rlc2MiLCJmbGV4V3JhcCIsImJveFNoYWRvdyIsImltYWdlUmVuZGVyaW5nIiwib3BhY2l0eSIsInRleHRBbGlnbiIsImZvb3Rlcl9kZXNjIiwiY29sX3Byb2R1Y3QiLCJmZWF0dXJlcyIsImNhbGN1bGF0b3IiLCJjb2xfc2VjdXJpdHkiLCJjb2xfY29tcGFueSIsInN1cHBvcnQiLCJEYXRlIiwiZ2V0RnVsbFllYXIiLCJib3JkZXIiLCJiYWNrZ3JvdW5kQ29sb3IiLCJ2aXNpdF9jb3VudCIsInRleHREZWNvcmF0aW9uIiwidGVybXMiLCJwcml2YWN5IiwibGFiZWxfbmFtZSIsInBsYWNlaG9sZGVyX25hbWUiLCJsYWJlbF9lbWFpbCIsInBsYWNlaG9sZGVyX2VtYWlsIiwiYnJhbmNoX2xvY2F0b3JfdGl0bGUiLCJicmFuY2hfbG9jYXRvcl9kZXNjIiwib3V0bGluZSIsIm1heEhlaWdodCIsIm92ZXJmbG93WSIsImJyYW5jaF9ob3VycyIsIlNlbmRJY29uIiwic2l6ZSIsIl9jMiIsIl9jIl0sInNvdXJjZXMiOlsiTGFuZGluZy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlUmVmIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHtcbiAgQXJyb3dSaWdodCxcbiAgU2hpZWxkQ2hlY2ssXG4gIFphcCxcbiAgQWN0aXZpdHksXG4gIENyZWRpdENhcmQsXG4gIEhhbmRDb2lucyxcbiAgV3JlbmNoLFxuICBQbGF5LFxuICBDaGVja0NpcmNsZSxcbiAgTWVudSxcbiAgWCxcbiAgTG9jayxcbiAgQ2hlY2ssXG4gIFVzZXJzLFxuICBTZWFyY2gsXG4gIFBob25lLFxuICBGaWxlVGV4dCxcbiAgTWFwUGluLFxuICBDaGV2cm9uTGVmdCxcbiAgQ2hldnJvblJpZ2h0LFxuICBEb3dubG9hZCxcbiAgU21hcnRwaG9uZSxcbiAgSW5mbyxcbiAgSGVscENpcmNsZSxcbiAgVHJlbmRpbmdVcCxcbiAgUGVyY2VudCxcbiAgU3BhcmtsZXMsXG4gIExhbmRtYXJrXG59IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vQXBwJztcbmltcG9ydCB7IHRyYW5zbGF0aW9ucyB9IGZyb20gJy4uL3V0aWxzL3RyYW5zbGF0aW9ucyc7XG5pbXBvcnQgUVJDb2RlIGZyb20gJ3FyY29kZSc7XG5pbXBvcnQgJy4uL2xhbmRpbmcuY3NzJztcblxuY29uc3QgTGFuZGluZyA9ICgpID0+IHtcbiAgY29uc3QgeyBpc0xvZ2dlZEluLCB1c2VyLCB2aXNpdENvdW50LCBsYW5ndWFnZSwgc2V0TGFuZ3VhZ2UgfSA9IHVzZUF1dGgoKTtcbiAgY29uc3QgdCA9IHRyYW5zbGF0aW9uc1tsYW5ndWFnZV0gfHwgdHJhbnNsYXRpb25zLmVuO1xuXG4gIC8vIExvY2FsIFFSIGNvZGUgc3RhdGVcbiAgY29uc3QgW3FyQ29kZVVybCwgc2V0UXJDb2RlVXJsXSA9IHVzZVN0YXRlKCcnKTtcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBRUkNvZGUudG9EYXRhVVJMKCdodHRwczovL2JhbmtkYXNoLmNvbS9pbnN0YWxsLWFwcCcsIHsgbWFyZ2luOiAxLCB3aWR0aDogMTUwIH0pXG4gICAgICAudGhlbih1cmwgPT4gc2V0UXJDb2RlVXJsKHVybCkpXG4gICAgICAuY2F0Y2goZXJyID0+IGNvbnNvbGUuZXJyb3IoZXJyKSk7XG4gIH0sIFtdKTtcblxuICAvLyBTZWFyY2ggc3RhdGUgJiBzdWdnZXN0aW9uIGxvZ2ljXG4gIGNvbnN0IFtzZWFyY2hRdWVyeSwgc2V0U2VhcmNoUXVlcnldID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbc2hvd1N1Z2dlc3Rpb25zLCBzZXRTaG93U3VnZ2VzdGlvbnNdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbc2VhcmNoUmVzdWx0LCBzZXRTZWFyY2hSZXN1bHRdID0gdXNlU3RhdGUobnVsbCk7XG4gIGNvbnN0IHNlYXJjaElucHV0UmVmID0gdXNlUmVmKG51bGwpO1xuXG4gIC8vIE1vZGFscyAmIE92ZXJsYXlzXG4gIGNvbnN0IFthY3RpdmVNb2RhbCwgc2V0QWN0aXZlTW9kYWxdID0gdXNlU3RhdGUobnVsbCk7IC8vICdhcHBseScsICdmb3JtcycsICdsb2NhdG9yJ1xuICBjb25zdCBbYXBwbHlQcm9kdWN0LCBzZXRBcHBseVByb2R1Y3RdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbYXBwbHlTdWNjZXNzLCBzZXRBcHBseVN1Y2Nlc3NdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbYXBwbHlGb3JtLCBzZXRBcHBseUZvcm1dID0gdXNlU3RhdGUoeyBuYW1lOiAnJywgZW1haWw6ICcnLCBwaG9uZTogJycsIGluY29tZTogJycgfSk7XG5cbiAgLy8gQ2Fyb3VzZWwgU3RhdGVcbiAgY29uc3QgW2N1cnJlbnRTbGlkZSwgc2V0Q3VycmVudFNsaWRlXSA9IHVzZVN0YXRlKDApO1xuICBjb25zdCBzbGlkZXMgPSBbXG4gICAge1xuICAgICAgdGl0bGU6IGxhbmd1YWdlID09PSAnZW4nID8gXCJHb2xkIExvYW4gQCA3LjIwJSBpbnRlcmVzdCByYXRlXCIgOiBcIuCkuOCljeCkteCksOCljeCkoyDgpIvgpKMgQCA3LjIwJSDgpKzgpY3gpK/gpL7gpJwg4KSm4KSwXCIsXG4gICAgICBkZXNjOiBsYW5ndWFnZSA9PT0gJ2VuJyA/IFwiSW5zdGFudCBhcHByb3ZhbCB3aXRoIG1pbmltYWwgcGFwZXJ3b3JrLiBTYWZlZ3VhcmQgeW91ciBnb2xkIHdoaWxlIHVubG9ja2luZyBpdHMgdmFsdWUuXCIgOiBcIuCkqOCljeCkr+ClguCkqOCkpOCkriDgpJXgpL7gpJfgpJzgpYAg4KSV4KS+4KSw4KWN4KSw4KS14KS+4KSIIOCkleClhyDgpLjgpL7gpKUg4KSk4KSk4KWN4KSV4KS+4KSyIOCkuOCljeCkteClgOCkleClg+CkpOCkv+ClpCDgpIXgpKrgpKjgpYcg4KS44KWL4KSo4KWHIOCkleCliyDgpLjgpYHgpLDgpJXgpY3gpLfgpL/gpKQg4KSw4KSW4KSk4KWHIOCkueClgeCkjyDgpIngpLjgpJXgpL4g4KSu4KWC4KSy4KWN4KSvIOCkheCkqOCksuClieCklSDgpJXgpLDgpYfgpILgpaRcIixcbiAgICAgIGJhZGdlOiBsYW5ndWFnZSA9PT0gJ2VuJyA/IFwiRkVTVElWRSBPRkZFUlwiIDogXCLgpIngpKTgpY3gpLjgpLUg4KSR4KSr4KSwXCIsXG4gICAgICBidG5UZXh0OiBsYW5ndWFnZSA9PT0gJ2VuJyA/IFwiQXBwbHkgR29sZCBMb2FuXCIgOiBcIuCkuOCljeCkteCksOCljeCkoyDgpIvgpKMg4KSV4KWHIOCksuCkv+CkjyDgpIbgpLXgpYfgpKbgpKgg4KSV4KSw4KWH4KSCXCIsXG4gICAgICBiZ0dyYWRpZW50OiBcImxpbmVhci1ncmFkaWVudCgxMzVkZWcsICNmNTllMGIgMCUsICNiNDUzMDkgMTAwJSlcIixcbiAgICAgIHRhcmdldDogXCJHb2xkIExvYW5cIlxuICAgIH0sXG4gICAge1xuICAgICAgdGl0bGU6IGxhbmd1YWdlID09PSAnZW4nID8gXCIxMDAlIFBhcGVybGVzcyBEaWdpdGFsIFBlcnNvbmFsIExvYW5cIiA6IFwiMTAwJSDgpKrgpYfgpKrgpLDgpLLgpYfgpLgg4KSh4KS/4KSc4KS/4KSf4KSyIOCkquCksOCljeCkuOCkqOCksiDgpLLgpYvgpKhcIixcbiAgICAgIGRlc2M6IGxhbmd1YWdlID09PSAnZW4nID8gXCJHZXQgY3JlZGl0IHVwIHRvICQyNSwwMDAgaW5zdGFudGx5IGluIHlvdXIgc2F2aW5ncyBhY2NvdW50IHdpdGhpbiA1IG1pbnV0ZXMuXCIgOiBcIjUg4KSu4KS/4KSo4KSfIOCkleClhyDgpK3gpYDgpKTgpLAg4KSF4KSq4KSo4KWHIOCkrOCkmuCkpCDgpJbgpL7gpKTgpYcg4KSu4KWH4KSCICQyNSwwMDAg4KSk4KSVIOCkleCkviDgpKTgpKTgpY3gpJXgpL7gpLIg4KSL4KSjIOCkquCljeCksOCkvuCkquCljeCkpCDgpJXgpLDgpYfgpILgpaRcIixcbiAgICAgIGJhZGdlOiBsYW5ndWFnZSA9PT0gJ2VuJyA/IFwiRElHSVRBTCBFWENMVVNJVkVcIiA6IFwi4KSh4KS/4KSc4KS/4KSf4KSyIOCkteCkv+CktuClh+Ckt1wiLFxuICAgICAgYnRuVGV4dDogbGFuZ3VhZ2UgPT09ICdlbicgPyBcIkNoZWNrIEVsaWdpYmlsaXR5XCIgOiBcIuCkquCkvuCkpOCljeCksOCkpOCkviDgpJzgpL7gpILgpJrgpYfgpIJcIixcbiAgICAgIGJnR3JhZGllbnQ6IFwibGluZWFyLWdyYWRpZW50KDEzNWRlZywgIzRmNDZlNSAwJSwgIzMxMmU4MSAxMDAlKVwiLFxuICAgICAgdGFyZ2V0OiBcIkRpZ2l0YWwgUGVyc29uYWwgTG9hblwiXG4gICAgfSxcbiAgICB7XG4gICAgICB0aXRsZTogbGFuZ3VhZ2UgPT09ICdlbicgPyBcIkJhbmtEYXNoIFdvcmxkIE1vYmlsZSBBcHAgTGF1bmNoXCIgOiBcIkJhbmtEYXNoIFdvcmxkIOCkruCli+CkrOCkvuCkh+CksiDgpJDgpKog4KSy4KWJ4KSo4KWN4KSaXCIsXG4gICAgICBkZXNjOiBsYW5ndWFnZSA9PT0gJ2VuJyA/IFwiRXhwZXJpZW5jZSBuZXh0LWdlbiBiYW5raW5nIG9uIHlvdXIgcGhvbmUuIFNjYW4sIHRyYW5zZmVyLCBwYXkgYmlsbHMgJiBpbnZlc3Qgb24gdGhlIGdvLlwiIDogXCLgpIXgpKrgpKjgpYcg4KSr4KWL4KSoIOCkquCksCDgpIXgpJfgpLLgpYAg4KSq4KWA4KSi4KS84KWAIOCkleClgCDgpKzgpYjgpILgpJXgpL/gpILgpJcg4KSV4KS+IOCkheCkqOClgeCkreCktSDgpJXgpLDgpYfgpILgpaQg4KS44KWN4KSV4KWI4KSoLCDgpJ/gpY3gpLDgpL7gpILgpLjgpKvgpLAsIOCkrOCkv+CksiDgpK3gpYHgpJfgpKTgpL7gpKgg4KSU4KSwIOCkqOCkv+CkteClh+CktiDgpJXgpLDgpYfgpILgpaRcIixcbiAgICAgIGJhZGdlOiBsYW5ndWFnZSA9PT0gJ2VuJyA/IFwiTkVXIFJFTEVBU0VcIiA6IFwi4KSo4KSv4KS+IOCksOCkv+CksuClgOCknFwiLFxuICAgICAgYnRuVGV4dDogbGFuZ3VhZ2UgPT09ICdlbicgPyBcIkRvd25sb2FkIEFwcFwiIDogXCLgpJDgpKog4KSh4KS+4KSJ4KSo4KSy4KWL4KShIOCkleCksOClh+CkglwiLFxuICAgICAgYmdHcmFkaWVudDogXCJsaW5lYXItZ3JhZGllbnQoMTM1ZGVnLCAjMGVhNWU5IDAlLCAjMDM2OWExIDEwMCUpXCIsXG4gICAgICB0YXJnZXQ6IFwiQmFua0Rhc2ggQXBwXCJcbiAgICB9XG4gIF07XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCB0aW1lciA9IHNldEludGVydmFsKCgpID0+IHtcbiAgICAgIHNldEN1cnJlbnRTbGlkZShwcmV2ID0+IChwcmV2ICsgMSkgJSBzbGlkZXMubGVuZ3RoKTtcbiAgICB9LCA2MDAwKTtcbiAgICByZXR1cm4gKCkgPT4gY2xlYXJJbnRlcnZhbCh0aW1lcik7XG4gIH0sIFtzbGlkZXMubGVuZ3RoXSk7XG5cbiAgLy8gUHJvZHVjdCBTaG93Y2FzZSBUYWJzXG4gIGNvbnN0IFthY3RpdmVUYWIsIHNldEFjdGl2ZVRhYl0gPSB1c2VTdGF0ZSgnQWNjb3VudHMnKTtcbiAgY29uc3QgcHJvZHVjdHMgPSB7XG4gICAgQWNjb3VudHM6IFtcbiAgICAgIHsgbmFtZTogXCJBZHZhbnRhZ2UgU2F2aW5ncyBBY2NvdW50XCIsIGRlc2M6IFwiUHJlbWl1bSBpbnRlcmVzdCByYXRlcyB1cCB0byA0LjIlIHAuYS4gd2l0aCB6ZXJvIGJhbGFuY2Ugb3B0aW9uIGZvciBzdHVkZW50cy5cIiwgYmVuZWZpdDogXCJGcmVlIERlYml0IENhcmQgJiBVbmxpbWl0ZWQgQVRNIHdpdGhkcmF3YWxzXCIgfSxcbiAgICAgIHsgbmFtZTogXCJQbGF0aW51bSBQcmVzdGlnZSBBY2NvdW50XCIsIGRlc2M6IFwiRGVzaWduZWQgZm9yIGhpZ2gtbmV0LXdvcnRoIGluZGl2aWR1YWxzLiBNdWx0aS1jdXJyZW5jeSBzdXBwb3J0ICYgcHJpdmF0ZSBtYW5hZ2VyLlwiLCBiZW5lZml0OiBcIkNvbXBsaW1lbnRhcnkgQWlycG9ydCBMb3VuZ2UgYWNjZXNzICYgemVybyBmZWUgdHJhbnNmZXJzXCIgfVxuICAgIF0sXG4gICAgTG9hbnM6IFtcbiAgICAgIHsgbmFtZTogXCJIb21lIExvYW5cIiwgZGVzYzogXCJCdWlsZCBvciBidXkgeW91ciBkcmVhbSBob21lLiBJbnRlcmVzdCByYXRlcyBzdGFydGluZyBmcm9tIDcuMjAlIHAuYS5cIiwgYmVuZWZpdDogXCJaZXJvIHByb2Nlc3NpbmcgZmVlcyAmIGZsZXhpYmxlIHJlcGF5bWVudCB0ZW51cmVcIiB9LFxuICAgICAgeyBuYW1lOiBcIkNhciBMb2FuXCIsIGRlc2M6IFwiRHJpdmUgaG9tZSB5b3VyIGRyZWFtIGNhci4gRmFzdCBwcm9jZXNzaW5nIGFuZCBjb21wZXRpdGl2ZSBpbnRlcmVzdCByYXRlcy5cIiwgYmVuZWZpdDogXCJVcCB0byA5MCUgb24tcm9hZCBmaW5hbmNpbmdcIiB9LFxuICAgICAgeyBuYW1lOiBcIkdvbGQgTG9hblwiLCBkZXNjOiBcIlVubG9jayB2YWx1ZSBvZiB5b3VyIGdvbGQgaW5zdGFudGx5LiBNaW5pbWFsIGRvY3VtZW50YXRpb24gYW5kIHNlY3VyZSB2YXVsdHMuXCIsIGJlbmVmaXQ6IFwiTG93IGludGVyZXN0IHJhdGVzIHN0YXJ0aW5nIEAgNy4yMCVcIiB9XG4gICAgXSxcbiAgICBDYXJkczogW1xuICAgICAgeyBuYW1lOiBcIlZpc2EgU2lnbmF0dXJlIENyZWRpdCBDYXJkXCIsIGRlc2M6IFwiRWFybiBwcmVtaXVtIHJld2FyZCBwb2ludHMgb24gZXZlcnkgZGluaW5nLCB0cmF2ZWwsIGFuZCBvbmxpbmUgcHVyY2hhc2UuXCIsIGJlbmVmaXQ6IFwiMTAlIGluc3RhbnQgZGlzY291bnQgd2l0aCBrZXkgcmV0YWlsIHBhcnRuZXJzXCIgfSxcbiAgICAgIHsgbmFtZTogXCJSdVBheSBTZWxlY3QgQ2FyZFwiLCBkZXNjOiBcIkRvbWVzdGljIGxvdW5nZSBhY2Nlc3MgYW5kIHdlbGxuZXNzIGJlbmVmaXRzIHdpdGggemVybyBhbm51YWwgZmVlLlwiLCBiZW5lZml0OiBcIkNhc2hiYWNrIHVwIHRvIDUlIG9uIHV0aWxpdHkgYmlsbHNcIiB9XG4gICAgXSxcbiAgICBEZXBvc2l0czogW1xuICAgICAgeyBuYW1lOiBcIkRvdWJsZSBEaGFtYWthIEZEXCIsIGRlc2M6IFwiRG91YmxlIHlvdXIgcHJpbmNpcGFsIGFtb3VudCBpbiBhIGZpeGVkIHRlcm0gdW5kZXIgc2VjdXJlIGdvdmVybm1lbnQgZ3VhcmFudGVlcy5cIiwgYmVuZWZpdDogXCJIaWdoZXIgaW50ZXJlc3QgcmF0ZXMgZm9yIHNlbmlvciBjaXRpemVucyAoKzAuNTAlKVwiIH0sXG4gICAgICB7IG5hbWU6IFwiUmVjdXJyaW5nIERlcG9zaXQgU2F2ZXJcIiwgZGVzYzogXCJCdWlsZCB5b3VyIHNhdmluZ3Mgc3lzdGVtYXRpY2FsbHkgd2l0aCBtb250aGx5IGRlcG9zaXRzIHN0YXJ0aW5nIGZyb20ganVzdCAkMTAuXCIsIGJlbmVmaXQ6IFwiQ29tcG91bmRlZCBxdWFydGVybHkgaW50ZXJlc3QgcmF0ZXNcIiB9XG4gICAgXVxuICB9O1xuXG4gIC8vIEludGVyYWN0aXZlIENhbGN1bGF0b3IgU3RhdGUgJiBBdXRvIEZpbGwgbG9naWNcbiAgY29uc3QgW2NhbGNBbW91bnQsIHNldENhbGNBbW91bnRdID0gdXNlU3RhdGUoJzEwMDAwJyk7XG4gIGNvbnN0IFtjYWxjUmF0ZSwgc2V0Q2FsY1JhdGVdID0gdXNlU3RhdGUoJzcuMicpO1xuICBjb25zdCBbY2FsY1Rlcm0sIHNldENhbGNUZXJtXSA9IHVzZVN0YXRlKCczNicpO1xuXG4gIGNvbnN0IGNhbGN1bGF0ZUluc3RhbGxtZW50ID0gKCkgPT4ge1xuICAgIGNvbnN0IFAgPSBwYXJzZUZsb2F0KGNhbGNBbW91bnQpO1xuICAgIGNvbnN0IHIgPSBwYXJzZUZsb2F0KGNhbGNSYXRlKSAvIDEyMDA7XG4gICAgY29uc3QgbiA9IHBhcnNlRmxvYXQoY2FsY1Rlcm0pO1xuXG4gICAgaWYgKGlzTmFOKFApIHx8IGlzTmFOKHIpIHx8IGlzTmFOKG4pIHx8IFAgPD0gMCB8fCByIDw9IDAgfHwgbiA8PSAwKSB7XG4gICAgICByZXR1cm4gJzAuMDAnO1xuICAgIH1cblxuICAgIGNvbnN0IGluc3RhbGxtZW50ID0gKFAgKiByICogTWF0aC5wb3coMSArIHIsIG4pKSAvIChNYXRoLnBvdygxICsgciwgbikgLSAxKTtcbiAgICByZXR1cm4gaW5zdGFsbG1lbnQudG9GaXhlZCgyKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVSYXRlQ2FyZENsaWNrID0gKHJhdGUsIHR5cGljYWxBbW91bnQsIGxhYmVsKSA9PiB7XG4gICAgc2V0Q2FsY1JhdGUocmF0ZS50b1N0cmluZygpKTtcbiAgICBzZXRDYWxjQW1vdW50KHR5cGljYWxBbW91bnQudG9TdHJpbmcoKSk7XG4gICAgY29uc3Qgc2VjdGlvbiA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdjYWxjdWxhdG9yJyk7XG4gICAgaWYgKHNlY3Rpb24pIHtcbiAgICAgIHNlY3Rpb24uc2Nyb2xsSW50b1ZpZXcoeyBiZWhhdmlvcjogJ3Ntb290aCcgfSk7XG4gICAgfVxuICB9O1xuXG4gIC8vIFN1Z2dlc3Rpb24gUGlsbCB0cmlnZ2VyXG4gIGNvbnN0IGhhbmRsZVBpbGxDbGljayA9ICh0ZXJtKSA9PiB7XG4gICAgc2V0U2VhcmNoUXVlcnkodGVybSk7XG4gICAgdHJpZ2dlclNlYXJjaCh0ZXJtKTtcbiAgfTtcblxuICAvLyBTZWFyY2ggbG9naWNcbiAgY29uc3QgdHJpZ2dlclNlYXJjaCA9IChxdWVyeSkgPT4ge1xuICAgIGlmICghcXVlcnkpIHJldHVybjtcbiAgICAvLyBTaW1wbGUgc2VhcmNoIGNhdGFsb2cgbWFwcGluZyBrZXl3b3JkcyB0byBzZWN0aW9ucyBvciBwcm9kdWN0c1xuICAgIGNvbnN0IHEgPSBxdWVyeS50b0xvd2VyQ2FzZSgpO1xuICAgIGxldCByZXN1bHQgPSBudWxsO1xuXG4gICAgaWYgKHEuaW5jbHVkZXMoJ2xvYW4nKSB8fCBxLmluY2x1ZGVzKCdob21lJykgfHwgcS5pbmNsdWRlcygnZ29sZCcpIHx8IHEuaW5jbHVkZXMoJ2NhcicpKSB7XG4gICAgICByZXN1bHQgPSB7XG4gICAgICAgIHRpdGxlOiBsYW5ndWFnZSA9PT0gJ2VuJyA/IFwiUmVsYXRlZCBMb2FuIFByb2R1Y3RzIEZvdW5kXCIgOiBcIuCkuOCkguCkrOCkguCkp+Ckv+CkpCDgpIvgpKMg4KSJ4KSk4KWN4KSq4KS+4KSmIOCkruCkv+CksuClh1wiLFxuICAgICAgICBkZXNjOiBsYW5ndWFnZSA9PT0gJ2VuJyA/IFwiV2Ugb2ZmZXIgSG9tZSBMb2FucyAoNy4yMCUpLCBHb2xkIExvYW5zICg3LjIwJSksIENhciBMb2FucyAoNy44MCUpLCBhbmQgUGVyc29uYWwgTG9hbnMgKDEwLjE1JSkuIFlvdSBjYW4gY2FsY3VsYXRlIHJhdGVzIGFuZCBhcHBseS5cIiA6IFwi4KS54KSuIOCkueCli+CkriDgpLLgpYvgpKggKDcuMjAlKSwg4KSX4KWL4KSy4KWN4KShIOCksuCli+CkqCAoNy4yMCUpLCDgpJXgpL7gpLAg4KSy4KWL4KSoICg3LjgwJSkg4KSU4KSwIOCkquCksOCljeCkuOCkqOCksiDgpLLgpYvgpKggKDEwLjE1JSkg4KSq4KWN4KSw4KSm4KS+4KSoIOCkleCksOCkpOClhyDgpLngpYjgpILgpaRcIixcbiAgICAgICAgYWN0aW9uOiAoKSA9PiB7XG4gICAgICAgICAgc2V0QWN0aXZlVGFiKCdMb2FucycpO1xuICAgICAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdwcm9kdWN0cy1zZWN0aW9uJyk/LnNjcm9sbEludG9WaWV3KHsgYmVoYXZpb3I6ICdzbW9vdGgnIH0pO1xuICAgICAgICB9LFxuICAgICAgICBidG5UZXh0OiBsYW5ndWFnZSA9PT0gJ2VuJyA/IFwiVmlldyBMb2FuIFByb2R1Y3RzXCIgOiBcIuCki+CkoyDgpIngpKTgpY3gpKrgpL7gpKYg4KSm4KWH4KSW4KWH4KSCXCJcbiAgICAgIH07XG4gICAgfSBlbHNlIGlmIChxLmluY2x1ZGVzKCdhY2NvdW50JykgfHwgcS5pbmNsdWRlcygnc2F2aW5nJykgfHwgcS5pbmNsdWRlcygnY3VycmVudCcpKSB7XG4gICAgICByZXN1bHQgPSB7XG4gICAgICAgIHRpdGxlOiBsYW5ndWFnZSA9PT0gJ2VuJyA/IFwiU2F2aW5ncyAmIEN1cnJlbnQgQWNjb3VudHNcIiA6IFwi4KSs4KSa4KSkIOCklOCksCDgpJrgpL7gpLLgpYIg4KSW4KS+4KSk4KWHXCIsXG4gICAgICAgIGRlc2M6IGxhbmd1YWdlID09PSAnZW4nID8gXCJCT0IgQWR2YW50YWdlIGFuZCBQbGF0aW51bSBTYXZpbmdzIGFjY291bnRzIG9mZmVyIGR5bmFtaWMgaW50ZXJlc3QsIGN1c3RvbSBkZWJpdCBjYXJkcywgYW5kIG11bHRpLWN1cnJlbmN5IHdhbGxldHMuXCIgOiBcIuCkrOClgOCkk+CkrOClgCDgpI/gpKHgpLXgpL7gpILgpJ/gpYfgpJwg4KSU4KSwIOCkquCljeCksuClh+Ckn+Ckv+CkqOCkriDgpKzgpJrgpKQg4KSW4KS+4KSk4KWHIOCkl+CkpOCkv+CktuClgOCksiDgpKzgpY3gpK/gpL7gpJwg4KSU4KSwIOCkleCkuOCljeCkn+CkriDgpKHgpYfgpKzgpL/gpJ8g4KSV4KS+4KSw4KWN4KShIOCkquCljeCksOCkpuCkvuCkqCDgpJXgpLDgpKTgpYcg4KS54KWI4KSC4KWkXCIsXG4gICAgICAgIGFjdGlvbjogKCkgPT4ge1xuICAgICAgICAgIHNldEFjdGl2ZVRhYignQWNjb3VudHMnKTtcbiAgICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncHJvZHVjdHMtc2VjdGlvbicpPy5zY3JvbGxJbnRvVmlldyh7IGJlaGF2aW9yOiAnc21vb3RoJyB9KTtcbiAgICAgICAgfSxcbiAgICAgICAgYnRuVGV4dDogbGFuZ3VhZ2UgPT09ICdlbicgPyBcIlZpZXcgQWNjb3VudHNcIiA6IFwi4KSW4KS+4KSk4KWHIOCkpuClh+CkluClh+CkglwiXG4gICAgICB9O1xuICAgIH0gZWxzZSBpZiAocS5pbmNsdWRlcygnb2ZmZXInKSB8fCBxLmluY2x1ZGVzKCdkaXNjb3VudCcpIHx8IHEuaW5jbHVkZXMoJ2Nhc2hiYWNrJykpIHtcbiAgICAgIHJlc3VsdCA9IHtcbiAgICAgICAgdGl0bGU6IGxhbmd1YWdlID09PSAnZW4nID8gXCJBY3RpdmUgUHJvbW90aW9uYWwgT2ZmZXJzXCIgOiBcIuCkuOCkleCljeCksOCkv+CkryDgpKrgpY3gpLDgpJrgpL7gpLAg4KSR4KSr4KSwXCIsXG4gICAgICAgIGRlc2M6IGxhbmd1YWdlID09PSAnZW4nID8gXCJHZXQgaW5zdGFudCAxMCUgZGlzY291bnQgb24gZGluaW5nLCBjYXNoYmFjayBvbiBncm9jZXJ5LCBvciBmcmVlIDMgbW9udGhzIE9UVCBzdWJzY3JpcHRpb25zIHdpdGggQmFua0Rhc2ggY2FyZHMuXCIgOiBcIuCkrOCliOCkguCkleCkoeCliOCktiDgpJXgpL7gpLDgpY3gpKEg4KSV4KWHIOCkuOCkvuCkpSDgpKHgpL7gpIfgpKjgpL/gpILgpJcg4KSq4KSwIOCkpOCkpOCljeCkleCkvuCksiAxMCUg4KSb4KWC4KSfLCDgpJXgpL/gpLDgpL7gpKjgpL4g4KSq4KSwIOCkleCliOCktuCkrOCliOCklSDgpK/gpL4g4KSu4KWB4KSr4KWN4KSkIDMg4KSu4KS54KWA4KSo4KWHIOCkleCkviDgpJPgpJ/gpYDgpJ/gpYAg4KS44KSs4KWN4KS44KSV4KWN4KSw4KS/4KSq4KWN4KS24KSoIOCkquCljeCksOCkvuCkquCljeCkpCDgpJXgpLDgpYfgpILgpaRcIixcbiAgICAgICAgYWN0aW9uOiAoKSA9PiB7XG4gICAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ29mZmVycy1zZWN0aW9uJyk/LnNjcm9sbEludG9WaWV3KHsgYmVoYXZpb3I6ICdzbW9vdGgnIH0pO1xuICAgICAgICB9LFxuICAgICAgICBidG5UZXh0OiBsYW5ndWFnZSA9PT0gJ2VuJyA/IFwiVmlldyBTcGVjaWFsIE9mZmVyc1wiIDogXCLgpLXgpL/gpLbgpYfgpLcg4KSR4KSr4KSwIOCkpuClh+CkluClh+CkglwiXG4gICAgICB9O1xuICAgIH0gZWxzZSBpZiAocS5pbmNsdWRlcygncmF0ZScpIHx8IHEuaW5jbHVkZXMoJ2ludGVyZXN0JykpIHtcbiAgICAgIHJlc3VsdCA9IHtcbiAgICAgICAgdGl0bGU6IGxhbmd1YWdlID09PSAnZW4nID8gXCJMaXZlIEludGVyZXN0IFJhdGVzIEZpbmRlclwiIDogXCLgpLLgpL7gpIfgpLUg4KSs4KWN4KSv4KS+4KScIOCkpuCksCDgpJbgpYvgpJzgpJVcIixcbiAgICAgICAgZGVzYzogbGFuZ3VhZ2UgPT09ICdlbicgPyBcIkNoZWNrIG91ciBkeW5hbWljIGludGVyZXN0IHJhdGUgZ3JpZC4gU3RhcnRpbmcgZnJvbSA3LjIwJSBmb3IgR29sZC9Ib21lIGxvYW5zIGFuZCB1cCB0byAxMC4xNSUgZm9yIFBlcnNvbmFsIExvYW5zLlwiIDogXCLgpLngpK7gpL7gpLDgpYAg4KSX4KSk4KS/4KS24KWA4KSyIOCkrOCljeCkr+CkvuCknCDgpKbgpLAg4KSX4KWN4KSw4KS/4KShIOCkleClgCDgpJzgpL7gpIHgpJog4KSV4KSw4KWH4KSC4KWkIOCkl+Cli+CksuCljeCkoS/gpLngpYvgpK4g4KSy4KWL4KSoIOCkleClhyDgpLLgpL/gpI8gNy4yMCUg4KS44KWHIOCktuClgeCksOClgiDgpLngpYvgpJXgpLAg4KSq4KSw4KWN4KS44KSo4KSyIOCksuCli+CkqCDgpJXgpYcg4KSy4KS/4KSPIDEwLjE1JSDgpKTgpJXgpaRcIixcbiAgICAgICAgYWN0aW9uOiAoKSA9PiB7XG4gICAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3JhdGVzLXNlY3Rpb24nKT8uc2Nyb2xsSW50b1ZpZXcoeyBiZWhhdmlvcjogJ3Ntb290aCcgfSk7XG4gICAgICAgIH0sXG4gICAgICAgIGJ0blRleHQ6IGxhbmd1YWdlID09PSAnZW4nID8gXCJWaWV3IEludGVyZXN0IFJhdGVzXCIgOiBcIuCkrOCljeCkr+CkvuCknCDgpKbgpLDgpYfgpIIg4KSm4KWH4KSW4KWH4KSCXCJcbiAgICAgIH07XG4gICAgfSBlbHNlIHtcbiAgICAgIHJlc3VsdCA9IHtcbiAgICAgICAgdGl0bGU6IGxhbmd1YWdlID09PSAnZW4nID8gXCJTZWFyY2ggUmVzdWx0c1wiIDogXCLgpJbgpYvgpJwg4KSq4KSw4KS/4KSj4KS+4KSuXCIsXG4gICAgICAgIGRlc2M6IGxhbmd1YWdlID09PSAnZW4nID8gYExvb2tpbmcgZm9yICcke3F1ZXJ5fSc/IEV4cGxvcmUgb3VyIG9ubGluZSBiYW5raW5nIHNlcnZpY2VzIGJ5IG9wZW5pbmcgYW4gYWNjb3VudCB0b2RheS5gIDogYCcke3F1ZXJ5fScg4KSV4KWAIOCkpOCksuCkvuCktiDgpLngpYg/IOCkhuCknCDgpLngpYAg4KSW4KS+4KSk4KS+IOCkluCli+CksuCkleCksCDgpLngpK7gpL7gpLDgpYAg4KSR4KSo4KSy4KS+4KSH4KSoIOCkrOCliOCkguCkleCkv+CkguCklyDgpLjgpYfgpLXgpL7gpJPgpIIg4KSV4KS+IOCkheCkqOCljeCkteClh+Ckt+CkoyDgpJXgpLDgpYfgpILgpaRgLFxuICAgICAgICBhY3Rpb246ICgpID0+IHtcbiAgICAgICAgICBzZXRBY3RpdmVNb2RhbCgnYXBwbHknKTtcbiAgICAgICAgICBzZXRBcHBseVByb2R1Y3QoJ0dlbmVyYWwgRGlnaXRhbCBBY2NvdW50Jyk7XG4gICAgICAgIH0sXG4gICAgICAgIGJ0blRleHQ6IGxhbmd1YWdlID09PSAnZW4nID8gXCJPcGVuIEZyZWUgQWNjb3VudFwiIDogXCLgpK7gpYHgpKvgpLzgpY3gpKQg4KSW4KS+4KSk4KS+IOCkluCli+CksuClh+CkglwiXG4gICAgICB9O1xuICAgIH1cblxuICAgIHNldFNlYXJjaFJlc3VsdChyZXN1bHQpO1xuICAgIHNldFNob3dTdWdnZXN0aW9ucyhmYWxzZSk7XG4gIH07XG5cbiAgLy8gSGFuZGxlIEFwcGxpY2F0aW9uIFN1Ym1pdFxuICBjb25zdCBoYW5kbGVBcHBseVN1Ym1pdCA9IChlKSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIGlmICghYXBwbHlGb3JtLm5hbWUgfHwgIWFwcGx5Rm9ybS5lbWFpbCB8fCAhYXBwbHlGb3JtLnBob25lKSB7XG4gICAgICBhbGVydChsYW5ndWFnZSA9PT0gJ2VuJyA/IFwiUGxlYXNlIGZpbGwgaW4gYWxsIHJlcXVpcmVkIGZpZWxkcy5cIiA6IFwi4KSV4KWD4KSq4KSv4KS+IOCkuOCkreClgCDgpIbgpLXgpLbgpY3gpK/gpJUg4KSr4KS84KWA4KSy4KWN4KShIOCkreCksOClh+CkguClpFwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBmZXRjaCgnaHR0cDovL2xvY2FsaG9zdDo1MDAwL2FwaS9hcHBsaWNhdGlvbnMnLCB7XG4gICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJ1xuICAgICAgfSxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgbmFtZTogYXBwbHlGb3JtLm5hbWUsXG4gICAgICAgIGVtYWlsOiBhcHBseUZvcm0uZW1haWwsXG4gICAgICAgIHBob25lOiBhcHBseUZvcm0ucGhvbmUsXG4gICAgICAgIGluY29tZTogYXBwbHlGb3JtLmluY29tZSxcbiAgICAgICAgcHJvZHVjdDogYXBwbHlQcm9kdWN0XG4gICAgICB9KVxuICAgIH0pXG4gICAgICAudGhlbihyZXMgPT4ge1xuICAgICAgICBpZiAoIXJlcy5vaykgdGhyb3cgbmV3IEVycm9yKCdGYWlsZWQgdG8gc3VibWl0IGFwcGxpY2F0aW9uJyk7XG4gICAgICAgIHJldHVybiByZXMuanNvbigpO1xuICAgICAgfSlcbiAgICAgIC50aGVuKCgpID0+IHtcbiAgICAgICAgc2V0QXBwbHlTdWNjZXNzKHRydWUpO1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICBzZXRBY3RpdmVNb2RhbChudWxsKTtcbiAgICAgICAgICBzZXRBcHBseVN1Y2Nlc3MoZmFsc2UpO1xuICAgICAgICAgIHNldEFwcGx5Rm9ybSh7IG5hbWU6ICcnLCBlbWFpbDogJycsIHBob25lOiAnJywgaW5jb21lOiAnJyB9KTtcbiAgICAgICAgfSwgMzAwMCk7XG4gICAgICB9KVxuICAgICAgLmNhdGNoKGVyciA9PiB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIHN1Ym1pdHRpbmcgYXBwbGljYXRpb246JywgZXJyKTtcbiAgICAgICAgYWxlcnQobGFuZ3VhZ2UgPT09ICdlbicgPyBcIkZhaWxlZCB0byBzdWJtaXQgYXBwbGljYXRpb24uIFBsZWFzZSB0cnkgYWdhaW4uXCIgOiBcIuCkhuCkteClh+CkpuCkqCDgpJzgpK7gpL4g4KSV4KSw4KSo4KWHIOCkruClh+CkgiDgpLXgpL/gpKvgpLLgpaQg4KSV4KWD4KSq4KSv4KS+IOCkquClgeCkqDog4KSq4KWN4KSw4KSv4KS+4KS4IOCkleCksOClh+CkguClpFwiKTtcbiAgICAgIH0pO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJsYW5kaW5nLWJvZHkgYW5pbWF0ZS1mYWRlXCI+XG4gICAgICB7LyogQmFja2dyb3VuZCBnbG93aW5nIGRlY29yYXRpb25zICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJsYW5kaW5nLWJnLWRlY29yIGRlY29yLXB1cnBsZVwiPjwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJsYW5kaW5nLWJnLWRlY29yIGRlY29yLWN5YW5cIj48L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGFuZGluZy1iZy1kZWNvciBkZWNvci1hbWJlclwiPjwvZGl2PlxuXG4gICAgICB7LyogVE9QIFVUSUxJVFkgQkFSIChCYW5rIG9mIEJhcm9kYSBJbnNwaXJlZCkgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInRvcC11dGlsaXR5LWJhclwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRvcC11dGlsaXR5LWNvbnRhaW5lclwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidXRpbGl0eS1sZWZ0XCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ1dGlsaXR5LWl0ZW1cIj48UGhvbmUgc2l6ZT17MTN9IC8+IHt0LnRvbGxfZnJlZX08L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ1dGlsaXR5LWl0ZW0gY3Vyc29yLXBvaW50ZXJcIiBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVNb2RhbCgnbG9jYXRvcicpfT48TWFwUGluIHNpemU9ezEzfSAvPiB7bGFuZ3VhZ2UgPT09ICdlbicgPyBcIkJyYW5jaCBMb2NhdG9yXCIgOiBcIuCktuCkvuCkluCkviDgpJbgpYvgpJzgpJVcIn08L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ1dGlsaXR5LWl0ZW0gY3Vyc29yLXBvaW50ZXJcIiBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVNb2RhbCgnZm9ybXMnKX0+PERvd25sb2FkIHNpemU9ezEzfSAvPiB7dC5kb3dubG9hZF9mb3Jtc308L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1dGlsaXR5LXJpZ2h0XCI+XG4gICAgICAgICAgICA8YSBocmVmPVwiI3JhdGVzLXNlY3Rpb25cIiBjbGFzc05hbWU9XCJ1dGlsaXR5LWxpbmtcIj48VHJlbmRpbmdVcCBzaXplPXsxM30gLz4ge3QucmF0ZXNfY2FyZHN9PC9hPlxuICAgICAgICAgICAgPExpbmsgdG89XCIvY29udGFjdFwiIGNsYXNzTmFtZT1cInV0aWxpdHktbGlua1wiPjxIZWxwQ2lyY2xlIHNpemU9ezEzfSAvPiB7dC5jdXN0X2NhcmV9PC9MaW5rPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsYW5ndWFnZS1zZWxlY3Rvci13cmFwcGVyXCI+XG4gICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICB2YWx1ZT17bGFuZ3VhZ2V9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRMYW5ndWFnZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibGFuZy1zZWxlY3QtdXRpbGl0eVwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiZW5cIj5FbmdsaXNoIPCfh6zwn4enPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImhpXCI+4KS54KS/4KSC4KSm4KWAIPCfh67wn4ezPC9vcHRpb24+XG4gICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBIRUFERVIgLyBOQVZJR0FUSU9OICovfVxuICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJsYW5kaW5nLWhlYWRlclwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxhbmRpbmctbmF2LWNvbnRhaW5lclwiPlxuICAgICAgICAgIDxMaW5rIHRvPVwiL1wiIGNsYXNzTmFtZT1cImxhbmRpbmctbG9nb1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsb2dvLWljb24tYm94XCI+XG4gICAgICAgICAgICAgIDxaYXAgc2l6ZT17MjJ9IGZpbGw9XCJ3aGl0ZVwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxzcGFuPkJhbmtEYXNoPC9zcGFuPlxuICAgICAgICAgIDwvTGluaz5cblxuICAgICAgICAgIHsvKiBDYXRlZ29yaXplZCBNZWdhLW5hdiBpdGVtcyAqL31cbiAgICAgICAgICA8bmF2IGNsYXNzTmFtZT1cIm1lZ2EtbmF2XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm5hdi1pdGVtLWRyb3Bkb3duXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm5hdi1kcm9wLWxhYmVsXCI+e3QubmF2X3BlcnNvbmFsfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJuYXYtZHJvcGRvd24tY29udGVudFwiPlxuICAgICAgICAgICAgICAgIDxhIGhyZWY9XCIjcHJvZHVjdHMtc2VjdGlvblwiIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYignQWNjb3VudHMnKX0+U2F2aW5ncyBBY2NvdW50czwvYT5cbiAgICAgICAgICAgICAgICA8YSBocmVmPVwiI3Byb2R1Y3RzLXNlY3Rpb25cIiBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoJ0xvYW5zJyl9PkhvbWUgTG9hbnM8L2E+XG4gICAgICAgICAgICAgICAgPGEgaHJlZj1cIiNwcm9kdWN0cy1zZWN0aW9uXCIgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKCdDYXJkcycpfT5DcmVkaXQgQ2FyZHM8L2E+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm5hdi1pdGVtLWRyb3Bkb3duXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm5hdi1kcm9wLWxhYmVsXCI+e3QubmF2X2J1c2luZXNzfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJuYXYtZHJvcGRvd24tY29udGVudFwiPlxuICAgICAgICAgICAgICAgIDxhIGhyZWY9XCIjcHJvZHVjdHMtc2VjdGlvblwiIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYignQWNjb3VudHMnKX0+Q3VycmVudCBBY2NvdW50czwvYT5cbiAgICAgICAgICAgICAgICA8YSBocmVmPVwiI3Byb2R1Y3RzLXNlY3Rpb25cIiBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoJ0RlcG9zaXRzJyl9PkZpeGVkIFRlcm0gRGVwb3NpdHM8L2E+XG4gICAgICAgICAgICAgICAgPGEgaHJlZj1cIiNwcm9kdWN0cy1zZWN0aW9uXCIgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKCdMb2FucycpfT5CdXNpbmVzcyBPdmVyZHJhZnRzPC9hPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJuYXYtaXRlbS1kcm9wZG93blwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJuYXYtZHJvcC1sYWJlbFwiPnt0Lm5hdl9hZ3JpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJuYXYtZHJvcGRvd24tY29udGVudFwiPlxuICAgICAgICAgICAgICAgIDxhIGhyZWY9XCIjcHJvZHVjdHMtc2VjdGlvblwiIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYignTG9hbnMnKX0+Q3JvcCBHb2xkIExvYW5zPC9hPlxuICAgICAgICAgICAgICAgIDxhIGhyZWY9XCIjcHJvZHVjdHMtc2VjdGlvblwiIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYignTG9hbnMnKX0+VHJhY3RvciBGaW5hbmNlPC9hPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPExpbmsgdG89XCIvY29udGFjdFwiIGNsYXNzTmFtZT1cIm5hdi1kaXJlY3QtbGlua1wiPnt0Lm5hdl9hYm91dH08L0xpbms+XG4gICAgICAgICAgPC9uYXY+XG5cbiAgICAgICAgICB7LyogU2VhcmNoIGJhciBpbnNpZGUgaGVhZGVyICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVhZGVyLXNlYXJjaC1jb250YWluZXJcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VhcmNoLWlucHV0LXdyYXBwZXJcIj5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgcmVmPXtzZWFyY2hJbnB1dFJlZn1cbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e3Quc2VhcmNoX3BsYWNlaG9sZGVyfVxuICAgICAgICAgICAgICAgIHZhbHVlPXtzZWFyY2hRdWVyeX1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcbiAgICAgICAgICAgICAgICAgIHNldFNlYXJjaFF1ZXJ5KGUudGFyZ2V0LnZhbHVlKTtcbiAgICAgICAgICAgICAgICAgIHNldFNob3dTdWdnZXN0aW9ucyhlLnRhcmdldC52YWx1ZS5sZW5ndGggPiAwKTtcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgIG9uRm9jdXM9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgIGlmIChzZWFyY2hRdWVyeS5sZW5ndGggPiAwKSBzZXRTaG93U3VnZ2VzdGlvbnModHJ1ZSk7XG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICBvbktleURvd249eyhlKSA9PiB7XG4gICAgICAgICAgICAgICAgICBpZiAoZS5rZXkgPT09ICdFbnRlcicpIHRyaWdnZXJTZWFyY2goc2VhcmNoUXVlcnkpO1xuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGVhZGVyLXNlYXJjaC1pbnB1dFwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDxTZWFyY2ggc2l6ZT17MTZ9IGNsYXNzTmFtZT1cInNlYXJjaC1pY29uXCIgb25DbGljaz17KCkgPT4gdHJpZ2dlclNlYXJjaChzZWFyY2hRdWVyeSl9IC8+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAge3Nob3dTdWdnZXN0aW9ucyAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VhcmNoLXN1Z2dlc3Rpb25zLW92ZXJsYXlcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN1Z2dlc3Rpb24taXRlbVwiIG9uQ2xpY2s9eygpID0+IGhhbmRsZVBpbGxDbGljaygnR29sZCBMb2FuJyl9PkdvbGQgTG9hbiBSYXRlczwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3VnZ2VzdGlvbi1pdGVtXCIgb25DbGljaz17KCkgPT4gaGFuZGxlUGlsbENsaWNrKCdTYXZpbmdzIEFjY291bnQnKX0+U2F2aW5ncyBBY2NvdW50IERldGFpbHM8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN1Z2dlc3Rpb24taXRlbVwiIG9uQ2xpY2s9eygpID0+IGhhbmRsZVBpbGxDbGljaygnU3BlY2lhbCBPZmZlcnMnKX0+U3BlY2lhbCBDYXNoYmFjayBPZmZlcnM8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN1Z2dlc3Rpb24taXRlbVwiIG9uQ2xpY2s9eygpID0+IGhhbmRsZVBpbGxDbGljaygnSG9tZSBMb2FuJyl9PkhvbWUgTG9hbiBDYWxjdWxhdG9yPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGFuZGluZy1uYXYtYWN0aW9uc1wiPlxuICAgICAgICAgICAge2lzTG9nZ2VkSW4gPyAoXG4gICAgICAgICAgICAgIDxMaW5rIHRvPVwiL2Rhc2hib2FyZFwiIGNsYXNzTmFtZT1cImJ0bi1uYXYtc2lnbnVwXCI+e3QuZGFzaGJvYXJkfTwvTGluaz5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgPExpbmsgdG89XCIvbG9naW5cIiBjbGFzc05hbWU9XCJidG4tbmF2LWxvZ2luXCI+e3QubG9naW59PC9MaW5rPlxuICAgICAgICAgICAgICAgIDxMaW5rIHRvPVwiL3JlZ2lzdGVyXCIgY2xhc3NOYW1lPVwiYnRuLW5hdi1zaWdudXBcIj57dC5zaWdudXB9PC9MaW5rPlxuICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9oZWFkZXI+XG5cbiAgICAgIHsvKiBTRUFSQ0ggUkVTVUxUIE9WRVJMQVkgQ0FSRCAqL31cbiAgICAgIHtzZWFyY2hSZXN1bHQgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlYXJjaC1yZXN1bHQtYmFubmVyLWNvbnRhaW5lclwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VhcmNoLXJlc3VsdC1iYW5uZXIgYW5pbWF0ZS1zbGlkZVwiPlxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGp1c3RpZnlDb250ZW50OiAnc3BhY2UtYmV0d2VlbicsIGFsaWduSXRlbXM6ICdmbGV4LXN0YXJ0JyB9fT5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzZWFyY2gtcmVzdWx0LWJhZGdlXCI+PFNwYXJrbGVzIHNpemU9ezEyfSAvPiB7bGFuZ3VhZ2UgPT09ICdlbicgPyBcIk1hdGNoIEZvdW5kXCIgOiBcIuCkruCliOCkmiDgpK7gpL/gpLLgpL5cIn08L3NwYW4+XG4gICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInNlYXJjaC1yZXN1bHQtdGl0bGVcIj57c2VhcmNoUmVzdWx0LnRpdGxlfTwvaDQ+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwic2VhcmNoLXJlc3VsdC1kZXNjXCI+e3NlYXJjaFJlc3VsdC5kZXNjfTwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuLWNsb3NlLXNlYXJjaFwiIG9uQ2xpY2s9eygpID0+IHNldFNlYXJjaFJlc3VsdChudWxsKX0+PFggc2l6ZT17MTh9IC8+PC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luVG9wOiAnMXJlbScsIGRpc3BsYXk6ICdmbGV4JywgZ2FwOiAnMXJlbScgfX0+XG4gICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuLXByaW1hcnlcIiBzdHlsZT17eyBwYWRkaW5nOiAnMC42cmVtIDEuMjVyZW0nLCBmb250U2l6ZTogJzAuOXJlbScgfX0gb25DbGljaz17KCkgPT4geyBzZWFyY2hSZXN1bHQuYWN0aW9uKCk7IHNldFNlYXJjaFJlc3VsdChudWxsKTsgfX0+XG4gICAgICAgICAgICAgICAge3NlYXJjaFJlc3VsdC5idG5UZXh0fVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4tc2Vjb25kYXJ5XCIgc3R5bGU9e3sgcGFkZGluZzogJzAuNnJlbSAxLjI1cmVtJywgZm9udFNpemU6ICcwLjlyZW0nIH19IG9uQ2xpY2s9eygpID0+IHNldFNlYXJjaFJlc3VsdChudWxsKX0+XG4gICAgICAgICAgICAgICAge2xhbmd1YWdlID09PSAnZW4nID8gXCJDbGVhciBTZWFyY2hcIiA6IFwi4KSW4KWL4KScIOCkuOCkvuCkq+CkvCDgpJXgpLDgpYfgpIJcIn1cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogUVVJQ0sgU1VHR0VTVElPTlMgUElMTFMgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInF1aWNrLXN1Z2dlc3Rpb25zLWJhclwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInF1aWNrLXN1Z2dlc3Rpb25zLWNvbnRhaW5lclwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInN1Z2dlc3Rpb24tbGFiZWxcIj48SW5mbyBzaXplPXsxNH0gLz4ge3QucXVpY2tfc3VnZ2VzdGlvbnN9Ojwvc3Bhbj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN1Z2dlc3Rpb24tcGlsbHNcIj5cbiAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwicGlsbC1idG5cIiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVQaWxsQ2xpY2soJ0RpZ2l0YWwgU2F2aW5ncyBBY2NvdW50Jyl9PntsYW5ndWFnZSA9PT0gJ2VuJyA/IFwiRGlnaXRhbCBTYXZpbmdzXCIgOiBcIuCkoeCkv+CknOCkv+Ckn+CksiDgpKzgpJrgpKRcIn08L2J1dHRvbj5cbiAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwicGlsbC1idG5cIiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVQaWxsQ2xpY2soJ0dvbGQgTG9hbicpfT57bGFuZ3VhZ2UgPT09ICdlbicgPyBcIkdvbGQgTG9hbiBAIDcuMjAlXCIgOiBcIuCkl+Cli+CksuCljeCkoSDgpLLgpYvgpKggQCA3LjIwJVwifTwvYnV0dG9uPlxuICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJwaWxsLWJ0blwiIG9uQ2xpY2s9eygpID0+IGhhbmRsZVBpbGxDbGljaygnSG9tZSBMb2FuJyl9PntsYW5ndWFnZSA9PT0gJ2VuJyA/IFwiSG9tZSBMb2FuIDcuMjAlXCIgOiBcIuCkueCli+CkriDgpLLgpYvgpKggNy4yMCVcIn08L2J1dHRvbj5cbiAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwicGlsbC1idG5cIiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVQaWxsQ2xpY2soJ09mZmVycycpfT57bGFuZ3VhZ2UgPT09ICdlbicgPyBcIlNwZWNpYWwgT2ZmZXJzXCIgOiBcIuCkteCkv+CktuClh+CktyDgpJHgpKvgpLBcIn08L2J1dHRvbj5cbiAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwicGlsbC1idG5cIiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVQaWxsQ2xpY2soJ0ludGVyZXN0IFJhdGVzJyl9PntsYW5ndWFnZSA9PT0gJ2VuJyA/IFwiSW50ZXJlc3QgUmF0ZXNcIiA6IFwi4KSs4KWN4KSv4KS+4KScIOCkpuCksOClh+CkglwifTwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogV0hBVCdTIE5FVyBDQVJPVVNFTCAvIFNMSURFUiAqL31cbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cIndoYXRzLW5ldy1zZWN0aW9uIGFuaW1hdGUtZmFkZVwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIndoYXRzLW5ldy1jb250YWluZXJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIndoYXRzLW5ldy1oZWFkZXJcIj5cbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJzZWN0aW9uLXRpdGxlXCI+PFNwYXJrbGVzIHNpemU9ezIwfSBjb2xvcj1cInZhcigtLWxkLXByaW1hcnkpXCIgc3R5bGU9e3sgbWFyZ2luUmlnaHQ6ICcwLjVyZW0nIH19IC8+e3Qud2hhdHNfbmV3X3RpdGxlfTwvaDI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcm91c2VsLW5hdlwiPlxuICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImNhcm91c2VsLW5hdi1idG5cIiBvbkNsaWNrPXsoKSA9PiBzZXRDdXJyZW50U2xpZGUocHJldiA9PiAocHJldiAtIDEgKyBzbGlkZXMubGVuZ3RoKSAlIHNsaWRlcy5sZW5ndGgpfT48Q2hldnJvbkxlZnQgc2l6ZT17MjB9IC8+PC9idXR0b24+XG4gICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiY2Fyb3VzZWwtbmF2LWJ0blwiIG9uQ2xpY2s9eygpID0+IHNldEN1cnJlbnRTbGlkZShwcmV2ID0+IChwcmV2ICsgMSkgJSBzbGlkZXMubGVuZ3RoKX0+PENoZXZyb25SaWdodCBzaXplPXsyMH0gLz48L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJvdXNlbC12aWV3cG9ydFwiPlxuICAgICAgICAgICAge3NsaWRlcy5tYXAoKHNsaWRlLCBpZHgpID0+IChcbiAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgIGtleT17aWR4fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGNhcm91c2VsLXNsaWRlICR7aWR4ID09PSBjdXJyZW50U2xpZGUgPyAnYWN0aXZlJyA6ICcnfWB9XG4gICAgICAgICAgICAgICAgc3R5bGU9e3sgYmFja2dyb3VuZDogc2xpZGUuYmdHcmFkaWVudCB9fVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbGlkZS1jb250ZW50XCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzbGlkZS1iYWRnZVwiPntzbGlkZS5iYWRnZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwic2xpZGUtdGl0bGVcIj57c2xpZGUudGl0bGV9PC9oMz5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInNsaWRlLWRlc2NcIj57c2xpZGUuZGVzY308L3A+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0bi1zbGlkZS1hY3Rpb25cIiBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHNldEFjdGl2ZU1vZGFsKCdhcHBseScpO1xuICAgICAgICAgICAgICAgICAgICBzZXRBcHBseVByb2R1Y3Qoc2xpZGUudGFyZ2V0KTtcbiAgICAgICAgICAgICAgICAgIH19PlxuICAgICAgICAgICAgICAgICAgICB7c2xpZGUuYnRuVGV4dH0gPEFycm93UmlnaHQgc2l6ZT17MTZ9IC8+XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNsaWRlLXZpc3VhbFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ2aXN1YWwtY2lyY2xlLWRlY29yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxUcmVuZGluZ1VwIHNpemU9ezgwfSBjb2xvcj1cInJnYmEoMjU1LDI1NSwyNTUsMC4xNSlcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcm91c2VsLWluZGljYXRvcnNcIj5cbiAgICAgICAgICAgIHtzbGlkZXMubWFwKChfLCBpZHgpID0+IChcbiAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICBrZXk9e2lkeH1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BpbmRpY2F0b3ItZG90ICR7aWR4ID09PSBjdXJyZW50U2xpZGUgPyAnYWN0aXZlJyA6ICcnfWB9XG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Q3VycmVudFNsaWRlKGlkeCl9XG4gICAgICAgICAgICAgID48L3NwYW4+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L3NlY3Rpb24+XG5cbiAgICAgIHsvKiBIRVJPIFNFQ1RJT04gKi99XG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJoZXJvLXNlY3Rpb25cIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoZXJvLWNvbnRlbnQgYW5pbWF0ZS1zbGlkZVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVyby10YWdcIj5cbiAgICAgICAgICAgIDxaYXAgc2l6ZT17MTR9IC8+IHt0Lmhlcm9fdGFnfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJoZXJvLXRpdGxlXCI+XG4gICAgICAgICAgICB7dC5oZXJvX3RpdGxlXzF9IDxiciAvPlxuICAgICAgICAgICAge3QuaGVyb190aXRsZV8yfVxuICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwiaGVyby1kZXNjXCI+XG4gICAgICAgICAgICB7dC5oZXJvX2Rlc2N9XG4gICAgICAgICAgPC9wPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVyby1jdGFzXCI+XG4gICAgICAgICAgICB7aXNMb2dnZWRJbiA/IChcbiAgICAgICAgICAgICAgPExpbmsgdG89XCIvZGFzaGJvYXJkXCIgY2xhc3NOYW1lPVwiYnRuLXByaW1hcnlcIj5cbiAgICAgICAgICAgICAgICB7dC5kYXNoYm9hcmR9IDxBcnJvd1JpZ2h0IHNpemU9ezE4fSAvPlxuICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgIDxMaW5rIHRvPVwiL3JlZ2lzdGVyXCIgY2xhc3NOYW1lPVwiYnRuLXByaW1hcnlcIj5cbiAgICAgICAgICAgICAgICAgIHt0Lm9wZW5fYWNjb3VudH0gPEFycm93UmlnaHQgc2l6ZT17MTh9IC8+XG4gICAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICAgIDxMaW5rIHRvPVwiL2xvZ2luXCIgY2xhc3NOYW1lPVwiYnRuLXNlY29uZGFyeVwiPlxuICAgICAgICAgICAgICAgICAgPFBsYXkgc2l6ZT17MTZ9IGZpbGw9XCJjdXJyZW50Q29sb3JcIiAvPiB7dC5zaWduX2lufVxuICAgICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhlcm8tbWVkaWFcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInZpc3VhbC1jYXJkcy1jb250YWluZXJcIj5cbiAgICAgICAgICAgIHsvKiBNYWluIFByZW1pdW0gQ2FyZCBWaXN1YWwgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhlcm8tbWFpbi1jYXJkXCI+XG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBqdXN0aWZ5Q29udGVudDogJ3NwYWNlLWJldHdlZW4nLCBhbGlnbkl0ZW1zOiAnY2VudGVyJyB9fT5cbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiAnMC44cmVtJywgY29sb3I6ICcjYzA4NGZjJywgbGV0dGVyU3BhY2luZzogJzAuMWVtJywgZm9udFdlaWdodDogNjAwIH19Pnt0LnBsYXRpbnVtX3ByZXN0aWdlfTwvZGl2PlxuICAgICAgICAgICAgICAgIDxaYXAgc2l6ZT17MjJ9IGNvbG9yPVwiI2MwODRmY1wiIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiAnMS40cmVtJywgZm9udFdlaWdodDogNzAwLCBjb2xvcjogJyNmZmYnLCBtYXJnaW46ICcxcmVtIDAnIH19PiQ0OCw5NTAuMDA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiAnMC43NXJlbScsIGNvbG9yOiAnI2E3OGJmYScgfX0+e3QuY2FyZF9ob2xkZXJ9PC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogJzAuOXJlbScsIGZvbnRXZWlnaHQ6IDYwMCwgY29sb3I6ICcjZmZmJyB9fT5BTEVYIFJBSE1BTjwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogU3ViLWNhcmQgVmlzdWFsICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoZXJvLXN1Yi1jYXJkXCI+XG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBqdXN0aWZ5Q29udGVudDogJ3NwYWNlLWJldHdlZW4nLCBhbGlnbkl0ZW1zOiAnY2VudGVyJyB9fT5cbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiAnMC44cmVtJywgY29sb3I6ICcjZTBmMmZlJywgbGV0dGVyU3BhY2luZzogJzAuMWVtJywgZm9udFdlaWdodDogNjAwIH19Pnt0LmJ1c2luZXNzX3NtYXJ0fTwvZGl2PlxuICAgICAgICAgICAgICAgIDxDcmVkaXRDYXJkIHNpemU9ezIyfSBjb2xvcj1cIiMzOGJkZjhcIiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogJzEuMjVyZW0nLCBmb250V2VpZ2h0OiA3MDAsIGNvbG9yOiAnI2ZmZicsIG1hcmdpbjogJzAuOHJlbSAwJyB9fT4kMTIsNDAwLjAwPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogJzAuNzVyZW0nLCBjb2xvcjogJyM3ZGQzZmMnIH19Pnt0LmNhcmRfaG9sZGVyfTwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFNpemU6ICcwLjlyZW0nLCBmb250V2VpZ2h0OiA2MDAsIGNvbG9yOiAnI2ZmZicgfX0+QVRJUVVSIFIuPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBGbG9hdGluZyBHbGFzc21vcnBoaWMgV2lkZ2V0cyAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2xhc3Mtd2lkZ2V0IHdpZGdldC1iYWxhbmNlXCI+XG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBnYXA6ICcwLjc1cmVtJywgYWxpZ25JdGVtczogJ2NlbnRlcicgfX0+XG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyB3aWR0aDogJzEwcHgnLCBoZWlnaHQ6ICcxMHB4JywgYm9yZGVyUmFkaXVzOiAnNTAlJywgYmFja2dyb3VuZDogJyMxMGI5ODEnIH19PjwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiAnMC43cmVtJywgY29sb3I6ICd2YXIoLS1sZC10ZXh0LW11dGVkKScgfX0+e3QuaW5jb21lX3N0cmVhbX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFNpemU6ICcwLjlyZW0nLCBmb250V2VpZ2h0OiA3MDAsIGNvbG9yOiAndmFyKC0tbGQtdGV4dC1tYWluKScgfX0+KyQ1LDIzMC4wMDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdsYXNzLXdpZGdldCB3aWRnZXQtYWN0aXZpdHlcIj5cbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGdhcDogJzAuNzVyZW0nLCBhbGlnbkl0ZW1zOiAnY2VudGVyJyB9fT5cbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHBhZGRpbmc6ICcwLjRyZW0nLCBib3JkZXJSYWRpdXM6ICc4cHgnLCBiYWNrZ3JvdW5kOiAncmdiYSg2LCAxODIsIDIxMiwgMC4xKScsIGNvbG9yOiAnIzA2YjZkNCcgfX0+XG4gICAgICAgICAgICAgICAgICA8QWN0aXZpdHkgc2l6ZT17MTZ9IC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFNpemU6ICcwLjdyZW0nLCBjb2xvcjogJ3ZhcigtLWxkLXRleHQtbXV0ZWQpJyB9fT57dC50cmFuc2FjdGlvbnNfc3RhdHVzfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogJzAuODVyZW0nLCBmb250V2VpZ2h0OiA2MDAsIGNvbG9yOiAndmFyKC0tbGQtdGV4dC1tYWluKScgfX0+OTkuOTglIHt0LmFwcHJvdmVkfTwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgey8qIElOVEVSQUNUSVZFIFBST0RVQ1RTIFNIT1dDQVNFIFRBQlMgKi99XG4gICAgICA8c2VjdGlvbiBpZD1cInByb2R1Y3RzLXNlY3Rpb25cIiBjbGFzc05hbWU9XCJmZWF0dXJlcy1zZWN0aW9uXCIgc3R5bGU9e3sgYmFja2dyb3VuZDogJ3JnYmEoMjU1LCAyNTUsIDI1NSwgMC4wMiknLCBib3JkZXJUb3A6ICcxcHggc29saWQgdmFyKC0tbGQtYm9yZGVyKScsIGJvcmRlckJvdHRvbTogJzFweCBzb2xpZCB2YXIoLS1sZC1ib3JkZXIpJyB9fT5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWN0aW9uLWhlYWRcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzZWN0aW9uLXRhZ1wiPntsYW5ndWFnZSA9PT0gJ2VuJyA/IFwiQlJPV1NFIE9VUiBQT1JURk9MSU9cIiA6IFwi4KS54KSu4KS+4KSw4KWHIOCkquCli+CksOCljeCkn+Ckq+Cli+CksuCkv+Ckr+CliyDgpKzgpY3gpLDgpL7gpIngpJzgpLwg4KSV4KSw4KWH4KSCXCJ9PC9zcGFuPlxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJzZWN0aW9uLXRpdGxlXCI+e2xhbmd1YWdlID09PSAnZW4nID8gXCJFeHBsb3JlIEJhbmtpbmcgUHJvZHVjdHNcIiA6IFwi4KSs4KWI4KSC4KSV4KS/4KSC4KSXIOCkieCkpOCljeCkquCkvuCkpuCli+CkgiDgpJXgpL4g4KSF4KSo4KWN4KS14KWH4KS34KSjIOCkleCksOClh+CkglwifTwvaDI+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwic2VjdGlvbi1kZXNjXCI+XG4gICAgICAgICAgICB7bGFuZ3VhZ2UgPT09ICdlbicgPyBcIkNob29zZSBmcm9tIG91ciB3aWRlIHJhbmdlIG9mIHRhaWxvcmVkIGZpbmFuY2lhbCBzb2x1dGlvbnMgZGVzaWduZWQgdG8gc2VydmUgeW91ciBkaXJlY3QgcGVyc29uYWwgb3IgYnVzaW5lc3MgbmVlZHMuXCIgOiBcIuCkheCkquCkqOClgCDgpLXgpY3gpK/gpJXgpY3gpKTgpL/gpJfgpKQg4KSv4KS+IOCkteCljeCkr+CkvuCkteCkuOCkvuCkr+Ckv+CklSDgpIbgpLXgpLbgpY3gpK/gpJXgpKTgpL7gpJPgpIIg4KSV4KWLIOCkquClguCksOCkviDgpJXgpLDgpKjgpYcg4KSV4KWHIOCksuCkv+CkjyDgpLngpK7gpL7gpLDgpYcg4KS14KWN4KSv4KS+4KSq4KSVIOCkteCkv+CkpOCljeCkpOClgOCkryDgpLjgpK7gpL7gpKfgpL7gpKjgpYvgpIIg4KSu4KWH4KSCIOCkuOClhyDgpJrgpYHgpKjgpYfgpILgpaRcIn1cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBUYWIgSGVhZGVycyAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9kdWN0LXRhYi1oZWFkZXJzXCI+XG4gICAgICAgICAge09iamVjdC5rZXlzKHByb2R1Y3RzKS5tYXAodGFiTmFtZSA9PiAoXG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIGtleT17dGFiTmFtZX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHJvZHVjdC10YWItYnRuICR7YWN0aXZlVGFiID09PSB0YWJOYW1lID8gJ2FjdGl2ZScgOiAnJ31gfVxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIodGFiTmFtZSl9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHt0YWJOYW1lID09PSAnQWNjb3VudHMnICYmIDxMYW5kbWFyayBzaXplPXsxNn0gLz59XG4gICAgICAgICAgICAgIHt0YWJOYW1lID09PSAnTG9hbnMnICYmIDxIYW5kQ29pbnMgc2l6ZT17MTZ9IC8+fVxuICAgICAgICAgICAgICB7dGFiTmFtZSA9PT0gJ0NhcmRzJyAmJiA8Q3JlZGl0Q2FyZCBzaXplPXsxNn0gLz59XG4gICAgICAgICAgICAgIHt0YWJOYW1lID09PSAnRGVwb3NpdHMnICYmIDxBY3Rpdml0eSBzaXplPXsxNn0gLz59XG4gICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IG1hcmdpbkxlZnQ6ICcwLjVyZW0nIH19Pnt0W2Bwcm9kdWN0XyR7dGFiTmFtZS50b0xvd2VyQ2FzZSgpfWBdIHx8IHRhYk5hbWV9PC9zcGFuPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBUYWIgY29udGVudCBjYXJkcyBncmlkICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2R1Y3QtY2FyZHMtZ3JpZCBhbmltYXRlLWZhZGVcIj5cbiAgICAgICAgICB7cHJvZHVjdHNbYWN0aXZlVGFiXS5tYXAoKHAsIGlkeCkgPT4gKFxuICAgICAgICAgICAgPGRpdiBrZXk9e2lkeH0gY2xhc3NOYW1lPVwicHJvZHVjdC1zaG93Y2FzZS1jYXJkXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZHVjdC1jYXJkLWhlYWRlclwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInByb2R1Y3QtdGFnLWJhZGdlXCI+PFNwYXJrbGVzIHNpemU9ezEyfSAvPiB7YWN0aXZlVGFifTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwicHJvZHVjdC1jYXJkLXRpdGxlXCI+e3AubmFtZX08L2g0PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwicHJvZHVjdC1jYXJkLWRlc2NcIj57cC5kZXNjfTwvcD5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9kdWN0LWNhcmQtYmVuZWZpdFwiPlxuICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZSBzaXplPXsxNH0gY29sb3I9XCIjMTBiOTgxXCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj57cC5iZW5lZml0fTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZHVjdC1jYXJkLWFjdGlvbnNcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0bi1wcmltYXJ5XCIgc3R5bGU9e3sgcGFkZGluZzogJzAuNXJlbSAxcmVtJywgZm9udFNpemU6ICcwLjg1cmVtJyB9fSBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICBzZXRBY3RpdmVNb2RhbCgnYXBwbHknKTtcbiAgICAgICAgICAgICAgICAgIHNldEFwcGx5UHJvZHVjdChwLm5hbWUpO1xuICAgICAgICAgICAgICAgIH19PlxuICAgICAgICAgICAgICAgICAge3QuYXBwbHlfbm93fVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuLXNlY29uZGFyeVwiIHN0eWxlPXt7IHBhZGRpbmc6ICcwLjVyZW0gMXJlbScsIGZvbnRTaXplOiAnMC44NXJlbScgfX0gb25DbGljaz17KCkgPT4gaGFuZGxlUGlsbENsaWNrKHAubmFtZSl9PlxuICAgICAgICAgICAgICAgICAge3Qua25vd19tb3JlfVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICkpfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgey8qIERZTkFNSUMgS0VZIElOVEVSRVNUIFJBVEVTIFNFQ1RJT04gKi99XG4gICAgICA8c2VjdGlvbiBpZD1cInJhdGVzLXNlY3Rpb25cIiBjbGFzc05hbWU9XCJmZWF0dXJlcy1zZWN0aW9uXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VjdGlvbi1oZWFkXCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic2VjdGlvbi10YWdcIj48UGVyY2VudCBzaXplPXsxNH0gc3R5bGU9e3sgbWFyZ2luUmlnaHQ6ICcwLjNyZW0nIH19IC8+e2xhbmd1YWdlID09PSAnZW4nID8gXCJCRVNUIElOIE1BUktFVCBSQVRFU1wiIDogXCLgpKzgpL7gpJzgpL7gpLAg4KSu4KWH4KSCIOCkuOCksOCljeCkteCli+CkpOCljeCkpOCkriDgpKbgpLDgpYfgpIJcIn08L3NwYW4+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInNlY3Rpb24tdGl0bGVcIj57dC5pbnRlcmVzdF9yYXRlc190aXRsZX08L2gyPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInNlY3Rpb24tZGVzY1wiPnt0LmludGVyZXN0X3JhdGVzX2Rlc2N9PC9wPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImludGVyZXN0LXJhdGVzLWdyaWRcIj5cbiAgICAgICAgICB7LyogUmF0ZSBjYXJkIDE6IEhvbWUgTG9hbiAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJhdGUtY2FyZC1pdGVtIGN1cnNvci1wb2ludGVyXCIgb25DbGljaz17KCkgPT4gaGFuZGxlUmF0ZUNhcmRDbGljayg3LjIwLCA1MDAwMCwgXCJIb21lIExvYW5cIil9PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyYXRlLWNhcmQtaGVhZFwiPlxuICAgICAgICAgICAgICA8TGFuZG1hcmsgc2l6ZT17MjB9IGNvbG9yPVwidmFyKC0tbGQtcHJpbWFyeSlcIiAvPlxuICAgICAgICAgICAgICA8aDU+e2xhbmd1YWdlID09PSAnZW4nID8gXCJIb21lIExvYW5cIiA6IFwi4KS54KWL4KSuIOCksuCli+CkqFwifTwvaDU+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmF0ZS1jYXJkLWJvZHlcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmF0ZS1udW1iZXJcIj43LjIwJSA8c3BhbiBjbGFzc05hbWU9XCJyYXRlLXN1ZmZpeFwiPnAuYS48L3NwYW4+PC9zcGFuPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJyYXRlLWRlc2NcIj57bGFuZ3VhZ2UgPT09ICdlbicgPyBcIlN0YXJ0aW5nIGludGVyZXN0IHJhdGUuIENsaWNrIHRvIHByZWZpbGwgY2FsY3VsYXRvci5cIiA6IFwi4KSq4KWN4KSw4KS+4KSw4KSC4KSt4KS/4KSVIOCkrOCljeCkr+CkvuCknCDgpKbgpLDgpaQg4KSV4KWI4KSy4KSV4KWB4KSy4KWH4KSf4KSwIOCkreCksOCkqOClhyDgpJXgpYcg4KSy4KS/4KSPIOCkleCljeCksuCkv+CklSDgpJXgpLDgpYfgpILgpaRcIn08L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBSYXRlIGNhcmQgMjogQ2FyIExvYW4gKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyYXRlLWNhcmQtaXRlbSBjdXJzb3ItcG9pbnRlclwiIG9uQ2xpY2s9eygpID0+IGhhbmRsZVJhdGVDYXJkQ2xpY2soNy44MCwgMjAwMDAsIFwiQ2FyIExvYW5cIil9PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyYXRlLWNhcmQtaGVhZFwiPlxuICAgICAgICAgICAgICA8WmFwIHNpemU9ezIwfSBjb2xvcj1cInZhcigtLWxkLXNlY29uZGFyeSlcIiAvPlxuICAgICAgICAgICAgICA8aDU+e2xhbmd1YWdlID09PSAnZW4nID8gXCJDYXIgTG9hblwiIDogXCLgpJXgpL7gpLAg4KSy4KWL4KSoXCJ9PC9oNT5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyYXRlLWNhcmQtYm9keVwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyYXRlLW51bWJlclwiPjcuODAlIDxzcGFuIGNsYXNzTmFtZT1cInJhdGUtc3VmZml4XCI+cC5hLjwvc3Bhbj48L3NwYW4+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInJhdGUtZGVzY1wiPntsYW5ndWFnZSA9PT0gJ2VuJyA/IFwiRm9yIGJyYW5kIG5ldyB2ZWhpY2xlcy4gQ2xpY2sgdG8gcHJlZmlsbCBjYWxjdWxhdG9yLlwiIDogXCLgpLXgpL7gpLngpKjgpYvgpIIg4KSV4KWHIOCksuCkv+Ckj+ClpCDgpJXgpYjgpLLgpJXgpYHgpLLgpYfgpJ/gpLAg4KSt4KSw4KSo4KWHIOCkleClhyDgpLLgpL/gpI8g4KSV4KWN4KSy4KS/4KSVIOCkleCksOClh+CkguClpFwifTwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIFJhdGUgY2FyZCAzOiBFZHVjYXRpb24gTG9hbiAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJhdGUtY2FyZC1pdGVtIGN1cnNvci1wb2ludGVyXCIgb25DbGljaz17KCkgPT4gaGFuZGxlUmF0ZUNhcmRDbGljayg4Ljg1LCAzMDAwMCwgXCJFZHVjYXRpb24gTG9hblwiKX0+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJhdGUtY2FyZC1oZWFkXCI+XG4gICAgICAgICAgICAgIDxVc2VycyBzaXplPXsyMH0gY29sb3I9XCJ2YXIoLS1sZC1hY2NlbnQpXCIgLz5cbiAgICAgICAgICAgICAgPGg1PntsYW5ndWFnZSA9PT0gJ2VuJyA/IFwiRWR1Y2F0aW9uIExvYW5cIiA6IFwi4KS24KS/4KSV4KWN4KS34KS+IOCki+Cko1wifTwvaDU+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmF0ZS1jYXJkLWJvZHlcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmF0ZS1udW1iZXJcIj44Ljg1JSA8c3BhbiBjbGFzc05hbWU9XCJyYXRlLXN1ZmZpeFwiPnAuYS48L3NwYW4+PC9zcGFuPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJyYXRlLWRlc2NcIj57bGFuZ3VhZ2UgPT09ICdlbicgPyBcIkZvciBoaWdoZXIgc3R1ZGllcyB3b3JsZHdpZGUuIENsaWNrIHRvIHByZWZpbGwgY2FsY3VsYXRvci5cIiA6IFwi4KSJ4KSa4KWN4KSaIOCktuCkv+CkleCljeCkt+CkviDgpJXgpYcg4KSy4KS/4KSP4KWkIOCkleCliOCksuCkleClgeCksuClh+Ckn+CksCDgpK3gpLDgpKjgpYcg4KSV4KWHIOCksuCkv+CkjyDgpJXgpY3gpLLgpL/gpJUg4KSV4KSw4KWH4KSC4KWkXCJ9PC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogUmF0ZSBjYXJkIDQ6IFBlcnNvbmFsIExvYW4gKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyYXRlLWNhcmQtaXRlbSBjdXJzb3ItcG9pbnRlclwiIG9uQ2xpY2s9eygpID0+IGhhbmRsZVJhdGVDYXJkQ2xpY2soMTAuMTUsIDEwMDAwLCBcIlBlcnNvbmFsIExvYW5cIil9PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyYXRlLWNhcmQtaGVhZFwiPlxuICAgICAgICAgICAgICA8Q3JlZGl0Q2FyZCBzaXplPXsyMH0gY29sb3I9XCIjZWM0ODk5XCIgLz5cbiAgICAgICAgICAgICAgPGg1PntsYW5ndWFnZSA9PT0gJ2VuJyA/IFwiUGVyc29uYWwgTG9hblwiIDogXCLgpLXgpY3gpK/gpJXgpY3gpKTgpL/gpJfgpKQg4KSL4KSjXCJ9PC9oNT5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyYXRlLWNhcmQtYm9keVwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyYXRlLW51bWJlclwiPjEwLjE1JSA8c3BhbiBjbGFzc05hbWU9XCJyYXRlLXN1ZmZpeFwiPnAuYS48L3NwYW4+PC9zcGFuPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJyYXRlLWRlc2NcIj57bGFuZ3VhZ2UgPT09ICdlbicgPyBcIlF1aWNrIGRpZ2l0YWwgcGVyc29uYWwgY3JlZGl0LiBDbGljayB0byBwcmVmaWxsIGNhbGN1bGF0b3IuXCIgOiBcIuCkpOCljeCkteCksOCkv+CkpCDgpKHgpL/gpJzgpL/gpJ/gpLIg4KSV4KWN4KSw4KWH4KSh4KS/4KSf4KWkIOCkleCliOCksuCkleClgeCksuClh+Ckn+CksCDgpK3gpLDgpKjgpYcg4KSV4KWHIOCksuCkv+CkjyDgpJXgpY3gpLLgpL/gpJUg4KSV4KSw4KWH4KSC4KWkXCJ9PC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICB7LyogSU5URVJBQ1RJVkUgQ0FMQ1VMQVRPUiBTRUNUSU9OICovfVxuICAgICAgPHNlY3Rpb24gaWQ9XCJjYWxjdWxhdG9yXCIgY2xhc3NOYW1lPVwiZmVhdHVyZXMtc2VjdGlvblwiIHN0eWxlPXt7IGJhY2tncm91bmQ6ICdyZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMDEpJywgYm9yZGVyVG9wOiAnMXB4IHNvbGlkIHZhcigtLWxkLWJvcmRlciknLCBib3JkZXJCb3R0b206ICcxcHggc29saWQgdmFyKC0tbGQtYm9yZGVyKScgfX0+XG4gICAgICAgIDxkaXYgc3R5bGU9e3sgbWF4V2lkdGg6ICcxMTAwcHgnLCBtYXJnaW46ICcwIGF1dG8nLCBkaXNwbGF5OiAnZ3JpZCcsIGdyaWRUZW1wbGF0ZUNvbHVtbnM6ICcxZnIgMWZyJywgZ2FwOiAnNHJlbScsIGFsaWduSXRlbXM6ICdjZW50ZXInIH19PlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzZWN0aW9uLXRhZ1wiPnt0LmNhbGNfc2VjdGlvbl90YWd9PC9zcGFuPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInNlY3Rpb24tdGl0bGVcIj57dC5jYWxjX3NlY3Rpb25fdGl0bGV9PC9oMj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInNlY3Rpb24tZGVzY1wiIHN0eWxlPXt7IG1hcmdpbkJvdHRvbTogJzJyZW0nIH19PlxuICAgICAgICAgICAgICB7dC5jYWxjX3NlY3Rpb25fZGVzY31cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBmbGV4RGlyZWN0aW9uOiAnY29sdW1uJywgZ2FwOiAnMXJlbScgfX0+XG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBnYXA6ICcwLjc1cmVtJywgYWxpZ25JdGVtczogJ2NlbnRlcicgfX0+XG4gICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlIHNpemU9ezE4fSBjb2xvcj1cIiMxMGI5ODFcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiAnMC45NXJlbScsIGZvbnRXZWlnaHQ6IDUwMCB9fT57dC5jYWxjX2l0ZW1fMX08L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgZ2FwOiAnMC43NXJlbScsIGFsaWduSXRlbXM6ICdjZW50ZXInIH19PlxuICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZSBzaXplPXsxOH0gY29sb3I9XCIjMTBiOTgxXCIgLz5cbiAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogJzAuOTVyZW0nLCBmb250V2VpZ2h0OiA1MDAgfX0+e3QuY2FsY19pdGVtXzJ9PC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGdhcDogJzAuNzVyZW0nLCBhbGlnbkl0ZW1zOiAnY2VudGVyJyB9fT5cbiAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUgc2l6ZT17MTh9IGNvbG9yPVwiIzEwYjk4MVwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFNpemU6ICcwLjk1cmVtJywgZm9udFdlaWdodDogNTAwIH19Pnt0LmNhbGNfaXRlbV8zfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhbGMtY2FyZFwiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiY2FsYy10aXRsZVwiPnt0LmNhbGNfY2FyZF90aXRsZX08L2gzPlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FsYy1ncm91cFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBqdXN0aWZ5Q29udGVudDogJ3NwYWNlLWJldHdlZW4nIH19PlxuICAgICAgICAgICAgICAgICAgPGxhYmVsPnt0LmNhbGNfbGFiZWxfcHJpbmNpcGFsfTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjYWxjLXZhbC1pbmRpY2F0b3JcIj4ke051bWJlcihjYWxjQW1vdW50KS50b0xvY2FsZVN0cmluZygpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJyYW5nZVwiXG4gICAgICAgICAgICAgICAgICBtaW49XCI1MDAwXCJcbiAgICAgICAgICAgICAgICAgIG1heD1cIjI1MDAwMFwiXG4gICAgICAgICAgICAgICAgICBzdGVwPVwiNTAwMFwiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjYWxjLXJhbmdlLXNsaWRlclwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Y2FsY0Ftb3VudH1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q2FsY0Ftb3VudChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYWxjLWdyb3VwXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGp1c3RpZnlDb250ZW50OiAnc3BhY2UtYmV0d2VlbicgfX0+XG4gICAgICAgICAgICAgICAgICA8bGFiZWw+e3QuY2FsY19sYWJlbF9yYXRlfTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjYWxjLXZhbC1pbmRpY2F0b3JcIj57Y2FsY1JhdGV9JTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJyYW5nZVwiXG4gICAgICAgICAgICAgICAgICBtaW49XCI1XCJcbiAgICAgICAgICAgICAgICAgIG1heD1cIjE4XCJcbiAgICAgICAgICAgICAgICAgIHN0ZXA9XCIwLjFcIlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY2FsYy1yYW5nZS1zbGlkZXJcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2NhbGNSYXRlfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDYWxjUmF0ZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYWxjLWdyb3VwXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGp1c3RpZnlDb250ZW50OiAnc3BhY2UtYmV0d2VlbicgfX0+XG4gICAgICAgICAgICAgICAgICA8bGFiZWw+e3QuY2FsY19sYWJlbF9kdXJhdGlvbn08L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2FsYy12YWwtaW5kaWNhdG9yXCI+e2NhbGNUZXJtfSBNb250aHM8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwicmFuZ2VcIlxuICAgICAgICAgICAgICAgICAgbWluPVwiMTJcIlxuICAgICAgICAgICAgICAgICAgbWF4PVwiMTIwXCJcbiAgICAgICAgICAgICAgICAgIHN0ZXA9XCIxMlwiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjYWxjLXJhbmdlLXNsaWRlclwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Y2FsY1Rlcm19XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldENhbGNUZXJtKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhbGMtcmVzdWx0XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogJzAuOHJlbScsIGNvbG9yOiAndmFyKC0tbGQtdGV4dC1tdXRlZCknLCBtYXJnaW5Cb3R0b206ICcwLjI1cmVtJyB9fT57dC5jYWxjX21vbnRobHlfcGF5bWVudH08L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhbGMtdmFsXCI+JHtjYWxjdWxhdGVJbnN0YWxsbWVudCgpfSA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogJzFyZW0nLCBmb250V2VpZ2h0OiA1MDAsIGNvbG9yOiAndmFyKC0tbGQtdGV4dC1tdXRlZCknIH19Pnt0LnBlcl9tb250aH08L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICB7LyogU1BFQ0lBTCBPRkZFUlMgU0VDVElPTiAqL31cbiAgICAgIDxzZWN0aW9uIGlkPVwib2ZmZXJzLXNlY3Rpb25cIiBjbGFzc05hbWU9XCJmZWF0dXJlcy1zZWN0aW9uXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VjdGlvbi1oZWFkXCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic2VjdGlvbi10YWdcIj48U3BhcmtsZXMgc2l6ZT17MTR9IHN0eWxlPXt7IG1hcmdpblJpZ2h0OiAnMC4zcmVtJyB9fSAvPntsYW5ndWFnZSA9PT0gJ2VuJyA/IFwiUFJPTU9USU9OUyAmIFJFV0FSRFNcIiA6IFwi4KSq4KWN4KSw4KSa4KS+4KSwIOCklOCksCDgpKrgpYHgpLDgpLjgpY3gpJXgpL7gpLBcIn08L3NwYW4+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInNlY3Rpb24tdGl0bGVcIj57dC5zcGVjaWFsX29mZmVyc190aXRsZX08L2gyPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInNlY3Rpb24tZGVzY1wiPnt0LnNwZWNpYWxfb2ZmZXJzX2Rlc2N9PC9wPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwZWNpYWwtb2ZmZXJzLWdyaWRcIj5cbiAgICAgICAgICB7LyogQ2FyZCAxICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib2ZmZXItY2FyZC1pdGVtXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm9mZmVyLWJhZGdlXCI+MTAlIE9GRjwvZGl2PlxuICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cIm9mZmVyLXRpdGxlXCI+e2xhbmd1YWdlID09PSAnZW4nID8gXCJJbnN0YW50IERpc2NvdW50IG9uIFRyYXZlbCAmIEZsaWdodHNcIiA6IFwi4KSv4KS+4KSk4KWN4KSw4KS+IOCklOCksCDgpIngpKHgpLzgpL7gpKjgpYvgpIIg4KSq4KSwIOCkpOCljeCkteCksOCkv+CkpCDgpJvgpYLgpJ9cIn08L2g0PlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwib2ZmZXItZGVzY1wiPntsYW5ndWFnZSA9PT0gJ2VuJyA/IFwiR2V0IDEwJSBpbnN0YW50IGRpc2NvdW50IHVwIHRvICQxMDAgb24gZmxpZ2h0IGJvb2tpbmdzIHVzaW5nIEJhbmtEYXNoIFNpZ25hdHVyZSBDYXJkcy5cIiA6IFwi4KSs4KWI4KSC4KSV4KSh4KWI4KS2IOCkuOCkv+Ckl+CljeCkqOClh+CkmuCksCDgpJXgpL7gpLDgpY3gpKHgpY3gpLgg4KSV4KS+IOCkieCkquCkr+Cli+CklyDgpJXgpLDgpJXgpYcg4KSr4KWN4KSy4KS+4KSH4KSfIOCkrOClgeCkleCkv+CkguCklyDgpKrgpLAgJDEwMCDgpKTgpJUgMTAlIOCkpOCljeCkteCksOCkv+CkpCDgpJvgpYLgpJ8g4KSq4KWN4KSw4KS+4KSq4KWN4KSkIOCkleCksOClh+CkguClpFwifTwvcD5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib2ZmZXItZm9vdGVyXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNvdXBvbi1jb2RlXCI+Q09ERTogPGI+REFTSFRSQVZFTDwvYj48L3NwYW4+XG4gICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuLXNlY29uZGFyeVwiIHN0eWxlPXt7IHBhZGRpbmc6ICcwLjRyZW0gMC44cmVtJywgZm9udFNpemU6ICcwLjhyZW0nIH19IG9uQ2xpY2s9eygpID0+IGhhbmRsZVBpbGxDbGljaygnT2ZmZXJzJyl9Pnt0LmFwcGx5X25vd308L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIENhcmQgMiAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm9mZmVyLWNhcmQtaXRlbVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvZmZlci1iYWRnZVwiPjE1JSBDQVNIQkFDSzwvZGl2PlxuICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cIm9mZmVyLXRpdGxlXCI+e2xhbmd1YWdlID09PSAnZW4nID8gXCJCdXkgMiBQcm9kdWN0cyAmIEdldCBHcm9jZXJ5IENhc2hiYWNrXCIgOiBcIjIg4KSJ4KSk4KWN4KSq4KS+4KSmIOCkluCksOClgOCkpuClh+CkgiDgpJTgpLAg4KSV4KS/4KSw4KS+4KSo4KS+IOCkleCliOCktuCkrOCliOCklSDgpKrgpY3gpLDgpL7gpKrgpY3gpKQg4KSV4KSw4KWH4KSCXCJ9PC9oND5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm9mZmVyLWRlc2NcIj57bGFuZ3VhZ2UgPT09ICdlbicgPyBcIlNob3Agb24gcGFydG5lcmVkIHN1cGVybWFya2V0cyBhbmQgdW5sb2NrIGZsYXQgMTUlIGNhc2hiYWNrIGNyZWRpdGVkIGRpcmVjdGx5IHRvIHNhdmluZ3MuXCIgOiBcIuCkuOCkvuCkneClh+CkpuCkvuCksCDgpLjgpYHgpKrgpLDgpK7gpL7gpLDgpY3gpJXgpYfgpJ8g4KSu4KWH4KSCIOCkluCksOClgOCkpuCkvuCksOClgCDgpJXgpLDgpYfgpIIg4KSU4KSwIOCkrOCkmuCkpCDgpJbgpL7gpKTgpYcg4KSu4KWH4KSCIOCkuOClgOCkp+ClhyDgpJzgpK7gpL4g4KSV4KS/4KSPIOCkl+CkjyAxNSUg4KSV4KWI4KS24KSs4KWI4KSVIOCkleCliyDgpIXgpKjgpLLgpYngpJUg4KSV4KSw4KWH4KSC4KWkXCJ9PC9wPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvZmZlci1mb290ZXJcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY291cG9uLWNvZGVcIj5DT0RFOiA8Yj5EQVNITUFSVDE1PC9iPjwvc3Bhbj5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4tc2Vjb25kYXJ5XCIgc3R5bGU9e3sgcGFkZGluZzogJzAuNHJlbSAwLjhyZW0nLCBmb250U2l6ZTogJzAuOHJlbScgfX0gb25DbGljaz17KCkgPT4gaGFuZGxlUGlsbENsaWNrKCdPZmZlcnMnKX0+e3QuYXBwbHlfbm93fTwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogQ2FyZCAzICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib2ZmZXItY2FyZC1pdGVtXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm9mZmVyLWJhZGdlXCI+MyBNT05USFMgRlJFRTwvZGl2PlxuICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cIm9mZmVyLXRpdGxlXCI+e2xhbmd1YWdlID09PSAnZW4nID8gXCJFbnRlcnRhaW5tZW50ICYgT1RUIFN1YnNjcmlwdGlvblwiIDogXCLgpK7gpKjgpYvgpLDgpILgpJzgpKgg4KSU4KSwIOCkk+Ckn+ClgOCkn+ClgCDgpLjgpKbgpLjgpY3gpK/gpKTgpL5cIn08L2g0PlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwib2ZmZXItZGVzY1wiPntsYW5ndWFnZSA9PT0gJ2VuJyA/IFwiR2V0IDMgbW9udGhzIGNvbXBsaW1lbnRhcnkgc3Vic2NyaXB0aW9uIHRvIHByZW1pZXIgbWVkaWEgcGFydG5lcnMgd2l0aCBuZXcgYWNjb3VudHMuXCIgOiBcIuCkqOCkjyDgpJbgpL7gpKTgpYvgpIIg4KSV4KWHIOCkuOCkvuCkpSDgpKrgpY3gpLDgpK7gpYHgpJYg4KSu4KWA4KSh4KS/4KSv4KS+IOCkreCkvuCkl+ClgOCkpuCkvuCksOCli+CkgiDgpJXgpYcg4KSy4KS/4KSPIDMg4KSu4KS54KWA4KSo4KWHIOCkleClgCDgpK7gpL7gpKjgpL7gpLDgpY3gpKUg4KS44KSm4KS44KWN4KSv4KSk4KS+IOCkquCljeCksOCkvuCkquCljeCkpCDgpJXgpLDgpYfgpILgpaRcIn08L3A+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm9mZmVyLWZvb3RlclwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjb3Vwb24tY29kZVwiPkNPREU6IDxiPkRBU0hTVFJFQU08L2I+PC9zcGFuPlxuICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0bi1zZWNvbmRhcnlcIiBzdHlsZT17eyBwYWRkaW5nOiAnMC40cmVtIDAuOHJlbScsIGZvbnRTaXplOiAnMC44cmVtJyB9fSBvbkNsaWNrPXsoKSA9PiBoYW5kbGVQaWxsQ2xpY2soJ09mZmVycycpfT57dC5hcHBseV9ub3d9PC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L3NlY3Rpb24+XG5cbiAgICAgIHsvKiBNT0JJTEUgQVBQIFBST01PIFNFQ1RJT04gKEJhbmsgb2YgQmFyb2RhIEluc3BpcmVkKSAqL31cbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImFwcC1wcm9tby1zZWN0aW9uXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXBwLXByb21vLWNhcmRcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFwcC1wcm9tby1ncmlkXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFwcC1wcm9tby1jb250ZW50XCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFwcC1iYWRnZS1uZXdcIj5ORVcgTE9PSzwvc3Bhbj5cbiAgICAgICAgICAgICAgPGgzPnt0LmFwcF9wcm9tb190aXRsZX08L2gzPlxuICAgICAgICAgICAgICA8cD57dC5hcHBfcHJvbW9fZGVzY308L3A+XG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBnYXA6ICcxLjVyZW0nLCBmbGV4V3JhcDogJ3dyYXAnLCBtYXJnaW5Ub3A6ICcxLjVyZW0nIH19PlxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgYmFja2dyb3VuZDogJyNmZmYnLCBwYWRkaW5nOiAnMC42cmVtJywgYm9yZGVyUmFkaXVzOiAnMTJweCcsIGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGp1c3RpZnlDb250ZW50OiAnY2VudGVyJywgYm94U2hhZG93OiAnMCA0cHggMTJweCByZ2JhKDAsMCwwLDAuMDgpJyB9fT5cbiAgICAgICAgICAgICAgICAgIHsvKiBMb2NhbCBnZW5lcmF0ZWQgcmVhbCBRUiBjb2RlIGltYWdlICovfVxuICAgICAgICAgICAgICAgICAge3FyQ29kZVVybCA/IChcbiAgICAgICAgICAgICAgICAgICAgPGltZyBcbiAgICAgICAgICAgICAgICAgICAgICBzcmM9e3FyQ29kZVVybH0gXG4gICAgICAgICAgICAgICAgICAgICAgYWx0PVwiU2NhbiBRUiBjb2RlIHRvIGluc3RhbGwgQmFua0Rhc2hcIiBcbiAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogJzgwcHgnLCBoZWlnaHQ6ICc4MHB4JywgZGlzcGxheTogJ2Jsb2NrJywgaW1hZ2VSZW5kZXJpbmc6ICdwaXhlbGF0ZWQnIH19IFxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcmVtaXVtLXNwaW5uZXJcIiBzdHlsZT17eyB3aWR0aDogJzMycHgnLCBoZWlnaHQ6ICczMnB4JyB9fT48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nLCBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicsIGdhcDogJzAuNXJlbScgfX0+XG4gICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiAnMC44NXJlbScsIGZvbnRXZWlnaHQ6IDYwMCwgY29sb3I6ICdyZ2JhKDI1NSwyNTUsMjU1LDAuOCknIH19PntsYW5ndWFnZSA9PT0gJ2VuJyA/IFwiU2NhbiBRUiBjb2RlIHRvIGluc3RhbGxcIiA6IFwi4KSH4KSC4KS44KWN4KSf4KWJ4KSyIOCkleCksOCkqOClhyDgpJXgpYcg4KSy4KS/4KSPIOCkleCljeCkr+ClguCkhuCksCDgpJXgpYvgpKEg4KS44KWN4KSV4KWI4KSoIOCkleCksOClh+CkglwifTwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhcHAtYnV0dG9uc1wiPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0bi1hcHAtc3RvcmVcIj48U21hcnRwaG9uZSBzaXplPXsxNH0gLz4gQXBwIFN0b3JlPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuLWFwcC1zdG9yZVwiPjxQbGF5IHNpemU9ezE0fSAvPiBHb29nbGUgUGxheTwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFwcC1wcm9tby12aXN1YWxcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhcHAtcGhvbmUtbW9ja3VwXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwaG9uZS1zY3JlZW5cIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGhvbmUtaGVhZGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInBob25lLXRpbWVcIj4wOTo0MTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwaG9uZS1jYW1lcmFcIj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwaG9uZS1hcHAtY29udGVudFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywganVzdGlmeUNvbnRlbnQ6ICdzcGFjZS1iZXR3ZWVuJywgYWxpZ25JdGVtczogJ2NlbnRlcicsIG1hcmdpbkJvdHRvbTogJzFyZW0nIH19PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFNpemU6ICcwLjY1cmVtJywgZm9udFdlaWdodDogNjAwIH19PkRhc2ggV29ybGQ8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8WmFwIHNpemU9ezE0fSBjb2xvcj1cIiNmNTllMGJcIiBmaWxsPVwiI2Y1OWUwYlwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGJhY2tncm91bmQ6ICdyZ2JhKDI1NSwyNTUsMjU1LDAuMSknLCBwYWRkaW5nOiAnMC43NXJlbScsIGJvcmRlclJhZGl1czogJzEwcHgnLCBtYXJnaW5Cb3R0b206ICcxcmVtJyB9fT5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiAnMC41cmVtJywgb3BhY2l0eTogMC44IH19PkF2YWlsYWJsZSBCYWxhbmNlPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogJzFyZW0nLCBmb250V2VpZ2h0OiA3MDAgfX0+JDE0LDkyNS44MDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZ3JpZCcsIGdyaWRUZW1wbGF0ZUNvbHVtbnM6ICdyZXBlYXQoMywgMWZyKScsIGdhcDogJzAuNXJlbScgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBiYWNrZ3JvdW5kOiAncmdiYSgyNTUsMjU1LDI1NSwwLjA1KScsIHBhZGRpbmc6ICcwLjVyZW0nLCBib3JkZXJSYWRpdXM6ICc4cHgnLCB0ZXh0QWxpZ246ICdjZW50ZXInLCBmb250U2l6ZTogJzAuNDVyZW0nIH19PlxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbmRJY29uIHNpemU9ezEyfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5TZW5kPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBiYWNrZ3JvdW5kOiAncmdiYSgyNTUsMjU1LDI1NSwwLjA1KScsIHBhZGRpbmc6ICcwLjVyZW0nLCBib3JkZXJSYWRpdXM6ICc4cHgnLCB0ZXh0QWxpZ246ICdjZW50ZXInLCBmb250U2l6ZTogJzAuNDVyZW0nIH19PlxuICAgICAgICAgICAgICAgICAgICAgICAgPFBlcmNlbnQgc2l6ZT17MTJ9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PkxvYW5zPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBiYWNrZ3JvdW5kOiAncmdiYSgyNTUsMjU1LDI1NSwwLjA1KScsIHBhZGRpbmc6ICcwLjVyZW0nLCBib3JkZXJSYWRpdXM6ICc4cHgnLCB0ZXh0QWxpZ246ICdjZW50ZXInLCBmb250U2l6ZTogJzAuNDVyZW0nIH19PlxuICAgICAgICAgICAgICAgICAgICAgICAgPENyZWRpdENhcmQgc2l6ZT17MTJ9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PkNhcmRzPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICB7LyogRk9PVEVSICovfVxuICAgICAgPGZvb3RlciBjbGFzc05hbWU9XCJsYW5kaW5nLWZvb3RlclwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvb3Rlci1ncmlkXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb290ZXItYnJhbmRcIj5cbiAgICAgICAgICAgIDxMaW5rIHRvPVwiL1wiIGNsYXNzTmFtZT1cImxhbmRpbmctbG9nb1wiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxvZ28taWNvbi1ib3hcIj5cbiAgICAgICAgICAgICAgICA8WmFwIHNpemU9ezIyfSBmaWxsPVwid2hpdGVcIiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPHNwYW4+QmFua0Rhc2g8L3NwYW4+XG4gICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb290ZXItZGVzY1wiPlxuICAgICAgICAgICAgICB7dC5mb290ZXJfZGVzY31cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9vdGVyLWNvbFwiPlxuICAgICAgICAgICAgPGg1Pnt0LmNvbF9wcm9kdWN0fTwvaDU+XG4gICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwiZm9vdGVyLWxpbmtzXCI+XG4gICAgICAgICAgICAgIDxsaT48YSBocmVmPVwiI2ZlYXR1cmVzXCI+e3QuZmVhdHVyZXN9PC9hPjwvbGk+XG4gICAgICAgICAgICAgIDxsaT48YSBocmVmPVwiI2NhbGN1bGF0b3JcIj57dC5jYWxjdWxhdG9yfTwvYT48L2xpPlxuICAgICAgICAgICAgICA8bGk+PExpbmsgdG89XCIvbG9naW5cIj57dC5kYXNoYm9hcmR9IFByZXZpZXc8L0xpbms+PC9saT5cbiAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvb3Rlci1jb2xcIj5cbiAgICAgICAgICAgIDxoNT57dC5jb2xfc2VjdXJpdHl9PC9oNT5cbiAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJmb290ZXItbGlua3NcIj5cbiAgICAgICAgICAgICAgPGxpPjxhIGhyZWY9XCIjXCI+RW5jcnlwdGlvbiBTdGFuZGFyZHM8L2E+PC9saT5cbiAgICAgICAgICAgICAgPGxpPjxhIGhyZWY9XCIjXCI+QWNjZXNzIE1hbmFnZW1lbnQ8L2E+PC9saT5cbiAgICAgICAgICAgICAgPGxpPjxhIGhyZWY9XCIjXCI+UHJpdmFjeSBQb2xpY3k8L2E+PC9saT5cbiAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvb3Rlci1jb2xcIj5cbiAgICAgICAgICAgIDxoNT57dC5jb2xfY29tcGFueX08L2g1PlxuICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImZvb3Rlci1saW5rc1wiPlxuICAgICAgICAgICAgICA8bGk+PGEgaHJlZj1cIiNcIj5BYm91dCBVczwvYT48L2xpPlxuICAgICAgICAgICAgICA8bGk+PGEgaHJlZj1cIiNcIj5DYXJlZXJzPC9hPjwvbGk+XG4gICAgICAgICAgICAgIDxsaT48TGluayB0bz1cIi9jb250YWN0XCI+e3Quc3VwcG9ydH08L0xpbms+PC9saT5cbiAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9vdGVyLWJvdHRvbVwiPlxuICAgICAgICAgIDxkaXY+wqkge25ldyBEYXRlKCkuZ2V0RnVsbFllYXIoKX0gQmFua0Rhc2guIEFsbCByaWdodHMgcmVzZXJ2ZWQuPC9kaXY+XG5cbiAgICAgICAgICB7dmlzaXRDb3VudCA+IDAgJiYgKFxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBnYXA6ICcwLjVyZW0nLCBiYWNrZ3JvdW5kOiAncmdiYSgwLDAsMCwwLjAzKScsIHBhZGRpbmc6ICcwLjRyZW0gMC44cmVtJywgYm9yZGVyUmFkaXVzOiAnMjBweCcsIGJvcmRlcjogJzFweCBzb2xpZCB2YXIoLS1sZC1ib3JkZXIpJywgZm9udFNpemU6ICcwLjg1cmVtJyB9fT5cbiAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgd2lkdGg6ICc4cHgnLCBoZWlnaHQ6ICc4cHgnLCBib3JkZXJSYWRpdXM6ICc1MCUnLCBiYWNrZ3JvdW5kQ29sb3I6ICcjMTBiOTgxJywgYm94U2hhZG93OiAnMCAwIDhweCAjMTBiOTgxJywgZGlzcGxheTogJ2lubGluZS1ibG9jaycgfX0+PC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogJ3ZhcigtLWxkLXRleHQtbXV0ZWQpJywgZm9udFdlaWdodDogNTAwIH19Pnt0LnZpc2l0X2NvdW50fSA8c3Ryb25nIHN0eWxlPXt7IGNvbG9yOiAndmFyKC0tbGQtdGV4dC1tYWluKScgfX0+e3Zpc2l0Q291bnQudG9Mb2NhbGVTdHJpbmcoKX08L3N0cm9uZz48L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGdhcDogJzEuNXJlbScgfX0+XG4gICAgICAgICAgICA8YSBocmVmPVwiI1wiIHN0eWxlPXt7IGNvbG9yOiAndmFyKC0tbGQtdGV4dC1tdXRlZCknLCB0ZXh0RGVjb3JhdGlvbjogJ25vbmUnIH19Pnt0LnRlcm1zfTwvYT5cbiAgICAgICAgICAgIDxhIGhyZWY9XCIjXCIgc3R5bGU9e3sgY29sb3I6ICd2YXIoLS1sZC10ZXh0LW11dGVkKScsIHRleHREZWNvcmF0aW9uOiAnbm9uZScgfX0+e3QucHJpdmFjeX08L2E+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9mb290ZXI+XG5cbiAgICAgIHsvKiBNT0RBTFMgKi99XG5cbiAgICAgIHsvKiAxLiBBUFBMWSBOT1cgQVBQTElDQVRJT04gRk9STSBNT0RBTCAqL31cbiAgICAgIHthY3RpdmVNb2RhbCA9PT0gJ2FwcGx5JyAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibW9kYWwtYmFja2Ryb3BcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1vZGFsLWNvbnRhaW5lciBhbmltYXRlLXNsaWRlXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1vZGFsLWhlYWRlclwiPlxuICAgICAgICAgICAgICA8aDM+e2xhbmd1YWdlID09PSAnZW4nID8gXCJBcHBseSBmb3IgUHJvZHVjdHNcIiA6IFwi4KSJ4KSk4KWN4KSq4KS+4KSmIOCkleClhyDgpLLgpL/gpI8g4KSG4KS14KWH4KSm4KSoIOCkleCksOClh+CkglwifTwvaDM+XG4gICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuLWNsb3NlLW1vZGFsXCIgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlTW9kYWwobnVsbCl9PjxYIHNpemU9ezIwfSAvPjwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICB7YXBwbHlTdWNjZXNzID8gKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFwcGx5LXN1Y2Nlc3MtYm94XCI+XG4gICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlIHNpemU9ezQ4fSBjb2xvcj1cIiMxMGI5ODFcIiAvPlxuICAgICAgICAgICAgICAgIDxoND57bGFuZ3VhZ2UgPT09ICdlbicgPyBcIkFwcGxpY2F0aW9uIFN1Ym1pdHRlZCBTdWNjZXNzZnVsbHkhXCIgOiBcIuCkhuCkteClh+CkpuCkqCDgpLjgpKvgpLLgpKTgpL7gpKrgpYLgpLDgpY3gpLXgpJUg4KSc4KSu4KS+IOCkleCkv+Ckr+CkviDgpJfgpK/gpL4hXCJ9PC9oND5cbiAgICAgICAgICAgICAgICA8cD57bGFuZ3VhZ2UgPT09ICdlbicgPyBgWW91ciBpbnRlcmVzdCBpbiAke2FwcGx5UHJvZHVjdH0gaGFzIGJlZW4gcmVnaXN0ZXJlZC4gT3VyIHJlcHJlc2VudGF0aXZlIHdpbGwgY2FsbCB5b3Ugd2l0aGluIDI0IGhvdXJzLmAgOiBg4KSG4KSq4KSV4KWAICR7YXBwbHlQcm9kdWN0fSDgpK7gpYfgpIIg4KSw4KWB4KSa4KS/IOCkpuCksOCljeCknCDgpJXgpLAg4KSy4KWAIOCkl+CkiCDgpLngpYjgpaQg4KS54KSu4KS+4KSw4KWHIOCkquCljeCksOCkpOCkv+CkqOCkv+Ckp+CkvyAyNCDgpJjgpILgpJ/gpYcg4KSV4KWHIOCkreClgOCkpOCksCDgpIbgpKrgpLjgpYcg4KS44KSC4KSq4KSw4KWN4KSVIOCkleCksOClh+CkguCkl+Clh+ClpGB9PC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVBcHBseVN1Ym1pdH0gY2xhc3NOYW1lPVwibW9kYWwtZm9ybVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgYmFja2dyb3VuZDogJ3JnYmEoNzksIDcwLCAyMjksIDAuMDgpJywgcGFkZGluZzogJzAuNzVyZW0nLCBib3JkZXJSYWRpdXM6ICcxMHB4JywgbWFyZ2luQm90dG9tOiAnMS4yNXJlbScsIGZvbnRTaXplOiAnMC45cmVtJywgYm9yZGVyOiAnMXB4IHNvbGlkIHZhcigtLWxkLWJvcmRlciknIH19PlxuICAgICAgICAgICAgICAgICAge2xhbmd1YWdlID09PSAnZW4nID8gXCJQcm9kdWN0IFNlbGVjdGVkOiBcIiA6IFwi4KSa4KSv4KSo4KS/4KSkIOCkieCkpOCljeCkquCkvuCkpjogXCJ9IDxiPnthcHBseVByb2R1Y3R9PC9iPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwLW1vZGFsXCI+XG4gICAgICAgICAgICAgICAgICA8bGFiZWw+e3QubGFiZWxfbmFtZX0gKjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17dC5wbGFjZWhvbGRlcl9uYW1lfVxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YXBwbHlGb3JtLm5hbWV9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0QXBwbHlGb3JtKHsgLi4uYXBwbHlGb3JtLCBuYW1lOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXAtbW9kYWxcIj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbD57dC5sYWJlbF9lbWFpbH0gKjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e3QucGxhY2Vob2xkZXJfZW1haWx9XG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXthcHBseUZvcm0uZW1haWx9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0QXBwbHlGb3JtKHsgLi4uYXBwbHlGb3JtLCBlbWFpbDogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwLW1vZGFsXCI+XG4gICAgICAgICAgICAgICAgICA8bGFiZWw+e2xhbmd1YWdlID09PSAnZW4nID8gXCJNb2JpbGUgUGhvbmUgTnVtYmVyICpcIiA6IFwi4KSu4KWL4KSs4KS+4KSH4KSyIOCkq+Cli+CkqCDgpKjgpILgpKzgpLAgKlwifTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRlbFwiXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiArOTEgOTk5OTk5OTk5OVwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXthcHBseUZvcm0ucGhvbmV9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0QXBwbHlGb3JtKHsgLi4uYXBwbHlGb3JtLCBwaG9uZTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwLW1vZGFsXCI+XG4gICAgICAgICAgICAgICAgICA8bGFiZWw+e2xhbmd1YWdlID09PSAnZW4nID8gXCJBcHByb3hpbWF0ZSBBbm51YWwgSW5jb21lICgkKVwiIDogXCLgpIXgpKjgpYHgpK7gpL7gpKjgpL/gpKQg4KS14KS+4KSw4KWN4KS34KS/4KSVIOCkhuCkryAoJClcIn08L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gNTAwMDBcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YXBwbHlGb3JtLmluY29tZX1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRBcHBseUZvcm0oeyAuLi5hcHBseUZvcm0sIGluY29tZTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgY2xhc3NOYW1lPVwiYnRuLXByaW1hcnlcIiBzdHlsZT17eyB3aWR0aDogJzEwMCUnLCBwYWRkaW5nOiAnMC44NXJlbScsIGRpc3BsYXk6ICdmbGV4JywganVzdGlmeUNvbnRlbnQ6ICdjZW50ZXInIH19PlxuICAgICAgICAgICAgICAgICAge2xhbmd1YWdlID09PSAnZW4nID8gXCJTdWJtaXQgU2VjdXJlIEFwcGxpY2F0aW9uXCIgOiBcIuCkuOClgeCksOCkleCljeCkt+Ckv+CkpCDgpIbgpLXgpYfgpKbgpKgg4KSc4KSu4KS+IOCkleCksOClh+CkglwifVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiAyLiBET1dOTE9BRCBGT1JNUyBNT0RBTCAqL31cbiAgICAgIHthY3RpdmVNb2RhbCA9PT0gJ2Zvcm1zJyAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibW9kYWwtYmFja2Ryb3BcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1vZGFsLWNvbnRhaW5lciBhbmltYXRlLXNsaWRlXCIgc3R5bGU9e3sgbWF4V2lkdGg6ICc1MDBweCcgfX0+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1vZGFsLWhlYWRlclwiPlxuICAgICAgICAgICAgICA8aDM+e3QuZG93bmxvYWRfZm9ybXN9PC9oMz5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4tY2xvc2UtbW9kYWxcIiBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVNb2RhbChudWxsKX0+PFggc2l6ZT17MjB9IC8+PC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybXMtbGlzdFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZG93bmxvYWQtaXRlbVwiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRXZWlnaHQ6IDYwMCwgZm9udFNpemU6ICcwLjk1cmVtJyB9fT5TYXZpbmdzIEFjY291bnQgT3BlbmluZyBGb3JtPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiAnMC43NXJlbScsIGNvbG9yOiAndmFyKC0tbGQtdGV4dC1tdXRlZCknIH19PlBERiB8IDI0MCBLQjwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuLXNlY29uZGFyeVwiIHN0eWxlPXt7IHBhZGRpbmc6ICcwLjRyZW0gMC44cmVtJywgZm9udFNpemU6ICcwLjhyZW0nIH19IG9uQ2xpY2s9eygpID0+IGFsZXJ0KFwiRG93bmxvYWRpbmcgU2F2aW5ncyBBY2NvdW50IE9wZW5pbmcgRm9ybS4uLlwiKX0+PERvd25sb2FkIHNpemU9ezE0fSAvPjwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWRvd25sb2FkLWl0ZW1cIj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250V2VpZ2h0OiA2MDAsIGZvbnRTaXplOiAnMC45NXJlbScgfX0+UmV0YWlsIExvYW4gQXBwbGljYXRpb24gRm9ybTwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogJzAuNzVyZW0nLCBjb2xvcjogJ3ZhcigtLWxkLXRleHQtbXV0ZWQpJyB9fT5QREYgfCA1ODAgS0I8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0bi1zZWNvbmRhcnlcIiBzdHlsZT17eyBwYWRkaW5nOiAnMC40cmVtIDAuOHJlbScsIGZvbnRTaXplOiAnMC44cmVtJyB9fSBvbkNsaWNrPXsoKSA9PiBhbGVydChcIkRvd25sb2FkaW5nIFJldGFpbCBMb2FuIEFwcGxpY2F0aW9uIEZvcm0uLi5cIil9PjxEb3dubG9hZCBzaXplPXsxNH0gLz48L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1kb3dubG9hZC1pdGVtXCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFdlaWdodDogNjAwLCBmb250U2l6ZTogJzAuOTVyZW0nIH19PktZQyBVcGRhdGlvbiBGb3JtPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiAnMC43NXJlbScsIGNvbG9yOiAndmFyKC0tbGQtdGV4dC1tdXRlZCknIH19PlBERiB8IDEyMCBLQjwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuLXNlY29uZGFyeVwiIHN0eWxlPXt7IHBhZGRpbmc6ICcwLjRyZW0gMC44cmVtJywgZm9udFNpemU6ICcwLjhyZW0nIH19IG9uQ2xpY2s9eygpID0+IGFsZXJ0KFwiRG93bmxvYWRpbmcgS1lDIFVwZGF0aW9uIEZvcm0uLi5cIil9PjxEb3dubG9hZCBzaXplPXsxNH0gLz48L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogMy4gQlJBTkNIIExPQ0FUT1IgTU9EQUwgKi99XG4gICAgICB7YWN0aXZlTW9kYWwgPT09ICdsb2NhdG9yJyAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibW9kYWwtYmFja2Ryb3BcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1vZGFsLWNvbnRhaW5lciBhbmltYXRlLXNsaWRlXCIgc3R5bGU9e3sgbWF4V2lkdGg6ICc2MDBweCcgfX0+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1vZGFsLWhlYWRlclwiPlxuICAgICAgICAgICAgICA8aDM+e3QuYnJhbmNoX2xvY2F0b3JfdGl0bGV9PC9oMz5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4tY2xvc2UtbW9kYWxcIiBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVNb2RhbChudWxsKX0+PFggc2l6ZT17MjB9IC8+PC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxwIHN0eWxlPXt7IGZvbnRTaXplOiAnMC45cmVtJywgY29sb3I6ICd2YXIoLS1sZC10ZXh0LW11dGVkKScsIG1hcmdpbkJvdHRvbTogJzFyZW0nIH19Pnt0LmJyYW5jaF9sb2NhdG9yX2Rlc2N9PC9wPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsb2NhdG9yLXNlYXJjaC1ib3hcIj5cbiAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgcGxhY2Vob2xkZXI9XCJFbnRlciBjaXR5IG9yIHppcCBjb2RlLi4uXCIgc3R5bGU9e3sgd2lkdGg6ICcxMDAlJywgcGFkZGluZzogJzAuNnJlbSAxcmVtJywgYm9yZGVyUmFkaXVzOiAnMTBweCcsIGJvcmRlcjogJzFweCBzb2xpZCB2YXIoLS1sZC1ib3JkZXIpJywgYmFja2dyb3VuZDogJ3ZhcigtLWxkLWJnKScsIG91dGxpbmU6ICdub25lJyB9fSAvPlxuICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0bi1wcmltYXJ5XCIgc3R5bGU9e3sgcGFkZGluZzogJzAuNnJlbSAxLjI1cmVtJyB9fSBvbkNsaWNrPXsoKSA9PiBhbGVydChcIlNlYXJjaGluZyBuZWFyYnkgYnJhbmNoZXMuLi5cIil9PntsYW5ndWFnZSA9PT0gJ2VuJyA/IFwiU2VhcmNoXCIgOiBcIuCkluCli+CknOClh+CkglwifTwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJyYW5jaGVzLWxpc3RcIiBzdHlsZT17eyBtYXJnaW5Ub3A6ICcxcmVtJywgZGlzcGxheTogJ2ZsZXgnLCBmbGV4RGlyZWN0aW9uOiAnY29sdW1uJywgZ2FwOiAnMC43NXJlbScsIG1heEhlaWdodDogJzI1MHB4Jywgb3ZlcmZsb3dZOiAnYXV0bycgfX0+XG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgYm9yZGVyOiAnMXB4IHNvbGlkIHZhcigtLWxkLWJvcmRlciknLCBwYWRkaW5nOiAnMC43NXJlbScsIGJvcmRlclJhZGl1czogJzEycHgnIH19PlxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFdlaWdodDogNzAwLCBmb250U2l6ZTogJzAuOTVyZW0nIH19PkNvbm5hdWdodCBQbGFjZSBCcmFuY2g8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiAnMC44NXJlbScsIGNvbG9yOiAndmFyKC0tbGQtdGV4dC1tdXRlZCknLCBtYXJnaW5Ub3A6ICcwLjI1cmVtJyB9fT5FLUJsb2NrLCBJbm5lciBDaXJjbGUsIE5ldyBEZWxoaSwgMTEwMDAxPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogJzAuNzhyZW0nLCBjb2xvcjogJ3ZhcigtLWxkLXByaW1hcnkpJywgZm9udFdlaWdodDogNjAwLCBtYXJnaW5Ub3A6ICcwLjRyZW0nIH19Pnt0LmJyYW5jaF9ob3Vyc306IDEwOjAwIEFNIC0gNDowMCBQTTwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBib3JkZXI6ICcxcHggc29saWQgdmFyKC0tbGQtYm9yZGVyKScsIHBhZGRpbmc6ICcwLjc1cmVtJywgYm9yZGVyUmFkaXVzOiAnMTJweCcgfX0+XG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250V2VpZ2h0OiA3MDAsIGZvbnRTaXplOiAnMC45NXJlbScgfX0+TXVtYmFpIE1haW4gQnJhbmNoPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogJzAuODVyZW0nLCBjb2xvcjogJ3ZhcigtLWxkLXRleHQtbXV0ZWQpJywgbWFyZ2luVG9wOiAnMC4yNXJlbScgfX0+SGVyaXRhZ2UgYnVpbGRpbmcsIEZvcnQsIE11bWJhaSwgNDAwMDAxPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogJzAuNzhyZW0nLCBjb2xvcjogJ3ZhcigtLWxkLXByaW1hcnkpJywgZm9udFdlaWdodDogNjAwLCBtYXJnaW5Ub3A6ICcwLjRyZW0nIH19Pnt0LmJyYW5jaF9ob3Vyc306IDEwOjAwIEFNIC0gNDowMCBQTTwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG4vLyBJbnRlcm5hbCBtb2NrdXAgaGVscGVyIGNvbXBvbmVudCBmb3IgQXBwIHBob25lXG5jb25zdCBTZW5kSWNvbiA9ICh7IHNpemUgfSkgPT4gKFxuICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB3aWR0aD17c2l6ZX0gaGVpZ2h0PXtzaXplfSB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiBzdHJva2VXaWR0aD1cIjJcIiBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCI+XG4gICAgPGxpbmUgeDE9XCIyMlwiIHkxPVwiMlwiIHgyPVwiMTFcIiB5Mj1cIjEzXCI+PC9saW5lPlxuICAgIDxwb2x5Z29uIHBvaW50cz1cIjIyIDIgMTUgMjIgMTEgMTMgMiA5IDIyIDJcIj48L3BvbHlnb24+XG4gIDwvc3ZnPlxuKTtcblxuZXhwb3J0IGRlZmF1bHQgTGFuZGluZztcbiJdLCJmaWxlIjoiRDovUmVhY3RfdGVzdF8xOV8wNV8yMDI2L3NyYy9jb21wb25lbnRzL0xhbmRpbmcuanN4In0=