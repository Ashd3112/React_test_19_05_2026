import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Dashboard.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=01f90aba"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/React_test_19_05_2026/src/components/Dashboard.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=01f90aba"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=01f90aba";
import { useAuth } from "/src/App.jsx";
import {
  LayoutDashboard,
  ArrowLeftRight,
  User,
  Users,
  LineChart,
  CreditCard,
  HandCoins,
  Wrench,
  Lightbulb,
  Settings,
  LogOut,
  Bell,
  Search,
  Send,
  ChevronRight,
  Plus,
  TrendingUp,
  DollarSign,
  Briefcase,
  ShieldCheck,
  Smartphone,
  Sparkles,
  Lock,
  Edit2,
  Trash2,
  Globe,
  X,
  Scan
} from "/node_modules/.vite/deps/lucide-react.js?v=01f90aba";
import QrScannerTab from "/src/components/QrScannerTab.jsx";
import "/src/dashboard.css";
const quickTransferUsers = [
  {
    name: "Livia Bator",
    role: "CEO",
    avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&h=120&fit=crop"
  },
  {
    name: "Randy Press",
    role: "Director",
    avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=120&h=120&fit=crop"
  },
  {
    name: "Worku Melese",
    role: "Designer",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&h=120&fit=crop"
  },
  {
    name: "Kevin Peterson",
    role: "Developer",
    avatar: "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=120&h=120&fit=crop"
  }
];
const Dashboard = () => {
  _s();
  const navigate = useNavigate();
  const userSession = (() => {
    const raw = localStorage.getItem("user");
    if (!raw) {
      return {
        name: "John Doe",
        email: "john.doe@gmail.com",
        role: "Viewer",
        permissions: {
          view_dashboard: true,
          manage_tx: false,
          manage_cards: false,
          manage_loans: false,
          manage_services: false,
          manage_users: false
        }
      };
    }
    const parsed = JSON.parse(raw);
    const emailLower = (parsed.email || "").toLowerCase();
    const isAdmin = emailLower === "admin@gmail.com";
    return {
      ...parsed,
      role: parsed.role || (isAdmin ? "Admin" : "Viewer"),
      permissions: parsed.permissions || {
        view_dashboard: true,
        manage_tx: isAdmin,
        manage_cards: isAdmin,
        manage_loans: isAdmin,
        manage_services: isAdmin,
        manage_users: isAdmin
      }
    };
  })();
  const CARDS_KEY = `bankdash_cards_${userSession.email.toLowerCase()}`;
  const TXS_KEY = `bankdash_txs_${userSession.email.toLowerCase()}`;
  const PROFILE_KEY = `bankdash_profile_${userSession.email.toLowerCase()}`;
  const SERVICES_KEY = `bankdash_services_${userSession.email.toLowerCase()}`;
  const LOANS_KEY = `bankdash_loans_${userSession.email.toLowerCase()}`;
  const [activeTab, setActiveTab] = useState(() => {
    const saved = localStorage.getItem("dashboard_active_tab");
    if (saved) {
      localStorage.removeItem("dashboard_active_tab");
      return saved;
    }
    return "Dashboard";
  });
  const [settingsSubTab, setSettingsSubTab] = useState("Edit Profile");
  const [searchQuery, setSearchQuery] = useState("");
  const [transactionTypeFilter, setTransactionTypeFilter] = useState("All");
  const [users, setUsers] = useState([]);
  const [userModalOpen, setUserModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [userForm, setUserForm] = useState({
    role: "Viewer",
    permissions: {
      view_dashboard: true,
      manage_tx: false,
      manage_cards: false,
      manage_loans: false,
      manage_services: false,
      manage_users: false
    }
  });
  const [notifications, setNotifications] = useState(() => {
    const isAdmin = userSession.role === "Admin";
    if (isAdmin) {
      return [
        { id: 1, text: "System Alert: 3 platform users registered database synced.", time: "Just now", type: "success", unread: true },
        { id: 2, text: "Role settings adjusted for 'Test User' (Viewer privileges).", time: "5 mins ago", type: "info", unread: true },
        { id: 3, text: "New contact query received from 'Sarah Jenkins'.", time: "1 hour ago", type: "warning", unread: true }
      ];
    } else {
      return [
        { id: 1, text: "Security Notice: Online Banking MFA is operational.", time: "2 mins ago", type: "success", unread: true },
        { id: 2, text: "Role limits configured: Account Viewer mode activated.", time: "10 mins ago", type: "info", unread: true },
        { id: 3, text: "Welcome to BankDash! Customize your profile avatar.", time: "1 day ago", type: "info", unread: false }
      ];
    }
  });
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const handleMarkAllRead = () => {
    setNotifications(notifications.map((n) => ({ ...n, unread: false })));
  };
  const [profile, setProfile] = useState(() => {
    const saved = localStorage.getItem(PROFILE_KEY);
    if (saved)
      return JSON.parse(saved);
    return {
      name: userSession.name || "John Doe",
      email: userSession.email || "john.doe@gmail.com",
      phone: "+1 (555) 019-2834",
      dob: "1995-08-12",
      address: "88 Tech Boulevard, Silicon Valley, CA",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&h=120&fit=crop"
    };
  });
  const [tempProfile, setTempProfile] = useState({ ...profile });
  const [passwordForm, setPasswordForm] = useState({ current: "", new: "", confirm: "" });
  const [settingsSuccess, setSettingsSuccess] = useState("");
  const [cards, setCards] = useState(() => {
    const saved = localStorage.getItem(CARDS_KEY);
    if (saved)
      return JSON.parse(saved);
    return [
      { id: 1, balance: 5756, holder: userSession.name || "John Doe", number: "3778 **** **** 1234", expiry: "12/28", type: "dark" },
      { id: 2, balance: 3502, holder: userSession.name || "John Doe", number: "4532 **** **** 5678", expiry: "06/27", type: "light" },
      { id: 3, balance: 8210, holder: userSession.name || "John Doe", number: "5412 **** **** 9012", expiry: "10/29", type: "purple" },
      { id: 4, balance: 1420, holder: userSession.name || "John Doe", number: "3799 **** **** 3456", expiry: "04/26", type: "green" }
    ];
  });
  const [transactions, setTransactions] = useState(() => {
    const saved = localStorage.getItem(TXS_KEY);
    if (saved)
      return JSON.parse(saved);
    return [
      { id: "TX001", desc: "Deposit from Card", date: "2021-01-28", type: "income", method: "Card", category: "Deposit", amount: 850, status: "Success" },
      { id: "TX002", desc: "Deposit Paypal", date: "2021-01-25", type: "income", method: "Paypal", category: "Deposit", amount: 2500, status: "Success" },
      { id: "TX003", desc: "Jemi Wilson", date: "2021-01-21", type: "income", method: "Wire Transfer", category: "Transfer", amount: 5400, status: "Success" },
      { id: "TX004", desc: "Spotify Premium", date: "2021-01-19", type: "expense", method: "Card", category: "Entertainment", amount: 15, status: "Success" },
      { id: "TX005", desc: "Netflix Subscription", date: "2021-01-15", type: "expense", method: "Paypal", category: "Entertainment", amount: 20, status: "Success" },
      { id: "TX006", desc: "Salary Payment", date: "2021-01-01", type: "income", method: "Wire Transfer", category: "Salary", amount: 8e3, status: "Success" },
      { id: "TX007", desc: "Amazon Purchase", date: "2020-12-28", type: "expense", method: "Card", category: "Shopping", amount: 120, status: "Pending" },
      { id: "TX008", desc: "Uber Ride", date: "2020-12-25", type: "expense", method: "Card", category: "Transport", amount: 35, status: "Failed" },
      { id: "TX009", desc: "Google Cloud Platform", date: "2020-12-20", type: "expense", method: "Card", category: "Hosting", amount: 312, status: "Success" },
      { id: "TX010", desc: "Upwork Payment Received", date: "2020-12-18", type: "income", method: "Wire Transfer", category: "Salary", amount: 1450, status: "Success" },
      { id: "TX011", desc: "Starbucks Coffee", date: "2020-12-15", type: "expense", method: "Card", category: "Food & Dining", amount: 12, status: "Success" },
      { id: "TX012", desc: "Office Supplies Inc", date: "2020-12-10", type: "expense", method: "Card", category: "Business", amount: 89, status: "Success" },
      { id: "TX013", desc: "Airbnb Booking Refund", date: "2020-12-05", type: "income", method: "Paypal", category: "Travel", amount: 450, status: "Success" },
      { id: "TX014", desc: "Adobe Creative Suite", date: "2020-12-01", type: "expense", method: "Card", category: "Software", amount: 55, status: "Success" }
    ];
  });
  const [services, setServices] = useState(() => {
    const saved = localStorage.getItem(SERVICES_KEY);
    if (saved)
      return JSON.parse(saved);
    return [
      { id: "srv-1", title: "Online Banking Security", desc: "Enable multi-factor authorization and security notifications", enabled: true, color: "#396AFF", iconName: "ShieldCheck" },
      { id: "srv-2", title: "Mobile Notification Alerts", desc: "Get SMS notifications for every debit and credit transfer", enabled: true, color: "#FFBB38", iconName: "Smartphone" },
      { id: "srv-3", title: "Weekly Auto Save", desc: "Automatically transfer 5% of weekly income into savings account", enabled: false, color: "#16DBAA", iconName: "DollarSign" },
      { id: "srv-4", title: "Monthly Expense Report", desc: "Receive interactive monthly breakdown PDF via email", enabled: false, color: "#FF4B4A", iconName: "Briefcase" },
      { id: "srv-5", title: "Travel Mode Verification", desc: "Allows global purchases without raising fraud detection triggers", enabled: false, color: "#A855F7", iconName: "Globe" },
      { id: "srv-6", title: "Crypto Buy Allowances", desc: "Grant wallet permission to directly interact with crypto gateways", enabled: false, color: "#EC4899", iconName: "CreditCard" }
    ];
  });
  const iconMap = {
    ShieldCheck,
    Smartphone,
    DollarSign,
    Briefcase,
    Globe,
    CreditCard
  };
  const [loans, setLoans] = useState(() => {
    const saved = localStorage.getItem(LOANS_KEY);
    if (saved)
      return JSON.parse(saved);
    return [
      { id: "L001", type: "Personal Loan", amount: 2e4, balance: 12500, installment: 550, duration: "36 Months" },
      { id: "L002", type: "Car Loan", amount: 35e3, balance: 28e3, installment: 720, duration: "60 Months" },
      { id: "L003", type: "Home Loan", amount: 25e4, balance: 235e3, installment: 1200, duration: "240 Months" },
      { id: "L004", type: "Education Loan", amount: 15e3, balance: 9200, installment: 320, duration: "48 Months" },
      { id: "L005", type: "Business Expansion", amount: 12e4, balance: 11e4, installment: 2400, duration: "60 Months" },
      { id: "L006", type: "Medical Emergency", amount: 8e3, balance: 0, installment: 400, duration: "20 Months" }
    ];
  });
  useEffect(() => {
    localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
  }, [profile, PROFILE_KEY]);
  useEffect(() => {
    localStorage.setItem(CARDS_KEY, JSON.stringify(cards));
  }, [cards, CARDS_KEY]);
  useEffect(() => {
    localStorage.setItem(TXS_KEY, JSON.stringify(transactions));
  }, [transactions, TXS_KEY]);
  useEffect(() => {
    localStorage.setItem(SERVICES_KEY, JSON.stringify(services));
  }, [services, SERVICES_KEY]);
  useEffect(() => {
    localStorage.setItem(LOANS_KEY, JSON.stringify(loans));
  }, [loans, LOANS_KEY]);
  useEffect(() => {
    setTempProfile({ ...profile });
  }, [profile]);
  useEffect(() => {
    const raw = localStorage.getItem("user");
    if (raw) {
      const parsed = JSON.parse(raw);
      if (!parsed.role || !parsed.permissions) {
        localStorage.setItem("user", JSON.stringify(userSession));
      }
    }
  }, [userSession]);
  const fetchUsers = async () => {
    try {
      const response = await fetch("http://localhost:5000/api/users", {
        headers: {
          "x-user-role": userSession.role
        }
      });
      if (response.ok) {
        const data = await response.json();
        setUsers(data);
      } else {
        console.error("Failed to fetch users");
      }
    } catch (err) {
      console.error("Error fetching users:", err);
    }
  };
  useEffect(() => {
    if (activeTab === "User Details") {
      fetchUsers();
    }
  }, [activeTab]);
  const handleUpdatePermissions = async (userId, updatedRole, updatedPermissions) => {
    try {
      const response = await fetch(`http://localhost:5000/api/users/${userId}/permissions`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "x-user-role": userSession.role
        },
        body: JSON.stringify({
          role: updatedRole,
          permissions: updatedPermissions
        })
      });
      const data = await response.json();
      if (response.ok) {
        alert(data.message || "Permissions updated successfully!");
        if (userId === userSession.id) {
          const updatedUser = { ...userSession, role: updatedRole, permissions: updatedPermissions };
          localStorage.setItem("user", JSON.stringify(updatedUser));
        }
        setNotifications(
          (prev) => [
            { id: Date.now(), text: `Role & access rights updated for user ${editingUser?.name || userId}.`, time: "Just now", type: "warning", unread: true },
            ...prev
          ]
        );
        fetchUsers();
        setUserModalOpen(false);
      } else {
        alert(data.error || "Failed to update permissions");
      }
    } catch (err) {
      console.error("Error updating permissions:", err);
      alert("Error updating permissions");
    }
  };
  const openUserPermissionsModal = (user) => {
    setEditingUser(user);
    setUserForm({
      role: user.role,
      permissions: { ...user.permissions }
    });
    setUserModalOpen(true);
  };
  const [newCardForm, setNewCardForm] = useState({ balance: "", holder: "", number: "", expiry: "", type: "dark" });
  const [loanCalc, setLoanCalc] = useState({ amount: "10000", rate: "5", term: "12", output: "856.07" });
  const [transferAmount, setTransferAmount] = useState("");
  const [transferSuccess, setTransferSuccess] = useState("");
  const [selectedUserIndex, setSelectedUserIndex] = useState(0);
  const [txModalOpen, setTxModalOpen] = useState(false);
  const [editingTx, setEditingTx] = useState(null);
  const [txForm, setTxForm] = useState({
    desc: "",
    amount: "",
    type: "expense",
    category: "Deposit",
    method: "Card",
    date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
    status: "Success"
  });
  const [cardModalOpen, setCardModalOpen] = useState(false);
  const [editingCard, setEditingCard] = useState(null);
  const [cardForm, setCardForm] = useState({
    balance: "",
    holder: "",
    number: "",
    expiry: "",
    type: "dark"
  });
  const { logout: contextLogout } = useAuth();
  const handleLogout = () => {
    contextLogout();
    navigate("/login");
  };
  const handleQuickTransfer = (e) => {
    e.preventDefault();
    const amt = parseFloat(transferAmount);
    if (!transferAmount || isNaN(amt) || amt <= 0) {
      alert("Please enter a valid transfer amount.");
      return;
    }
    if (cards.length === 0) {
      alert("You must have at least one credit card to make a transfer.");
      return;
    }
    if (cards[0].balance < amt) {
      alert(`Insufficient funds in your primary ${cards[0].type} card!`);
      return;
    }
    const recipient = quickTransferUsers[selectedUserIndex].name;
    const updatedCards = [...cards];
    updatedCards[0].balance -= amt;
    setCards(updatedCards);
    const newTx = {
      id: `TX${Math.floor(100 + Math.random() * 900)}`,
      desc: `Transfer to ${recipient}`,
      date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
      type: "expense",
      method: "Paypal",
      category: "Transfer",
      amount: amt,
      status: "Success"
    };
    setTransactions([newTx, ...transactions]);
    setNotifications(
      (prev) => [
        { id: Date.now(), text: `Quick Transfer of $${amt.toLocaleString()} to ${recipient} completed.`, time: "Just now", type: "success", unread: true },
        ...prev
      ]
    );
    setTransferSuccess(`Successfully sent $${amt.toLocaleString()} to ${recipient}!`);
    setTransferAmount("");
    setTimeout(() => {
      setTransferSuccess("");
    }, 4e3);
  };
  const openTxCreateModal = () => {
    setEditingTx(null);
    setTxForm({
      desc: "",
      amount: "",
      type: "expense",
      category: "Deposit",
      method: "Card",
      date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
      status: "Success"
    });
    setTxModalOpen(true);
  };
  const openTxEditModal = (tx) => {
    setEditingTx(tx);
    setTxForm({
      desc: tx.desc,
      amount: tx.amount.toString(),
      type: tx.type,
      category: tx.category,
      method: tx.method,
      date: tx.date,
      status: tx.status
    });
    setTxModalOpen(true);
  };
  const handleTxSubmit = (e) => {
    e.preventDefault();
    if (!txForm.desc || !txForm.amount || isNaN(parseFloat(txForm.amount))) {
      alert("Please fill out all fields with valid data.");
      return;
    }
    if (editingTx) {
      setTransactions(transactions.map((t) => {
        if (t.id === editingTx.id) {
          return {
            ...t,
            desc: txForm.desc,
            amount: parseFloat(txForm.amount),
            type: txForm.type,
            category: txForm.category,
            method: txForm.method,
            date: txForm.date,
            status: txForm.status
          };
        }
        return t;
      }));
      setNotifications(
        (prev) => [
          { id: Date.now(), text: `Transaction "${txForm.desc}" updated successfully.`, time: "Just now", type: "info", unread: true },
          ...prev
        ]
      );
      alert("Transaction updated successfully!");
    } else {
      const newTx = {
        id: `TX${Math.floor(100 + Math.random() * 900)}`,
        desc: txForm.desc,
        amount: parseFloat(txForm.amount),
        type: txForm.type,
        category: txForm.category,
        method: txForm.method,
        date: txForm.date,
        status: txForm.status
      };
      setTransactions([newTx, ...transactions]);
      setNotifications(
        (prev) => [
          { id: Date.now(), text: `New transaction "${txForm.desc}" ($${parseFloat(txForm.amount).toLocaleString()}) created.`, time: "Just now", type: "success", unread: true },
          ...prev
        ]
      );
      alert("Transaction created successfully!");
    }
    setTxModalOpen(false);
  };
  const handleDeleteTx = (txId) => {
    if (window.confirm("Are you sure you want to delete this transaction?")) {
      setTransactions(transactions.filter((t) => t.id !== txId));
      setNotifications(
        (prev) => [
          { id: Date.now(), text: `Transaction removed successfully.`, time: "Just now", type: "warning", unread: true },
          ...prev
        ]
      );
    }
  };
  const handleAddCard = (e) => {
    e.preventDefault();
    if (!newCardForm.balance || !newCardForm.holder || !newCardForm.number || !newCardForm.expiry) {
      alert("Please fill out all fields to add a credit card.");
      return;
    }
    const newCard = {
      id: Date.now(),
      balance: parseFloat(newCardForm.balance) || 0,
      holder: newCardForm.holder,
      number: newCardForm.number.replace(/(\d{4})/g, "$1 ").trim(),
      expiry: newCardForm.expiry,
      type: newCardForm.type
    };
    setCards([...cards, newCard]);
    setNotifications(
      (prev) => [
        { id: Date.now(), text: `New credit card created for ${newCard.holder}.`, time: "Just now", type: "success", unread: true },
        ...prev
      ]
    );
    setNewCardForm({ balance: "", holder: "", number: "", expiry: "", type: "dark" });
    alert("Card successfully added!");
  };
  const openCardEditModal = (card) => {
    setEditingCard(card);
    setCardForm({
      balance: card.balance.toString(),
      holder: card.holder,
      number: card.number.replace(/\s+/g, ""),
      expiry: card.expiry,
      type: card.type
    });
    setCardModalOpen(true);
  };
  const handleCardUpdateSubmit = (e) => {
    e.preventDefault();
    if (!cardForm.holder || !cardForm.balance || !cardForm.number || !cardForm.expiry) {
      alert("Please enter valid inputs.");
      return;
    }
    setCards(cards.map((c) => {
      if (c.id === editingCard.id) {
        return {
          ...c,
          holder: cardForm.holder,
          balance: parseFloat(cardForm.balance),
          number: cardForm.number.replace(/(\d{4})/g, "$1 ").trim(),
          expiry: cardForm.expiry,
          type: cardForm.type
        };
      }
      return c;
    }));
    setCardModalOpen(false);
    setNotifications(
      (prev) => [
        { id: Date.now(), text: `Credit card details for ${cardForm.holder} updated.`, time: "Just now", type: "info", unread: true },
        ...prev
      ]
    );
    alert("Card updated successfully!");
  };
  const handleDeleteCard = (cardId) => {
    if (window.confirm("Are you sure you want to delete this credit card?")) {
      setCards(cards.filter((c) => c.id !== cardId));
      setNotifications(
        (prev) => [
          { id: Date.now(), text: `Credit card removed successfully.`, time: "Just now", type: "warning", unread: true },
          ...prev
        ]
      );
    }
  };
  const calculateLoan = (e) => {
    e.preventDefault();
    const P = parseFloat(loanCalc.amount);
    const r = parseFloat(loanCalc.rate) / 12 / 100;
    const n = parseInt(loanCalc.term);
    if (isNaN(P) || isNaN(r) || isNaN(n) || P <= 0 || r <= 0 || n <= 0) {
      alert("Please enter valid calculator inputs.");
      return;
    }
    const monthlyInstallment = P * r * Math.pow(1 + r, n) / (Math.pow(1 + r, n) - 1);
    setLoanCalc({ ...loanCalc, output: monthlyInstallment.toFixed(2) });
  };
  const toggleService = (srvId) => {
    setServices(services.map((srv) => {
      if (srv.id === srvId) {
        return { ...srv, enabled: !srv.enabled };
      }
      return srv;
    }));
  };
  const handleProfileSave = (e) => {
    e.preventDefault();
    setProfile({ ...tempProfile });
    setNotifications(
      (prev) => [
        { id: Date.now(), text: "Profile details updated successfully.", time: "Just now", type: "success", unread: true },
        ...prev
      ]
    );
    setSettingsSuccess("Profile updated successfully!");
    setTimeout(() => setSettingsSuccess(""), 3e3);
  };
  const handleSecuritySave = (e) => {
    e.preventDefault();
    if (!passwordForm.current || !passwordForm.new || !passwordForm.confirm) {
      alert("Please fill in all password fields.");
      return;
    }
    if (passwordForm.new !== passwordForm.confirm) {
      alert("New password and confirm password do not match!");
      return;
    }
    setPasswordForm({ current: "", new: "", confirm: "" });
    setNotifications(
      (prev) => [
        { id: Date.now(), text: "Security credentials / Password changed successfully.", time: "Just now", type: "success", unread: true },
        ...prev
      ]
    );
    setSettingsSuccess("Password changed successfully!");
    setTimeout(() => setSettingsSuccess(""), 3e3);
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "dashboard-container", children: [
    /* @__PURE__ */ jsxDEV("aside", { className: "sidebar", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "sidebar-header", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "logo-icon", children: /* @__PURE__ */ jsxDEV("svg", { width: "20", height: "20", viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg", children: [
          /* @__PURE__ */ jsxDEV("path", { d: "M12 2L2 7L12 12L22 7L12 2Z", fill: "white", stroke: "white", strokeWidth: "2", strokeLinejoin: "round" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 709,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("path", { d: "M2 17L12 22L22 17", stroke: "white", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 710,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("path", { d: "M2 12L12 17L22 12", stroke: "white", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 711,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 708,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 707,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("h1", { className: "logo-text", children: "BankDash." }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 714,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
        lineNumber: 706,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("nav", { className: "sidebar-nav", children: menuItems.filter((item) => {
        if (item.name === "User Details") {
          return userSession.role === "Admin" || userSession.role === "Editor";
        }
        return true;
      }).map((item) => {
        const Icon = item.icon;
        return /* @__PURE__ */ jsxDEV(
          "a",
          {
            href: "#",
            onClick: (e) => {
              e.preventDefault();
              setActiveTab(item.name);
            },
            className: `nav-item ${activeTab === item.name ? "active" : ""}`,
            children: [
              /* @__PURE__ */ jsxDEV(Icon, { size: 20 }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 734,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: item.name }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 735,
                columnNumber: 19
              }, this)
            ]
          },
          item.name,
          true,
          {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 728,
            columnNumber: 15
          },
          this
        );
      }) }, void 0, false, {
        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
        lineNumber: 717,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sidebar-footer", children: /* @__PURE__ */ jsxDEV("button", { onClick: handleLogout, className: "logout-btn", children: [
        /* @__PURE__ */ jsxDEV(LogOut, { size: 18 }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 743,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: "Logout" }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 744,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
        lineNumber: 742,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
        lineNumber: 741,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
      lineNumber: 705,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("main", { className: "main-content", children: [
      /* @__PURE__ */ jsxDEV("header", { className: "topbar", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "page-title", children: activeTab === "Dashboard" ? "Overview" : activeTab }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 752,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "topbar-actions", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "search-bar", children: [
            /* @__PURE__ */ jsxDEV(Search, { size: 18, className: "search-icon" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 756,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                placeholder: "Search for something",
                value: searchQuery,
                onChange: (e) => setSearchQuery(e.target.value)
              },
              void 0,
              false,
              {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 757,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 755,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: "icon-btn", onClick: () => setActiveTab("Setting"), "aria-label": "Settings", children: /* @__PURE__ */ jsxDEV(Settings, { size: 20 }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 766,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 765,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "icon-btn-container", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                className: `icon-btn ${notificationsOpen ? "active" : ""}`,
                onClick: () => setNotificationsOpen(!notificationsOpen),
                "aria-label": "Notifications",
                children: [
                  /* @__PURE__ */ jsxDEV(Bell, { size: 20 }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 775,
                    columnNumber: 17
                  }, this),
                  notifications.filter((n) => n.unread).length > 0 && /* @__PURE__ */ jsxDEV("span", { className: "notification-badge", children: notifications.filter((n) => n.unread).length }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 777,
                    columnNumber: 17
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 770,
                columnNumber: 15
              },
              this
            ),
            notificationsOpen && /* @__PURE__ */ jsxDEV("div", { className: "notification-dropdown", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "notification-header", children: [
                /* @__PURE__ */ jsxDEV("h4", { children: "Notifications" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 786,
                  columnNumber: 21
                }, this),
                notifications.filter((n) => n.unread).length > 0 && /* @__PURE__ */ jsxDEV("button", { className: "clear-notifications-btn", onClick: handleMarkAllRead, children: "Mark all as read" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 788,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 785,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("ul", { className: "notification-list", children: notifications.length === 0 ? /* @__PURE__ */ jsxDEV("li", { className: "notification-empty", children: "No notifications" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 795,
                columnNumber: 19
              }, this) : notifications.map(
                (n) => /* @__PURE__ */ jsxDEV(
                  "li",
                  {
                    className: `notification-item ${n.unread ? "unread" : ""}`,
                    onClick: () => {
                      setNotifications(notifications.map((item) => item.id === n.id ? { ...item, unread: false } : item));
                    },
                    children: [
                      /* @__PURE__ */ jsxDEV("span", { className: `notification-status-dot status-dot-${n.type}` }, void 0, false, {
                        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                        lineNumber: 805,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "notification-item-content", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "notification-item-text", children: n.text }, void 0, false, {
                          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                          lineNumber: 807,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "notification-item-time", children: n.time }, void 0, false, {
                          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                          lineNumber: 808,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                        lineNumber: 806,
                        columnNumber: 27
                      }, this)
                    ]
                  },
                  n.id,
                  true,
                  {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 798,
                    columnNumber: 19
                  },
                  this
                )
              ) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 793,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 784,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 769,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "user-profile", onClick: () => {
            setActiveTab("Setting");
            setSettingsSubTab("Edit Profile");
          }, children: /* @__PURE__ */ jsxDEV(
            "img",
            {
              src: profile.avatar,
              alt: "User Profile",
              className: "avatar-img"
            },
            void 0,
            false,
            {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 819,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 818,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 754,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
        lineNumber: 751,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "dashboard-content", children: [
        activeTab === "Dashboard" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "dashboard-section-row", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "col-8", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "section-header", children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "section-title", children: "My Cards" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 839,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("a", { href: "#", className: "see-all-link", onClick: (e) => {
                  e.preventDefault();
                  setActiveTab("Credit Cards");
                }, children: "See All" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 840,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 838,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "cards-container", children: cards.map(
                (card) => /* @__PURE__ */ jsxDEV("div", { className: `credit-card ${card.type}`, children: [
                  userSession.permissions?.manage_cards && /* @__PURE__ */ jsxDEV("div", { className: "card-actions-overlay", children: [
                    /* @__PURE__ */ jsxDEV("button", { className: "card-mini-btn", onClick: () => openCardEditModal(card), title: "Edit Card", children: /* @__PURE__ */ jsxDEV(Edit2, { size: 13 }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 849,
                      columnNumber: 31
                    }, this) }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 848,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("button", { className: "card-mini-btn", onClick: () => handleDeleteCard(card.id), title: "Delete Card", children: /* @__PURE__ */ jsxDEV(Trash2, { size: 13 }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 852,
                      columnNumber: 31
                    }, this) }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 851,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 847,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "card-header-row", children: [
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "card-label", children: "Balance" }, void 0, false, {
                        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                        lineNumber: 859,
                        columnNumber: 29
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "card-balance", children: [
                        "$",
                        card.balance.toLocaleString()
                      ] }, void 0, true, {
                        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                        lineNumber: 860,
                        columnNumber: 29
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 858,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "img",
                      {
                        src: card.type === "light" ? "https://img.icons8.com/ios/50/343c6a/chip.png" : "https://img.icons8.com/ios-filled/50/ffffff/chip.png",
                        alt: "Chip",
                        className: "card-chip"
                      },
                      void 0,
                      false,
                      {
                        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                        lineNumber: 862,
                        columnNumber: 27
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 857,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "card-middle-row", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "card-holder-info", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "card-label", children: "Card Holder" }, void 0, false, {
                        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                        lineNumber: 870,
                        columnNumber: 29
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "card-value", children: card.holder }, void 0, false, {
                        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                        lineNumber: 871,
                        columnNumber: 29
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 869,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "card-expiry-info", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "card-label", children: "Valid Thru" }, void 0, false, {
                        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                        lineNumber: 874,
                        columnNumber: 29
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "card-value", children: card.expiry }, void 0, false, {
                        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                        lineNumber: 875,
                        columnNumber: 29
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 873,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 868,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "card-footer-row", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "card-number", children: card.number }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 879,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("svg", { className: "card-logo", width: "44", height: "30", viewBox: "0 0 44 30", fill: "none", xmlns: "http://www.w3.org/2000/svg", children: [
                      /* @__PURE__ */ jsxDEV("circle", { cx: "15", cy: "15", r: "15", fill: card.type === "light" ? "#9199AF" : "white", fillOpacity: "0.5" }, void 0, false, {
                        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                        lineNumber: 881,
                        columnNumber: 29
                      }, this),
                      /* @__PURE__ */ jsxDEV("circle", { cx: "29", cy: "15", r: "15", fill: card.type === "light" ? "#9199AF" : "white", fillOpacity: "0.5" }, void 0, false, {
                        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                        lineNumber: 882,
                        columnNumber: 29
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 880,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 878,
                    columnNumber: 25
                  }, this)
                ] }, card.id, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 844,
                  columnNumber: 19
                }, this)
              ) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 842,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 837,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "col-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "section-header", children: /* @__PURE__ */ jsxDEV("h3", { className: "section-title", children: "Recent Transaction" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 893,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 892,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "panel", children: /* @__PURE__ */ jsxDEV("div", { className: "transactions-list", children: transactions.slice(0, 3).map(
                (tx) => /* @__PURE__ */ jsxDEV("div", { className: "transaction-item", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "transaction-left", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: `transaction-icon-wrapper ${tx.category === "Deposit" ? "blue" : tx.category === "Transfer" ? "green" : "yellow"}`, children: tx.category === "Deposit" ? /* @__PURE__ */ jsxDEV("svg", { width: "20", height: "20", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2.5", children: /* @__PURE__ */ jsxDEV("path", { d: "M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 906,
                      columnNumber: 35
                    }, this) }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 905,
                      columnNumber: 27
                    }, this) : tx.category === "Transfer" ? /* @__PURE__ */ jsxDEV("svg", { width: "20", height: "20", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2.5", children: /* @__PURE__ */ jsxDEV("path", { d: "M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 910,
                      columnNumber: 35
                    }, this) }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 909,
                      columnNumber: 27
                    }, this) : /* @__PURE__ */ jsxDEV("svg", { width: "20", height: "20", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2.5", children: [
                      /* @__PURE__ */ jsxDEV("rect", { x: "2", y: "5", width: "20", height: "14", rx: "2" }, void 0, false, {
                        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                        lineNumber: 914,
                        columnNumber: 35
                      }, this),
                      /* @__PURE__ */ jsxDEV("line", { x1: "2", y1: "10", x2: "22", y2: "10" }, void 0, false, {
                        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                        lineNumber: 915,
                        columnNumber: 35
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 913,
                      columnNumber: 27
                    }, this) }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 900,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "transaction-details", children: [
                      /* @__PURE__ */ jsxDEV("h4", { children: tx.desc }, void 0, false, {
                        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                        lineNumber: 920,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV("p", { children: tx.date }, void 0, false, {
                        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                        lineNumber: 921,
                        columnNumber: 31
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 919,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 899,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: `transaction-amount ${tx.type === "expense" ? "negative" : "positive"}`, children: [
                    tx.type === "expense" ? "-" : "+",
                    "$",
                    tx.amount.toLocaleString()
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 924,
                    columnNumber: 27
                  }, this)
                ] }, tx.id, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 898,
                  columnNumber: 21
                }, this)
              ) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 896,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 895,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 891,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 835,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "dashboard-section-row", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "col-8", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "section-header", children: /* @__PURE__ */ jsxDEV("h3", { className: "section-title", children: "Weekly Activity" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 939,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 938,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "panel", style: { height: "320px" }, children: [
                /* @__PURE__ */ jsxDEV("div", { className: "chart-legend", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "legend-item", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "legend-color withdraw" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 944,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { children: "Withdraw" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 945,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 943,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "legend-item", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "legend-color deposit" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 948,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { children: "Deposit" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 949,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 947,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 942,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("svg", { className: "weekly-chart-svg", viewBox: "0 0 600 220", children: [
                  /* @__PURE__ */ jsxDEV("line", { x1: "50", y1: "30", x2: "560", y2: "30", stroke: "#F3F3F5", strokeWidth: "1" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 953,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("line", { x1: "50", y1: "70", x2: "560", y2: "70", stroke: "#F3F3F5", strokeWidth: "1" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 954,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("line", { x1: "50", y1: "110", x2: "560", y2: "110", stroke: "#F3F3F5", strokeWidth: "1" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 955,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("line", { x1: "50", y1: "150", x2: "560", y2: "150", stroke: "#F3F3F5", strokeWidth: "1" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 956,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("line", { x1: "50", y1: "190", x2: "560", y2: "190", stroke: "#E6EFF5", strokeWidth: "1.5" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 957,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("text", { x: "35", y: "34", fill: "#718EBF", fontSize: "12", fontWeight: "500", textAnchor: "end", children: "500" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 959,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("text", { x: "35", y: "74", fill: "#718EBF", fontSize: "12", fontWeight: "500", textAnchor: "end", children: "300" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 960,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("text", { x: "35", y: "114", fill: "#718EBF", fontSize: "12", fontWeight: "500", textAnchor: "end", children: "200" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 961,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("text", { x: "35", y: "154", fill: "#718EBF", fontSize: "12", fontWeight: "500", textAnchor: "end", children: "100" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 962,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("text", { x: "35", y: "194", fill: "#718EBF", fontSize: "12", fontWeight: "500", textAnchor: "end", children: "0" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 963,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("g", { className: "bar-group", children: [
                    /* @__PURE__ */ jsxDEV("rect", { x: "85", y: "62", width: "14", height: "128", rx: "4", fill: "#343C6A" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 966,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("rect", { x: "103", y: "122", width: "14", height: "68", rx: "4", fill: "#396AFF" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 967,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("text", { x: "101", y: "210", fill: "#718EBF", fontSize: "12", fontWeight: "500", textAnchor: "middle", children: "Sat" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 968,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 965,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("g", { className: "bar-group", children: [
                    /* @__PURE__ */ jsxDEV("rect", { x: "155", y: "94", width: "14", height: "96", rx: "4", fill: "#343C6A" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 971,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("rect", { x: "173", y: "158", width: "14", height: "32", rx: "4", fill: "#396AFF" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 972,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("text", { x: "171", y: "210", fill: "#718EBF", fontSize: "12", fontWeight: "500", textAnchor: "middle", children: "Sun" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 973,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 970,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("g", { className: "bar-group", children: [
                    /* @__PURE__ */ jsxDEV("rect", { x: "225", y: "102", width: "14", height: "88", rx: "4", fill: "#343C6A" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 976,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("rect", { x: "243", y: "118", width: "14", height: "72", rx: "4", fill: "#396AFF" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 977,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("text", { x: "241", y: "210", fill: "#718EBF", fontSize: "12", fontWeight: "500", textAnchor: "middle", children: "Mon" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 978,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 975,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("g", { className: "bar-group", children: [
                    /* @__PURE__ */ jsxDEV("rect", { x: "295", y: "62", width: "14", height: "128", rx: "4", fill: "#343C6A" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 981,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("rect", { x: "313", y: "90", width: "14", height: "100", rx: "4", fill: "#396AFF" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 982,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("text", { x: "311", y: "210", fill: "#718EBF", fontSize: "12", fontWeight: "500", textAnchor: "middle", children: "Tue" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 983,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 980,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("g", { className: "bar-group", children: [
                    /* @__PURE__ */ jsxDEV("rect", { x: "365", y: "146", width: "14", height: "44", rx: "4", fill: "#343C6A" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 986,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("rect", { x: "383", y: "122", width: "14", height: "68", rx: "4", fill: "#396AFF" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 987,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("text", { x: "381", y: "210", fill: "#718EBF", fontSize: "12", fontWeight: "500", textAnchor: "middle", children: "Wed" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 988,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 985,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("g", { className: "bar-group", children: [
                    /* @__PURE__ */ jsxDEV("rect", { x: "435", y: "86", width: "14", height: "104", rx: "4", fill: "#343C6A" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 991,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("rect", { x: "453", y: "122", width: "14", height: "68", rx: "4", fill: "#396AFF" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 992,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("text", { x: "451", y: "210", fill: "#718EBF", fontSize: "12", fontWeight: "500", textAnchor: "middle", children: "Thu" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 993,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 990,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("g", { className: "bar-group", children: [
                    /* @__PURE__ */ jsxDEV("rect", { x: "505", y: "82", width: "14", height: "108", rx: "4", fill: "#343C6A" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 996,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("rect", { x: "523", y: "102", width: "14", height: "88", rx: "4", fill: "#396AFF" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 997,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("text", { x: "521", y: "210", fill: "#718EBF", fontSize: "12", fontWeight: "500", textAnchor: "middle", children: "Fri" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 998,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 995,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 952,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 941,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 937,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "col-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "section-header", children: /* @__PURE__ */ jsxDEV("h3", { className: "section-title", children: "Expense Statistics" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1007,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1006,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "panel", style: { height: "320px" }, children: [
                /* @__PURE__ */ jsxDEV("div", { className: "expense-donut-container", children: /* @__PURE__ */ jsxDEV("svg", { className: "donut-chart-svg", viewBox: "0 0 200 200", children: [
                  /* @__PURE__ */ jsxDEV("circle", { cx: "100", cy: "100", r: "85", fill: "none", stroke: "#F5F7FA", strokeWidth: "16" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1012,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("circle", { className: "donut-segment", cx: "100", cy: "100", r: "70", fill: "none", stroke: "#396AFF", strokeWidth: "20", strokeDasharray: "153.9 440", strokeDashoffset: "0", transform: "rotate(-90 100 100)" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1013,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("circle", { className: "donut-segment", cx: "100", cy: "100", r: "70", fill: "none", stroke: "#343C6A", strokeWidth: "20", strokeDasharray: "132 440", strokeDashoffset: "-153.9", transform: "rotate(-90 100 100)" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1014,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("circle", { className: "donut-segment", cx: "100", cy: "100", r: "70", fill: "none", stroke: "#FC7900", strokeWidth: "20", strokeDasharray: "88 440", strokeDashoffset: "-285.9", transform: "rotate(-90 100 100)" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1015,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("circle", { className: "donut-segment", cx: "100", cy: "100", r: "70", fill: "none", stroke: "#16DBAA", strokeWidth: "20", strokeDasharray: "66 440", strokeDashoffset: "-373.9", transform: "rotate(-90 100 100)" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1016,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("text", { x: "100", y: "95", className: "chart-center-text", fill: "#343C6A", fontSize: "18", fontWeight: "700", children: "30%" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1018,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("text", { x: "100", y: "115", className: "chart-center-text", fill: "#718EBF", fontSize: "11", fontWeight: "600", letterSpacing: "0.5", children: "Entertainment" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1019,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1011,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1010,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.5rem 1rem", marginTop: "0.5rem", padding: "0 0.5rem" }, children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "legend-item", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "legend-color", style: { background: "#343C6A" } }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1023,
                      columnNumber: 52
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.8rem", fontWeight: 600 }, children: "30% Ent." }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1023,
                      columnNumber: 124
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1023,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "legend-item", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "legend-color", style: { background: "#396AFF" } }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1024,
                      columnNumber: 52
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.8rem", fontWeight: 600 }, children: "35% Others" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1024,
                      columnNumber: 124
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1024,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "legend-item", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "legend-color", style: { background: "#FC7900" } }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1025,
                      columnNumber: 52
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.8rem", fontWeight: 600 }, children: "20% Inv." }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1025,
                      columnNumber: 124
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1025,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "legend-item", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "legend-color", style: { background: "#16DBAA" } }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1026,
                      columnNumber: 52
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.8rem", fontWeight: 600 }, children: "15% Bills" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1026,
                      columnNumber: 124
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1026,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1022,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1009,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1005,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 935,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "dashboard-section-row", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "col-5", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "section-header", children: /* @__PURE__ */ jsxDEV("h3", { className: "section-title", children: "Quick Transfer" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1037,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1036,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "panel", style: { height: "280px" }, children: /* @__PURE__ */ jsxDEV("div", { className: "quick-transfer-container", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "users-slider-row", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "users-slider", children: quickTransferUsers.map(
                    (user, idx) => /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: `slider-user ${selectedUserIndex === idx ? "selected" : ""}`,
                        onClick: () => setSelectedUserIndex(idx),
                        children: [
                          /* @__PURE__ */ jsxDEV("img", { src: user.avatar, alt: user.name, className: "user-avatar" }, void 0, false, {
                            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                            lineNumber: 1049,
                            columnNumber: 31
                          }, this),
                          /* @__PURE__ */ jsxDEV("span", { className: "user-name", children: user.name.split(" ")[0] }, void 0, false, {
                            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                            lineNumber: 1050,
                            columnNumber: 31
                          }, this),
                          /* @__PURE__ */ jsxDEV("span", { className: "user-role", children: user.role }, void 0, false, {
                            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                            lineNumber: 1051,
                            columnNumber: 31
                          }, this)
                        ]
                      },
                      user.name,
                      true,
                      {
                        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                        lineNumber: 1044,
                        columnNumber: 25
                      },
                      this
                    )
                  ) }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1042,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("button", { className: "slider-arrow-btn", "aria-label": "Next User", children: /* @__PURE__ */ jsxDEV(ChevronRight, { size: 20 }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1056,
                    columnNumber: 27
                  }, this) }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1055,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1041,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("form", { onSubmit: handleQuickTransfer, className: "transfer-action-row", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "transfer-label", children: "Write Amount" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1061,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "amount-input-wrapper", style: !userSession.permissions?.manage_tx ? { opacity: 0.7 } : {}, children: [
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "text",
                        placeholder: userSession.permissions?.manage_tx ? "525.50" : "Disabled (Read-Only)",
                        value: transferAmount,
                        onChange: (e) => setTransferAmount(e.target.value),
                        disabled: !userSession.permissions?.manage_tx
                      },
                      void 0,
                      false,
                      {
                        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                        lineNumber: 1063,
                        columnNumber: 27
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "send-btn", disabled: !userSession.permissions?.manage_tx, style: !userSession.permissions?.manage_tx ? { opacity: 0.5, cursor: "not-allowed", pointerEvents: "none" } : {}, children: [
                      /* @__PURE__ */ jsxDEV("span", { children: "Send" }, void 0, false, {
                        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                        lineNumber: 1071,
                        columnNumber: 29
                      }, this),
                      /* @__PURE__ */ jsxDEV(Send, { size: 15 }, void 0, false, {
                        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                        lineNumber: 1072,
                        columnNumber: 29
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1070,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1062,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1060,
                  columnNumber: 23
                }, this),
                transferSuccess && /* @__PURE__ */ jsxDEV("div", { style: {
                  marginTop: "0.75rem",
                  padding: "0.5rem 1rem",
                  background: "rgba(22, 219, 170, 0.12)",
                  color: "#0e906f",
                  borderRadius: "12px",
                  fontSize: "0.85rem",
                  fontWeight: 600,
                  textAlign: "center",
                  border: "1px solid rgba(22, 219, 170, 0.25)",
                  animation: "slideUp 0.3s ease-out"
                }, children: transferSuccess }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1077,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1040,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1039,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1035,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "col-7", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "section-header", children: /* @__PURE__ */ jsxDEV("h3", { className: "section-title", children: "Balance History" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1099,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1098,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "panel", style: { height: "280px" }, children: /* @__PURE__ */ jsxDEV("div", { className: "balance-chart-container", children: /* @__PURE__ */ jsxDEV("svg", { className: "balance-chart-svg", viewBox: "0 0 600 200", children: [
                /* @__PURE__ */ jsxDEV("defs", { children: /* @__PURE__ */ jsxDEV("linearGradient", { id: "balanceGradient", x1: "0", y1: "0", x2: "0", y2: "1", children: [
                  /* @__PURE__ */ jsxDEV("stop", { offset: "0%", stopColor: "#1814F3", stopOpacity: "0.22" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1106,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("stop", { offset: "100%", stopColor: "#1814F3", stopOpacity: "0.0" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1107,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1105,
                  columnNumber: 27
                }, this) }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1104,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("line", { className: "balance-grid-line", x1: "40", y1: "30", x2: "570", y2: "30", stroke: "#F3F3F5", strokeWidth: "1" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1111,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("line", { className: "balance-grid-line", x1: "40", y1: "75", x2: "570", y2: "75", stroke: "#F3F3F5", strokeWidth: "1" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1112,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("line", { className: "balance-grid-line", x1: "40", y1: "120", x2: "570", y2: "120", stroke: "#F3F3F5", strokeWidth: "1" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1113,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("line", { className: "balance-grid-line", x1: "40", y1: "165", x2: "570", y2: "165", stroke: "#E6EFF5", strokeWidth: "1.5" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1114,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("text", { x: "30", y: "34", fill: "#718EBF", fontSize: "12", fontWeight: "500", textAnchor: "end", children: "800" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1116,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("text", { x: "30", y: "79", fill: "#718EBF", fontSize: "12", fontWeight: "500", textAnchor: "end", children: "400" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1117,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("text", { x: "30", y: "124", fill: "#718EBF", fontSize: "12", fontWeight: "500", textAnchor: "end", children: "200" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1118,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("text", { x: "30", y: "169", fill: "#718EBF", fontSize: "12", fontWeight: "500", textAnchor: "end", children: "0" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1119,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("text", { x: "60", y: "190", fill: "#718EBF", fontSize: "12", fontWeight: "500", textAnchor: "middle", children: "Jul" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1121,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("text", { x: "145", y: "190", fill: "#718EBF", fontSize: "12", fontWeight: "500", textAnchor: "middle", children: "Aug" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1122,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("text", { x: "230", y: "190", fill: "#718EBF", fontSize: "12", fontWeight: "500", textAnchor: "middle", children: "Sep" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1123,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("text", { x: "315", y: "190", fill: "#718EBF", fontSize: "12", fontWeight: "500", textAnchor: "middle", children: "Oct" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1124,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("text", { x: "400", y: "190", fill: "#718EBF", fontSize: "12", fontWeight: "500", textAnchor: "middle", children: "Nov" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1125,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("text", { x: "485", y: "190", fill: "#718EBF", fontSize: "12", fontWeight: "500", textAnchor: "middle", children: "Dec" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1126,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("text", { x: "560", y: "190", fill: "#718EBF", fontSize: "12", fontWeight: "500", textAnchor: "middle", children: "Jan" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1127,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "path",
                  {
                    d: "M 60 165 C 102.5 150, 102.5 110, 145 110 C 187.5 110, 187.5 130, 230 130 C 272.5 130, 272.5 60, 315 60 C 357.5 60, 357.5 120, 400 120 C 442.5 120, 442.5 80, 485 80 C 527.5 80, 527.5 50, 560 50 L 560 165 Z",
                    fill: "url(#balanceGradient)"
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1129,
                    columnNumber: 25
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "path",
                  {
                    d: "M 60 165 C 102.5 150, 102.5 110, 145 110 C 187.5 110, 187.5 130, 230 130 C 272.5 130, 272.5 60, 315 60 C 357.5 60, 357.5 120, 400 120 C 442.5 120, 442.5 80, 485 80 C 527.5 80, 527.5 50, 560 50",
                    fill: "none",
                    stroke: "#1814F3",
                    strokeWidth: "3.5",
                    strokeLinecap: "round"
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1134,
                    columnNumber: 25
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("circle", { cx: "315", cy: "60", r: "5", fill: "#1814F3", stroke: "#FFFFFF", strokeWidth: "2" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1142,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("circle", { cx: "560", cy: "50", r: "5", fill: "#1814F3", stroke: "#FFFFFF", strokeWidth: "2" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1143,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1103,
                columnNumber: 23
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1102,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1101,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1097,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 1033,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 833,
          columnNumber: 11
        }, this),
        activeTab === "Transactions" && /* @__PURE__ */ jsxDEV("div", { className: "col-12", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "section-header", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "filter-tabs", style: { marginBottom: 0, borderBottom: "none" }, children: [
              /* @__PURE__ */ jsxDEV(
                "div",
                {
                  className: `filter-tab ${transactionTypeFilter === "All" ? "active" : ""}`,
                  onClick: () => setTransactionTypeFilter("All"),
                  children: "All Transactions"
                },
                void 0,
                false,
                {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1159,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "div",
                {
                  className: `filter-tab ${transactionTypeFilter === "income" ? "active" : ""}`,
                  onClick: () => setTransactionTypeFilter("income"),
                  children: "Income"
                },
                void 0,
                false,
                {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1165,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "div",
                {
                  className: `filter-tab ${transactionTypeFilter === "expense" ? "active" : ""}`,
                  onClick: () => setTransactionTypeFilter("expense"),
                  children: "Expense"
                },
                void 0,
                false,
                {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1171,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1158,
              columnNumber: 17
            }, this),
            userSession.permissions?.manage_tx && /* @__PURE__ */ jsxDEV("button", { className: "settings-save-btn", style: { margin: 0, padding: "0.6rem 1.5rem", borderRadius: "40px" }, onClick: openTxCreateModal, children: [
              /* @__PURE__ */ jsxDEV(Plus, { size: 16, style: { marginRight: "0.4rem", verticalAlign: "middle" } }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1181,
                columnNumber: 21
              }, this),
              "Add Transaction"
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1180,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 1157,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "table-wrapper", children: /* @__PURE__ */ jsxDEV("table", { className: "custom-table", children: [
            /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { children: [
              /* @__PURE__ */ jsxDEV("th", { children: "Description" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1191,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("th", { children: "Transaction ID" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1192,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("th", { children: "Category" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1193,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("th", { children: "Method" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1194,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("th", { children: "Date" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1195,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("th", { children: "Amount" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1196,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("th", { children: "Status" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1197,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("th", { children: "Actions" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1198,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1190,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1189,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("tbody", { children: transactions.filter((tx) => transactionTypeFilter === "All" || tx.type === transactionTypeFilter).filter(
              (tx) => tx.desc.toLowerCase().includes(searchQuery.toLowerCase()) || tx.id.toLowerCase().includes(searchQuery.toLowerCase()) || tx.category.toLowerCase().includes(searchQuery.toLowerCase())
            ).map(
              (tx) => /* @__PURE__ */ jsxDEV("tr", { children: [
                /* @__PURE__ */ jsxDEV("td", { style: { display: "flex", alignItems: "center", gap: "0.75rem" }, children: [
                  /* @__PURE__ */ jsxDEV("div", { className: `transaction-icon-wrapper ${tx.type === "income" ? "green" : "red"}`, style: { width: "36px", height: "36px" }, children: tx.type === "income" ? /* @__PURE__ */ jsxDEV(TrendingUp, { size: 16 }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1215,
                    columnNumber: 55
                  }, this) : /* @__PURE__ */ jsxDEV(TrendingUp, { size: 16, style: { transform: "rotate(180deg)" } }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1215,
                    columnNumber: 82
                  }, this) }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1212,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { children: tx.desc }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1217,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1211,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("td", { style: { color: "#718EBF" }, children: tx.id }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1219,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("td", { children: tx.category }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1220,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("td", { children: tx.method }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1221,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("td", { style: { color: "#718EBF" }, children: tx.date }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1222,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("td", { style: {
                  fontWeight: "700",
                  color: tx.type === "expense" ? "var(--error)" : "var(--success)"
                }, children: [
                  tx.type === "expense" ? "-" : "+",
                  "$",
                  tx.amount.toLocaleString()
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1223,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("span", { className: `status-badge ${tx.status === "Success" ? "success" : tx.status === "Pending" ? "pending" : "failed"}`, children: tx.status }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1230,
                  columnNumber: 29
                }, this) }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1229,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("td", { children: userSession.permissions?.manage_tx ? /* @__PURE__ */ jsxDEV("div", { className: "action-btn-group", children: [
                  /* @__PURE__ */ jsxDEV("button", { className: "table-action-btn edit", onClick: () => openTxEditModal(tx), title: "Edit", children: /* @__PURE__ */ jsxDEV(Edit2, { size: 15 }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1242,
                    columnNumber: 35
                  }, this) }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1241,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("button", { className: "table-action-btn delete", onClick: () => handleDeleteTx(tx.id), title: "Delete", children: /* @__PURE__ */ jsxDEV(Trash2, { size: 15 }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1245,
                    columnNumber: 35
                  }, this) }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1244,
                    columnNumber: 33
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1240,
                  columnNumber: 23
                }, this) : /* @__PURE__ */ jsxDEV("span", { style: { color: "#94a3b8", fontSize: "0.85rem", fontWeight: 600 }, children: "Read-Only" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1249,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1237,
                  columnNumber: 27
                }, this)
              ] }, tx.id, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1210,
                columnNumber: 19
              }, this)
            ) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1201,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 1188,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 1187,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 1156,
          columnNumber: 11
        }, this),
        activeTab === "Accounts" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "summary-cards-grid", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "summary-card", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "summary-icon-box", style: { background: "#FFF5E9", color: "#FFBB38" }, children: /* @__PURE__ */ jsxDEV(DollarSign, { size: 24 }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1269,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1268,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("div", { className: "summary-label", children: "My Balance" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1272,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "summary-val", children: [
                  "$",
                  cards.reduce((acc, c) => acc + c.balance, 0).toLocaleString()
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1273,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1271,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1267,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "summary-card", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "summary-icon-box", style: { background: "#E7F3FF", color: "#396AFF" }, children: /* @__PURE__ */ jsxDEV(TrendingUp, { size: 24 }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1279,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1278,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("div", { className: "summary-label", children: "Income Growth" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1282,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "summary-val", children: "+15.8%" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1283,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1281,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1277,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "summary-card", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "summary-icon-box", style: { background: "#DCFCE7", color: "#10B981" }, children: /* @__PURE__ */ jsxDEV(CreditCard, { size: 24 }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1289,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1288,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("div", { className: "summary-label", children: "Total Accounts" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1292,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "summary-val", children: [
                  cards.length,
                  " Active"
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1293,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1291,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1287,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 1266,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "dashboard-section-row", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "col-8", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "section-header", children: /* @__PURE__ */ jsxDEV("h3", { className: "section-title", children: "Recent Deposits" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1302,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1301,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "table-wrapper", children: /* @__PURE__ */ jsxDEV("table", { className: "custom-table", children: [
                /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { children: [
                  /* @__PURE__ */ jsxDEV("th", { children: "Description" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1308,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("th", { children: "Date" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1309,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("th", { children: "Method" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1310,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("th", { children: "Amount" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1311,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1307,
                  columnNumber: 25
                }, this) }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1306,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("tbody", { children: transactions.filter((tx) => tx.type === "income").slice(0, 4).map(
                  (tx) => /* @__PURE__ */ jsxDEV("tr", { children: [
                    /* @__PURE__ */ jsxDEV("td", { children: tx.desc }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1320,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV("td", { style: { color: "#718EBF" }, children: tx.date }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1321,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV("td", { children: tx.method }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1322,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV("td", { style: { color: "var(--success)", fontWeight: "700" }, children: [
                      "+$",
                      tx.amount.toLocaleString()
                    ] }, void 0, true, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1323,
                      columnNumber: 31
                    }, this)
                  ] }, tx.id, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1319,
                    columnNumber: 23
                  }, this)
                ) }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1314,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1305,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1304,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1300,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "col-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "section-header", children: /* @__PURE__ */ jsxDEV("h3", { className: "section-title", children: "Weekly Cash Flow" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1336,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1335,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "panel", style: { padding: "2rem", justifyContent: "space-around" }, children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.85rem", color: "#718EBF" }, children: "Average Deposit" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1340,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "1.75rem", fontWeight: 700, color: "var(--success)", marginTop: "0.25rem" }, children: "+$3,450" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1341,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1339,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.85rem", color: "#718EBF" }, children: "Average Withdrawal" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1344,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "1.75rem", fontWeight: 700, color: "var(--error)", marginTop: "0.25rem" }, children: "-$412" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1345,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1343,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1338,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1334,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 1299,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 1264,
          columnNumber: 11
        }, this),
        activeTab === "Investments" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "summary-cards-grid", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "summary-card", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "summary-icon-box", style: { background: "#E7F3FF", color: "#396AFF" }, children: /* @__PURE__ */ jsxDEV(Briefcase, { size: 24 }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1361,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1360,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("div", { className: "summary-label", children: "Total Value" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1364,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "summary-val", children: "$65,240" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1365,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1363,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1359,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "summary-card", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "summary-icon-box", style: { background: "#DCFCE7", color: "#10B981" }, children: /* @__PURE__ */ jsxDEV(TrendingUp, { size: 24 }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1370,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1369,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("div", { className: "summary-label", children: "Net Growth" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1373,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "summary-val", children: "+$8,241 (12.4%)" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1374,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1372,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1368,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "summary-card", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "summary-icon-box", style: { background: "#FFF5E9", color: "#FFBB38" }, children: /* @__PURE__ */ jsxDEV(Sparkles, { size: 24 }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1379,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1378,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("div", { className: "summary-label", children: "Assets Count" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1382,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "summary-val", children: "4 Active" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1383,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1381,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1377,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 1358,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "dashboard-section-row", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "col-7", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "section-header", children: /* @__PURE__ */ jsxDEV("h3", { className: "section-title", children: "My Portfolio" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1391,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1390,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "panel", style: { height: "300px" }, children: /* @__PURE__ */ jsxDEV("div", { className: "stocks-list", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "stock-row-item", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "stock-name-col", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "stock-icon-wrapper", style: { background: "#000000" }, children: "A" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1397,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "stock-title", children: "Apple Inc." }, void 0, false, {
                        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                        lineNumber: 1399,
                        columnNumber: 29
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "stock-desc", children: "AAPL (Nasdaq)" }, void 0, false, {
                        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                        lineNumber: 1400,
                        columnNumber: 29
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1398,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1396,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "stock-val-box", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "stock-price", children: "$174.12" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1404,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "stock-change-percent positive", children: "+1.85%" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1405,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1403,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1395,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "stock-row-item", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "stock-name-col", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "stock-icon-wrapper", style: { background: "#E82127" }, children: "T" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1410,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "stock-title", children: "Tesla Inc." }, void 0, false, {
                        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                        lineNumber: 1412,
                        columnNumber: 29
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "stock-desc", children: "TSLA (Nasdaq)" }, void 0, false, {
                        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                        lineNumber: 1413,
                        columnNumber: 29
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1411,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1409,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "stock-val-box", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "stock-price", children: "$185.00" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1417,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "stock-change-percent negative", children: "-2.40%" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1418,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1416,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1408,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "stock-row-item", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "stock-name-col", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "stock-icon-wrapper", style: { background: "#4285F4" }, children: "G" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1423,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "stock-title", children: "Alphabet Inc." }, void 0, false, {
                        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                        lineNumber: 1425,
                        columnNumber: 29
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "stock-desc", children: "GOOGL (Nasdaq)" }, void 0, false, {
                        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                        lineNumber: 1426,
                        columnNumber: 29
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1424,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1422,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "stock-val-box", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "stock-price", children: "$154.20" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1430,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "stock-change-percent positive", children: "+0.95%" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1431,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1429,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1421,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1394,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1393,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1389,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "col-5", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "section-header", children: /* @__PURE__ */ jsxDEV("h3", { className: "section-title", children: "Investment Growth Chart" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1440,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1439,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "panel", style: { height: "300px", display: "flex", alignItems: "center", justifyContent: "center" }, children: /* @__PURE__ */ jsxDEV("svg", { width: "220", height: "150", viewBox: "0 0 220 150", children: [
                /* @__PURE__ */ jsxDEV("path", { d: "M 10 130 C 50 110, 80 40, 120 70 C 160 100, 180 20, 210 10", fill: "none", stroke: "var(--accent-primary)", strokeWidth: "4", strokeLinecap: "round" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1444,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("circle", { cx: "210", cy: "10", r: "6", fill: "var(--accent-primary)", stroke: "#FFFFFF", strokeWidth: "2" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1445,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("text", { x: "10", y: "145", fill: "#718EBF", fontSize: "10", children: "2021" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1446,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("text", { x: "210", y: "145", fill: "#718EBF", fontSize: "10", textAnchor: "end", children: "2026" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1447,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1443,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1442,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1438,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 1388,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 1357,
          columnNumber: 11
        }, this),
        activeTab === "Credit Cards" && /* @__PURE__ */ jsxDEV("div", { className: "dashboard-section-row", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "col-7", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "section-header", children: /* @__PURE__ */ jsxDEV("h3", { className: "section-title", children: "My Cards" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1463,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1462,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(290px, 1fr))", gap: "1.5rem" }, children: cards.map(
              (card) => /* @__PURE__ */ jsxDEV("div", { className: `credit-card ${card.type}`, style: { width: "100%" }, children: [
                userSession.permissions?.manage_cards && /* @__PURE__ */ jsxDEV("div", { className: "card-actions-overlay", children: [
                  /* @__PURE__ */ jsxDEV("button", { className: "card-mini-btn", onClick: () => openCardEditModal(card), title: "Edit Card", children: /* @__PURE__ */ jsxDEV(Edit2, { size: 13 }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1472,
                    columnNumber: 29
                  }, this) }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1471,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("button", { className: "card-mini-btn", onClick: () => handleDeleteCard(card.id), title: "Delete Card", children: /* @__PURE__ */ jsxDEV(Trash2, { size: 13 }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1475,
                    columnNumber: 29
                  }, this) }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1474,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1470,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "card-header-row", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "card-label", children: "Balance" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1482,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "card-balance", children: [
                      "$",
                      card.balance.toLocaleString()
                    ] }, void 0, true, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1483,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1481,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "img",
                    {
                      src: card.type === "light" ? "https://img.icons8.com/ios/50/343c6a/chip.png" : "https://img.icons8.com/ios-filled/50/ffffff/chip.png",
                      alt: "Chip",
                      className: "card-chip"
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1485,
                      columnNumber: 25
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1480,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "card-middle-row", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "card-holder-info", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "card-label", children: "Card Holder" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1493,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "card-value", children: card.holder }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1494,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1492,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "card-expiry-info", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "card-label", children: "Valid Thru" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1497,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "card-value", children: card.expiry }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1498,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1496,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1491,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "card-footer-row", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "card-number", children: card.number }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1502,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("svg", { className: "card-logo", width: "44", height: "30", viewBox: "0 0 44 30", fill: "none", xmlns: "http://www.w3.org/2000/svg", children: [
                    /* @__PURE__ */ jsxDEV("circle", { cx: "15", cy: "15", r: "15", fill: card.type === "light" ? "#9199AF" : "white", fillOpacity: "0.5" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1504,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("circle", { cx: "29", cy: "15", r: "15", fill: card.type === "light" ? "#9199AF" : "white", fillOpacity: "0.5" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1505,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1503,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1501,
                  columnNumber: 23
                }, this)
              ] }, card.id, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1467,
                columnNumber: 17
              }, this)
            ) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1465,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 1461,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "col-5", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "section-header", children: /* @__PURE__ */ jsxDEV("h3", { className: "section-title", children: "Add New Card" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1516,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1515,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "panel", style: { minHeight: "340px" }, children: [
              !userSession.permissions?.manage_cards && /* @__PURE__ */ jsxDEV("div", { style: { color: "var(--error)", background: "rgba(255, 75, 74, 0.08)", border: "1px solid rgba(255, 75, 74, 0.2)", padding: "0.75rem", borderRadius: "12px", fontSize: "0.85rem", fontWeight: 600, marginBottom: "1rem", textAlign: "center" }, children: "Read-Only: Card creation is disabled." }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1520,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("form", { onSubmit: handleAddCard, className: "add-card-form", style: !userSession.permissions?.manage_cards ? { opacity: 0.6 } : {}, children: [
                /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", style: { gridColumn: "span 2" }, children: [
                  /* @__PURE__ */ jsxDEV("label", { children: "Card Holder Name" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1526,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      className: "settings-form-input",
                      placeholder: "John Doe",
                      value: newCardForm.holder,
                      onChange: (e) => setNewCardForm({ ...newCardForm, holder: e.target.value }),
                      disabled: !userSession.permissions?.manage_cards
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1527,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1525,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", children: [
                  /* @__PURE__ */ jsxDEV("label", { children: "Starting Balance ($)" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1537,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "number",
                      className: "settings-form-input",
                      placeholder: "2500",
                      value: newCardForm.balance,
                      onChange: (e) => setNewCardForm({ ...newCardForm, balance: e.target.value }),
                      disabled: !userSession.permissions?.manage_cards
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1538,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1536,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", children: [
                  /* @__PURE__ */ jsxDEV("label", { children: "Expiry Date" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1548,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      className: "settings-form-input",
                      placeholder: "MM/YY",
                      maxLength: "5",
                      value: newCardForm.expiry,
                      onChange: (e) => setNewCardForm({ ...newCardForm, expiry: e.target.value }),
                      disabled: !userSession.permissions?.manage_cards
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1549,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1547,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", children: [
                  /* @__PURE__ */ jsxDEV("label", { children: "Card Number (16 Digits)" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1560,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      className: "settings-form-input",
                      placeholder: "4812384910293847",
                      maxLength: "16",
                      value: newCardForm.number,
                      onChange: (e) => setNewCardForm({ ...newCardForm, number: e.target.value }),
                      disabled: !userSession.permissions?.manage_cards
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1561,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1559,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", children: [
                  /* @__PURE__ */ jsxDEV("label", { children: "Card Color theme" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1572,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "select",
                    {
                      className: "settings-form-input",
                      value: newCardForm.type,
                      onChange: (e) => setNewCardForm({ ...newCardForm, type: e.target.value }),
                      disabled: !userSession.permissions?.manage_cards,
                      children: [
                        /* @__PURE__ */ jsxDEV("option", { value: "dark", children: "Dark Gradient" }, void 0, false, {
                          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                          lineNumber: 1579,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "light", children: "Light Border" }, void 0, false, {
                          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                          lineNumber: 1580,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "green", children: "Emerald Green" }, void 0, false, {
                          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                          lineNumber: 1581,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "purple", children: "Royal Purple" }, void 0, false, {
                          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                          lineNumber: 1582,
                          columnNumber: 25
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 1573,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1571,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "add-card-btn", disabled: !userSession.permissions?.manage_cards, style: !userSession.permissions?.manage_cards ? { opacity: 0.5, cursor: "not-allowed", pointerEvents: "none" } : {}, children: "Create Credit Card" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1585,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1524,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1518,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 1514,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 1459,
          columnNumber: 11
        }, this),
        activeTab === "Loans" && /* @__PURE__ */ jsxDEV("div", { className: "dashboard-section-row", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "col-8", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "section-header", children: /* @__PURE__ */ jsxDEV("h3", { className: "section-title", children: "Active Loans" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1602,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1601,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "table-wrapper", children: /* @__PURE__ */ jsxDEV("table", { className: "custom-table", children: [
              /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { children: [
                /* @__PURE__ */ jsxDEV("th", { children: "Loan ID" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1608,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("th", { children: "Loan Type" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1609,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("th", { children: "Principal Amount" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1610,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("th", { children: "Outstanding Balance" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1611,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("th", { children: "Installment" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1612,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("th", { children: "Term Left" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1613,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1607,
                columnNumber: 23
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1606,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("tbody", { children: loans.map(
                (loan) => /* @__PURE__ */ jsxDEV("tr", { children: [
                  /* @__PURE__ */ jsxDEV("td", { style: { color: "#718EBF" }, children: loan.id }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1619,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { style: { fontWeight: "600" }, children: loan.type }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1620,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { children: [
                    "$",
                    loan.amount.toLocaleString()
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1621,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { children: [
                    "$",
                    loan.balance.toLocaleString()
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1622,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { style: { color: "var(--error)" }, children: [
                    "$",
                    loan.installment,
                    "/mo"
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1623,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { children: loan.duration }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1624,
                    columnNumber: 27
                  }, this)
                ] }, loan.id, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1618,
                  columnNumber: 21
                }, this)
              ) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1616,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1605,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1604,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 1600,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "col-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "section-header", children: /* @__PURE__ */ jsxDEV("h3", { className: "section-title", children: "Loan Calculator" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1635,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1634,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "panel", style: { minHeight: "340px" }, children: /* @__PURE__ */ jsxDEV("form", { onSubmit: calculateLoan, style: { display: "flex", flexDirection: "column", gap: "1rem", opacity: !userSession.permissions?.manage_loans ? 0.8 : 1 }, children: [
              !userSession.permissions?.manage_loans && /* @__PURE__ */ jsxDEV("div", { style: { color: "var(--error)", background: "rgba(255, 75, 74, 0.08)", border: "1px solid rgba(255, 75, 74, 0.2)", padding: "0.6rem", borderRadius: "10px", fontSize: "0.8rem", fontWeight: 600, textAlign: "center" }, children: "Read-Only: Calculator disabled." }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1640,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", children: [
                /* @__PURE__ */ jsxDEV("label", { children: "Principal Amount ($)" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1645,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "number",
                    className: "settings-form-input",
                    value: loanCalc.amount,
                    onChange: (e) => setLoanCalc({ ...loanCalc, amount: e.target.value }),
                    disabled: !userSession.permissions?.manage_loans
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1646,
                    columnNumber: 23
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1644,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", children: [
                /* @__PURE__ */ jsxDEV("label", { children: "Interest Rate (% Annual)" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1655,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "number",
                    step: "0.1",
                    className: "settings-form-input",
                    value: loanCalc.rate,
                    onChange: (e) => setLoanCalc({ ...loanCalc, rate: e.target.value }),
                    disabled: !userSession.permissions?.manage_loans
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1656,
                    columnNumber: 23
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1654,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", children: [
                /* @__PURE__ */ jsxDEV("label", { children: "Duration (Months)" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1666,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "number",
                    className: "settings-form-input",
                    value: loanCalc.term,
                    onChange: (e) => setLoanCalc({ ...loanCalc, term: e.target.value }),
                    disabled: !userSession.permissions?.manage_loans
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1667,
                    columnNumber: 23
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1665,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "add-card-btn", disabled: !userSession.permissions?.manage_loans, style: !userSession.permissions?.manage_loans ? { gridColumn: "span 1", opacity: 0.5, cursor: "not-allowed", pointerEvents: "none" } : { gridColumn: "span 1" }, children: "Calculate Installment" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1675,
                columnNumber: 21
              }, this),
              loanCalc.output && /* @__PURE__ */ jsxDEV("div", { style: { marginTop: "0.5rem", textAlign: "center" }, children: [
                /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.8rem", color: "#718EBF" }, children: "Estimated Installment" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1680,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "1.5rem", fontWeight: "700", color: "var(--accent-primary)" }, children: [
                  "$",
                  loanCalc.output,
                  " / mo"
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1681,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1679,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1638,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1637,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 1633,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 1598,
          columnNumber: 11
        }, this),
        activeTab === "Services" && /* @__PURE__ */ jsxDEV("div", { className: "col-12", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "section-header", children: /* @__PURE__ */ jsxDEV("h3", { className: "section-title", children: "Manage Services" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 1698,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 1697,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "services-list", children: services.map((srv) => {
            const SrvIcon = iconMap[srv.iconName] || ShieldCheck;
            return /* @__PURE__ */ jsxDEV("div", { className: "service-item-box", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "service-icon-box", style: { background: `${srv.color}15`, color: srv.color }, children: /* @__PURE__ */ jsxDEV(SrvIcon, { size: 24 }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1706,
                columnNumber: 25
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1705,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "service-text", children: [
                /* @__PURE__ */ jsxDEV("h4", { children: srv.title }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1709,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("p", { children: srv.desc }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1710,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1708,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("label", { className: "switch-label", style: { pointerEvents: userSession.permissions?.manage_services ? "auto" : "none", opacity: userSession.permissions?.manage_services ? 1 : 0.6 }, children: [
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "checkbox",
                    checked: srv.enabled,
                    onChange: () => toggleService(srv.id),
                    disabled: !userSession.permissions?.manage_services
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1714,
                    columnNumber: 27
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "switch-slider" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1720,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1713,
                columnNumber: 25
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1712,
                columnNumber: 23
              }, this)
            ] }, srv.id, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1704,
              columnNumber: 19
            }, this);
          }) }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 1700,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 1696,
          columnNumber: 11
        }, this),
        activeTab === "My Privileges" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "summary-cards-grid", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "summary-card", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "summary-icon-box", style: { background: "#E7F3FF", color: "#396AFF" }, children: /* @__PURE__ */ jsxDEV(Sparkles, { size: 24 }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1738,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1737,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("div", { className: "summary-label", children: "Loyalty Tier" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1741,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "summary-val", children: "Gold Member" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1742,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1740,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1736,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "summary-card", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "summary-icon-box", style: { background: "#FFF5E9", color: "#FFBB38" }, children: /* @__PURE__ */ jsxDEV(TrendingUp, { size: 24 }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1747,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1746,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("div", { className: "summary-label", children: "Reward Points Balance" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1750,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "summary-val", children: "12,450 pts" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1751,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1749,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1745,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 1735,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "dashboard-section-row", children: /* @__PURE__ */ jsxDEV("div", { className: "col-12", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "section-header", children: /* @__PURE__ */ jsxDEV("h3", { className: "section-title", children: "Tier Benefits & Privileges" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1759,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1758,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "panel", style: { height: "auto", gap: "1.25rem" }, children: [
              /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: "1.5rem", borderBottom: "1px solid var(--border-color)", paddingBottom: "1rem" }, children: [
                /* @__PURE__ */ jsxDEV("div", { style: { background: "rgba(24, 20, 243, 0.05)", borderRadius: "50%", width: "40px", height: "40px", display: "flex", alignItems: "center", justifyContent: "center", color: "var(--accent-primary)", fontWeight: "700" }, children: "1" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1763,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("h4", { style: { color: "var(--text-primary)", fontWeight: 600 }, children: "0% Transaction Fees" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1765,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { style: { color: "var(--text-secondary)", fontSize: "0.85rem", marginTop: "0.2rem" }, children: "Enjoy free wire transfers and credit card payments to all international banks." }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1766,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1764,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1762,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: "1.5rem", borderBottom: "1px solid var(--border-color)", paddingBottom: "1rem" }, children: [
                /* @__PURE__ */ jsxDEV("div", { style: { background: "rgba(24, 20, 243, 0.05)", borderRadius: "50%", width: "40px", height: "40px", display: "flex", alignItems: "center", justifyContent: "center", color: "var(--accent-primary)", fontWeight: "700" }, children: "2" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1770,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("h4", { style: { color: "var(--text-primary)", fontWeight: 600 }, children: "Priority Support" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1772,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { style: { color: "var(--text-secondary)", fontSize: "0.85rem", marginTop: "0.2rem" }, children: "24/7 dedicated support desk with chat responses in under 1 minute." }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1773,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1771,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1769,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: "1.5rem" }, children: [
                /* @__PURE__ */ jsxDEV("div", { style: { background: "rgba(24, 20, 243, 0.05)", borderRadius: "50%", width: "40px", height: "40px", display: "flex", alignItems: "center", justifyContent: "center", color: "var(--accent-primary)", fontWeight: "700" }, children: "3" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1777,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("h4", { style: { color: "var(--text-primary)", fontWeight: 600 }, children: "Airport Lounge Access" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1779,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { style: { color: "var(--text-secondary)", fontSize: "0.85rem", marginTop: "0.2rem" }, children: "Complimentary global access to premium airport lounges with your primary dark card." }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1780,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1778,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1776,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1761,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 1757,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 1756,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 1734,
          columnNumber: 11
        }, this),
        activeTab === "Setting" && /* @__PURE__ */ jsxDEV("div", { className: "col-12", children: /* @__PURE__ */ jsxDEV("div", { className: "settings-panel", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "settings-tabs", children: [
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: `settings-tab ${settingsSubTab === "Edit Profile" ? "active" : ""}`,
                onClick: () => setSettingsSubTab("Edit Profile"),
                children: "Edit Profile"
              },
              void 0,
              false,
              {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1796,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: `settings-tab ${settingsSubTab === "Preference" ? "active" : ""}`,
                onClick: () => setSettingsSubTab("Preference"),
                children: "Preferences"
              },
              void 0,
              false,
              {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1802,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: `settings-tab ${settingsSubTab === "Security" ? "active" : ""}`,
                onClick: () => setSettingsSubTab("Security"),
                children: "Security"
              },
              void 0,
              false,
              {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1808,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 1795,
            columnNumber: 17
          }, this),
          settingsSubTab === "Edit Profile" && /* @__PURE__ */ jsxDEV("div", { className: "settings-content-wrapper", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "profile-avatar-section", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "avatar-edit-wrapper", onClick: () => {
                const newAvatar = prompt("Enter a URL for your profile image:", tempProfile.avatar);
                if (newAvatar)
                  setTempProfile({ ...tempProfile, avatar: newAvatar });
              }, children: [
                /* @__PURE__ */ jsxDEV(
                  "img",
                  {
                    src: tempProfile.avatar,
                    alt: "Edit Avatar",
                    className: "avatar-edit-img"
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1825,
                    columnNumber: 25
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "avatar-edit-badge", children: /* @__PURE__ */ jsxDEV("svg", { width: "14", height: "14", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2.5", children: /* @__PURE__ */ jsxDEV("path", { d: "M12 20h9M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1832,
                  columnNumber: 29
                }, this) }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1831,
                  columnNumber: 27
                }, this) }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1830,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1821,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.75rem", color: "var(--text-secondary)", marginTop: "0.75rem", fontWeight: 600 }, children: "Click to Change Photo" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1836,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1820,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("form", { onSubmit: handleProfileSave, className: "settings-form", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", children: [
                /* @__PURE__ */ jsxDEV("label", { children: "Your Name" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1842,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    className: "settings-form-input",
                    value: tempProfile.name,
                    onChange: (e) => setTempProfile({ ...tempProfile, name: e.target.value })
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1843,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1841,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", children: [
                /* @__PURE__ */ jsxDEV("label", { children: "Email Address" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1851,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "email",
                    className: "settings-form-input",
                    value: tempProfile.email,
                    onChange: (e) => setTempProfile({ ...tempProfile, email: e.target.value })
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1852,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1850,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", children: [
                /* @__PURE__ */ jsxDEV("label", { children: "Phone Number" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1860,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    className: "settings-form-input",
                    value: tempProfile.phone,
                    onChange: (e) => setTempProfile({ ...tempProfile, phone: e.target.value })
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1861,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1859,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", children: [
                /* @__PURE__ */ jsxDEV("label", { children: "Date of Birth" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1869,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "date",
                    className: "settings-form-input",
                    value: tempProfile.dob,
                    onChange: (e) => setTempProfile({ ...tempProfile, dob: e.target.value })
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1870,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1868,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", style: { gridColumn: "span 2" }, children: [
                /* @__PURE__ */ jsxDEV("label", { children: "Address" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1878,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    className: "settings-form-input",
                    value: tempProfile.address,
                    onChange: (e) => setTempProfile({ ...tempProfile, address: e.target.value })
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1879,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1877,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "settings-save-btn", children: "Save Profile Details" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1886,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1840,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 1818,
            columnNumber: 15
          }, this),
          settingsSubTab === "Preference" && /* @__PURE__ */ jsxDEV("div", { className: "settings-content-wrapper", children: /* @__PURE__ */ jsxDEV("form", { onSubmit: (e) => {
            e.preventDefault();
            setSettingsSuccess("Preferences saved!");
            setTimeout(() => setSettingsSuccess(""), 3e3);
          }, className: "settings-form", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", children: [
              /* @__PURE__ */ jsxDEV("label", { children: "Default Currency" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1898,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("select", { className: "settings-form-input", children: [
                /* @__PURE__ */ jsxDEV("option", { value: "USD", children: "USD ($) - US Dollar" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1900,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("option", { value: "EUR", children: "EUR (€) - Euro" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1901,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("option", { value: "GBP", children: "GBP (£) - British Pound" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1902,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1899,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1897,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", children: [
              /* @__PURE__ */ jsxDEV("label", { children: "Default Time Zone" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1906,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("select", { className: "settings-form-input", children: [
                /* @__PURE__ */ jsxDEV("option", { value: "EST", children: "GMT-5 (EST) - Eastern Time" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1908,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("option", { value: "GMT", children: "GMT+0 (GMT) - London Time" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1909,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("option", { value: "IST", children: "GMT+5:30 (IST) - India Time" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1910,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1907,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1905,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", style: { gridColumn: "span 2", marginTop: "1rem" }, children: [
              /* @__PURE__ */ jsxDEV("h4", { style: { fontSize: "0.95rem", fontWeight: 600, color: "var(--text-primary)", marginBottom: "1rem" }, children: "Notification Preferences" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1914,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", flexDirection: "column", gap: "1rem" }, children: [
                /* @__PURE__ */ jsxDEV("label", { style: { display: "flex", alignItems: "center", gap: "0.75rem", cursor: "pointer", fontSize: "0.9rem" }, children: [
                  /* @__PURE__ */ jsxDEV("input", { type: "checkbox", defaultChecked: true }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1917,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { children: "I want to receive weekly email statement summaries." }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1918,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1916,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("label", { style: { display: "flex", alignItems: "center", gap: "0.75rem", cursor: "pointer", fontSize: "0.9rem" }, children: [
                  /* @__PURE__ */ jsxDEV("input", { type: "checkbox", defaultChecked: true }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1921,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { children: "Notify me about login actions from unrecognized devices." }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 1922,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1920,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1915,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1913,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "settings-save-btn", children: "Save Preferences" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1926,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 1896,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 1895,
            columnNumber: 15
          }, this),
          settingsSubTab === "Security" && /* @__PURE__ */ jsxDEV("div", { className: "settings-content-wrapper", children: /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSecuritySave, className: "settings-form full-width", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", children: [
              /* @__PURE__ */ jsxDEV("label", { children: "Current Password" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1938,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "password",
                  className: "settings-form-input",
                  placeholder: "••••••••",
                  value: passwordForm.current,
                  onChange: (e) => setPasswordForm({ ...passwordForm, current: e.target.value })
                },
                void 0,
                false,
                {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1939,
                  columnNumber: 25
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1937,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", children: [
              /* @__PURE__ */ jsxDEV("label", { children: "New Password" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1948,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "password",
                  className: "settings-form-input",
                  placeholder: "••••••••",
                  value: passwordForm.new,
                  onChange: (e) => setPasswordForm({ ...passwordForm, new: e.target.value })
                },
                void 0,
                false,
                {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1949,
                  columnNumber: 25
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1947,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", children: [
              /* @__PURE__ */ jsxDEV("label", { children: "Confirm New Password" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 1958,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "password",
                  className: "settings-form-input",
                  placeholder: "••••••••",
                  value: passwordForm.confirm,
                  onChange: (e) => setPasswordForm({ ...passwordForm, confirm: e.target.value })
                },
                void 0,
                false,
                {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 1959,
                  columnNumber: 25
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1957,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "settings-save-btn", style: { gridColumn: "span 1" }, children: "Update Password" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 1967,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 1936,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 1935,
            columnNumber: 15
          }, this),
          settingsSuccess && /* @__PURE__ */ jsxDEV("div", { style: {
            marginTop: "1.5rem",
            padding: "0.8rem 1.5rem",
            background: "rgba(22, 219, 170, 0.12)",
            color: "#0e906f",
            borderRadius: "12px",
            fontSize: "0.95rem",
            fontWeight: 600,
            textAlign: "center",
            border: "1px solid rgba(22, 219, 170, 0.25)",
            animation: "slideUp 0.3s ease-out"
          }, children: settingsSuccess }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 1976,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 1794,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 1793,
          columnNumber: 11
        }, this),
        activeTab === "User Details" && /* @__PURE__ */ jsxDEV("div", { className: "col-12", style: { animation: "fadeIn 0.4s ease-out" }, children: [
          /* @__PURE__ */ jsxDEV("div", { className: "section-header", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "section-title", children: "User Roles & Access Rights" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 2001,
              columnNumber: 17
            }, this),
            userSession.role === "Admin" && /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.85rem", color: "var(--accent-primary)", fontWeight: 600, padding: "0.4rem 1rem", background: "rgba(24, 20, 243, 0.05)", borderRadius: "20px" }, children: "Administrator Mode (Write Access)" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 2003,
              columnNumber: 15
            }, this),
            userSession.role === "Editor" && /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.85rem", color: "var(--text-secondary)", fontWeight: 600, padding: "0.4rem 1rem", background: "rgba(0, 0, 0, 0.05)", borderRadius: "20px" }, children: "Editor Mode (Read Only)" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 2008,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 2e3,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "table-wrapper", children: /* @__PURE__ */ jsxDEV("table", { className: "custom-table", children: [
            /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { children: [
              /* @__PURE__ */ jsxDEV("th", { children: "User Info" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 2018,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("th", { children: "Email Address" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 2019,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("th", { children: "System Role" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 2020,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("th", { children: "Access Rights Summary" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 2021,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("th", { children: "Actions" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 2022,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 2017,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 2016,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("tbody", { children: users.filter(
              (user) => !searchQuery || (user.name || "").toLowerCase().includes(searchQuery.toLowerCase()) || (user.email || "").toLowerCase().includes(searchQuery.toLowerCase()) || (user.role || "").toLowerCase().includes(searchQuery.toLowerCase()) || (user.id || "").toString().toLowerCase().includes(searchQuery.toLowerCase())
            ).map(
              (user) => /* @__PURE__ */ jsxDEV("tr", { children: [
                /* @__PURE__ */ jsxDEV("td", { style: { display: "flex", alignItems: "center", gap: "0.75rem" }, children: [
                  /* @__PURE__ */ jsxDEV("div", { style: {
                    width: "36px",
                    height: "36px",
                    borderRadius: "50%",
                    background: "linear-gradient(135deg, var(--accent-primary) 0%, #1814F3 100%)",
                    color: "#ffffff",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontWeight: 600,
                    fontSize: "0.9rem"
                  }, children: user.name.charAt(0).toUpperCase() }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 2037,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("div", { style: { fontWeight: 600 }, children: user.name }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 2052,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.75rem", color: "var(--text-secondary)" }, children: [
                      "ID: ",
                      user.id
                    ] }, void 0, true, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 2053,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 2051,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 2036,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("td", { children: user.email }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 2056,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("span", { className: `status-badge ${user.role === "Admin" ? "failed" : user.role === "Editor" ? "pending" : "success"}`, style: {
                  background: user.role === "Admin" ? "rgba(139, 92, 246, 0.12)" : user.role === "Editor" ? "rgba(57, 106, 255, 0.12)" : "rgba(107, 114, 128, 0.12)",
                  color: user.role === "Admin" ? "#8B5CF6" : user.role === "Editor" ? "#396AFF" : "#6B7280",
                  padding: "0.35rem 0.85rem"
                }, children: user.role }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 2058,
                  columnNumber: 27
                }, this) }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 2057,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: "0.5rem", flexWrap: "wrap" }, children: Object.entries(user.permissions || {}).map(
                  ([key, val]) => /* @__PURE__ */ jsxDEV(
                    "span",
                    {
                      style: {
                        fontSize: "0.75rem",
                        padding: "0.15rem 0.5rem",
                        borderRadius: "6px",
                        background: val ? "rgba(16, 185, 129, 0.08)" : "rgba(239, 68, 68, 0.08)",
                        color: val ? "#10B981" : "#EF4444",
                        border: `1px solid ${val ? "rgba(16, 185, 129, 0.2)" : "rgba(239, 68, 68, 0.2)"}`,
                        display: "inline-flex",
                        alignItems: "center",
                        gap: "0.25rem",
                        fontWeight: 600
                      },
                      children: [
                        /* @__PURE__ */ jsxDEV("span", { style: {
                          width: "5px",
                          height: "5px",
                          borderRadius: "50%",
                          background: val ? "#10B981" : "#EF4444"
                        } }, void 0, false, {
                          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                          lineNumber: 2087,
                          columnNumber: 33
                        }, this),
                        key.replace("manage_", "").replace("view_", "")
                      ]
                    },
                    key,
                    true,
                    {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 2072,
                      columnNumber: 25
                    },
                    this
                  )
                ) }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 2070,
                  columnNumber: 27
                }, this) }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 2069,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("td", { children: userSession.role === "Admin" ? /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    className: "table-action-btn edit",
                    onClick: () => openUserPermissionsModal(user),
                    title: "Manage Permissions",
                    style: { background: "rgba(24, 20, 243, 0.08)", color: "var(--accent-primary)", width: "36px", height: "36px", borderRadius: "8px", display: "flex", alignItems: "center", justifyContent: "center" },
                    children: /* @__PURE__ */ jsxDEV(Settings, { size: 16 }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 2106,
                      columnNumber: 31
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 2100,
                    columnNumber: 23
                  },
                  this
                ) : /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    className: "table-action-btn edit",
                    onClick: () => openUserPermissionsModal(user),
                    title: "View Permissions",
                    style: { background: "rgba(107, 114, 128, 0.08)", color: "#6B7280", width: "36px", height: "36px", borderRadius: "8px", display: "flex", alignItems: "center", justifyContent: "center" },
                    children: /* @__PURE__ */ jsxDEV(Search, { size: 16 }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                      lineNumber: 2115,
                      columnNumber: 31
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 2109,
                    columnNumber: 23
                  },
                  this
                ) }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 2098,
                  columnNumber: 25
                }, this)
              ] }, user.id, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 2035,
                columnNumber: 19
              }, this)
            ) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 2025,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 2015,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 2014,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 1999,
          columnNumber: 11
        }, this),
        activeTab === "Scan & Pay" && /* @__PURE__ */ jsxDEV(
          QrScannerTab,
          {
            userSession,
            cards,
            onAddTransaction: (newTx) => setTransactions((prev) => [newTx, ...prev]),
            onUpdateCardBalance: (cardId, newBalance) => {
              setCards((prev) => prev.map((c) => c.id === cardId ? { ...c, balance: newBalance } : c));
            },
            onAddNotification: (newNotification) => {
              setNotifications((prev) => [newNotification, ...prev]);
            }
          },
          void 0,
          false,
          {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 2128,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
        lineNumber: 828,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
      lineNumber: 750,
      columnNumber: 7
    }, this),
    txModalOpen && /* @__PURE__ */ jsxDEV("div", { className: "modal-backdrop", onClick: () => setTxModalOpen(false), children: /* @__PURE__ */ jsxDEV("div", { className: "modal-container", onClick: (e) => e.stopPropagation(), children: [
      /* @__PURE__ */ jsxDEV("div", { className: "modal-header", children: [
        /* @__PURE__ */ jsxDEV("h3", { children: editingTx ? "Edit Transaction" : "Create Transaction" }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 2150,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "modal-close-btn", onClick: () => setTxModalOpen(false), children: /* @__PURE__ */ jsxDEV(X, { size: 18 }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 2152,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 2151,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
        lineNumber: 2149,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleTxSubmit, style: { display: "flex", flexDirection: "column", gap: "1rem" }, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", children: [
          /* @__PURE__ */ jsxDEV("label", { children: "Description" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 2157,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              className: "settings-form-input",
              placeholder: "e.g. Spotify Premium",
              value: txForm.desc,
              onChange: (e) => setTxForm({ ...txForm, desc: e.target.value }),
              required: true
            },
            void 0,
            false,
            {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 2158,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 2156,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", children: [
          /* @__PURE__ */ jsxDEV("label", { children: "Amount ($)" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 2168,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "number",
              step: "0.01",
              className: "settings-form-input",
              placeholder: "e.g. 15.00",
              value: txForm.amount,
              onChange: (e) => setTxForm({ ...txForm, amount: e.target.value }),
              required: true
            },
            void 0,
            false,
            {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 2169,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 2167,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem" }, children: [
          /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Type" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 2181,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                className: "settings-form-input",
                value: txForm.type,
                onChange: (e) => setTxForm({ ...txForm, type: e.target.value }),
                children: [
                  /* @__PURE__ */ jsxDEV("option", { value: "expense", children: "Expense (-)" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 2187,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "income", children: "Income (+)" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 2188,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 2182,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 2180,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Status" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 2192,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                className: "settings-form-input",
                value: txForm.status,
                onChange: (e) => setTxForm({ ...txForm, status: e.target.value }),
                children: [
                  /* @__PURE__ */ jsxDEV("option", { value: "Success", children: "Success" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 2198,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "Pending", children: "Pending" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 2199,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "Failed", children: "Failed" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 2200,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 2193,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 2191,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 2179,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem" }, children: [
          /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Category" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 2206,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                className: "settings-form-input",
                value: txForm.category,
                onChange: (e) => setTxForm({ ...txForm, category: e.target.value }),
                children: [
                  /* @__PURE__ */ jsxDEV("option", { value: "Deposit", children: "Deposit" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 2212,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "Transfer", children: "Transfer" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 2213,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "Entertainment", children: "Entertainment" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 2214,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "Shopping", children: "Shopping" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 2215,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "Salary", children: "Salary" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 2216,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "Transport", children: "Transport" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 2217,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "Others", children: "Others" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 2218,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 2207,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 2205,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Method" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 2222,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                className: "settings-form-input",
                value: txForm.method,
                onChange: (e) => setTxForm({ ...txForm, method: e.target.value }),
                children: [
                  /* @__PURE__ */ jsxDEV("option", { value: "Card", children: "Card" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 2228,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "Paypal", children: "Paypal" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 2229,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "Wire Transfer", children: "Wire Transfer" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 2230,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 2223,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 2221,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 2204,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", children: [
          /* @__PURE__ */ jsxDEV("label", { children: "Date" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 2235,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "date",
              className: "settings-form-input",
              value: txForm.date,
              onChange: (e) => setTxForm({ ...txForm, date: e.target.value }),
              required: true
            },
            void 0,
            false,
            {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 2236,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 2234,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "modal-footer", children: [
          /* @__PURE__ */ jsxDEV("button", { type: "button", className: "modal-btn-cancel", onClick: () => setTxModalOpen(false), children: "Cancel" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 2245,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "add-card-btn", style: { margin: 0, padding: "0.75rem 2rem" }, children: editingTx ? "Save Changes" : "Create" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 2246,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 2244,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
        lineNumber: 2155,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
      lineNumber: 2148,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
      lineNumber: 2147,
      columnNumber: 7
    }, this),
    cardModalOpen && /* @__PURE__ */ jsxDEV("div", { className: "modal-backdrop", onClick: () => setCardModalOpen(false), children: /* @__PURE__ */ jsxDEV("div", { className: "modal-container", onClick: (e) => e.stopPropagation(), children: [
      /* @__PURE__ */ jsxDEV("div", { className: "modal-header", children: [
        /* @__PURE__ */ jsxDEV("h3", { children: "Edit Credit Card" }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 2262,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "modal-close-btn", onClick: () => setCardModalOpen(false), children: /* @__PURE__ */ jsxDEV(X, { size: 18 }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 2264,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 2263,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
        lineNumber: 2261,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleCardUpdateSubmit, style: { display: "flex", flexDirection: "column", gap: "1rem" }, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", children: [
          /* @__PURE__ */ jsxDEV("label", { children: "Card Holder Name" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 2269,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              className: "settings-form-input",
              placeholder: "e.g. John Doe",
              value: cardForm.holder,
              onChange: (e) => setCardForm({ ...cardForm, holder: e.target.value }),
              required: true
            },
            void 0,
            false,
            {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 2270,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 2268,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", children: [
          /* @__PURE__ */ jsxDEV("label", { children: "Balance ($)" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 2280,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "number",
              className: "settings-form-input",
              placeholder: "e.g. 5000",
              value: cardForm.balance,
              onChange: (e) => setCardForm({ ...cardForm, balance: e.target.value }),
              required: true
            },
            void 0,
            false,
            {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 2281,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 2279,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem" }, children: [
          /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Expiry Date" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 2292,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                className: "settings-form-input",
                placeholder: "MM/YY",
                maxLength: "5",
                value: cardForm.expiry,
                onChange: (e) => setCardForm({ ...cardForm, expiry: e.target.value }),
                required: true
              },
              void 0,
              false,
              {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 2293,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 2291,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Card Style" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 2304,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                className: "settings-form-input",
                value: cardForm.type,
                onChange: (e) => setCardForm({ ...cardForm, type: e.target.value }),
                children: [
                  /* @__PURE__ */ jsxDEV("option", { value: "dark", children: "Dark Gradient" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 2310,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "light", children: "Light Border" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 2311,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "green", children: "Emerald Green" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 2312,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "purple", children: "Royal Purple" }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 2313,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 2305,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 2303,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 2290,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", children: [
          /* @__PURE__ */ jsxDEV("label", { children: "Card Number (16 Digits)" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 2318,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              className: "settings-form-input",
              placeholder: "4812384910293847",
              maxLength: "16",
              value: cardForm.number,
              onChange: (e) => setCardForm({ ...cardForm, number: e.target.value }),
              required: true
            },
            void 0,
            false,
            {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 2319,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 2317,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "modal-footer", children: [
          /* @__PURE__ */ jsxDEV("button", { type: "button", className: "modal-btn-cancel", onClick: () => setCardModalOpen(false), children: "Cancel" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 2330,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "add-card-btn", style: { margin: 0, padding: "0.75rem 2rem" }, children: "Save Changes" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 2331,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 2329,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
        lineNumber: 2267,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
      lineNumber: 2260,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
      lineNumber: 2259,
      columnNumber: 7
    }, this),
    userModalOpen && editingUser && /* @__PURE__ */ jsxDEV("div", { className: "modal-backdrop", onClick: () => setUserModalOpen(false), children: /* @__PURE__ */ jsxDEV("div", { className: "modal-container", onClick: (e) => e.stopPropagation(), style: { maxWidth: "520px" }, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "modal-header", children: [
        /* @__PURE__ */ jsxDEV("h3", { children: userSession.role === "Admin" ? "Manage Access Rights" : "View Access Rights" }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 2346,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "modal-close-btn", onClick: () => setUserModalOpen(false), children: /* @__PURE__ */ jsxDEV(X, { size: 18 }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 2348,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 2347,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
        lineNumber: 2345,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { marginBottom: "1.25rem", paddingBottom: "1rem", borderBottom: "1px solid var(--border-color)" }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: { fontWeight: 700, fontSize: "1.1rem", color: "var(--text-primary)" }, children: editingUser.name }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 2353,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.85rem", color: "var(--text-secondary)", marginTop: "0.15rem" }, children: editingUser.email }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 2354,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
        lineNumber: 2352,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: (e) => {
        e.preventDefault();
        if (userSession.role !== "Admin") {
          setUserModalOpen(false);
          return;
        }
        handleUpdatePermissions(editingUser.id, userForm.role, userForm.permissions);
      }, style: { display: "flex", flexDirection: "column", gap: "1.25rem" }, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", children: [
          /* @__PURE__ */ jsxDEV("label", { style: { fontWeight: 600 }, children: "System Role" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 2367,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "select",
            {
              className: "settings-form-input",
              value: userForm.role,
              onChange: (e) => {
                const newRole = e.target.value;
                let newPermissions = { ...userForm.permissions };
                if (newRole === "Admin") {
                  newPermissions = {
                    view_dashboard: true,
                    manage_tx: true,
                    manage_cards: true,
                    manage_loans: true,
                    manage_services: true,
                    manage_users: true
                  };
                } else if (newRole === "Viewer") {
                  newPermissions = {
                    view_dashboard: true,
                    manage_tx: false,
                    manage_cards: false,
                    manage_loans: false,
                    manage_services: false,
                    manage_users: false
                  };
                } else if (newRole === "Editor") {
                  newPermissions = {
                    view_dashboard: true,
                    manage_tx: true,
                    manage_cards: true,
                    manage_loans: true,
                    manage_services: true,
                    manage_users: false
                  };
                }
                setUserForm({ role: newRole, permissions: newPermissions });
              },
              disabled: userSession.role !== "Admin",
              children: [
                /* @__PURE__ */ jsxDEV("option", { value: "Admin", children: "Admin (Full Write Access)" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 2406,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("option", { value: "Editor", children: "Editor (Read/Write except Users)" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 2407,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("option", { value: "Viewer", children: "Viewer (Read-Only Access)" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 2408,
                  columnNumber: 19
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 2368,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 2366,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { style: { display: "block", fontWeight: 600, marginBottom: "0.75rem", fontSize: "0.95rem" }, children: "Individual Feature Access Rights" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 2413,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", flexDirection: "column", gap: "0.75rem", background: "var(--bg-primary)", padding: "1rem", borderRadius: "15px", border: "1px solid var(--border-color)" }, children: [
            /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", justifyContent: "space-between" }, children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("div", { style: { fontWeight: 600, fontSize: "0.85rem" }, children: "Dashboard Overview" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 2420,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.75rem", color: "var(--text-secondary)" }, children: "Allow viewing standard dashboard metrics and charts." }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 2421,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 2419,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "switch-label", style: { pointerEvents: userSession.role !== "Admin" ? "none" : "auto" }, children: [
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "checkbox",
                    checked: userForm.permissions.view_dashboard,
                    onChange: (e) => setUserForm({
                      ...userForm,
                      permissions: { ...userForm.permissions, view_dashboard: e.target.checked }
                    }),
                    disabled: userSession.role !== "Admin"
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 2424,
                    columnNumber: 23
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "switch-slider" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 2433,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 2423,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 2418,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", justifyContent: "space-between", borderTop: "1px solid rgba(0,0,0,0.05)", paddingTop: "0.75rem" }, children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("div", { style: { fontWeight: 600, fontSize: "0.85rem" }, children: "Transactions Management" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 2440,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.75rem", color: "var(--text-secondary)" }, children: "Allow adding, editing, deleting and transferring funds." }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 2441,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 2439,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "switch-label", style: { pointerEvents: userSession.role !== "Admin" ? "none" : "auto" }, children: [
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "checkbox",
                    checked: userForm.permissions.manage_tx,
                    onChange: (e) => setUserForm({
                      ...userForm,
                      permissions: { ...userForm.permissions, manage_tx: e.target.checked }
                    }),
                    disabled: userSession.role !== "Admin"
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 2444,
                    columnNumber: 23
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "switch-slider" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 2453,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 2443,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 2438,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", justifyContent: "space-between", borderTop: "1px solid rgba(0,0,0,0.05)", paddingTop: "0.75rem" }, children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("div", { style: { fontWeight: 600, fontSize: "0.85rem" }, children: "Credit Cards Management" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 2460,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.75rem", color: "var(--text-secondary)" }, children: "Allow creating, modifying or removing credit cards." }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 2461,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 2459,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "switch-label", style: { pointerEvents: userSession.role !== "Admin" ? "none" : "auto" }, children: [
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "checkbox",
                    checked: userForm.permissions.manage_cards,
                    onChange: (e) => setUserForm({
                      ...userForm,
                      permissions: { ...userForm.permissions, manage_cards: e.target.checked }
                    }),
                    disabled: userSession.role !== "Admin"
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 2464,
                    columnNumber: 23
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "switch-slider" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 2473,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 2463,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 2458,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", justifyContent: "space-between", borderTop: "1px solid rgba(0,0,0,0.05)", paddingTop: "0.75rem" }, children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("div", { style: { fontWeight: 600, fontSize: "0.85rem" }, children: "Loans Calculator & Management" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 2480,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.75rem", color: "var(--text-secondary)" }, children: "Allow calculations and updates of loan structures." }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 2481,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 2479,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "switch-label", style: { pointerEvents: userSession.role !== "Admin" ? "none" : "auto" }, children: [
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "checkbox",
                    checked: userForm.permissions.manage_loans,
                    onChange: (e) => setUserForm({
                      ...userForm,
                      permissions: { ...userForm.permissions, manage_loans: e.target.checked }
                    }),
                    disabled: userSession.role !== "Admin"
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 2484,
                    columnNumber: 23
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "switch-slider" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 2493,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 2483,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 2478,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", justifyContent: "space-between", borderTop: "1px solid rgba(0,0,0,0.05)", paddingTop: "0.75rem" }, children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("div", { style: { fontWeight: 600, fontSize: "0.85rem" }, children: "Services Activation" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 2500,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.75rem", color: "var(--text-secondary)" }, children: "Allow toggling account-specific mobile security and savings services." }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 2501,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 2499,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "switch-label", style: { pointerEvents: userSession.role !== "Admin" ? "none" : "auto" }, children: [
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "checkbox",
                    checked: userForm.permissions.manage_services,
                    onChange: (e) => setUserForm({
                      ...userForm,
                      permissions: { ...userForm.permissions, manage_services: e.target.checked }
                    }),
                    disabled: userSession.role !== "Admin"
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 2504,
                    columnNumber: 23
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "switch-slider" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 2513,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 2503,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 2498,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", justifyContent: "space-between", borderTop: "1px solid rgba(0,0,0,0.05)", paddingTop: "0.75rem" }, children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("div", { style: { fontWeight: 600, fontSize: "0.85rem" }, children: "User Profiles & Access Rights" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 2520,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "0.75rem", color: "var(--text-secondary)" }, children: "Allow managing roles and modifying authorization access of other users." }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 2521,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 2519,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "switch-label", style: { pointerEvents: userSession.role !== "Admin" ? "none" : "auto" }, children: [
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "checkbox",
                    checked: userForm.permissions.manage_users,
                    onChange: (e) => setUserForm({
                      ...userForm,
                      permissions: { ...userForm.permissions, manage_users: e.target.checked }
                    }),
                    disabled: userSession.role !== "Admin"
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                    lineNumber: 2524,
                    columnNumber: 23
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "switch-slider" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                  lineNumber: 2533,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
                lineNumber: 2523,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
              lineNumber: 2518,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 2415,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 2412,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "modal-footer", children: [
          /* @__PURE__ */ jsxDEV("button", { type: "button", className: "modal-btn-cancel", onClick: () => setUserModalOpen(false), children: userSession.role === "Admin" ? "Cancel" : "Close" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 2541,
            columnNumber: 17
          }, this),
          userSession.role === "Admin" && /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "add-card-btn", style: { margin: 0, padding: "0.75rem 2rem" }, children: "Save Changes" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
            lineNumber: 2545,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
          lineNumber: 2540,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
        lineNumber: 2357,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
      lineNumber: 2344,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
      lineNumber: 2343,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/React_test_19_05_2026/src/components/Dashboard.jsx",
    lineNumber: 703,
    columnNumber: 5
  }, this);
};
_s(Dashboard, "IdG5yNHuVI2tqKvJRrCYXHX9xf4=", false, function() {
  return [useNavigate, useAuth];
});
_c = Dashboard;
const menuItems = [
  { name: "Dashboard", icon: LayoutDashboard },
  { name: "Transactions", icon: ArrowLeftRight },
  { name: "Scan & Pay", icon: Scan },
  { name: "Accounts", icon: User },
  { name: "Investments", icon: LineChart },
  { name: "Credit Cards", icon: CreditCard },
  { name: "Loans", icon: HandCoins },
  { name: "Services", icon: Wrench },
  { name: "My Privileges", icon: Lightbulb },
  { name: "User Details", icon: Users },
  { name: "Setting", icon: Settings }
];
export default Dashboard;
var _c;
$RefreshReg$(_c, "Dashboard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/React_test_19_05_2026/src/components/Dashboard.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/React_test_19_05_2026/src/components/Dashboard.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaXJCYyxTQTRIRixVQTVIRTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFqckJkLFNBQVNBLFVBQVVDLGlCQUFpQjtBQUNwQyxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsZUFBZTtBQUN4QjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxPQUFPQyxrQkFBa0I7QUFDekIsT0FBTztBQUVQLE1BQU1DLHFCQUFxQjtBQUFBLEVBQ3pCO0FBQUEsSUFDRUMsTUFBTTtBQUFBLElBQ05DLE1BQU07QUFBQSxJQUNOQyxRQUFRO0FBQUEsRUFDVjtBQUFBLEVBQ0E7QUFBQSxJQUNFRixNQUFNO0FBQUEsSUFDTkMsTUFBTTtBQUFBLElBQ05DLFFBQVE7QUFBQSxFQUNWO0FBQUEsRUFDQTtBQUFBLElBQ0VGLE1BQU07QUFBQSxJQUNOQyxNQUFNO0FBQUEsSUFDTkMsUUFBUTtBQUFBLEVBQ1Y7QUFBQSxFQUNBO0FBQUEsSUFDRUYsTUFBTTtBQUFBLElBQ05DLE1BQU07QUFBQSxJQUNOQyxRQUFRO0FBQUEsRUFDVjtBQUFDO0FBR0gsTUFBTUMsWUFBWUEsTUFBTTtBQUFBQyxLQUFBO0FBQ3RCLFFBQU1DLFdBQVdyQyxZQUFZO0FBRzdCLFFBQU1zQyxlQUFlLE1BQU07QUFDekIsVUFBTUMsTUFBTUMsYUFBYUMsUUFBUSxNQUFNO0FBQ3ZDLFFBQUksQ0FBQ0YsS0FBSztBQUNSLGFBQU87QUFBQSxRQUNMUCxNQUFNO0FBQUEsUUFDTlUsT0FBTztBQUFBLFFBQ1BULE1BQU07QUFBQSxRQUNOVSxhQUFhO0FBQUEsVUFDWEMsZ0JBQWdCO0FBQUEsVUFDaEJDLFdBQVc7QUFBQSxVQUNYQyxjQUFjO0FBQUEsVUFDZEMsY0FBYztBQUFBLFVBQ2RDLGlCQUFpQjtBQUFBLFVBQ2pCQyxjQUFjO0FBQUEsUUFDaEI7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLFVBQU1DLFNBQVNDLEtBQUtDLE1BQU1iLEdBQUc7QUFDN0IsVUFBTWMsY0FBY0gsT0FBT1IsU0FBUyxJQUFJWSxZQUFZO0FBQ3BELFVBQU1DLFVBQVVGLGVBQWU7QUFDL0IsV0FBTztBQUFBLE1BQ0wsR0FBR0g7QUFBQUEsTUFDSGpCLE1BQU1pQixPQUFPakIsU0FBU3NCLFVBQVUsVUFBVTtBQUFBLE1BQzFDWixhQUFhTyxPQUFPUCxlQUFlO0FBQUEsUUFDakNDLGdCQUFnQjtBQUFBLFFBQ2hCQyxXQUFXVTtBQUFBQSxRQUNYVCxjQUFjUztBQUFBQSxRQUNkUixjQUFjUTtBQUFBQSxRQUNkUCxpQkFBaUJPO0FBQUFBLFFBQ2pCTixjQUFjTTtBQUFBQSxNQUNoQjtBQUFBLElBQ0Y7QUFBQSxFQUNGLEdBQUc7QUFHSCxRQUFNQyxZQUFZLGtCQUFrQmxCLFlBQVlJLE1BQU1ZLFlBQVksQ0FBQztBQUNuRSxRQUFNRyxVQUFVLGdCQUFnQm5CLFlBQVlJLE1BQU1ZLFlBQVksQ0FBQztBQUMvRCxRQUFNSSxjQUFjLG9CQUFvQnBCLFlBQVlJLE1BQU1ZLFlBQVksQ0FBQztBQUN2RSxRQUFNSyxlQUFlLHFCQUFxQnJCLFlBQVlJLE1BQU1ZLFlBQVksQ0FBQztBQUN6RSxRQUFNTSxZQUFZLGtCQUFrQnRCLFlBQVlJLE1BQU1ZLFlBQVksQ0FBQztBQUduRSxRQUFNLENBQUNPLFdBQVdDLFlBQVksSUFBSWhFLFNBQVMsTUFBTTtBQUMvQyxVQUFNaUUsUUFBUXZCLGFBQWFDLFFBQVEsc0JBQXNCO0FBQ3pELFFBQUlzQixPQUFPO0FBQ1R2QixtQkFBYXdCLFdBQVcsc0JBQXNCO0FBQzlDLGFBQU9EO0FBQUFBLElBQ1Q7QUFDQSxXQUFPO0FBQUEsRUFDVCxDQUFDO0FBQ0QsUUFBTSxDQUFDRSxnQkFBZ0JDLGlCQUFpQixJQUFJcEUsU0FBUyxjQUFjO0FBR25FLFFBQU0sQ0FBQ3FFLGFBQWFDLGNBQWMsSUFBSXRFLFNBQVMsRUFBRTtBQUNqRCxRQUFNLENBQUN1RSx1QkFBdUJDLHdCQUF3QixJQUFJeEUsU0FBUyxLQUFLO0FBR3hFLFFBQU0sQ0FBQ3lFLE9BQU9DLFFBQVEsSUFBSTFFLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUMyRSxlQUFlQyxnQkFBZ0IsSUFBSTVFLFNBQVMsS0FBSztBQUN4RCxRQUFNLENBQUM2RSxhQUFhQyxjQUFjLElBQUk5RSxTQUFTLElBQUk7QUFDbkQsUUFBTSxDQUFDK0UsVUFBVUMsV0FBVyxJQUFJaEYsU0FBUztBQUFBLElBQ3ZDbUMsTUFBTTtBQUFBLElBQ05VLGFBQWE7QUFBQSxNQUNYQyxnQkFBZ0I7QUFBQSxNQUNoQkMsV0FBVztBQUFBLE1BQ1hDLGNBQWM7QUFBQSxNQUNkQyxjQUFjO0FBQUEsTUFDZEMsaUJBQWlCO0FBQUEsTUFDakJDLGNBQWM7QUFBQSxJQUNoQjtBQUFBLEVBQ0YsQ0FBQztBQUdELFFBQU0sQ0FBQzhCLGVBQWVDLGdCQUFnQixJQUFJbEYsU0FBUyxNQUFNO0FBQ3ZELFVBQU15RCxVQUFVakIsWUFBWUwsU0FBUztBQUNyQyxRQUFJc0IsU0FBUztBQUNYLGFBQU87QUFBQSxRQUNMLEVBQUUwQixJQUFJLEdBQUdDLE1BQU0sOERBQThEQyxNQUFNLFlBQVlDLE1BQU0sV0FBV0MsUUFBUSxLQUFLO0FBQUEsUUFDN0gsRUFBRUosSUFBSSxHQUFHQyxNQUFNLCtEQUErREMsTUFBTSxjQUFjQyxNQUFNLFFBQVFDLFFBQVEsS0FBSztBQUFBLFFBQzdILEVBQUVKLElBQUksR0FBR0MsTUFBTSxvREFBb0RDLE1BQU0sY0FBY0MsTUFBTSxXQUFXQyxRQUFRLEtBQUs7QUFBQSxNQUFDO0FBQUEsSUFFMUgsT0FBTztBQUNMLGFBQU87QUFBQSxRQUNMLEVBQUVKLElBQUksR0FBR0MsTUFBTSx1REFBdURDLE1BQU0sY0FBY0MsTUFBTSxXQUFXQyxRQUFRLEtBQUs7QUFBQSxRQUN4SCxFQUFFSixJQUFJLEdBQUdDLE1BQU0sMERBQTBEQyxNQUFNLGVBQWVDLE1BQU0sUUFBUUMsUUFBUSxLQUFLO0FBQUEsUUFDekgsRUFBRUosSUFBSSxHQUFHQyxNQUFNLHVEQUF1REMsTUFBTSxhQUFhQyxNQUFNLFFBQVFDLFFBQVEsTUFBTTtBQUFBLE1BQUM7QUFBQSxJQUUxSDtBQUFBLEVBQ0YsQ0FBQztBQUNELFFBQU0sQ0FBQ0MsbUJBQW1CQyxvQkFBb0IsSUFBSXpGLFNBQVMsS0FBSztBQUVoRSxRQUFNMEYsb0JBQW9CQSxNQUFNO0FBQzlCUixxQkFBaUJELGNBQWNVLElBQUksQ0FBQUMsT0FBTSxFQUFFLEdBQUdBLEdBQUdMLFFBQVEsTUFBTSxFQUFFLENBQUM7QUFBQSxFQUNwRTtBQUdBLFFBQU0sQ0FBQ00sU0FBU0MsVUFBVSxJQUFJOUYsU0FBUyxNQUFNO0FBQzNDLFVBQU1pRSxRQUFRdkIsYUFBYUMsUUFBUWlCLFdBQVc7QUFDOUMsUUFBSUs7QUFBTyxhQUFPWixLQUFLQyxNQUFNVyxLQUFLO0FBQ2xDLFdBQU87QUFBQSxNQUNML0IsTUFBTU0sWUFBWU4sUUFBUTtBQUFBLE1BQzFCVSxPQUFPSixZQUFZSSxTQUFTO0FBQUEsTUFDNUJtRCxPQUFPO0FBQUEsTUFDUEMsS0FBSztBQUFBLE1BQ0xDLFNBQVM7QUFBQSxNQUNUN0QsUUFBUTtBQUFBLElBQ1Y7QUFBQSxFQUNGLENBQUM7QUFHRCxRQUFNLENBQUM4RCxhQUFhQyxjQUFjLElBQUluRyxTQUFTLEVBQUUsR0FBRzZGLFFBQVEsQ0FBQztBQUM3RCxRQUFNLENBQUNPLGNBQWNDLGVBQWUsSUFBSXJHLFNBQVMsRUFBRXNHLFNBQVMsSUFBSUMsS0FBSyxJQUFJQyxTQUFTLEdBQUcsQ0FBQztBQUN0RixRQUFNLENBQUNDLGlCQUFpQkMsa0JBQWtCLElBQUkxRyxTQUFTLEVBQUU7QUFHekQsUUFBTSxDQUFDMkcsT0FBT0MsUUFBUSxJQUFJNUcsU0FBUyxNQUFNO0FBQ3ZDLFVBQU1pRSxRQUFRdkIsYUFBYUMsUUFBUWUsU0FBUztBQUM1QyxRQUFJTztBQUFPLGFBQU9aLEtBQUtDLE1BQU1XLEtBQUs7QUFDbEMsV0FBTztBQUFBLE1BQ0wsRUFBRWtCLElBQUksR0FBRzBCLFNBQVMsTUFBTUMsUUFBUXRFLFlBQVlOLFFBQVEsWUFBWTZFLFFBQVEsdUJBQXVCQyxRQUFRLFNBQVMxQixNQUFNLE9BQU87QUFBQSxNQUM3SCxFQUFFSCxJQUFJLEdBQUcwQixTQUFTLE1BQU1DLFFBQVF0RSxZQUFZTixRQUFRLFlBQVk2RSxRQUFRLHVCQUF1QkMsUUFBUSxTQUFTMUIsTUFBTSxRQUFRO0FBQUEsTUFDOUgsRUFBRUgsSUFBSSxHQUFHMEIsU0FBUyxNQUFNQyxRQUFRdEUsWUFBWU4sUUFBUSxZQUFZNkUsUUFBUSx1QkFBdUJDLFFBQVEsU0FBUzFCLE1BQU0sU0FBUztBQUFBLE1BQy9ILEVBQUVILElBQUksR0FBRzBCLFNBQVMsTUFBTUMsUUFBUXRFLFlBQVlOLFFBQVEsWUFBWTZFLFFBQVEsdUJBQXVCQyxRQUFRLFNBQVMxQixNQUFNLFFBQVE7QUFBQSxJQUFDO0FBQUEsRUFFbkksQ0FBQztBQUdELFFBQU0sQ0FBQzJCLGNBQWNDLGVBQWUsSUFBSWxILFNBQVMsTUFBTTtBQUNyRCxVQUFNaUUsUUFBUXZCLGFBQWFDLFFBQVFnQixPQUFPO0FBQzFDLFFBQUlNO0FBQU8sYUFBT1osS0FBS0MsTUFBTVcsS0FBSztBQUNsQyxXQUFPO0FBQUEsTUFDTCxFQUFFa0IsSUFBSSxTQUFTZ0MsTUFBTSxxQkFBcUJDLE1BQU0sY0FBYzlCLE1BQU0sVUFBVStCLFFBQVEsUUFBUUMsVUFBVSxXQUFXQyxRQUFRLEtBQUtDLFFBQVEsVUFBVTtBQUFBLE1BQ2xKLEVBQUVyQyxJQUFJLFNBQVNnQyxNQUFNLGtCQUFrQkMsTUFBTSxjQUFjOUIsTUFBTSxVQUFVK0IsUUFBUSxVQUFVQyxVQUFVLFdBQVdDLFFBQVEsTUFBTUMsUUFBUSxVQUFVO0FBQUEsTUFDbEosRUFBRXJDLElBQUksU0FBU2dDLE1BQU0sZUFBZUMsTUFBTSxjQUFjOUIsTUFBTSxVQUFVK0IsUUFBUSxpQkFBaUJDLFVBQVUsWUFBWUMsUUFBUSxNQUFNQyxRQUFRLFVBQVU7QUFBQSxNQUN2SixFQUFFckMsSUFBSSxTQUFTZ0MsTUFBTSxtQkFBbUJDLE1BQU0sY0FBYzlCLE1BQU0sV0FBVytCLFFBQVEsUUFBUUMsVUFBVSxpQkFBaUJDLFFBQVEsSUFBSUMsUUFBUSxVQUFVO0FBQUEsTUFDdEosRUFBRXJDLElBQUksU0FBU2dDLE1BQU0sd0JBQXdCQyxNQUFNLGNBQWM5QixNQUFNLFdBQVcrQixRQUFRLFVBQVVDLFVBQVUsaUJBQWlCQyxRQUFRLElBQUlDLFFBQVEsVUFBVTtBQUFBLE1BQzdKLEVBQUVyQyxJQUFJLFNBQVNnQyxNQUFNLGtCQUFrQkMsTUFBTSxjQUFjOUIsTUFBTSxVQUFVK0IsUUFBUSxpQkFBaUJDLFVBQVUsVUFBVUMsUUFBUSxLQUFNQyxRQUFRLFVBQVU7QUFBQSxNQUN4SixFQUFFckMsSUFBSSxTQUFTZ0MsTUFBTSxtQkFBbUJDLE1BQU0sY0FBYzlCLE1BQU0sV0FBVytCLFFBQVEsUUFBUUMsVUFBVSxZQUFZQyxRQUFRLEtBQUtDLFFBQVEsVUFBVTtBQUFBLE1BQ2xKLEVBQUVyQyxJQUFJLFNBQVNnQyxNQUFNLGFBQWFDLE1BQU0sY0FBYzlCLE1BQU0sV0FBVytCLFFBQVEsUUFBUUMsVUFBVSxhQUFhQyxRQUFRLElBQUlDLFFBQVEsU0FBUztBQUFBLE1BQzNJLEVBQUVyQyxJQUFJLFNBQVNnQyxNQUFNLHlCQUF5QkMsTUFBTSxjQUFjOUIsTUFBTSxXQUFXK0IsUUFBUSxRQUFRQyxVQUFVLFdBQVdDLFFBQVEsS0FBS0MsUUFBUSxVQUFVO0FBQUEsTUFDdkosRUFBRXJDLElBQUksU0FBU2dDLE1BQU0sMkJBQTJCQyxNQUFNLGNBQWM5QixNQUFNLFVBQVUrQixRQUFRLGlCQUFpQkMsVUFBVSxVQUFVQyxRQUFRLE1BQU1DLFFBQVEsVUFBVTtBQUFBLE1BQ2pLLEVBQUVyQyxJQUFJLFNBQVNnQyxNQUFNLG9CQUFvQkMsTUFBTSxjQUFjOUIsTUFBTSxXQUFXK0IsUUFBUSxRQUFRQyxVQUFVLGlCQUFpQkMsUUFBUSxJQUFJQyxRQUFRLFVBQVU7QUFBQSxNQUN2SixFQUFFckMsSUFBSSxTQUFTZ0MsTUFBTSx1QkFBdUJDLE1BQU0sY0FBYzlCLE1BQU0sV0FBVytCLFFBQVEsUUFBUUMsVUFBVSxZQUFZQyxRQUFRLElBQUlDLFFBQVEsVUFBVTtBQUFBLE1BQ3JKLEVBQUVyQyxJQUFJLFNBQVNnQyxNQUFNLHlCQUF5QkMsTUFBTSxjQUFjOUIsTUFBTSxVQUFVK0IsUUFBUSxVQUFVQyxVQUFVLFVBQVVDLFFBQVEsS0FBS0MsUUFBUSxVQUFVO0FBQUEsTUFDdkosRUFBRXJDLElBQUksU0FBU2dDLE1BQU0sd0JBQXdCQyxNQUFNLGNBQWM5QixNQUFNLFdBQVcrQixRQUFRLFFBQVFDLFVBQVUsWUFBWUMsUUFBUSxJQUFJQyxRQUFRLFVBQVU7QUFBQSxJQUFDO0FBQUEsRUFFM0osQ0FBQztBQUdELFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJMUgsU0FBUyxNQUFNO0FBQzdDLFVBQU1pRSxRQUFRdkIsYUFBYUMsUUFBUWtCLFlBQVk7QUFDL0MsUUFBSUk7QUFBTyxhQUFPWixLQUFLQyxNQUFNVyxLQUFLO0FBQ2xDLFdBQU87QUFBQSxNQUNMLEVBQUVrQixJQUFJLFNBQVN3QyxPQUFPLDJCQUEyQlIsTUFBTSxnRUFBZ0VTLFNBQVMsTUFBTUMsT0FBTyxXQUFXQyxVQUFVLGNBQWM7QUFBQSxNQUNoTCxFQUFFM0MsSUFBSSxTQUFTd0MsT0FBTyw4QkFBOEJSLE1BQU0sNkRBQTZEUyxTQUFTLE1BQU1DLE9BQU8sV0FBV0MsVUFBVSxhQUFhO0FBQUEsTUFDL0ssRUFBRTNDLElBQUksU0FBU3dDLE9BQU8sb0JBQW9CUixNQUFNLG1FQUFtRVMsU0FBUyxPQUFPQyxPQUFPLFdBQVdDLFVBQVUsYUFBYTtBQUFBLE1BQzVLLEVBQUUzQyxJQUFJLFNBQVN3QyxPQUFPLDBCQUEwQlIsTUFBTSx1REFBdURTLFNBQVMsT0FBT0MsT0FBTyxXQUFXQyxVQUFVLFlBQVk7QUFBQSxNQUNySyxFQUFFM0MsSUFBSSxTQUFTd0MsT0FBTyw0QkFBNEJSLE1BQU0sb0VBQW9FUyxTQUFTLE9BQU9DLE9BQU8sV0FBV0MsVUFBVSxRQUFRO0FBQUEsTUFDaEwsRUFBRTNDLElBQUksU0FBU3dDLE9BQU8seUJBQXlCUixNQUFNLHFFQUFxRVMsU0FBUyxPQUFPQyxPQUFPLFdBQVdDLFVBQVUsYUFBYTtBQUFBLElBQUM7QUFBQSxFQUV4TCxDQUFDO0FBR0QsUUFBTUMsVUFBVTtBQUFBLElBQ2R4RztBQUFBQSxJQUNBQztBQUFBQSxJQUNBSDtBQUFBQSxJQUNBQztBQUFBQSxJQUNBTztBQUFBQSxJQUNBcEI7QUFBQUEsRUFDRjtBQUdBLFFBQU0sQ0FBQ3VILE9BQU9DLFFBQVEsSUFBSWpJLFNBQVMsTUFBTTtBQUN2QyxVQUFNaUUsUUFBUXZCLGFBQWFDLFFBQVFtQixTQUFTO0FBQzVDLFFBQUlHO0FBQU8sYUFBT1osS0FBS0MsTUFBTVcsS0FBSztBQUNsQyxXQUFPO0FBQUEsTUFDTCxFQUFFa0IsSUFBSSxRQUFRRyxNQUFNLGlCQUFpQmlDLFFBQVEsS0FBT1YsU0FBUyxPQUFPcUIsYUFBYSxLQUFLQyxVQUFVLFlBQVk7QUFBQSxNQUM1RyxFQUFFaEQsSUFBSSxRQUFRRyxNQUFNLFlBQVlpQyxRQUFRLE1BQU9WLFNBQVMsTUFBT3FCLGFBQWEsS0FBS0MsVUFBVSxZQUFZO0FBQUEsTUFDdkcsRUFBRWhELElBQUksUUFBUUcsTUFBTSxhQUFhaUMsUUFBUSxNQUFRVixTQUFTLE9BQVFxQixhQUFhLE1BQU1DLFVBQVUsYUFBYTtBQUFBLE1BQzVHLEVBQUVoRCxJQUFJLFFBQVFHLE1BQU0sa0JBQWtCaUMsUUFBUSxNQUFPVixTQUFTLE1BQU1xQixhQUFhLEtBQUtDLFVBQVUsWUFBWTtBQUFBLE1BQzVHLEVBQUVoRCxJQUFJLFFBQVFHLE1BQU0sc0JBQXNCaUMsUUFBUSxNQUFRVixTQUFTLE1BQVFxQixhQUFhLE1BQU1DLFVBQVUsWUFBWTtBQUFBLE1BQ3BILEVBQUVoRCxJQUFJLFFBQVFHLE1BQU0scUJBQXFCaUMsUUFBUSxLQUFNVixTQUFTLEdBQUdxQixhQUFhLEtBQUtDLFVBQVUsWUFBWTtBQUFBLElBQUM7QUFBQSxFQUVoSCxDQUFDO0FBR0RsSSxZQUFVLE1BQU07QUFDZHlDLGlCQUFhMEYsUUFBUXhFLGFBQWFQLEtBQUtnRixVQUFVeEMsT0FBTyxDQUFDO0FBQUEsRUFDM0QsR0FBRyxDQUFDQSxTQUFTakMsV0FBVyxDQUFDO0FBRXpCM0QsWUFBVSxNQUFNO0FBQ2R5QyxpQkFBYTBGLFFBQVExRSxXQUFXTCxLQUFLZ0YsVUFBVTFCLEtBQUssQ0FBQztBQUFBLEVBQ3ZELEdBQUcsQ0FBQ0EsT0FBT2pELFNBQVMsQ0FBQztBQUVyQnpELFlBQVUsTUFBTTtBQUNkeUMsaUJBQWEwRixRQUFRekUsU0FBU04sS0FBS2dGLFVBQVVwQixZQUFZLENBQUM7QUFBQSxFQUM1RCxHQUFHLENBQUNBLGNBQWN0RCxPQUFPLENBQUM7QUFFMUIxRCxZQUFVLE1BQU07QUFDZHlDLGlCQUFhMEYsUUFBUXZFLGNBQWNSLEtBQUtnRixVQUFVWixRQUFRLENBQUM7QUFBQSxFQUM3RCxHQUFHLENBQUNBLFVBQVU1RCxZQUFZLENBQUM7QUFFM0I1RCxZQUFVLE1BQU07QUFDZHlDLGlCQUFhMEYsUUFBUXRFLFdBQVdULEtBQUtnRixVQUFVTCxLQUFLLENBQUM7QUFBQSxFQUN2RCxHQUFHLENBQUNBLE9BQU9sRSxTQUFTLENBQUM7QUFHckI3RCxZQUFVLE1BQU07QUFDZGtHLG1CQUFlLEVBQUUsR0FBR04sUUFBUSxDQUFDO0FBQUEsRUFDL0IsR0FBRyxDQUFDQSxPQUFPLENBQUM7QUFHWjVGLFlBQVUsTUFBTTtBQUNkLFVBQU13QyxNQUFNQyxhQUFhQyxRQUFRLE1BQU07QUFDdkMsUUFBSUYsS0FBSztBQUNQLFlBQU1XLFNBQVNDLEtBQUtDLE1BQU1iLEdBQUc7QUFDN0IsVUFBSSxDQUFDVyxPQUFPakIsUUFBUSxDQUFDaUIsT0FBT1AsYUFBYTtBQUN2Q0gscUJBQWEwRixRQUFRLFFBQVEvRSxLQUFLZ0YsVUFBVTdGLFdBQVcsQ0FBQztBQUFBLE1BQzFEO0FBQUEsSUFDRjtBQUFBLEVBQ0YsR0FBRyxDQUFDQSxXQUFXLENBQUM7QUFFaEIsUUFBTThGLGFBQWEsWUFBWTtBQUM3QixRQUFJO0FBQ0YsWUFBTUMsV0FBVyxNQUFNQyxNQUFNLG1DQUFtQztBQUFBLFFBQzlEQyxTQUFTO0FBQUEsVUFDUCxlQUFlakcsWUFBWUw7QUFBQUEsUUFDN0I7QUFBQSxNQUNGLENBQUM7QUFDRCxVQUFJb0csU0FBU0csSUFBSTtBQUNmLGNBQU1DLE9BQU8sTUFBTUosU0FBU0ssS0FBSztBQUNqQ2xFLGlCQUFTaUUsSUFBSTtBQUFBLE1BQ2YsT0FBTztBQUNMRSxnQkFBUUMsTUFBTSx1QkFBdUI7QUFBQSxNQUN2QztBQUFBLElBQ0YsU0FBU0MsS0FBSztBQUNaRixjQUFRQyxNQUFNLHlCQUF5QkMsR0FBRztBQUFBLElBQzVDO0FBQUEsRUFDRjtBQUVBOUksWUFBVSxNQUFNO0FBQ2QsUUFBSThELGNBQWMsZ0JBQWdCO0FBQ2hDdUUsaUJBQVc7QUFBQSxJQUNiO0FBQUEsRUFDRixHQUFHLENBQUN2RSxTQUFTLENBQUM7QUFFZCxRQUFNaUYsMEJBQTBCLE9BQU9DLFFBQVFDLGFBQWFDLHVCQUF1QjtBQUNqRixRQUFJO0FBQ0YsWUFBTVosV0FBVyxNQUFNQyxNQUFNLG1DQUFtQ1MsTUFBTSxnQkFBZ0I7QUFBQSxRQUNwRjVCLFFBQVE7QUFBQSxRQUNSb0IsU0FBUztBQUFBLFVBQ1AsZ0JBQWdCO0FBQUEsVUFDaEIsZUFBZWpHLFlBQVlMO0FBQUFBLFFBQzdCO0FBQUEsUUFDQWlILE1BQU0vRixLQUFLZ0YsVUFBVTtBQUFBLFVBQ25CbEcsTUFBTStHO0FBQUFBLFVBQ05yRyxhQUFhc0c7QUFBQUEsUUFDZixDQUFDO0FBQUEsTUFDSCxDQUFDO0FBRUQsWUFBTVIsT0FBTyxNQUFNSixTQUFTSyxLQUFLO0FBQ2pDLFVBQUlMLFNBQVNHLElBQUk7QUFDZlcsY0FBTVYsS0FBS1csV0FBVyxtQ0FBbUM7QUFDekQsWUFBSUwsV0FBV3pHLFlBQVkyQyxJQUFJO0FBQzdCLGdCQUFNb0UsY0FBYyxFQUFFLEdBQUcvRyxhQUFhTCxNQUFNK0csYUFBYXJHLGFBQWFzRyxtQkFBbUI7QUFDekZ6Ryx1QkFBYTBGLFFBQVEsUUFBUS9FLEtBQUtnRixVQUFVa0IsV0FBVyxDQUFDO0FBQUEsUUFDMUQ7QUFDQXJFO0FBQUFBLFVBQWlCLENBQUFzRSxTQUFRO0FBQUEsWUFDdkIsRUFBRXJFLElBQUlzRSxLQUFLQyxJQUFJLEdBQUd0RSxNQUFNLHlDQUF5Q1AsYUFBYTNDLFFBQVErRyxNQUFNLEtBQUs1RCxNQUFNLFlBQVlDLE1BQU0sV0FBV0MsUUFBUSxLQUFLO0FBQUEsWUFDakosR0FBR2lFO0FBQUFBLFVBQUk7QUFBQSxRQUNSO0FBQ0RsQixtQkFBVztBQUNYMUQseUJBQWlCLEtBQUs7QUFBQSxNQUN4QixPQUFPO0FBQ0x5RSxjQUFNVixLQUFLRyxTQUFTLDhCQUE4QjtBQUFBLE1BQ3BEO0FBQUEsSUFDRixTQUFTQyxLQUFLO0FBQ1pGLGNBQVFDLE1BQU0sK0JBQStCQyxHQUFHO0FBQ2hETSxZQUFNLDRCQUE0QjtBQUFBLElBQ3BDO0FBQUEsRUFDRjtBQUVBLFFBQU1NLDJCQUEyQkEsQ0FBQ0MsU0FBUztBQUN6QzlFLG1CQUFlOEUsSUFBSTtBQUNuQjVFLGdCQUFZO0FBQUEsTUFDVjdDLE1BQU15SCxLQUFLekg7QUFBQUEsTUFDWFUsYUFBYSxFQUFFLEdBQUcrRyxLQUFLL0csWUFBWTtBQUFBLElBQ3JDLENBQUM7QUFDRCtCLHFCQUFpQixJQUFJO0FBQUEsRUFDdkI7QUFHQSxRQUFNLENBQUNpRixhQUFhQyxjQUFjLElBQUk5SixTQUFTLEVBQUU2RyxTQUFTLElBQUlDLFFBQVEsSUFBSUMsUUFBUSxJQUFJQyxRQUFRLElBQUkxQixNQUFNLE9BQU8sQ0FBQztBQUdoSCxRQUFNLENBQUN5RSxVQUFVQyxXQUFXLElBQUloSyxTQUFTLEVBQUV1SCxRQUFRLFNBQVMwQyxNQUFNLEtBQUtDLE1BQU0sTUFBTUMsUUFBUSxTQUFTLENBQUM7QUFHckcsUUFBTSxDQUFDQyxnQkFBZ0JDLGlCQUFpQixJQUFJckssU0FBUyxFQUFFO0FBQ3ZELFFBQU0sQ0FBQ3NLLGlCQUFpQkMsa0JBQWtCLElBQUl2SyxTQUFTLEVBQUU7QUFDekQsUUFBTSxDQUFDd0ssbUJBQW1CQyxvQkFBb0IsSUFBSXpLLFNBQVMsQ0FBQztBQU01RCxRQUFNLENBQUMwSyxhQUFhQyxjQUFjLElBQUkzSyxTQUFTLEtBQUs7QUFDcEQsUUFBTSxDQUFDNEssV0FBV0MsWUFBWSxJQUFJN0ssU0FBUyxJQUFJO0FBQy9DLFFBQU0sQ0FBQzhLLFFBQVFDLFNBQVMsSUFBSS9LLFNBQVM7QUFBQSxJQUNuQ21ILE1BQU07QUFBQSxJQUNOSSxRQUFRO0FBQUEsSUFDUmpDLE1BQU07QUFBQSxJQUNOZ0MsVUFBVTtBQUFBLElBQ1ZELFFBQVE7QUFBQSxJQUNSRCxPQUFNLG9CQUFJcUMsS0FBSyxHQUFFdUIsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsSUFDM0N6RCxRQUFRO0FBQUEsRUFDVixDQUFDO0FBR0QsUUFBTSxDQUFDMEQsZUFBZUMsZ0JBQWdCLElBQUluTCxTQUFTLEtBQUs7QUFDeEQsUUFBTSxDQUFDb0wsYUFBYUMsY0FBYyxJQUFJckwsU0FBUyxJQUFJO0FBQ25ELFFBQU0sQ0FBQ3NMLFVBQVVDLFdBQVcsSUFBSXZMLFNBQVM7QUFBQSxJQUN2QzZHLFNBQVM7QUFBQSxJQUNUQyxRQUFRO0FBQUEsSUFDUkMsUUFBUTtBQUFBLElBQ1JDLFFBQVE7QUFBQSxJQUNSMUIsTUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUVELFFBQU0sRUFBRWtHLFFBQVFDLGNBQWMsSUFBSXRMLFFBQVE7QUFFMUMsUUFBTXVMLGVBQWVBLE1BQU07QUFDekJELGtCQUFjO0FBQ2RsSixhQUFTLFFBQVE7QUFBQSxFQUNuQjtBQUdBLFFBQU1vSixzQkFBc0JBLENBQUNDLE1BQU07QUFDakNBLE1BQUVDLGVBQWU7QUFDakIsVUFBTUMsTUFBTUMsV0FBVzNCLGNBQWM7QUFDckMsUUFBSSxDQUFDQSxrQkFBa0I0QixNQUFNRixHQUFHLEtBQUtBLE9BQU8sR0FBRztBQUM3Q3pDLFlBQU0sdUNBQXVDO0FBQzdDO0FBQUEsSUFDRjtBQUVBLFFBQUkxQyxNQUFNc0YsV0FBVyxHQUFHO0FBQ3RCNUMsWUFBTSw0REFBNEQ7QUFDbEU7QUFBQSxJQUNGO0FBRUEsUUFBSTFDLE1BQU0sQ0FBQyxFQUFFRSxVQUFVaUYsS0FBSztBQUMxQnpDLFlBQU0sc0NBQXNDMUMsTUFBTSxDQUFDLEVBQUVyQixJQUFJLFFBQVE7QUFDakU7QUFBQSxJQUNGO0FBRUEsVUFBTTRHLFlBQVlqSyxtQkFBbUJ1SSxpQkFBaUIsRUFBRXRJO0FBR3hELFVBQU1pSyxlQUFlLENBQUMsR0FBR3hGLEtBQUs7QUFDOUJ3RixpQkFBYSxDQUFDLEVBQUV0RixXQUFXaUY7QUFDM0JsRixhQUFTdUYsWUFBWTtBQUdyQixVQUFNQyxRQUFRO0FBQUEsTUFDWmpILElBQUksS0FBS2tILEtBQUtDLE1BQU0sTUFBTUQsS0FBS0UsT0FBTyxJQUFJLEdBQUcsQ0FBQztBQUFBLE1BQzlDcEYsTUFBTSxlQUFlK0UsU0FBUztBQUFBLE1BQzlCOUUsT0FBTSxvQkFBSXFDLEtBQUssR0FBRXVCLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLE1BQzNDM0YsTUFBTTtBQUFBLE1BQ04rQixRQUFRO0FBQUEsTUFDUkMsVUFBVTtBQUFBLE1BQ1ZDLFFBQVF1RTtBQUFBQSxNQUNSdEUsUUFBUTtBQUFBLElBQ1Y7QUFDQU4sb0JBQWdCLENBQUNrRixPQUFPLEdBQUduRixZQUFZLENBQUM7QUFFeEMvQjtBQUFBQSxNQUFpQixDQUFBc0UsU0FBUTtBQUFBLFFBQ3ZCLEVBQUVyRSxJQUFJc0UsS0FBS0MsSUFBSSxHQUFHdEUsTUFBTSxzQkFBc0IwRyxJQUFJVSxlQUFlLENBQUMsT0FBT04sU0FBUyxlQUFlN0csTUFBTSxZQUFZQyxNQUFNLFdBQVdDLFFBQVEsS0FBSztBQUFBLFFBQ2pKLEdBQUdpRTtBQUFBQSxNQUFJO0FBQUEsSUFDUjtBQUVEZSx1QkFBbUIsc0JBQXNCdUIsSUFBSVUsZUFBZSxDQUFDLE9BQU9OLFNBQVMsR0FBRztBQUNoRjdCLHNCQUFrQixFQUFFO0FBRXBCb0MsZUFBVyxNQUFNO0FBQ2ZsQyx5QkFBbUIsRUFBRTtBQUFBLElBQ3ZCLEdBQUcsR0FBSTtBQUFBLEVBQ1Q7QUFLQSxRQUFNbUMsb0JBQW9CQSxNQUFNO0FBQzlCN0IsaUJBQWEsSUFBSTtBQUNqQkUsY0FBVTtBQUFBLE1BQ1I1RCxNQUFNO0FBQUEsTUFDTkksUUFBUTtBQUFBLE1BQ1JqQyxNQUFNO0FBQUEsTUFDTmdDLFVBQVU7QUFBQSxNQUNWRCxRQUFRO0FBQUEsTUFDUkQsT0FBTSxvQkFBSXFDLEtBQUssR0FBRXVCLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLE1BQzNDekQsUUFBUTtBQUFBLElBQ1YsQ0FBQztBQUNEbUQsbUJBQWUsSUFBSTtBQUFBLEVBQ3JCO0FBRUEsUUFBTWdDLGtCQUFrQkEsQ0FBQ0MsT0FBTztBQUM5Qi9CLGlCQUFhK0IsRUFBRTtBQUNmN0IsY0FBVTtBQUFBLE1BQ1I1RCxNQUFNeUYsR0FBR3pGO0FBQUFBLE1BQ1RJLFFBQVFxRixHQUFHckYsT0FBT3NGLFNBQVM7QUFBQSxNQUMzQnZILE1BQU1zSCxHQUFHdEg7QUFBQUEsTUFDVGdDLFVBQVVzRixHQUFHdEY7QUFBQUEsTUFDYkQsUUFBUXVGLEdBQUd2RjtBQUFBQSxNQUNYRCxNQUFNd0YsR0FBR3hGO0FBQUFBLE1BQ1RJLFFBQVFvRixHQUFHcEY7QUFBQUEsSUFDYixDQUFDO0FBQ0RtRCxtQkFBZSxJQUFJO0FBQUEsRUFDckI7QUFFQSxRQUFNbUMsaUJBQWlCQSxDQUFDbEIsTUFBTTtBQUM1QkEsTUFBRUMsZUFBZTtBQUNqQixRQUFJLENBQUNmLE9BQU8zRCxRQUFRLENBQUMyRCxPQUFPdkQsVUFBVXlFLE1BQU1ELFdBQVdqQixPQUFPdkQsTUFBTSxDQUFDLEdBQUc7QUFDdEU4QixZQUFNLDZDQUE2QztBQUNuRDtBQUFBLElBQ0Y7QUFFQSxRQUFJdUIsV0FBVztBQUViMUQsc0JBQWdCRCxhQUFhdEIsSUFBSSxDQUFBb0gsTUFBSztBQUNwQyxZQUFJQSxFQUFFNUgsT0FBT3lGLFVBQVV6RixJQUFJO0FBQ3pCLGlCQUFPO0FBQUEsWUFDTCxHQUFHNEg7QUFBQUEsWUFDSDVGLE1BQU0yRCxPQUFPM0Q7QUFBQUEsWUFDYkksUUFBUXdFLFdBQVdqQixPQUFPdkQsTUFBTTtBQUFBLFlBQ2hDakMsTUFBTXdGLE9BQU94RjtBQUFBQSxZQUNiZ0MsVUFBVXdELE9BQU94RDtBQUFBQSxZQUNqQkQsUUFBUXlELE9BQU96RDtBQUFBQSxZQUNmRCxNQUFNMEQsT0FBTzFEO0FBQUFBLFlBQ2JJLFFBQVFzRCxPQUFPdEQ7QUFBQUEsVUFDakI7QUFBQSxRQUNGO0FBQ0EsZUFBT3VGO0FBQUFBLE1BQ1QsQ0FBQyxDQUFDO0FBQ0Y3SDtBQUFBQSxRQUFpQixDQUFBc0UsU0FBUTtBQUFBLFVBQ3ZCLEVBQUVyRSxJQUFJc0UsS0FBS0MsSUFBSSxHQUFHdEUsTUFBTSxnQkFBZ0IwRixPQUFPM0QsSUFBSSwyQkFBMkI5QixNQUFNLFlBQVlDLE1BQU0sUUFBUUMsUUFBUSxLQUFLO0FBQUEsVUFDM0gsR0FBR2lFO0FBQUFBLFFBQUk7QUFBQSxNQUNSO0FBQ0RILFlBQU0sbUNBQW1DO0FBQUEsSUFDM0MsT0FBTztBQUVMLFlBQU0rQyxRQUFRO0FBQUEsUUFDWmpILElBQUksS0FBS2tILEtBQUtDLE1BQU0sTUFBTUQsS0FBS0UsT0FBTyxJQUFJLEdBQUcsQ0FBQztBQUFBLFFBQzlDcEYsTUFBTTJELE9BQU8zRDtBQUFBQSxRQUNiSSxRQUFRd0UsV0FBV2pCLE9BQU92RCxNQUFNO0FBQUEsUUFDaENqQyxNQUFNd0YsT0FBT3hGO0FBQUFBLFFBQ2JnQyxVQUFVd0QsT0FBT3hEO0FBQUFBLFFBQ2pCRCxRQUFReUQsT0FBT3pEO0FBQUFBLFFBQ2ZELE1BQU0wRCxPQUFPMUQ7QUFBQUEsUUFDYkksUUFBUXNELE9BQU90RDtBQUFBQSxNQUNqQjtBQUNBTixzQkFBZ0IsQ0FBQ2tGLE9BQU8sR0FBR25GLFlBQVksQ0FBQztBQUN4Qy9CO0FBQUFBLFFBQWlCLENBQUFzRSxTQUFRO0FBQUEsVUFDdkIsRUFBRXJFLElBQUlzRSxLQUFLQyxJQUFJLEdBQUd0RSxNQUFNLG9CQUFvQjBGLE9BQU8zRCxJQUFJLE9BQU80RSxXQUFXakIsT0FBT3ZELE1BQU0sRUFBRWlGLGVBQWUsQ0FBQyxjQUFjbkgsTUFBTSxZQUFZQyxNQUFNLFdBQVdDLFFBQVEsS0FBSztBQUFBLFVBQ3RLLEdBQUdpRTtBQUFBQSxRQUFJO0FBQUEsTUFDUjtBQUNESCxZQUFNLG1DQUFtQztBQUFBLElBQzNDO0FBQ0FzQixtQkFBZSxLQUFLO0FBQUEsRUFDdEI7QUFFQSxRQUFNcUMsaUJBQWlCQSxDQUFDQyxTQUFTO0FBQy9CLFFBQUlDLE9BQU8xRyxRQUFRLG1EQUFtRCxHQUFHO0FBQ3ZFVSxzQkFBZ0JELGFBQWFrRyxPQUFPLENBQUFKLE1BQUtBLEVBQUU1SCxPQUFPOEgsSUFBSSxDQUFDO0FBQ3ZEL0g7QUFBQUEsUUFBaUIsQ0FBQXNFLFNBQVE7QUFBQSxVQUN2QixFQUFFckUsSUFBSXNFLEtBQUtDLElBQUksR0FBR3RFLE1BQU0scUNBQXFDQyxNQUFNLFlBQVlDLE1BQU0sV0FBV0MsUUFBUSxLQUFLO0FBQUEsVUFDN0csR0FBR2lFO0FBQUFBLFFBQUk7QUFBQSxNQUNSO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFLQSxRQUFNNEQsZ0JBQWdCQSxDQUFDeEIsTUFBTTtBQUMzQkEsTUFBRUMsZUFBZTtBQUNqQixRQUFJLENBQUNoQyxZQUFZaEQsV0FBVyxDQUFDZ0QsWUFBWS9DLFVBQVUsQ0FBQytDLFlBQVk5QyxVQUFVLENBQUM4QyxZQUFZN0MsUUFBUTtBQUM3RnFDLFlBQU0sa0RBQWtEO0FBQ3hEO0FBQUEsSUFDRjtBQUVBLFVBQU1nRSxVQUFVO0FBQUEsTUFDZGxJLElBQUlzRSxLQUFLQyxJQUFJO0FBQUEsTUFDYjdDLFNBQVNrRixXQUFXbEMsWUFBWWhELE9BQU8sS0FBSztBQUFBLE1BQzVDQyxRQUFRK0MsWUFBWS9DO0FBQUFBLE1BQ3BCQyxRQUFROEMsWUFBWTlDLE9BQU91RyxRQUFRLFlBQVksS0FBSyxFQUFFQyxLQUFLO0FBQUEsTUFDM0R2RyxRQUFRNkMsWUFBWTdDO0FBQUFBLE1BQ3BCMUIsTUFBTXVFLFlBQVl2RTtBQUFBQSxJQUNwQjtBQUVBc0IsYUFBUyxDQUFDLEdBQUdELE9BQU8wRyxPQUFPLENBQUM7QUFDNUJuSTtBQUFBQSxNQUFpQixDQUFBc0UsU0FBUTtBQUFBLFFBQ3ZCLEVBQUVyRSxJQUFJc0UsS0FBS0MsSUFBSSxHQUFHdEUsTUFBTSwrQkFBK0JpSSxRQUFRdkcsTUFBTSxLQUFLekIsTUFBTSxZQUFZQyxNQUFNLFdBQVdDLFFBQVEsS0FBSztBQUFBLFFBQzFILEdBQUdpRTtBQUFBQSxNQUFJO0FBQUEsSUFDUjtBQUNETSxtQkFBZSxFQUFFakQsU0FBUyxJQUFJQyxRQUFRLElBQUlDLFFBQVEsSUFBSUMsUUFBUSxJQUFJMUIsTUFBTSxPQUFPLENBQUM7QUFDaEYrRCxVQUFNLDBCQUEwQjtBQUFBLEVBQ2xDO0FBRUEsUUFBTW1FLG9CQUFvQkEsQ0FBQ0MsU0FBUztBQUNsQ3BDLG1CQUFlb0MsSUFBSTtBQUNuQmxDLGdCQUFZO0FBQUEsTUFDVjFFLFNBQVM0RyxLQUFLNUcsUUFBUWdHLFNBQVM7QUFBQSxNQUMvQi9GLFFBQVEyRyxLQUFLM0c7QUFBQUEsTUFDYkMsUUFBUTBHLEtBQUsxRyxPQUFPdUcsUUFBUSxRQUFRLEVBQUU7QUFBQSxNQUN0Q3RHLFFBQVF5RyxLQUFLekc7QUFBQUEsTUFDYjFCLE1BQU1tSSxLQUFLbkk7QUFBQUEsSUFDYixDQUFDO0FBQ0Q2RixxQkFBaUIsSUFBSTtBQUFBLEVBQ3ZCO0FBRUEsUUFBTXVDLHlCQUF5QkEsQ0FBQzlCLE1BQU07QUFDcENBLE1BQUVDLGVBQWU7QUFDakIsUUFBSSxDQUFDUCxTQUFTeEUsVUFBVSxDQUFDd0UsU0FBU3pFLFdBQVcsQ0FBQ3lFLFNBQVN2RSxVQUFVLENBQUN1RSxTQUFTdEUsUUFBUTtBQUNqRnFDLFlBQU0sNEJBQTRCO0FBQ2xDO0FBQUEsSUFDRjtBQUVBekMsYUFBU0QsTUFBTWhCLElBQUksQ0FBQWdJLE1BQUs7QUFDdEIsVUFBSUEsRUFBRXhJLE9BQU9pRyxZQUFZakcsSUFBSTtBQUMzQixlQUFPO0FBQUEsVUFDTCxHQUFHd0k7QUFBQUEsVUFDSDdHLFFBQVF3RSxTQUFTeEU7QUFBQUEsVUFDakJELFNBQVNrRixXQUFXVCxTQUFTekUsT0FBTztBQUFBLFVBQ3BDRSxRQUFRdUUsU0FBU3ZFLE9BQU91RyxRQUFRLFlBQVksS0FBSyxFQUFFQyxLQUFLO0FBQUEsVUFDeER2RyxRQUFRc0UsU0FBU3RFO0FBQUFBLFVBQ2pCMUIsTUFBTWdHLFNBQVNoRztBQUFBQSxRQUNqQjtBQUFBLE1BQ0Y7QUFDQSxhQUFPcUk7QUFBQUEsSUFDVCxDQUFDLENBQUM7QUFDRnhDLHFCQUFpQixLQUFLO0FBQ3RCakc7QUFBQUEsTUFBaUIsQ0FBQXNFLFNBQVE7QUFBQSxRQUN2QixFQUFFckUsSUFBSXNFLEtBQUtDLElBQUksR0FBR3RFLE1BQU0sMkJBQTJCa0csU0FBU3hFLE1BQU0sYUFBYXpCLE1BQU0sWUFBWUMsTUFBTSxRQUFRQyxRQUFRLEtBQUs7QUFBQSxRQUM1SCxHQUFHaUU7QUFBQUEsTUFBSTtBQUFBLElBQ1I7QUFDREgsVUFBTSw0QkFBNEI7QUFBQSxFQUNwQztBQUVBLFFBQU11RSxtQkFBbUJBLENBQUNDLFdBQVc7QUFDbkMsUUFBSVgsT0FBTzFHLFFBQVEsbURBQW1ELEdBQUc7QUFDdkVJLGVBQVNELE1BQU13RyxPQUFPLENBQUFRLE1BQUtBLEVBQUV4SSxPQUFPMEksTUFBTSxDQUFDO0FBQzNDM0k7QUFBQUEsUUFBaUIsQ0FBQXNFLFNBQVE7QUFBQSxVQUN2QixFQUFFckUsSUFBSXNFLEtBQUtDLElBQUksR0FBR3RFLE1BQU0scUNBQXFDQyxNQUFNLFlBQVlDLE1BQU0sV0FBV0MsUUFBUSxLQUFLO0FBQUEsVUFDN0csR0FBR2lFO0FBQUFBLFFBQUk7QUFBQSxNQUNSO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFLQSxRQUFNc0UsZ0JBQWdCQSxDQUFDbEMsTUFBTTtBQUMzQkEsTUFBRUMsZUFBZTtBQUNqQixVQUFNa0MsSUFBSWhDLFdBQVdoQyxTQUFTeEMsTUFBTTtBQUNwQyxVQUFNeUcsSUFBSWpDLFdBQVdoQyxTQUFTRSxJQUFJLElBQUksS0FBSztBQUMzQyxVQUFNckUsSUFBSXFJLFNBQVNsRSxTQUFTRyxJQUFJO0FBRWhDLFFBQUk4QixNQUFNK0IsQ0FBQyxLQUFLL0IsTUFBTWdDLENBQUMsS0FBS2hDLE1BQU1wRyxDQUFDLEtBQUttSSxLQUFLLEtBQUtDLEtBQUssS0FBS3BJLEtBQUssR0FBRztBQUNsRXlELFlBQU0sdUNBQXVDO0FBQzdDO0FBQUEsSUFDRjtBQUVBLFVBQU02RSxxQkFBc0JILElBQUlDLElBQUkzQixLQUFLOEIsSUFBSSxJQUFJSCxHQUFHcEksQ0FBQyxLQUFNeUcsS0FBSzhCLElBQUksSUFBSUgsR0FBR3BJLENBQUMsSUFBSTtBQUNoRm9FLGdCQUFZLEVBQUUsR0FBR0QsVUFBVUksUUFBUStELG1CQUFtQkUsUUFBUSxDQUFDLEVBQUUsQ0FBQztBQUFBLEVBQ3BFO0FBR0EsUUFBTUMsZ0JBQWdCQSxDQUFDQyxVQUFVO0FBQy9CNUcsZ0JBQVlELFNBQVM5QixJQUFJLENBQUE0SSxRQUFPO0FBQzlCLFVBQUlBLElBQUlwSixPQUFPbUosT0FBTztBQUNwQixlQUFPLEVBQUUsR0FBR0MsS0FBSzNHLFNBQVMsQ0FBQzJHLElBQUkzRyxRQUFRO0FBQUEsTUFDekM7QUFDQSxhQUFPMkc7QUFBQUEsSUFDVCxDQUFDLENBQUM7QUFBQSxFQUNKO0FBR0EsUUFBTUMsb0JBQW9CQSxDQUFDNUMsTUFBTTtBQUMvQkEsTUFBRUMsZUFBZTtBQUNqQi9GLGVBQVcsRUFBRSxHQUFHSSxZQUFZLENBQUM7QUFDN0JoQjtBQUFBQSxNQUFpQixDQUFBc0UsU0FBUTtBQUFBLFFBQ3ZCLEVBQUVyRSxJQUFJc0UsS0FBS0MsSUFBSSxHQUFHdEUsTUFBTSx5Q0FBeUNDLE1BQU0sWUFBWUMsTUFBTSxXQUFXQyxRQUFRLEtBQUs7QUFBQSxRQUNqSCxHQUFHaUU7QUFBQUEsTUFBSTtBQUFBLElBQ1I7QUFDRDlDLHVCQUFtQiwrQkFBK0I7QUFDbEQrRixlQUFXLE1BQU0vRixtQkFBbUIsRUFBRSxHQUFHLEdBQUk7QUFBQSxFQUMvQztBQUdBLFFBQU0rSCxxQkFBcUJBLENBQUM3QyxNQUFNO0FBQ2hDQSxNQUFFQyxlQUFlO0FBQ2pCLFFBQUksQ0FBQ3pGLGFBQWFFLFdBQVcsQ0FBQ0YsYUFBYUcsT0FBTyxDQUFDSCxhQUFhSSxTQUFTO0FBQ3ZFNkMsWUFBTSxxQ0FBcUM7QUFDM0M7QUFBQSxJQUNGO0FBQ0EsUUFBSWpELGFBQWFHLFFBQVFILGFBQWFJLFNBQVM7QUFDN0M2QyxZQUFNLGlEQUFpRDtBQUN2RDtBQUFBLElBQ0Y7QUFDQWhELG9CQUFnQixFQUFFQyxTQUFTLElBQUlDLEtBQUssSUFBSUMsU0FBUyxHQUFHLENBQUM7QUFDckR0QjtBQUFBQSxNQUFpQixDQUFBc0UsU0FBUTtBQUFBLFFBQ3ZCLEVBQUVyRSxJQUFJc0UsS0FBS0MsSUFBSSxHQUFHdEUsTUFBTSx5REFBeURDLE1BQU0sWUFBWUMsTUFBTSxXQUFXQyxRQUFRLEtBQUs7QUFBQSxRQUNqSSxHQUFHaUU7QUFBQUEsTUFBSTtBQUFBLElBQ1I7QUFDRDlDLHVCQUFtQixnQ0FBZ0M7QUFDbkQrRixlQUFXLE1BQU0vRixtQkFBbUIsRUFBRSxHQUFHLEdBQUk7QUFBQSxFQUMvQztBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLHVCQUViO0FBQUEsMkJBQUMsV0FBTSxXQUFVLFdBQ2Y7QUFBQSw2QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsYUFDYixpQ0FBQyxTQUFJLE9BQU0sTUFBSyxRQUFPLE1BQUssU0FBUSxhQUFZLE1BQUssUUFBTyxPQUFNLDhCQUNoRTtBQUFBLGlDQUFDLFVBQUssR0FBRSw4QkFBNkIsTUFBSyxTQUFRLFFBQU8sU0FBUSxhQUFZLEtBQUksZ0JBQWUsV0FBaEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUc7QUFBQSxVQUN2Ryx1QkFBQyxVQUFLLEdBQUUscUJBQW9CLFFBQU8sU0FBUSxhQUFZLEtBQUksZUFBYyxTQUFRLGdCQUFlLFdBQWhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVHO0FBQUEsVUFDdkcsdUJBQUMsVUFBSyxHQUFFLHFCQUFvQixRQUFPLFNBQVEsYUFBWSxLQUFJLGVBQWMsU0FBUSxnQkFBZSxXQUFoRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1RztBQUFBLGFBSHpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQSxLQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFFBQ0EsdUJBQUMsUUFBRyxXQUFVLGFBQVkseUJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUM7QUFBQSxXQVJyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxlQUNaZ0ksb0JBQ0V2QixPQUFPLENBQUN3QixTQUFTO0FBQ2hCLFlBQUlBLEtBQUt6TSxTQUFTLGdCQUFnQjtBQUNoQyxpQkFBT00sWUFBWUwsU0FBUyxXQUFXSyxZQUFZTCxTQUFTO0FBQUEsUUFDOUQ7QUFDQSxlQUFPO0FBQUEsTUFDVCxDQUFDLEVBQ0F3RCxJQUFJLENBQUNnSixTQUFTO0FBQ2IsY0FBTUMsT0FBT0QsS0FBS0U7QUFDbEIsZUFDRTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBRUMsTUFBSztBQUFBLFlBQ0wsU0FBUyxDQUFDakQsTUFBTTtBQUFFQSxnQkFBRUMsZUFBZTtBQUFHN0gsMkJBQWEySyxLQUFLek0sSUFBSTtBQUFBLFlBQUc7QUFBQSxZQUMvRCxXQUFXLFlBQVk2QixjQUFjNEssS0FBS3pNLE9BQU8sV0FBVyxFQUFFO0FBQUEsWUFFOUQ7QUFBQSxxQ0FBQyxRQUFLLE1BQU0sTUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFlO0FBQUEsY0FDZix1QkFBQyxVQUFNeU0sZUFBS3pNLFFBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUI7QUFBQTtBQUFBO0FBQUEsVUFOWnlNLEtBQUt6TTtBQUFBQSxVQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFRQTtBQUFBLE1BRUosQ0FBQyxLQXJCTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBc0JBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2IsaUNBQUMsWUFBTyxTQUFTd0osY0FBYyxXQUFVLGNBQ3ZDO0FBQUEsK0JBQUMsVUFBTyxNQUFNLE1BQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQjtBQUFBLFFBQ2pCLHVCQUFDLFVBQUssc0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFZO0FBQUEsV0FGZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxTQXpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMENBO0FBQUEsSUFHQSx1QkFBQyxVQUFLLFdBQVUsZ0JBQ2Q7QUFBQSw2QkFBQyxZQUFPLFdBQVUsVUFDaEI7QUFBQSwrQkFBQyxRQUFHLFdBQVUsY0FBYzNILHdCQUFjLGNBQWMsYUFBYUEsYUFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErRTtBQUFBLFFBRS9FLHVCQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsbUNBQUMsVUFBTyxNQUFNLElBQUksV0FBVSxpQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUM7QUFBQSxZQUN6QztBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxhQUFZO0FBQUEsZ0JBQ1osT0FBT007QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDdUgsTUFBTXRILGVBQWVzSCxFQUFFa0QsT0FBT0MsS0FBSztBQUFBO0FBQUEsY0FKaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSWtEO0FBQUEsZUFOcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLFVBRUEsdUJBQUMsWUFBTyxXQUFVLFlBQVcsU0FBUyxNQUFNL0ssYUFBYSxTQUFTLEdBQUcsY0FBVyxZQUM5RSxpQ0FBQyxZQUFTLE1BQU0sTUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUIsS0FEckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLHNCQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFXLFlBQVl3QixvQkFBb0IsV0FBVyxFQUFFO0FBQUEsZ0JBQ3hELFNBQVMsTUFBTUMscUJBQXFCLENBQUNELGlCQUFpQjtBQUFBLGdCQUN0RCxjQUFXO0FBQUEsZ0JBRVg7QUFBQSx5Q0FBQyxRQUFLLE1BQU0sTUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFlO0FBQUEsa0JBQ2RQLGNBQWNrSSxPQUFPLENBQUF2SCxNQUFLQSxFQUFFTCxNQUFNLEVBQUUwRyxTQUFTLEtBQzVDLHVCQUFDLFVBQUssV0FBVSxzQkFDYmhILHdCQUFja0ksT0FBTyxDQUFBdkgsTUFBS0EsRUFBRUwsTUFBTSxFQUFFMEcsVUFEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBO0FBQUE7QUFBQSxjQVRKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVdBO0FBQUEsWUFFQ3pHLHFCQUNDLHVCQUFDLFNBQUksV0FBVSx5QkFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSx1QkFDYjtBQUFBLHVDQUFDLFFBQUcsNkJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUI7QUFBQSxnQkFDaEJQLGNBQWNrSSxPQUFPLENBQUF2SCxNQUFLQSxFQUFFTCxNQUFNLEVBQUUwRyxTQUFTLEtBQzVDLHVCQUFDLFlBQU8sV0FBVSwyQkFBMEIsU0FBU3ZHLG1CQUFrQixnQ0FBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBT0E7QUFBQSxjQUNBLHVCQUFDLFFBQUcsV0FBVSxxQkFDWFQsd0JBQWNnSCxXQUFXLElBQ3hCLHVCQUFDLFFBQUcsV0FBVSxzQkFBcUIsZ0NBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1ELElBRW5EaEgsY0FBY1U7QUFBQUEsZ0JBQUksQ0FBQUMsTUFDaEI7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBRUMsV0FBVyxxQkFBcUJBLEVBQUVMLFNBQVMsV0FBVyxFQUFFO0FBQUEsb0JBQ3hELFNBQVMsTUFBTTtBQUNiTCx1Q0FBaUJELGNBQWNVLElBQUksQ0FBQWdKLFNBQVFBLEtBQUt4SixPQUFPUyxFQUFFVCxLQUFLLEVBQUUsR0FBR3dKLE1BQU1wSixRQUFRLE1BQU0sSUFBSW9KLElBQUksQ0FBQztBQUFBLG9CQUNsRztBQUFBLG9CQUVBO0FBQUEsNkNBQUMsVUFBSyxXQUFXLHNDQUFzQy9JLEVBQUVOLElBQUksTUFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBaUU7QUFBQSxzQkFDakUsdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsK0NBQUMsVUFBSyxXQUFVLDBCQUEwQk0sWUFBRVIsUUFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBaUQ7QUFBQSx3QkFDakQsdUJBQUMsVUFBSyxXQUFVLDBCQUEwQlEsWUFBRVAsUUFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBaUQ7QUFBQSwyQkFGbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFHQTtBQUFBO0FBQUE7QUFBQSxrQkFWS08sRUFBRVQ7QUFBQUEsa0JBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFZQTtBQUFBLGNBQ0QsS0FsQkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFvQkE7QUFBQSxpQkE3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE4QkE7QUFBQSxlQTdDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQStDQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGdCQUFlLFNBQVMsTUFBTTtBQUFFbkIseUJBQWEsU0FBUztBQUFHSSw4QkFBa0IsY0FBYztBQUFBLFVBQUcsR0FDekc7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLEtBQUt5QixRQUFRekQ7QUFBQUEsY0FDYixLQUFJO0FBQUEsY0FDSixXQUFVO0FBQUE7QUFBQSxZQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUd3QixLQUoxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BO0FBQUEsYUF0RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXVFQTtBQUFBLFdBMUVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEyRUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxxQkFJWjJCO0FBQUFBLHNCQUFjLGVBQ2IsbUNBRUU7QUFBQSxpQ0FBQyxTQUFJLFdBQVUseUJBRWI7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLHVDQUFDLFFBQUcsV0FBVSxpQkFBZ0Isd0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXNDO0FBQUEsZ0JBQ3RDLHVCQUFDLE9BQUUsTUFBSyxLQUFJLFdBQVUsZ0JBQWUsU0FBUyxDQUFDNkgsTUFBTTtBQUFFQSxvQkFBRUMsZUFBZTtBQUFHN0gsK0JBQWEsY0FBYztBQUFBLGdCQUFHLEdBQUcsdUJBQTVHO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW1IO0FBQUEsbUJBRnJIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxtQkFDWjJDLGdCQUFNaEI7QUFBQUEsZ0JBQUksQ0FBQzhILFNBQ1YsdUJBQUMsU0FBa0IsV0FBVyxlQUFlQSxLQUFLbkksSUFBSSxJQUVuRDlDO0FBQUFBLDhCQUFZSyxhQUFhRyxnQkFDeEIsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsMkNBQUMsWUFBTyxXQUFVLGlCQUFnQixTQUFTLE1BQU13SyxrQkFBa0JDLElBQUksR0FBRyxPQUFNLGFBQzlFLGlDQUFDLFNBQU0sTUFBTSxNQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdCLEtBRGxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxZQUFPLFdBQVUsaUJBQWdCLFNBQVMsTUFBTUcsaUJBQWlCSCxLQUFLdEksRUFBRSxHQUFHLE9BQU0sZUFDaEYsaUNBQUMsVUFBTyxNQUFNLE1BQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUIsS0FEbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBT0E7QUFBQSxrQkFHRix1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSwyQ0FBQyxTQUNDO0FBQUEsNkNBQUMsU0FBSSxXQUFVLGNBQWEsdUJBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQW1DO0FBQUEsc0JBQ25DLHVCQUFDLFNBQUksV0FBVSxnQkFBZTtBQUFBO0FBQUEsd0JBQUVzSSxLQUFLNUcsUUFBUTJGLGVBQWU7QUFBQSwyQkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBOEQ7QUFBQSx5QkFGaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFHQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLEtBQUtpQixLQUFLbkksU0FBUyxVQUFVLGtEQUFrRDtBQUFBLHdCQUMvRSxLQUFJO0FBQUEsd0JBQ0osV0FBVTtBQUFBO0FBQUEsc0JBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUd1QjtBQUFBLHVCQVJ6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVVBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsMkNBQUMsU0FBSSxXQUFVLG9CQUNiO0FBQUEsNkNBQUMsU0FBSSxXQUFVLGNBQWEsMkJBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXVDO0FBQUEsc0JBQ3ZDLHVCQUFDLFNBQUksV0FBVSxjQUFjbUksZUFBSzNHLFVBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXlDO0FBQUEseUJBRjNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBR0E7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLFdBQVUsb0JBQ2I7QUFBQSw2Q0FBQyxTQUFJLFdBQVUsY0FBYSwwQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBc0M7QUFBQSxzQkFDdEMsdUJBQUMsU0FBSSxXQUFVLGNBQWMyRyxlQUFLekcsVUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBeUM7QUFBQSx5QkFGM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFHQTtBQUFBLHVCQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBU0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSwyQ0FBQyxTQUFJLFdBQVUsZUFBZXlHLGVBQUsxRyxVQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUEwQztBQUFBLG9CQUMxQyx1QkFBQyxTQUFJLFdBQVUsYUFBWSxPQUFNLE1BQUssUUFBTyxNQUFLLFNBQVEsYUFBWSxNQUFLLFFBQU8sT0FBTSw4QkFDdEY7QUFBQSw2Q0FBQyxZQUFPLElBQUcsTUFBSyxJQUFHLE1BQUssR0FBRSxNQUFLLE1BQU0wRyxLQUFLbkksU0FBUyxVQUFVLFlBQVksU0FBUyxhQUFZLFNBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQW1HO0FBQUEsc0JBQ25HLHVCQUFDLFlBQU8sSUFBRyxNQUFLLElBQUcsTUFBSyxHQUFFLE1BQUssTUFBTW1JLEtBQUtuSSxTQUFTLFVBQVUsWUFBWSxTQUFTLGFBQVksU0FBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBbUc7QUFBQSx5QkFGckc7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFHQTtBQUFBLHVCQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBTUE7QUFBQSxxQkF4Q1FtSSxLQUFLdEksSUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXlDQTtBQUFBLGNBQ0QsS0E1Q0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE2Q0E7QUFBQSxpQkFsREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFtREE7QUFBQSxZQUdBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLGtCQUNiLGlDQUFDLFFBQUcsV0FBVSxpQkFBZ0Isa0NBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdELEtBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiLGlDQUFDLFNBQUksV0FBVSxxQkFDWjhCLHVCQUFhK0gsTUFBTSxHQUFHLENBQUMsRUFBRXJKO0FBQUFBLGdCQUFJLENBQUNpSCxPQUM3Qix1QkFBQyxTQUFnQixXQUFVLG9CQUN6QjtBQUFBLHlDQUFDLFNBQUksV0FBVSxvQkFDYjtBQUFBLDJDQUFDLFNBQUksV0FBVyw0QkFDZEEsR0FBR3RGLGFBQWEsWUFBWSxTQUM1QnNGLEdBQUd0RixhQUFhLGFBQWEsVUFBVSxRQUFRLElBRTlDc0YsYUFBR3RGLGFBQWEsWUFDZix1QkFBQyxTQUFJLE9BQU0sTUFBSyxRQUFPLE1BQUssU0FBUSxhQUFZLE1BQUssUUFBTyxRQUFPLGdCQUFlLGFBQVksT0FDNUYsaUNBQUMsVUFBSyxHQUFFLCtEQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW1FLEtBRHJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUEsSUFDRXNGLEdBQUd0RixhQUFhLGFBQ2xCLHVCQUFDLFNBQUksT0FBTSxNQUFLLFFBQU8sTUFBSyxTQUFRLGFBQVksTUFBSyxRQUFPLFFBQU8sZ0JBQWUsYUFBWSxPQUM1RixpQ0FBQyxVQUFLLEdBQUUsMENBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBOEMsS0FEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQSxJQUVBLHVCQUFDLFNBQUksT0FBTSxNQUFLLFFBQU8sTUFBSyxTQUFRLGFBQVksTUFBSyxRQUFPLFFBQU8sZ0JBQWUsYUFBWSxPQUM1RjtBQUFBLDZDQUFDLFVBQUssR0FBRSxLQUFJLEdBQUUsS0FBSSxPQUFNLE1BQUssUUFBTyxNQUFLLElBQUcsT0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBK0M7QUFBQSxzQkFDL0MsdUJBQUMsVUFBSyxJQUFHLEtBQUksSUFBRyxNQUFLLElBQUcsTUFBSyxJQUFHLFFBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQW9DO0FBQUEseUJBRnRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBR0EsS0FoQko7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFrQkE7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLFdBQVUsdUJBQ2I7QUFBQSw2Q0FBQyxRQUFJc0YsYUFBR3pGLFFBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBYTtBQUFBLHNCQUNiLHVCQUFDLE9BQUd5RixhQUFHeEYsUUFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFZO0FBQUEseUJBRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFHQTtBQUFBLHVCQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXdCQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVyxzQkFBc0J3RixHQUFHdEgsU0FBUyxZQUFZLGFBQWEsVUFBVSxJQUNsRnNIO0FBQUFBLHVCQUFHdEgsU0FBUyxZQUFZLE1BQU07QUFBQSxvQkFBSTtBQUFBLG9CQUFFc0gsR0FBR3JGLE9BQU9pRixlQUFlO0FBQUEsdUJBRGhFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkE1QlFJLEdBQUd6SCxJQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBNkJBO0FBQUEsY0FDRCxLQWhDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWlDQSxLQWxDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW1DQTtBQUFBLGlCQXZDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXdDQTtBQUFBLGVBaEdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUdBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUseUJBRWI7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxrQkFDYixpQ0FBQyxRQUFHLFdBQVUsaUJBQWdCLCtCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2QyxLQUQvQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsU0FBUSxPQUFPLEVBQUU4SixRQUFRLFFBQVEsR0FDOUM7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLDJDQUFDLFVBQUssV0FBVSwyQkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBd0M7QUFBQSxvQkFDeEMsdUJBQUMsVUFBSyx3QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFjO0FBQUEsdUJBRmhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLDJDQUFDLFVBQUssV0FBVSwwQkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBdUM7QUFBQSxvQkFDdkMsdUJBQUMsVUFBSyx1QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFhO0FBQUEsdUJBRmY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLHFCQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBU0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsb0JBQW1CLFNBQVEsZUFDeEM7QUFBQSx5Q0FBQyxVQUFLLElBQUcsTUFBSyxJQUFHLE1BQUssSUFBRyxPQUFNLElBQUcsTUFBSyxRQUFPLFdBQVUsYUFBWSxPQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1RTtBQUFBLGtCQUN2RSx1QkFBQyxVQUFLLElBQUcsTUFBSyxJQUFHLE1BQUssSUFBRyxPQUFNLElBQUcsTUFBSyxRQUFPLFdBQVUsYUFBWSxPQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1RTtBQUFBLGtCQUN2RSx1QkFBQyxVQUFLLElBQUcsTUFBSyxJQUFHLE9BQU0sSUFBRyxPQUFNLElBQUcsT0FBTSxRQUFPLFdBQVUsYUFBWSxPQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF5RTtBQUFBLGtCQUN6RSx1QkFBQyxVQUFLLElBQUcsTUFBSyxJQUFHLE9BQU0sSUFBRyxPQUFNLElBQUcsT0FBTSxRQUFPLFdBQVUsYUFBWSxPQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF5RTtBQUFBLGtCQUN6RSx1QkFBQyxVQUFLLElBQUcsTUFBSyxJQUFHLE9BQU0sSUFBRyxPQUFNLElBQUcsT0FBTSxRQUFPLFdBQVUsYUFBWSxTQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyRTtBQUFBLGtCQUUzRSx1QkFBQyxVQUFLLEdBQUUsTUFBSyxHQUFFLE1BQUssTUFBSyxXQUFVLFVBQVMsTUFBSyxZQUFXLE9BQU0sWUFBVyxPQUFNLG1CQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFzRjtBQUFBLGtCQUN0Rix1QkFBQyxVQUFLLEdBQUUsTUFBSyxHQUFFLE1BQUssTUFBSyxXQUFVLFVBQVMsTUFBSyxZQUFXLE9BQU0sWUFBVyxPQUFNLG1CQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFzRjtBQUFBLGtCQUN0Rix1QkFBQyxVQUFLLEdBQUUsTUFBSyxHQUFFLE9BQU0sTUFBSyxXQUFVLFVBQVMsTUFBSyxZQUFXLE9BQU0sWUFBVyxPQUFNLG1CQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1RjtBQUFBLGtCQUN2Rix1QkFBQyxVQUFLLEdBQUUsTUFBSyxHQUFFLE9BQU0sTUFBSyxXQUFVLFVBQVMsTUFBSyxZQUFXLE9BQU0sWUFBVyxPQUFNLG1CQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1RjtBQUFBLGtCQUN2Rix1QkFBQyxVQUFLLEdBQUUsTUFBSyxHQUFFLE9BQU0sTUFBSyxXQUFVLFVBQVMsTUFBSyxZQUFXLE9BQU0sWUFBVyxPQUFNLGlCQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFxRjtBQUFBLGtCQUVyRix1QkFBQyxPQUFFLFdBQVUsYUFDWDtBQUFBLDJDQUFDLFVBQUssR0FBRSxNQUFLLEdBQUUsTUFBSyxPQUFNLE1BQUssUUFBTyxPQUFNLElBQUcsS0FBSSxNQUFLLGFBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlFO0FBQUEsb0JBQ2pFLHVCQUFDLFVBQUssR0FBRSxPQUFNLEdBQUUsT0FBTSxPQUFNLE1BQUssUUFBTyxNQUFLLElBQUcsS0FBSSxNQUFLLGFBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWtFO0FBQUEsb0JBQ2xFLHVCQUFDLFVBQUssR0FBRSxPQUFNLEdBQUUsT0FBTSxNQUFLLFdBQVUsVUFBUyxNQUFLLFlBQVcsT0FBTSxZQUFXLFVBQVMsbUJBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTJGO0FBQUEsdUJBSDdGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSUE7QUFBQSxrQkFDQSx1QkFBQyxPQUFFLFdBQVUsYUFDWDtBQUFBLDJDQUFDLFVBQUssR0FBRSxPQUFNLEdBQUUsTUFBSyxPQUFNLE1BQUssUUFBTyxNQUFLLElBQUcsS0FBSSxNQUFLLGFBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlFO0FBQUEsb0JBQ2pFLHVCQUFDLFVBQUssR0FBRSxPQUFNLEdBQUUsT0FBTSxPQUFNLE1BQUssUUFBTyxNQUFLLElBQUcsS0FBSSxNQUFLLGFBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWtFO0FBQUEsb0JBQ2xFLHVCQUFDLFVBQUssR0FBRSxPQUFNLEdBQUUsT0FBTSxNQUFLLFdBQVUsVUFBUyxNQUFLLFlBQVcsT0FBTSxZQUFXLFVBQVMsbUJBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTJGO0FBQUEsdUJBSDdGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSUE7QUFBQSxrQkFDQSx1QkFBQyxPQUFFLFdBQVUsYUFDWDtBQUFBLDJDQUFDLFVBQUssR0FBRSxPQUFNLEdBQUUsT0FBTSxPQUFNLE1BQUssUUFBTyxNQUFLLElBQUcsS0FBSSxNQUFLLGFBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWtFO0FBQUEsb0JBQ2xFLHVCQUFDLFVBQUssR0FBRSxPQUFNLEdBQUUsT0FBTSxPQUFNLE1BQUssUUFBTyxNQUFLLElBQUcsS0FBSSxNQUFLLGFBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWtFO0FBQUEsb0JBQ2xFLHVCQUFDLFVBQUssR0FBRSxPQUFNLEdBQUUsT0FBTSxNQUFLLFdBQVUsVUFBUyxNQUFLLFlBQVcsT0FBTSxZQUFXLFVBQVMsbUJBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTJGO0FBQUEsdUJBSDdGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSUE7QUFBQSxrQkFDQSx1QkFBQyxPQUFFLFdBQVUsYUFDWDtBQUFBLDJDQUFDLFVBQUssR0FBRSxPQUFNLEdBQUUsTUFBSyxPQUFNLE1BQUssUUFBTyxPQUFNLElBQUcsS0FBSSxNQUFLLGFBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWtFO0FBQUEsb0JBQ2xFLHVCQUFDLFVBQUssR0FBRSxPQUFNLEdBQUUsTUFBSyxPQUFNLE1BQUssUUFBTyxPQUFNLElBQUcsS0FBSSxNQUFLLGFBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWtFO0FBQUEsb0JBQ2xFLHVCQUFDLFVBQUssR0FBRSxPQUFNLEdBQUUsT0FBTSxNQUFLLFdBQVUsVUFBUyxNQUFLLFlBQVcsT0FBTSxZQUFXLFVBQVMsbUJBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTJGO0FBQUEsdUJBSDdGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSUE7QUFBQSxrQkFDQSx1QkFBQyxPQUFFLFdBQVUsYUFDWDtBQUFBLDJDQUFDLFVBQUssR0FBRSxPQUFNLEdBQUUsT0FBTSxPQUFNLE1BQUssUUFBTyxNQUFLLElBQUcsS0FBSSxNQUFLLGFBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWtFO0FBQUEsb0JBQ2xFLHVCQUFDLFVBQUssR0FBRSxPQUFNLEdBQUUsT0FBTSxPQUFNLE1BQUssUUFBTyxNQUFLLElBQUcsS0FBSSxNQUFLLGFBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWtFO0FBQUEsb0JBQ2xFLHVCQUFDLFVBQUssR0FBRSxPQUFNLEdBQUUsT0FBTSxNQUFLLFdBQVUsVUFBUyxNQUFLLFlBQVcsT0FBTSxZQUFXLFVBQVMsbUJBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTJGO0FBQUEsdUJBSDdGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSUE7QUFBQSxrQkFDQSx1QkFBQyxPQUFFLFdBQVUsYUFDWDtBQUFBLDJDQUFDLFVBQUssR0FBRSxPQUFNLEdBQUUsTUFBSyxPQUFNLE1BQUssUUFBTyxPQUFNLElBQUcsS0FBSSxNQUFLLGFBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWtFO0FBQUEsb0JBQ2xFLHVCQUFDLFVBQUssR0FBRSxPQUFNLEdBQUUsT0FBTSxPQUFNLE1BQUssUUFBTyxNQUFLLElBQUcsS0FBSSxNQUFLLGFBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWtFO0FBQUEsb0JBQ2xFLHVCQUFDLFVBQUssR0FBRSxPQUFNLEdBQUUsT0FBTSxNQUFLLFdBQVUsVUFBUyxNQUFLLFlBQVcsT0FBTSxZQUFXLFVBQVMsbUJBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTJGO0FBQUEsdUJBSDdGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSUE7QUFBQSxrQkFDQSx1QkFBQyxPQUFFLFdBQVUsYUFDWDtBQUFBLDJDQUFDLFVBQUssR0FBRSxPQUFNLEdBQUUsTUFBSyxPQUFNLE1BQUssUUFBTyxPQUFNLElBQUcsS0FBSSxNQUFLLGFBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWtFO0FBQUEsb0JBQ2xFLHVCQUFDLFVBQUssR0FBRSxPQUFNLEdBQUUsT0FBTSxPQUFNLE1BQUssUUFBTyxNQUFLLElBQUcsS0FBSSxNQUFLLGFBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWtFO0FBQUEsb0JBQ2xFLHVCQUFDLFVBQUssR0FBRSxPQUFNLEdBQUUsT0FBTSxNQUFLLFdBQVUsVUFBUyxNQUFLLFlBQVcsT0FBTSxZQUFXLFVBQVMsbUJBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTJGO0FBQUEsdUJBSDdGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSUE7QUFBQSxxQkEvQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFnREE7QUFBQSxtQkEzREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE0REE7QUFBQSxpQkFoRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpRUE7QUFBQSxZQUdBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLGtCQUNiLGlDQUFDLFFBQUcsV0FBVSxpQkFBZ0Isa0NBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdELEtBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxTQUFRLE9BQU8sRUFBRUEsUUFBUSxRQUFRLEdBQzlDO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDJCQUNiLGlDQUFDLFNBQUksV0FBVSxtQkFBa0IsU0FBUSxlQUN2QztBQUFBLHlDQUFDLFlBQU8sSUFBRyxPQUFNLElBQUcsT0FBTSxHQUFFLE1BQUssTUFBSyxRQUFPLFFBQU8sV0FBVSxhQUFZLFFBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQThFO0FBQUEsa0JBQzlFLHVCQUFDLFlBQU8sV0FBVSxpQkFBZ0IsSUFBRyxPQUFNLElBQUcsT0FBTSxHQUFFLE1BQUssTUFBSyxRQUFPLFFBQU8sV0FBVSxhQUFZLE1BQUssaUJBQWdCLGFBQVksa0JBQWlCLEtBQUksV0FBVSx5QkFBcEs7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBeUw7QUFBQSxrQkFDekwsdUJBQUMsWUFBTyxXQUFVLGlCQUFnQixJQUFHLE9BQU0sSUFBRyxPQUFNLEdBQUUsTUFBSyxNQUFLLFFBQU8sUUFBTyxXQUFVLGFBQVksTUFBSyxpQkFBZ0IsV0FBVSxrQkFBaUIsVUFBUyxXQUFVLHlCQUF2SztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE0TDtBQUFBLGtCQUM1TCx1QkFBQyxZQUFPLFdBQVUsaUJBQWdCLElBQUcsT0FBTSxJQUFHLE9BQU0sR0FBRSxNQUFLLE1BQUssUUFBTyxRQUFPLFdBQVUsYUFBWSxNQUFLLGlCQUFnQixVQUFTLGtCQUFpQixVQUFTLFdBQVUseUJBQXRLO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTJMO0FBQUEsa0JBQzNMLHVCQUFDLFlBQU8sV0FBVSxpQkFBZ0IsSUFBRyxPQUFNLElBQUcsT0FBTSxHQUFFLE1BQUssTUFBSyxRQUFPLFFBQU8sV0FBVSxhQUFZLE1BQUssaUJBQWdCLFVBQVMsa0JBQWlCLFVBQVMsV0FBVSx5QkFBdEs7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMkw7QUFBQSxrQkFFM0wsdUJBQUMsVUFBSyxHQUFFLE9BQU0sR0FBRSxNQUFLLFdBQVUscUJBQW9CLE1BQUssV0FBVSxVQUFTLE1BQUssWUFBVyxPQUFNLG1CQUFqRztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFvRztBQUFBLGtCQUNwRyx1QkFBQyxVQUFLLEdBQUUsT0FBTSxHQUFFLE9BQU0sV0FBVSxxQkFBb0IsTUFBSyxXQUFVLFVBQVMsTUFBSyxZQUFXLE9BQU0sZUFBYyxPQUFNLDZCQUF0SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFtSTtBQUFBLHFCQVJySTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVNBLEtBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFXQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFQyxTQUFTLFFBQVFDLHFCQUFxQixXQUFXQyxLQUFLLGVBQWVDLFdBQVcsVUFBVUMsU0FBUyxXQUFXLEdBQzFIO0FBQUEseUNBQUMsU0FBSSxXQUFVLGVBQWM7QUFBQSwyQ0FBQyxVQUFLLFdBQVUsZ0JBQWUsT0FBTyxFQUFFQyxZQUFZLFVBQVUsS0FBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUU7QUFBQSxvQkFBTyx1QkFBQyxVQUFLLE9BQU8sRUFBRUMsVUFBVSxVQUFVQyxZQUFZLElBQUksR0FBRyx3QkFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBOEQ7QUFBQSx1QkFBbks7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMEs7QUFBQSxrQkFDMUssdUJBQUMsU0FBSSxXQUFVLGVBQWM7QUFBQSwyQ0FBQyxVQUFLLFdBQVUsZ0JBQWUsT0FBTyxFQUFFRixZQUFZLFVBQVUsS0FBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUU7QUFBQSxvQkFBTyx1QkFBQyxVQUFLLE9BQU8sRUFBRUMsVUFBVSxVQUFVQyxZQUFZLElBQUksR0FBRywwQkFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0U7QUFBQSx1QkFBcks7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNEs7QUFBQSxrQkFDNUssdUJBQUMsU0FBSSxXQUFVLGVBQWM7QUFBQSwyQ0FBQyxVQUFLLFdBQVUsZ0JBQWUsT0FBTyxFQUFFRixZQUFZLFVBQVUsS0FBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUU7QUFBQSxvQkFBTyx1QkFBQyxVQUFLLE9BQU8sRUFBRUMsVUFBVSxVQUFVQyxZQUFZLElBQUksR0FBRyx3QkFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBOEQ7QUFBQSx1QkFBbks7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMEs7QUFBQSxrQkFDMUssdUJBQUMsU0FBSSxXQUFVLGVBQWM7QUFBQSwyQ0FBQyxVQUFLLFdBQVUsZ0JBQWUsT0FBTyxFQUFFRixZQUFZLFVBQVUsS0FBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUU7QUFBQSxvQkFBTyx1QkFBQyxVQUFLLE9BQU8sRUFBRUMsVUFBVSxVQUFVQyxZQUFZLElBQUksR0FBRyx5QkFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBK0Q7QUFBQSx1QkFBcEs7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMks7QUFBQSxxQkFKN0s7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFLQTtBQUFBLG1CQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW1CQTtBQUFBLGlCQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXdCQTtBQUFBLGVBOUZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBK0ZBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUseUJBRWI7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxrQkFDYixpQ0FBQyxRQUFHLFdBQVUsaUJBQWdCLDhCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0QyxLQUQ5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsU0FBUSxPQUFPLEVBQUVSLFFBQVEsUUFBUSxHQUM5QyxpQ0FBQyxTQUFJLFdBQVUsNEJBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsb0JBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsZ0JBQ1poTiw2QkFBbUIwRDtBQUFBQSxvQkFBSSxDQUFDaUUsTUFBTThGLFFBQzdCO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUVDLFdBQVcsZUFBZWxGLHNCQUFzQmtGLE1BQU0sYUFBYSxFQUFFO0FBQUEsd0JBQ3JFLFNBQVMsTUFBTWpGLHFCQUFxQmlGLEdBQUc7QUFBQSx3QkFFdkM7QUFBQSxpREFBQyxTQUFJLEtBQUs5RixLQUFLeEgsUUFBUSxLQUFLd0gsS0FBSzFILE1BQU0sV0FBVSxpQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBOEQ7QUFBQSwwQkFDOUQsdUJBQUMsVUFBSyxXQUFVLGFBQWEwSCxlQUFLMUgsS0FBSytJLE1BQU0sR0FBRyxFQUFFLENBQUMsS0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBcUQ7QUFBQSwwQkFDckQsdUJBQUMsVUFBSyxXQUFVLGFBQWFyQixlQUFLekgsUUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBdUM7QUFBQTtBQUFBO0FBQUEsc0JBTmxDeUgsS0FBSzFIO0FBQUFBLHNCQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBUUE7QUFBQSxrQkFDRCxLQVhIO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBWUE7QUFBQSxrQkFDQSx1QkFBQyxZQUFPLFdBQVUsb0JBQW1CLGNBQVcsYUFDOUMsaUNBQUMsZ0JBQWEsTUFBTSxNQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1QixLQUR6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBaUJBO0FBQUEsZ0JBRUEsdUJBQUMsVUFBSyxVQUFVeUoscUJBQXFCLFdBQVUsdUJBQzdDO0FBQUEseUNBQUMsVUFBSyxXQUFVLGtCQUFpQiw0QkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNkM7QUFBQSxrQkFDN0MsdUJBQUMsU0FBSSxXQUFVLHdCQUF1QixPQUFPLENBQUNuSixZQUFZSyxhQUFhRSxZQUFZLEVBQUU0TSxTQUFTLElBQUksSUFBSSxDQUFDLEdBQ3JHO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLGFBQWFuTixZQUFZSyxhQUFhRSxZQUFZLFdBQVc7QUFBQSx3QkFDN0QsT0FBT3FIO0FBQUFBLHdCQUNQLFVBQVUsQ0FBQ3dCLE1BQU12QixrQkFBa0J1QixFQUFFa0QsT0FBT0MsS0FBSztBQUFBLHdCQUNqRCxVQUFVLENBQUN2TSxZQUFZSyxhQUFhRTtBQUFBQTtBQUFBQSxzQkFMdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtnRDtBQUFBLG9CQUVoRCx1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLFlBQVcsVUFBVSxDQUFDUCxZQUFZSyxhQUFhRSxXQUFXLE9BQU8sQ0FBQ1AsWUFBWUssYUFBYUUsWUFBWSxFQUFFNE0sU0FBUyxLQUFLQyxRQUFRLGVBQWVDLGVBQWUsT0FBTyxJQUFJLENBQUMsR0FDdk07QUFBQSw2Q0FBQyxVQUFLLG9CQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQVU7QUFBQSxzQkFDVix1QkFBQyxRQUFLLE1BQU0sTUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFlO0FBQUEseUJBRmpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBR0E7QUFBQSx1QkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVlBO0FBQUEscUJBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFlQTtBQUFBLGdCQUNDdkYsbUJBQ0MsdUJBQUMsU0FBSSxPQUFPO0FBQUEsa0JBQ1YrRSxXQUFXO0FBQUEsa0JBQ1hDLFNBQVM7QUFBQSxrQkFDVEMsWUFBWTtBQUFBLGtCQUNaMUgsT0FBTztBQUFBLGtCQUNQaUksY0FBYztBQUFBLGtCQUNkTixVQUFVO0FBQUEsa0JBQ1ZDLFlBQVk7QUFBQSxrQkFDWk0sV0FBVztBQUFBLGtCQUNYQyxRQUFRO0FBQUEsa0JBQ1JDLFdBQVc7QUFBQSxnQkFDYixHQUNHM0YsNkJBWkg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFhQTtBQUFBLG1CQWxESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW9EQSxLQXJERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXNEQTtBQUFBLGlCQTFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTJEQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsa0JBQ2IsaUNBQUMsUUFBRyxXQUFVLGlCQUFnQiwrQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkMsS0FEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQVEsT0FBTyxFQUFFMkUsUUFBUSxRQUFRLEdBQzlDLGlDQUFDLFNBQUksV0FBVSwyQkFDYixpQ0FBQyxTQUFJLFdBQVUscUJBQW9CLFNBQVEsZUFDekM7QUFBQSx1Q0FBQyxVQUNDLGlDQUFDLG9CQUFlLElBQUcsbUJBQWtCLElBQUcsS0FBSSxJQUFHLEtBQUksSUFBRyxLQUFJLElBQUcsS0FDM0Q7QUFBQSx5Q0FBQyxVQUFLLFFBQU8sTUFBSyxXQUFVLFdBQVUsYUFBWSxVQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF3RDtBQUFBLGtCQUN4RCx1QkFBQyxVQUFLLFFBQU8sUUFBTyxXQUFVLFdBQVUsYUFBWSxTQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF5RDtBQUFBLHFCQUYzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFLQTtBQUFBLGdCQUVBLHVCQUFDLFVBQUssV0FBVSxxQkFBb0IsSUFBRyxNQUFLLElBQUcsTUFBSyxJQUFHLE9BQU0sSUFBRyxNQUFLLFFBQU8sV0FBVSxhQUFZLE9BQWxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFHO0FBQUEsZ0JBQ3JHLHVCQUFDLFVBQUssV0FBVSxxQkFBb0IsSUFBRyxNQUFLLElBQUcsTUFBSyxJQUFHLE9BQU0sSUFBRyxNQUFLLFFBQU8sV0FBVSxhQUFZLE9BQWxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFHO0FBQUEsZ0JBQ3JHLHVCQUFDLFVBQUssV0FBVSxxQkFBb0IsSUFBRyxNQUFLLElBQUcsT0FBTSxJQUFHLE9BQU0sSUFBRyxPQUFNLFFBQU8sV0FBVSxhQUFZLE9BQXBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVHO0FBQUEsZ0JBQ3ZHLHVCQUFDLFVBQUssV0FBVSxxQkFBb0IsSUFBRyxNQUFLLElBQUcsT0FBTSxJQUFHLE9BQU0sSUFBRyxPQUFNLFFBQU8sV0FBVSxhQUFZLFNBQXBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlHO0FBQUEsZ0JBRXpHLHVCQUFDLFVBQUssR0FBRSxNQUFLLEdBQUUsTUFBSyxNQUFLLFdBQVUsVUFBUyxNQUFLLFlBQVcsT0FBTSxZQUFXLE9BQU0sbUJBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXNGO0FBQUEsZ0JBQ3RGLHVCQUFDLFVBQUssR0FBRSxNQUFLLEdBQUUsTUFBSyxNQUFLLFdBQVUsVUFBUyxNQUFLLFlBQVcsT0FBTSxZQUFXLE9BQU0sbUJBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXNGO0FBQUEsZ0JBQ3RGLHVCQUFDLFVBQUssR0FBRSxNQUFLLEdBQUUsT0FBTSxNQUFLLFdBQVUsVUFBUyxNQUFLLFlBQVcsT0FBTSxZQUFXLE9BQU0sbUJBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVGO0FBQUEsZ0JBQ3ZGLHVCQUFDLFVBQUssR0FBRSxNQUFLLEdBQUUsT0FBTSxNQUFLLFdBQVUsVUFBUyxNQUFLLFlBQVcsT0FBTSxZQUFXLE9BQU0saUJBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFGO0FBQUEsZ0JBRXJGLHVCQUFDLFVBQUssR0FBRSxNQUFLLEdBQUUsT0FBTSxNQUFLLFdBQVUsVUFBUyxNQUFLLFlBQVcsT0FBTSxZQUFXLFVBQVMsbUJBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBGO0FBQUEsZ0JBQzFGLHVCQUFDLFVBQUssR0FBRSxPQUFNLEdBQUUsT0FBTSxNQUFLLFdBQVUsVUFBUyxNQUFLLFlBQVcsT0FBTSxZQUFXLFVBQVMsbUJBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJGO0FBQUEsZ0JBQzNGLHVCQUFDLFVBQUssR0FBRSxPQUFNLEdBQUUsT0FBTSxNQUFLLFdBQVUsVUFBUyxNQUFLLFlBQVcsT0FBTSxZQUFXLFVBQVMsbUJBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJGO0FBQUEsZ0JBQzNGLHVCQUFDLFVBQUssR0FBRSxPQUFNLEdBQUUsT0FBTSxNQUFLLFdBQVUsVUFBUyxNQUFLLFlBQVcsT0FBTSxZQUFXLFVBQVMsbUJBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJGO0FBQUEsZ0JBQzNGLHVCQUFDLFVBQUssR0FBRSxPQUFNLEdBQUUsT0FBTSxNQUFLLFdBQVUsVUFBUyxNQUFLLFlBQVcsT0FBTSxZQUFXLFVBQVMsbUJBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJGO0FBQUEsZ0JBQzNGLHVCQUFDLFVBQUssR0FBRSxPQUFNLEdBQUUsT0FBTSxNQUFLLFdBQVUsVUFBUyxNQUFLLFlBQVcsT0FBTSxZQUFXLFVBQVMsbUJBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJGO0FBQUEsZ0JBQzNGLHVCQUFDLFVBQUssR0FBRSxPQUFNLEdBQUUsT0FBTSxNQUFLLFdBQVUsVUFBUyxNQUFLLFlBQVcsT0FBTSxZQUFXLFVBQVMsbUJBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJGO0FBQUEsZ0JBRTNGO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLEdBQUU7QUFBQSxvQkFDRixNQUFLO0FBQUE7QUFBQSxrQkFGUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRThCO0FBQUEsZ0JBRzlCO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLEdBQUU7QUFBQSxvQkFDRixNQUFLO0FBQUEsb0JBQ0wsUUFBTztBQUFBLG9CQUNQLGFBQVk7QUFBQSxvQkFDWixlQUFjO0FBQUE7QUFBQSxrQkFMaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUt1QjtBQUFBLGdCQUd2Qix1QkFBQyxZQUFPLElBQUcsT0FBTSxJQUFHLE1BQUssR0FBRSxLQUFJLE1BQUssV0FBVSxRQUFPLFdBQVUsYUFBWSxPQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE4RTtBQUFBLGdCQUM5RSx1QkFBQyxZQUFPLElBQUcsT0FBTSxJQUFHLE1BQUssR0FBRSxLQUFJLE1BQUssV0FBVSxRQUFPLFdBQVUsYUFBWSxPQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE4RTtBQUFBLG1CQXhDaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF5Q0EsS0ExQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkEyQ0EsS0E1Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE2Q0E7QUFBQSxpQkFqREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFrREE7QUFBQSxlQWxIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1IQTtBQUFBLGFBM1RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0VEE7QUFBQSxRQU1EbEwsY0FBYyxrQkFDYix1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxlQUFjLE9BQU8sRUFBRW1NLGNBQWMsR0FBR0MsY0FBYyxPQUFPLEdBQzFFO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVyxjQUFjNUwsMEJBQTBCLFFBQVEsV0FBVyxFQUFFO0FBQUEsa0JBQ3hFLFNBQVMsTUFBTUMseUJBQXlCLEtBQUs7QUFBQSxrQkFBRTtBQUFBO0FBQUEsZ0JBRmpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFXLGNBQWNELDBCQUEwQixXQUFXLFdBQVcsRUFBRTtBQUFBLGtCQUMzRSxTQUFTLE1BQU1DLHlCQUF5QixRQUFRO0FBQUEsa0JBQUU7QUFBQTtBQUFBLGdCQUZwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVyxjQUFjRCwwQkFBMEIsWUFBWSxXQUFXLEVBQUU7QUFBQSxrQkFDNUUsU0FBUyxNQUFNQyx5QkFBeUIsU0FBUztBQUFBLGtCQUFFO0FBQUE7QUFBQSxnQkFGckQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxpQkFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFtQkE7QUFBQSxZQUVDaEMsWUFBWUssYUFBYUUsYUFDeEIsdUJBQUMsWUFBTyxXQUFVLHFCQUFvQixPQUFPLEVBQUVxTixRQUFRLEdBQUdkLFNBQVMsaUJBQWlCUSxjQUFjLE9BQU8sR0FBRyxTQUFTcEQsbUJBQ25IO0FBQUEscUNBQUMsUUFBSyxNQUFNLElBQUksT0FBTyxFQUFFMkQsYUFBYSxVQUFVQyxlQUFlLFNBQVMsS0FBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEU7QUFBQTtBQUFBLGlCQUQ1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsZUExQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE0QkE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxpQkFDYixpQ0FBQyxXQUFNLFdBQVUsZ0JBQ2Y7QUFBQSxtQ0FBQyxXQUNDLGlDQUFDLFFBQ0M7QUFBQSxxQ0FBQyxRQUFHLDJCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWU7QUFBQSxjQUNmLHVCQUFDLFFBQUcsOEJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0I7QUFBQSxjQUNsQix1QkFBQyxRQUFHLHdCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQVk7QUFBQSxjQUNaLHVCQUFDLFFBQUcsc0JBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBVTtBQUFBLGNBQ1YsdUJBQUMsUUFBRyxvQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFRO0FBQUEsY0FDUix1QkFBQyxRQUFHLHNCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQVU7QUFBQSxjQUNWLHVCQUFDLFFBQUcsc0JBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBVTtBQUFBLGNBQ1YsdUJBQUMsUUFBRyx1QkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFXO0FBQUEsaUJBUmI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFTQSxLQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBV0E7QUFBQSxZQUNBLHVCQUFDLFdBQ0VySix1QkFDRWtHLE9BQU8sQ0FBQVAsT0FBTXJJLDBCQUEwQixTQUFTcUksR0FBR3RILFNBQVNmLHFCQUFxQixFQUNqRjRJO0FBQUFBLGNBQU8sQ0FBQVAsT0FDTkEsR0FBR3pGLEtBQUszRCxZQUFZLEVBQUUrTSxTQUFTbE0sWUFBWWIsWUFBWSxDQUFDLEtBQ3hEb0osR0FBR3pILEdBQUczQixZQUFZLEVBQUUrTSxTQUFTbE0sWUFBWWIsWUFBWSxDQUFDLEtBQ3REb0osR0FBR3RGLFNBQVM5RCxZQUFZLEVBQUUrTSxTQUFTbE0sWUFBWWIsWUFBWSxDQUFDO0FBQUEsWUFDOUQsRUFDQ21DO0FBQUFBLGNBQUksQ0FBQ2lILE9BQ0osdUJBQUMsUUFDQztBQUFBLHVDQUFDLFFBQUcsT0FBTyxFQUFFc0MsU0FBUyxRQUFRc0IsWUFBWSxVQUFVcEIsS0FBSyxVQUFVLEdBQ2pFO0FBQUEseUNBQUMsU0FBSSxXQUFXLDRCQUNkeEMsR0FBR3RILFNBQVMsV0FBVyxVQUFVLEtBQUssSUFDcEMsT0FBTyxFQUFFbUwsT0FBTyxRQUFReEIsUUFBUSxPQUFPLEdBQ3hDckMsYUFBR3RILFNBQVMsV0FBVyx1QkFBQyxjQUFXLE1BQU0sTUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBcUIsSUFBTSx1QkFBQyxjQUFXLE1BQU0sSUFBSSxPQUFPLEVBQUVvTCxXQUFXLGlCQUFpQixLQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2RCxLQUhsSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUlBO0FBQUEsa0JBQ0EsdUJBQUMsVUFBTTlELGFBQUd6RixRQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWU7QUFBQSxxQkFOakI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFPQTtBQUFBLGdCQUNBLHVCQUFDLFFBQUcsT0FBTyxFQUFFVSxPQUFPLFVBQVUsR0FBSStFLGFBQUd6SCxNQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3QztBQUFBLGdCQUN4Qyx1QkFBQyxRQUFJeUgsYUFBR3RGLFlBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUI7QUFBQSxnQkFDakIsdUJBQUMsUUFBSXNGLGFBQUd2RixVQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWU7QUFBQSxnQkFDZix1QkFBQyxRQUFHLE9BQU8sRUFBRVEsT0FBTyxVQUFVLEdBQUkrRSxhQUFHeEYsUUFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMEM7QUFBQSxnQkFDMUMsdUJBQUMsUUFBRyxPQUFPO0FBQUEsa0JBQ1RxSSxZQUFZO0FBQUEsa0JBQ1o1SCxPQUFPK0UsR0FBR3RILFNBQVMsWUFBWSxpQkFBaUI7QUFBQSxnQkFDbEQsR0FDR3NIO0FBQUFBLHFCQUFHdEgsU0FBUyxZQUFZLE1BQU07QUFBQSxrQkFBSTtBQUFBLGtCQUFFc0gsR0FBR3JGLE9BQU9pRixlQUFlO0FBQUEscUJBSmhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS0E7QUFBQSxnQkFDQSx1QkFBQyxRQUNDLGlDQUFDLFVBQUssV0FBVyxnQkFDZkksR0FBR3BGLFdBQVcsWUFBWSxZQUMxQm9GLEdBQUdwRixXQUFXLFlBQVksWUFBWSxRQUFRLElBRTdDb0YsYUFBR3BGLFVBSk47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBT0E7QUFBQSxnQkFDQSx1QkFBQyxRQUVFaEYsc0JBQVlLLGFBQWFFLFlBQ3hCLHVCQUFDLFNBQUksV0FBVSxvQkFDYjtBQUFBLHlDQUFDLFlBQU8sV0FBVSx5QkFBd0IsU0FBUyxNQUFNNEosZ0JBQWdCQyxFQUFFLEdBQUcsT0FBTSxRQUNsRixpQ0FBQyxTQUFNLE1BQU0sTUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQixLQURsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsWUFBTyxXQUFVLDJCQUEwQixTQUFTLE1BQU1JLGVBQWVKLEdBQUd6SCxFQUFFLEdBQUcsT0FBTSxVQUN0RixpQ0FBQyxVQUFPLE1BQU0sTUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpQixLQURuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFPQSxJQUVBLHVCQUFDLFVBQUssT0FBTyxFQUFFMEMsT0FBTyxXQUFXMkgsVUFBVSxXQUFXQyxZQUFZLElBQUksR0FBRyx5QkFBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0YsS0FadEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFjQTtBQUFBLG1CQXpDTzdDLEdBQUd6SCxJQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBMENBO0FBQUEsWUFDRCxLQXBETDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXFEQTtBQUFBLGVBbEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUVBLEtBcEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcUVBO0FBQUEsYUFwR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXFHQTtBQUFBLFFBTURwQixjQUFjLGNBQ2IsbUNBRUU7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsc0JBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsb0JBQW1CLE9BQU8sRUFBRXdMLFlBQVksV0FBVzFILE9BQU8sVUFBVSxHQUNqRixpQ0FBQyxjQUFXLE1BQU0sTUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUIsS0FEdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsU0FDQztBQUFBLHVDQUFDLFNBQUksV0FBVSxpQkFBZ0IsMEJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlDO0FBQUEsZ0JBQ3pDLHVCQUFDLFNBQUksV0FBVSxlQUFjO0FBQUE7QUFBQSxrQkFBR2xCLE1BQU1nSyxPQUFPLENBQUNDLEtBQUtqRCxNQUFNaUQsTUFBTWpELEVBQUU5RyxTQUFTLENBQUMsRUFBRzJGLGVBQWU7QUFBQSxxQkFBN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0Y7QUFBQSxtQkFGakc7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGlCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxvQkFBbUIsT0FBTyxFQUFFK0MsWUFBWSxXQUFXMUgsT0FBTyxVQUFVLEdBQ2pGLGlDQUFDLGNBQVcsTUFBTSxNQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxQixLQUR2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxTQUNDO0FBQUEsdUNBQUMsU0FBSSxXQUFVLGlCQUFnQiw2QkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNEM7QUFBQSxnQkFDNUMsdUJBQUMsU0FBSSxXQUFVLGVBQWMsc0JBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW1DO0FBQUEsbUJBRnJDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxpQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsb0JBQW1CLE9BQU8sRUFBRTBILFlBQVksV0FBVzFILE9BQU8sVUFBVSxHQUNqRixpQ0FBQyxjQUFXLE1BQU0sTUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUIsS0FEdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsU0FDQztBQUFBLHVDQUFDLFNBQUksV0FBVSxpQkFBZ0IsOEJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZDO0FBQUEsZ0JBQzdDLHVCQUFDLFNBQUksV0FBVSxlQUFlbEI7QUFBQUEsd0JBQU1zRjtBQUFBQSxrQkFBTztBQUFBLHFCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrRDtBQUFBLG1CQUZwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsaUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLGVBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBOEJBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUseUJBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxrQkFDYixpQ0FBQyxRQUFHLFdBQVUsaUJBQWdCLCtCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2QyxLQUQvQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2IsaUNBQUMsV0FBTSxXQUFVLGdCQUNmO0FBQUEsdUNBQUMsV0FDQyxpQ0FBQyxRQUNDO0FBQUEseUNBQUMsUUFBRywyQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFlO0FBQUEsa0JBQ2YsdUJBQUMsUUFBRyxvQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFRO0FBQUEsa0JBQ1IsdUJBQUMsUUFBRyxzQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFVO0FBQUEsa0JBQ1YsdUJBQUMsUUFBRyxzQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFVO0FBQUEscUJBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBT0E7QUFBQSxnQkFDQSx1QkFBQyxXQUNFaEYsdUJBQ0VrRyxPQUFPLENBQUFQLE9BQU1BLEdBQUd0SCxTQUFTLFFBQVEsRUFDakMwSixNQUFNLEdBQUcsQ0FBQyxFQUNWcko7QUFBQUEsa0JBQUksQ0FBQ2lILE9BQ0osdUJBQUMsUUFDQztBQUFBLDJDQUFDLFFBQUlBLGFBQUd6RixRQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWE7QUFBQSxvQkFDYix1QkFBQyxRQUFHLE9BQU8sRUFBRVUsT0FBTyxVQUFVLEdBQUkrRSxhQUFHeEYsUUFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBMEM7QUFBQSxvQkFDMUMsdUJBQUMsUUFBSXdGLGFBQUd2RixVQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWU7QUFBQSxvQkFDZix1QkFBQyxRQUFHLE9BQU8sRUFBRVEsT0FBTyxrQkFBa0I0SCxZQUFZLE1BQU0sR0FBRTtBQUFBO0FBQUEsc0JBQ3JEN0MsR0FBR3JGLE9BQU9pRixlQUFlO0FBQUEseUJBRDlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFOT0ksR0FBR3pILElBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFPQTtBQUFBLGdCQUNELEtBYkw7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFjQTtBQUFBLG1CQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXdCQSxLQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTBCQTtBQUFBLGlCQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQStCQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsa0JBQ2IsaUNBQUMsUUFBRyxXQUFVLGlCQUFnQixnQ0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEMsS0FEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQVEsT0FBTyxFQUFFbUssU0FBUyxRQUFRdUIsZ0JBQWdCLGVBQWUsR0FDOUU7QUFBQSx1Q0FBQyxTQUNDO0FBQUEseUNBQUMsU0FBSSxPQUFPLEVBQUVyQixVQUFVLFdBQVczSCxPQUFPLFVBQVUsR0FBRywrQkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBc0U7QUFBQSxrQkFDdEUsdUJBQUMsU0FBSSxPQUFPLEVBQUUySCxVQUFVLFdBQVdDLFlBQVksS0FBSzVILE9BQU8sa0JBQWtCd0gsV0FBVyxVQUFVLEdBQUcsdUJBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTRHO0FBQUEscUJBRjlHO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxnQkFDQSx1QkFBQyxTQUNDO0FBQUEseUNBQUMsU0FBSSxPQUFPLEVBQUVHLFVBQVUsV0FBVzNILE9BQU8sVUFBVSxHQUFHLGtDQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF5RTtBQUFBLGtCQUN6RSx1QkFBQyxTQUFJLE9BQU8sRUFBRTJILFVBQVUsV0FBV0MsWUFBWSxLQUFLNUgsT0FBTyxnQkFBZ0J3SCxXQUFXLFVBQVUsR0FBRyxxQkFBbkc7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBd0c7QUFBQSxxQkFGMUc7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLG1CQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBU0E7QUFBQSxpQkFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWNBO0FBQUEsZUFqREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrREE7QUFBQSxhQXJGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBc0ZBO0FBQUEsUUFNRHRMLGNBQWMsaUJBQ2IsbUNBQ0U7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsc0JBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsb0JBQW1CLE9BQU8sRUFBRXdMLFlBQVksV0FBVzFILE9BQU8sVUFBVSxHQUNqRixpQ0FBQyxhQUFVLE1BQU0sTUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0IsS0FEdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsU0FDQztBQUFBLHVDQUFDLFNBQUksV0FBVSxpQkFBZ0IsMkJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBDO0FBQUEsZ0JBQzFDLHVCQUFDLFNBQUksV0FBVSxlQUFjLHVCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvQztBQUFBLG1CQUZ0QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsaUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLG9CQUFtQixPQUFPLEVBQUUwSCxZQUFZLFdBQVcxSCxPQUFPLFVBQVUsR0FDakYsaUNBQUMsY0FBVyxNQUFNLE1BQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFCLEtBRHZCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFNBQ0M7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsaUJBQWdCLDBCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5QztBQUFBLGdCQUN6Qyx1QkFBQyxTQUFJLFdBQVUsZUFBYywrQkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNEM7QUFBQSxtQkFGOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGlCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxvQkFBbUIsT0FBTyxFQUFFMEgsWUFBWSxXQUFXMUgsT0FBTyxVQUFVLEdBQ2pGLGlDQUFDLFlBQVMsTUFBTSxNQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtQixLQURyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxTQUNDO0FBQUEsdUNBQUMsU0FBSSxXQUFVLGlCQUFnQiw0QkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkM7QUFBQSxnQkFDM0MsdUJBQUMsU0FBSSxXQUFVLGVBQWMsd0JBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFDO0FBQUEsbUJBRnZDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxpQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsZUEzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE0QkE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSx5QkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLGtCQUNiLGlDQUFDLFFBQUcsV0FBVSxpQkFBZ0IsNEJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBDLEtBRDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxTQUFRLE9BQU8sRUFBRW9ILFFBQVEsUUFBUSxHQUM5QyxpQ0FBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLDJDQUFDLFNBQUksV0FBVSxzQkFBcUIsT0FBTyxFQUFFTSxZQUFZLFVBQVUsR0FBRyxpQkFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBdUU7QUFBQSxvQkFDdkUsdUJBQUMsU0FDQztBQUFBLDZDQUFDLFNBQUksV0FBVSxlQUFjLDBCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF1QztBQUFBLHNCQUN2Qyx1QkFBQyxTQUFJLFdBQVUsY0FBYSw2QkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBeUM7QUFBQSx5QkFGM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFHQTtBQUFBLHVCQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBTUE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSwyQ0FBQyxTQUFJLFdBQVUsZUFBYyx1QkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBb0M7QUFBQSxvQkFDcEMsdUJBQUMsU0FBSSxXQUFVLGlDQUFnQyxzQkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBcUQ7QUFBQSx1QkFGdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLHFCQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBWUE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSwyQ0FBQyxTQUFJLFdBQVUsc0JBQXFCLE9BQU8sRUFBRUEsWUFBWSxVQUFVLEdBQUcsaUJBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXVFO0FBQUEsb0JBQ3ZFLHVCQUFDLFNBQ0M7QUFBQSw2Q0FBQyxTQUFJLFdBQVUsZUFBYywwQkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBdUM7QUFBQSxzQkFDdkMsdUJBQUMsU0FBSSxXQUFVLGNBQWEsNkJBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXlDO0FBQUEseUJBRjNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBR0E7QUFBQSx1QkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU1BO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsMkNBQUMsU0FBSSxXQUFVLGVBQWMsdUJBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW9DO0FBQUEsb0JBQ3BDLHVCQUFDLFNBQUksV0FBVSxpQ0FBZ0Msc0JBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXFEO0FBQUEsdUJBRnZEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxxQkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVlBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsMkNBQUMsU0FBSSxXQUFVLHNCQUFxQixPQUFPLEVBQUVBLFlBQVksVUFBVSxHQUFHLGlCQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF1RTtBQUFBLG9CQUN2RSx1QkFBQyxTQUNDO0FBQUEsNkNBQUMsU0FBSSxXQUFVLGVBQWMsNkJBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTBDO0FBQUEsc0JBQzFDLHVCQUFDLFNBQUksV0FBVSxjQUFhLDhCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUEwQztBQUFBLHlCQUY1QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUdBO0FBQUEsdUJBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFNQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLDJDQUFDLFNBQUksV0FBVSxlQUFjLHVCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFvQztBQUFBLG9CQUNwQyx1QkFBQyxTQUFJLFdBQVUsaUNBQWdDLHNCQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFxRDtBQUFBLHVCQUZ2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEscUJBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFZQTtBQUFBLG1CQXZDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXdDQSxLQXpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTBDQTtBQUFBLGlCQTlDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQStDQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsa0JBQ2IsaUNBQUMsUUFBRyxXQUFVLGlCQUFnQix1Q0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUQsS0FEdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQVEsT0FBTyxFQUFFTixRQUFRLFNBQVNDLFNBQVMsUUFBUXNCLFlBQVksVUFBVUssZ0JBQWdCLFNBQVMsR0FDL0csaUNBQUMsU0FBSSxPQUFNLE9BQU0sUUFBTyxPQUFNLFNBQVEsZUFDcEM7QUFBQSx1Q0FBQyxVQUFLLEdBQUUsOERBQTZELE1BQUssUUFBTyxRQUFPLHlCQUF3QixhQUFZLEtBQUksZUFBYyxXQUE5STtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxSjtBQUFBLGdCQUNySix1QkFBQyxZQUFPLElBQUcsT0FBTSxJQUFHLE1BQUssR0FBRSxLQUFJLE1BQUsseUJBQXdCLFFBQU8sV0FBVSxhQUFZLE9BQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTRGO0FBQUEsZ0JBQzVGLHVCQUFDLFVBQUssR0FBRSxNQUFLLEdBQUUsT0FBTSxNQUFLLFdBQVUsVUFBUyxNQUFLLG9CQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzRDtBQUFBLGdCQUN0RCx1QkFBQyxVQUFLLEdBQUUsT0FBTSxHQUFFLE9BQU0sTUFBSyxXQUFVLFVBQVMsTUFBSyxZQUFXLE9BQU0sb0JBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXdFO0FBQUEsbUJBSjFFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU9BO0FBQUEsaUJBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFZQTtBQUFBLGVBOURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBK0RBO0FBQUEsYUE5RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQStGQTtBQUFBLFFBTUQ5TSxjQUFjLGtCQUNiLHVCQUFDLFNBQUksV0FBVSx5QkFFYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGtCQUNiLGlDQUFDLFFBQUcsV0FBVSxpQkFBZ0Isd0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNDLEtBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFbUwsU0FBUyxRQUFRQyxxQkFBcUIseUNBQXlDQyxLQUFLLFNBQVMsR0FDeEd6SSxnQkFBTWhCO0FBQUFBLGNBQUksQ0FBQzhILFNBQ1YsdUJBQUMsU0FBa0IsV0FBVyxlQUFlQSxLQUFLbkksSUFBSSxJQUFJLE9BQU8sRUFBRW1MLE9BQU8sT0FBTyxHQUU5RWpPO0FBQUFBLDRCQUFZSyxhQUFhRyxnQkFDeEIsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEseUNBQUMsWUFBTyxXQUFVLGlCQUFnQixTQUFTLE1BQU13SyxrQkFBa0JDLElBQUksR0FBRyxPQUFNLGFBQzlFLGlDQUFDLFNBQU0sTUFBTSxNQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdCLEtBRGxCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxZQUFPLFdBQVUsaUJBQWdCLFNBQVMsTUFBTUcsaUJBQWlCSCxLQUFLdEksRUFBRSxHQUFHLE9BQU0sZUFDaEYsaUNBQUMsVUFBTyxNQUFNLE1BQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUIsS0FEbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBT0E7QUFBQSxnQkFHRix1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSx5Q0FBQyxTQUNDO0FBQUEsMkNBQUMsU0FBSSxXQUFVLGNBQWEsdUJBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW1DO0FBQUEsb0JBQ25DLHVCQUFDLFNBQUksV0FBVSxnQkFBZTtBQUFBO0FBQUEsc0JBQUVzSSxLQUFLNUcsUUFBUTJGLGVBQWU7QUFBQSx5QkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBOEQ7QUFBQSx1QkFGaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLEtBQUtpQixLQUFLbkksU0FBUyxVQUFVLGtEQUFrRDtBQUFBLHNCQUMvRSxLQUFJO0FBQUEsc0JBQ0osV0FBVTtBQUFBO0FBQUEsb0JBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUd1QjtBQUFBLHFCQVJ6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLG9CQUNiO0FBQUEsMkNBQUMsU0FBSSxXQUFVLGNBQWEsMkJBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXVDO0FBQUEsb0JBQ3ZDLHVCQUFDLFNBQUksV0FBVSxjQUFjbUksZUFBSzNHLFVBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXlDO0FBQUEsdUJBRjNDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsb0JBQ2I7QUFBQSwyQ0FBQyxTQUFJLFdBQVUsY0FBYSwwQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBc0M7QUFBQSxvQkFDdEMsdUJBQUMsU0FBSSxXQUFVLGNBQWMyRyxlQUFLekcsVUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBeUM7QUFBQSx1QkFGM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLHFCQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBU0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsZUFBZXlHLGVBQUsxRyxVQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEwQztBQUFBLGtCQUMxQyx1QkFBQyxTQUFJLFdBQVUsYUFBWSxPQUFNLE1BQUssUUFBTyxNQUFLLFNBQVEsYUFBWSxNQUFLLFFBQU8sT0FBTSw4QkFDdEY7QUFBQSwyQ0FBQyxZQUFPLElBQUcsTUFBSyxJQUFHLE1BQUssR0FBRSxNQUFLLE1BQU0wRyxLQUFLbkksU0FBUyxVQUFVLFlBQVksU0FBUyxhQUFZLFNBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW1HO0FBQUEsb0JBQ25HLHVCQUFDLFlBQU8sSUFBRyxNQUFLLElBQUcsTUFBSyxHQUFFLE1BQUssTUFBTW1JLEtBQUtuSSxTQUFTLFVBQVUsWUFBWSxTQUFTLGFBQVksU0FBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBbUc7QUFBQSx1QkFGckc7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLHFCQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBTUE7QUFBQSxtQkF4Q1FtSSxLQUFLdEksSUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXlDQTtBQUFBLFlBQ0QsS0E1Q0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE2Q0E7QUFBQSxlQWpERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtEQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsa0JBQ2IsaUNBQUMsUUFBRyxXQUFVLGlCQUFnQiw0QkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEMsS0FENUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQVEsT0FBTyxFQUFFMkwsV0FBVyxRQUFRLEdBQ2hEO0FBQUEsZUFBQ3RPLFlBQVlLLGFBQWFHLGdCQUN6Qix1QkFBQyxTQUFJLE9BQU8sRUFBRTZFLE9BQU8sZ0JBQWdCMEgsWUFBWSwyQkFBMkJTLFFBQVEsb0NBQW9DVixTQUFTLFdBQVdRLGNBQWMsUUFBUU4sVUFBVSxXQUFXQyxZQUFZLEtBQUtTLGNBQWMsUUFBUUgsV0FBVyxTQUFTLEdBQUUscURBQXBQO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUVGLHVCQUFDLFVBQUssVUFBVTNDLGVBQWUsV0FBVSxpQkFBZ0IsT0FBTyxDQUFDNUssWUFBWUssYUFBYUcsZUFBZSxFQUFFMk0sU0FBUyxJQUFJLElBQUksQ0FBQyxHQUMzSDtBQUFBLHVDQUFDLFNBQUksV0FBVSx3QkFBdUIsT0FBTyxFQUFFb0IsWUFBWSxTQUFTLEdBQ2xFO0FBQUEseUNBQUMsV0FBTSxnQ0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1QjtBQUFBLGtCQUN2QjtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsV0FBVTtBQUFBLHNCQUNWLGFBQVk7QUFBQSxzQkFDWixPQUFPbEgsWUFBWS9DO0FBQUFBLHNCQUNuQixVQUFVLENBQUM4RSxNQUFNOUIsZUFBZSxFQUFFLEdBQUdELGFBQWEvQyxRQUFROEUsRUFBRWtELE9BQU9DLE1BQU0sQ0FBQztBQUFBLHNCQUMxRSxVQUFVLENBQUN2TSxZQUFZSyxhQUFhRztBQUFBQTtBQUFBQSxvQkFOdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU1tRDtBQUFBLHFCQVJyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEseUNBQUMsV0FBTSxvQ0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyQjtBQUFBLGtCQUMzQjtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsV0FBVTtBQUFBLHNCQUNWLGFBQVk7QUFBQSxzQkFDWixPQUFPNkcsWUFBWWhEO0FBQUFBLHNCQUNuQixVQUFVLENBQUMrRSxNQUFNOUIsZUFBZSxFQUFFLEdBQUdELGFBQWFoRCxTQUFTK0UsRUFBRWtELE9BQU9DLE1BQU0sQ0FBQztBQUFBLHNCQUMzRSxVQUFVLENBQUN2TSxZQUFZSyxhQUFhRztBQUFBQTtBQUFBQSxvQkFOdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU1tRDtBQUFBLHFCQVJyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEseUNBQUMsV0FBTSwyQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFrQjtBQUFBLGtCQUNsQjtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsV0FBVTtBQUFBLHNCQUNWLGFBQVk7QUFBQSxzQkFDWixXQUFVO0FBQUEsc0JBQ1YsT0FBTzZHLFlBQVk3QztBQUFBQSxzQkFDbkIsVUFBVSxDQUFDNEUsTUFBTTlCLGVBQWUsRUFBRSxHQUFHRCxhQUFhN0MsUUFBUTRFLEVBQUVrRCxPQUFPQyxNQUFNLENBQUM7QUFBQSxzQkFDMUUsVUFBVSxDQUFDdk0sWUFBWUssYUFBYUc7QUFBQUE7QUFBQUEsb0JBUHRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFPbUQ7QUFBQSxxQkFUckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFXQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLHlDQUFDLFdBQU0sdUNBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBOEI7QUFBQSxrQkFDOUI7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFdBQVU7QUFBQSxzQkFDVixhQUFZO0FBQUEsc0JBQ1osV0FBVTtBQUFBLHNCQUNWLE9BQU82RyxZQUFZOUM7QUFBQUEsc0JBQ25CLFVBQVUsQ0FBQzZFLE1BQU05QixlQUFlLEVBQUUsR0FBR0QsYUFBYTlDLFFBQVE2RSxFQUFFa0QsT0FBT0MsTUFBTSxDQUFDO0FBQUEsc0JBQzFFLFVBQVUsQ0FBQ3ZNLFlBQVlLLGFBQWFHO0FBQUFBO0FBQUFBLG9CQVB0QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBT21EO0FBQUEscUJBVHJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBV0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSx5Q0FBQyxXQUFNLGdDQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVCO0FBQUEsa0JBQ3ZCO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVU7QUFBQSxzQkFDVixPQUFPNkcsWUFBWXZFO0FBQUFBLHNCQUNuQixVQUFVLENBQUNzRyxNQUFNOUIsZUFBZSxFQUFFLEdBQUdELGFBQWF2RSxNQUFNc0csRUFBRWtELE9BQU9DLE1BQU0sQ0FBQztBQUFBLHNCQUN4RSxVQUFVLENBQUN2TSxZQUFZSyxhQUFhRztBQUFBQSxzQkFFcEM7QUFBQSwrQ0FBQyxZQUFPLE9BQU0sUUFBTyw2QkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBa0M7QUFBQSx3QkFDbEMsdUJBQUMsWUFBTyxPQUFNLFNBQVEsNEJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWtDO0FBQUEsd0JBQ2xDLHVCQUFDLFlBQU8sT0FBTSxTQUFRLDZCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFtQztBQUFBLHdCQUNuQyx1QkFBQyxZQUFPLE9BQU0sVUFBUyw0QkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBbUM7QUFBQTtBQUFBO0FBQUEsb0JBVHJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFVQTtBQUFBLHFCQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBYUE7QUFBQSxnQkFDQSx1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLGdCQUFlLFVBQVUsQ0FBQ1IsWUFBWUssYUFBYUcsY0FBYyxPQUFPLENBQUNSLFlBQVlLLGFBQWFHLGVBQWUsRUFBRTJNLFNBQVMsS0FBS0MsUUFBUSxlQUFlQyxlQUFlLE9BQU8sSUFBSSxDQUFDLEdBQUUsa0NBQXJOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkEvREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFnRUE7QUFBQSxpQkF0RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF1RUE7QUFBQSxlQTNFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTRFQTtBQUFBLGFBbklGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvSUE7QUFBQSxRQU1EOUwsY0FBYyxXQUNiLHVCQUFDLFNBQUksV0FBVSx5QkFFYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGtCQUNiLGlDQUFDLFFBQUcsV0FBVSxpQkFBZ0IsNEJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBDLEtBRDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDYixpQ0FBQyxXQUFNLFdBQVUsZ0JBQ2Y7QUFBQSxxQ0FBQyxXQUNDLGlDQUFDLFFBQ0M7QUFBQSx1Q0FBQyxRQUFHLHVCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQVc7QUFBQSxnQkFDWCx1QkFBQyxRQUFHLHlCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWE7QUFBQSxnQkFDYix1QkFBQyxRQUFHLGdDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW9CO0FBQUEsZ0JBQ3BCLHVCQUFDLFFBQUcsbUNBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUI7QUFBQSxnQkFDdkIsdUJBQUMsUUFBRywyQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFlO0FBQUEsZ0JBQ2YsdUJBQUMsUUFBRyx5QkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFhO0FBQUEsbUJBTmY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBU0E7QUFBQSxjQUNBLHVCQUFDLFdBQ0VpRSxnQkFBTXJDO0FBQUFBLGdCQUFJLENBQUNxTCxTQUNWLHVCQUFDLFFBQ0M7QUFBQSx5Q0FBQyxRQUFHLE9BQU8sRUFBRW5KLE9BQU8sVUFBVSxHQUFJbUosZUFBSzdMLE1BQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTBDO0FBQUEsa0JBQzFDLHVCQUFDLFFBQUcsT0FBTyxFQUFFc0ssWUFBWSxNQUFNLEdBQUl1QixlQUFLMUwsUUFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNkM7QUFBQSxrQkFDN0MsdUJBQUMsUUFBRztBQUFBO0FBQUEsb0JBQUUwTCxLQUFLekosT0FBT2lGLGVBQWU7QUFBQSx1QkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBbUM7QUFBQSxrQkFDbkMsdUJBQUMsUUFBRztBQUFBO0FBQUEsb0JBQUV3RSxLQUFLbkssUUFBUTJGLGVBQWU7QUFBQSx1QkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBb0M7QUFBQSxrQkFDcEMsdUJBQUMsUUFBRyxPQUFPLEVBQUUzRSxPQUFPLGVBQWUsR0FBRztBQUFBO0FBQUEsb0JBQUVtSixLQUFLOUk7QUFBQUEsb0JBQVk7QUFBQSx1QkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNEQ7QUFBQSxrQkFDNUQsdUJBQUMsUUFBSThJLGVBQUs3SSxZQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW1CO0FBQUEscUJBTlo2SSxLQUFLN0wsSUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU9BO0FBQUEsY0FDRCxLQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBV0E7QUFBQSxpQkF0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF1QkEsS0F4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF5QkE7QUFBQSxlQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQThCQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsa0JBQ2IsaUNBQUMsUUFBRyxXQUFVLGlCQUFnQiwrQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkMsS0FEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQVEsT0FBTyxFQUFFMkwsV0FBVyxRQUFRLEdBQ2pELGlDQUFDLFVBQUssVUFBVWhELGVBQWUsT0FBTyxFQUFFb0IsU0FBUyxRQUFRK0IsZUFBZSxVQUFVN0IsS0FBSyxRQUFRTyxTQUFTLENBQUNuTixZQUFZSyxhQUFhSSxlQUFlLE1BQU0sRUFBRSxHQUN0SjtBQUFBLGVBQUNULFlBQVlLLGFBQWFJLGdCQUN6Qix1QkFBQyxTQUFJLE9BQU8sRUFBRTRFLE9BQU8sZ0JBQWdCMEgsWUFBWSwyQkFBMkJTLFFBQVEsb0NBQW9DVixTQUFTLFVBQVVRLGNBQWMsUUFBUU4sVUFBVSxVQUFVQyxZQUFZLEtBQUtNLFdBQVcsU0FBUyxHQUFFLCtDQUE1TjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FFRix1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSx1Q0FBQyxXQUFNLG9DQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJCO0FBQUEsZ0JBQzNCO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxXQUFVO0FBQUEsb0JBQ1YsT0FBT2hHLFNBQVN4QztBQUFBQSxvQkFDaEIsVUFBVSxDQUFDcUUsTUFBTTVCLFlBQVksRUFBRSxHQUFHRCxVQUFVeEMsUUFBUXFFLEVBQUVrRCxPQUFPQyxNQUFNLENBQUM7QUFBQSxvQkFDcEUsVUFBVSxDQUFDdk0sWUFBWUssYUFBYUk7QUFBQUE7QUFBQUEsa0JBTHRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLbUQ7QUFBQSxtQkFQckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFTQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsdUNBQUMsV0FBTSx3Q0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUErQjtBQUFBLGdCQUMvQjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLFdBQVU7QUFBQSxvQkFDVixPQUFPOEcsU0FBU0U7QUFBQUEsb0JBQ2hCLFVBQVUsQ0FBQzJCLE1BQU01QixZQUFZLEVBQUUsR0FBR0QsVUFBVUUsTUFBTTJCLEVBQUVrRCxPQUFPQyxNQUFNLENBQUM7QUFBQSxvQkFDbEUsVUFBVSxDQUFDdk0sWUFBWUssYUFBYUk7QUFBQUE7QUFBQUEsa0JBTnRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNbUQ7QUFBQSxtQkFSckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFVQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsdUNBQUMsV0FBTSxpQ0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3QjtBQUFBLGdCQUN4QjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsV0FBVTtBQUFBLG9CQUNWLE9BQU84RyxTQUFTRztBQUFBQSxvQkFDaEIsVUFBVSxDQUFDMEIsTUFBTTVCLFlBQVksRUFBRSxHQUFHRCxVQUFVRyxNQUFNMEIsRUFBRWtELE9BQU9DLE1BQU0sQ0FBQztBQUFBLG9CQUNsRSxVQUFVLENBQUN2TSxZQUFZSyxhQUFhSTtBQUFBQTtBQUFBQSxrQkFMdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUttRDtBQUFBLG1CQVByRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVNBO0FBQUEsY0FDQSx1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLGdCQUFlLFVBQVUsQ0FBQ1QsWUFBWUssYUFBYUksY0FBYyxPQUFPLENBQUNULFlBQVlLLGFBQWFJLGVBQWUsRUFBRThOLFlBQVksVUFBVXBCLFNBQVMsS0FBS0MsUUFBUSxlQUFlQyxlQUFlLE9BQU8sSUFBSSxFQUFFa0IsWUFBWSxTQUFTLEdBQUUscUNBQWpRO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNDaEgsU0FBU0ksVUFDUix1QkFBQyxTQUFJLE9BQU8sRUFBRWtGLFdBQVcsVUFBVVUsV0FBVyxTQUFTLEdBQ3JEO0FBQUEsdUNBQUMsU0FBSSxPQUFPLEVBQUVQLFVBQVUsVUFBVTNILE9BQU8sVUFBVSxHQUFHLHFDQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyRTtBQUFBLGdCQUMzRSx1QkFBQyxTQUFJLE9BQU8sRUFBRTJILFVBQVUsVUFBVUMsWUFBWSxPQUFPNUgsT0FBTyx3QkFBd0IsR0FBRTtBQUFBO0FBQUEsa0JBQ2xGa0MsU0FBU0k7QUFBQUEsa0JBQU87QUFBQSxxQkFEcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxpQkE5Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnREEsS0FqREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFrREE7QUFBQSxlQXRERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXVEQTtBQUFBLGFBMUZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEyRkE7QUFBQSxRQU1EcEcsY0FBYyxjQUNiLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGtCQUNiLGlDQUFDLFFBQUcsV0FBVSxpQkFBZ0IsK0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZDLEtBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDWjBELG1CQUFTOUIsSUFBSSxDQUFDNEksUUFBUTtBQUNyQixrQkFBTTJDLFVBQVVuSixRQUFRd0csSUFBSXpHLFFBQVEsS0FBS3ZHO0FBQ3pDLG1CQUNFLHVCQUFDLFNBQWlCLFdBQVUsb0JBQzFCO0FBQUEscUNBQUMsU0FBSSxXQUFVLG9CQUFtQixPQUFPLEVBQUVnTyxZQUFZLEdBQUdoQixJQUFJMUcsS0FBSyxNQUFNQSxPQUFPMEcsSUFBSTFHLE1BQU0sR0FDeEYsaUNBQUMsV0FBUSxNQUFNLE1BQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0IsS0FEcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEsdUNBQUMsUUFBSTBHLGNBQUk1RyxTQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWU7QUFBQSxnQkFDZix1QkFBQyxPQUFHNEcsY0FBSXBILFFBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBYTtBQUFBLG1CQUZmO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLFNBQ0MsaUNBQUMsV0FBTSxXQUFVLGdCQUFlLE9BQU8sRUFBRTBJLGVBQWVyTixZQUFZSyxhQUFhSyxrQkFBa0IsU0FBUyxRQUFReU0sU0FBU25OLFlBQVlLLGFBQWFLLGtCQUFrQixJQUFJLElBQUksR0FDOUs7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBU3FMLElBQUkzRztBQUFBQSxvQkFDYixVQUFVLE1BQU15RyxjQUFjRSxJQUFJcEosRUFBRTtBQUFBLG9CQUNwQyxVQUFVLENBQUMzQyxZQUFZSyxhQUFhSztBQUFBQTtBQUFBQSxrQkFKdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUlzRDtBQUFBLGdCQUV0RCx1QkFBQyxVQUFLLFdBQVUsbUJBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdDO0FBQUEsbUJBUGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVVBO0FBQUEsaUJBbEJRcUwsSUFBSXBKLElBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFtQkE7QUFBQSxVQUVKLENBQUMsS0F6Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEwQkE7QUFBQSxhQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0JBO0FBQUEsUUFNRHBCLGNBQWMsbUJBQ2IsbUNBQ0U7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsc0JBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsb0JBQW1CLE9BQU8sRUFBRXdMLFlBQVksV0FBVzFILE9BQU8sVUFBVSxHQUNqRixpQ0FBQyxZQUFTLE1BQU0sTUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUIsS0FEckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsU0FDQztBQUFBLHVDQUFDLFNBQUksV0FBVSxpQkFBZ0IsNEJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJDO0FBQUEsZ0JBQzNDLHVCQUFDLFNBQUksV0FBVSxlQUFjLDJCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3QztBQUFBLG1CQUYxQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsaUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLG9CQUFtQixPQUFPLEVBQUUwSCxZQUFZLFdBQVcxSCxPQUFPLFVBQVUsR0FDakYsaUNBQUMsY0FBVyxNQUFNLE1BQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFCLEtBRHZCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFNBQ0M7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsaUJBQWdCLHFDQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvRDtBQUFBLGdCQUNwRCx1QkFBQyxTQUFJLFdBQVUsZUFBYywwQkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUM7QUFBQSxtQkFGekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGlCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxlQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1CQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLHlCQUNiLGlDQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGtCQUNiLGlDQUFDLFFBQUcsV0FBVSxpQkFBZ0IsMENBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdELEtBRDFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxTQUFRLE9BQU8sRUFBRW9ILFFBQVEsUUFBUUcsS0FBSyxVQUFVLEdBQzdEO0FBQUEscUNBQUMsU0FBSSxPQUFPLEVBQUVGLFNBQVMsUUFBUUUsS0FBSyxVQUFVZSxjQUFjLGlDQUFpQ2dCLGVBQWUsT0FBTyxHQUNqSDtBQUFBLHVDQUFDLFNBQUksT0FBTyxFQUFFNUIsWUFBWSwyQkFBMkJPLGNBQWMsT0FBT1csT0FBTyxRQUFReEIsUUFBUSxRQUFRQyxTQUFTLFFBQVFzQixZQUFZLFVBQVVLLGdCQUFnQixVQUFVaEosT0FBTyx5QkFBeUI0SCxZQUFZLE1BQU0sR0FBRyxpQkFBL047QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ087QUFBQSxnQkFDaE8sdUJBQUMsU0FDQztBQUFBLHlDQUFDLFFBQUcsT0FBTyxFQUFFNUgsT0FBTyx1QkFBdUI0SCxZQUFZLElBQUksR0FBRyxtQ0FBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUY7QUFBQSxrQkFDakYsdUJBQUMsT0FBRSxPQUFPLEVBQUU1SCxPQUFPLHlCQUF5QjJILFVBQVUsV0FBV0gsV0FBVyxTQUFTLEdBQUcsOEZBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXNLO0FBQUEscUJBRnhLO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxtQkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU1BO0FBQUEsY0FDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRUgsU0FBUyxRQUFRRSxLQUFLLFVBQVVlLGNBQWMsaUNBQWlDZ0IsZUFBZSxPQUFPLEdBQ2pIO0FBQUEsdUNBQUMsU0FBSSxPQUFPLEVBQUU1QixZQUFZLDJCQUEyQk8sY0FBYyxPQUFPVyxPQUFPLFFBQVF4QixRQUFRLFFBQVFDLFNBQVMsUUFBUXNCLFlBQVksVUFBVUssZ0JBQWdCLFVBQVVoSixPQUFPLHlCQUF5QjRILFlBQVksTUFBTSxHQUFHLGlCQUEvTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnTztBQUFBLGdCQUNoTyx1QkFBQyxTQUNDO0FBQUEseUNBQUMsUUFBRyxPQUFPLEVBQUU1SCxPQUFPLHVCQUF1QjRILFlBQVksSUFBSSxHQUFHLGdDQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE4RTtBQUFBLGtCQUM5RSx1QkFBQyxPQUFFLE9BQU8sRUFBRTVILE9BQU8seUJBQXlCMkgsVUFBVSxXQUFXSCxXQUFXLFNBQVMsR0FBRyxrRkFBeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMEo7QUFBQSxxQkFGNUo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLG1CQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFSCxTQUFTLFFBQVFFLEtBQUssU0FBUyxHQUMzQztBQUFBLHVDQUFDLFNBQUksT0FBTyxFQUFFRyxZQUFZLDJCQUEyQk8sY0FBYyxPQUFPVyxPQUFPLFFBQVF4QixRQUFRLFFBQVFDLFNBQVMsUUFBUXNCLFlBQVksVUFBVUssZ0JBQWdCLFVBQVVoSixPQUFPLHlCQUF5QjRILFlBQVksTUFBTSxHQUFHLGlCQUEvTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnTztBQUFBLGdCQUNoTyx1QkFBQyxTQUNDO0FBQUEseUNBQUMsUUFBRyxPQUFPLEVBQUU1SCxPQUFPLHVCQUF1QjRILFlBQVksSUFBSSxHQUFHLHFDQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFtRjtBQUFBLGtCQUNuRix1QkFBQyxPQUFFLE9BQU8sRUFBRTVILE9BQU8seUJBQXlCMkgsVUFBVSxXQUFXSCxXQUFXLFNBQVMsR0FBRyxtR0FBeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMks7QUFBQSxxQkFGN0s7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLG1CQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTUE7QUFBQSxpQkFyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFzQkE7QUFBQSxlQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTJCQSxLQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTZCQTtBQUFBLGFBbkRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvREE7QUFBQSxRQU1EdEwsY0FBYyxhQUNiLHVCQUFDLFNBQUksV0FBVSxVQUNiLGlDQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVyxnQkFBZ0JJLG1CQUFtQixpQkFBaUIsV0FBVyxFQUFFO0FBQUEsZ0JBQzVFLFNBQVMsTUFBTUMsa0JBQWtCLGNBQWM7QUFBQSxnQkFBRTtBQUFBO0FBQUEsY0FGbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVyxnQkFBZ0JELG1CQUFtQixlQUFlLFdBQVcsRUFBRTtBQUFBLGdCQUMxRSxTQUFTLE1BQU1DLGtCQUFrQixZQUFZO0FBQUEsZ0JBQUU7QUFBQTtBQUFBLGNBRmpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVcsZ0JBQWdCRCxtQkFBbUIsYUFBYSxXQUFXLEVBQUU7QUFBQSxnQkFDeEUsU0FBUyxNQUFNQyxrQkFBa0IsVUFBVTtBQUFBLGdCQUFFO0FBQUE7QUFBQSxjQUYvQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLGVBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsVUFHQ0QsbUJBQW1CLGtCQUNsQix1QkFBQyxTQUFJLFdBQVUsNEJBRWI7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsdUJBQXNCLFNBQVMsTUFBTTtBQUNsRCxzQkFBTWlOLFlBQVlDLE9BQU8sdUNBQXVDbkwsWUFBWTlELE1BQU07QUFDbEYsb0JBQUlnUDtBQUFXakwsaUNBQWUsRUFBRSxHQUFHRCxhQUFhOUQsUUFBUWdQLFVBQVUsQ0FBQztBQUFBLGNBQ3JFLEdBQ0U7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxLQUFLbEwsWUFBWTlEO0FBQUFBLG9CQUNqQixLQUFJO0FBQUEsb0JBQ0osV0FBVTtBQUFBO0FBQUEsa0JBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUc2QjtBQUFBLGdCQUU3Qix1QkFBQyxTQUFJLFdBQVUscUJBQ2IsaUNBQUMsU0FBSSxPQUFNLE1BQUssUUFBTyxNQUFLLFNBQVEsYUFBWSxNQUFLLFFBQU8sUUFBTyxnQkFBZSxhQUFZLE9BQzVGLGlDQUFDLFVBQUssR0FBRSxxRUFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5RSxLQUQzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQTtBQUFBLG1CQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBY0E7QUFBQSxjQUNBLHVCQUFDLFVBQUssT0FBTyxFQUFFb04sVUFBVSxXQUFXM0gsT0FBTyx5QkFBeUJ3SCxXQUFXLFdBQVdJLFlBQVksSUFBSSxHQUFHLHFDQUE3RztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrSTtBQUFBLGlCQWhCcEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpQkE7QUFBQSxZQUdBLHVCQUFDLFVBQUssVUFBVWpCLG1CQUFtQixXQUFVLGlCQUMzQztBQUFBLHFDQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLHVDQUFDLFdBQU0seUJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0I7QUFBQSxnQkFDaEI7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFdBQVU7QUFBQSxvQkFDVixPQUFPdEksWUFBWWhFO0FBQUFBLG9CQUNuQixVQUFVLENBQUMwSixNQUFNekYsZUFBZSxFQUFFLEdBQUdELGFBQWFoRSxNQUFNMEosRUFBRWtELE9BQU9DLE1BQU0sQ0FBQztBQUFBO0FBQUEsa0JBSjFFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFJNEU7QUFBQSxtQkFOOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFRQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsdUNBQUMsV0FBTSw2QkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvQjtBQUFBLGdCQUNwQjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsV0FBVTtBQUFBLG9CQUNWLE9BQU83SSxZQUFZdEQ7QUFBQUEsb0JBQ25CLFVBQVUsQ0FBQ2dKLE1BQU16RixlQUFlLEVBQUUsR0FBR0QsYUFBYXRELE9BQU9nSixFQUFFa0QsT0FBT0MsTUFBTSxDQUFDO0FBQUE7QUFBQSxrQkFKM0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUk2RTtBQUFBLG1CQU4vRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVFBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSx1Q0FBQyxXQUFNLDRCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW1CO0FBQUEsZ0JBQ25CO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxXQUFVO0FBQUEsb0JBQ1YsT0FBTzdJLFlBQVlIO0FBQUFBLG9CQUNuQixVQUFVLENBQUM2RixNQUFNekYsZUFBZSxFQUFFLEdBQUdELGFBQWFILE9BQU82RixFQUFFa0QsT0FBT0MsTUFBTSxDQUFDO0FBQUE7QUFBQSxrQkFKM0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUk2RTtBQUFBLG1CQU4vRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVFBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSx1Q0FBQyxXQUFNLDZCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW9CO0FBQUEsZ0JBQ3BCO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxXQUFVO0FBQUEsb0JBQ1YsT0FBTzdJLFlBQVlGO0FBQUFBLG9CQUNuQixVQUFVLENBQUM0RixNQUFNekYsZUFBZSxFQUFFLEdBQUdELGFBQWFGLEtBQUs0RixFQUFFa0QsT0FBT0MsTUFBTSxDQUFDO0FBQUE7QUFBQSxrQkFKekU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUkyRTtBQUFBLG1CQU43RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVFBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsd0JBQXVCLE9BQU8sRUFBRWdDLFlBQVksU0FBUyxHQUNsRTtBQUFBLHVDQUFDLFdBQU0sdUJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBYztBQUFBLGdCQUNkO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxXQUFVO0FBQUEsb0JBQ1YsT0FBTzdLLFlBQVlEO0FBQUFBLG9CQUNuQixVQUFVLENBQUMyRixNQUFNekYsZUFBZSxFQUFFLEdBQUdELGFBQWFELFNBQVMyRixFQUFFa0QsT0FBT0MsTUFBTSxDQUFDO0FBQUE7QUFBQSxrQkFKN0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUkrRTtBQUFBLG1CQU5qRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVFBO0FBQUEsY0FDQSx1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLHFCQUFtQixvQ0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQWhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlEQTtBQUFBLGVBdkVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBd0VBO0FBQUEsVUFJRDVLLG1CQUFtQixnQkFDbEIsdUJBQUMsU0FBSSxXQUFVLDRCQUNiLGlDQUFDLFVBQUssVUFBVSxDQUFDeUgsTUFBTTtBQUFFQSxjQUFFQyxlQUFlO0FBQUduRiwrQkFBbUIsb0JBQW9CO0FBQUcrRix1QkFBVyxNQUFNL0YsbUJBQW1CLEVBQUUsR0FBRyxHQUFJO0FBQUEsVUFBRyxHQUFHLFdBQVUsaUJBQ2xKO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEscUNBQUMsV0FBTSxnQ0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1QjtBQUFBLGNBQ3ZCLHVCQUFDLFlBQU8sV0FBVSx1QkFDaEI7QUFBQSx1Q0FBQyxZQUFPLE9BQU0sT0FBTSxtQ0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUM7QUFBQSxnQkFDdkMsdUJBQUMsWUFBTyxPQUFNLE9BQU0sOEJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtDO0FBQUEsZ0JBQ2xDLHVCQUFDLFlBQU8sT0FBTSxPQUFNLHVDQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyQztBQUFBLG1CQUg3QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsaUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEscUNBQUMsV0FBTSxpQ0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3QjtBQUFBLGNBQ3hCLHVCQUFDLFlBQU8sV0FBVSx1QkFDaEI7QUFBQSx1Q0FBQyxZQUFPLE9BQU0sT0FBTSwwQ0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBOEM7QUFBQSxnQkFDOUMsdUJBQUMsWUFBTyxPQUFNLE9BQU0seUNBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZDO0FBQUEsZ0JBQzdDLHVCQUFDLFlBQU8sT0FBTSxPQUFNLDJDQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUErQztBQUFBLG1CQUhqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsaUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUF1QixPQUFPLEVBQUVxSyxZQUFZLFVBQVUxQixXQUFXLE9BQU8sR0FDckY7QUFBQSxxQ0FBQyxRQUFHLE9BQU8sRUFBRUcsVUFBVSxXQUFXQyxZQUFZLEtBQUs1SCxPQUFPLHVCQUF1QnFJLGNBQWMsT0FBTyxHQUFHLHdDQUF6RztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpSTtBQUFBLGNBQ2pJLHVCQUFDLFNBQUksT0FBTyxFQUFFaEIsU0FBUyxRQUFRK0IsZUFBZSxVQUFVN0IsS0FBSyxPQUFPLEdBQ2xFO0FBQUEsdUNBQUMsV0FBTSxPQUFPLEVBQUVGLFNBQVMsUUFBUXNCLFlBQVksVUFBVXBCLEtBQUssV0FBV1EsUUFBUSxXQUFXSixVQUFVLFNBQVMsR0FDM0c7QUFBQSx5Q0FBQyxXQUFNLE1BQUssWUFBVyxnQkFBYyxRQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFxQztBQUFBLGtCQUNyQyx1QkFBQyxVQUFLLG1FQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXlEO0FBQUEscUJBRjNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxnQkFDQSx1QkFBQyxXQUFNLE9BQU8sRUFBRU4sU0FBUyxRQUFRc0IsWUFBWSxVQUFVcEIsS0FBSyxXQUFXUSxRQUFRLFdBQVdKLFVBQVUsU0FBUyxHQUMzRztBQUFBLHlDQUFDLFdBQU0sTUFBSyxZQUFXLGdCQUFjLFFBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFDO0FBQUEsa0JBQ3JDLHVCQUFDLFVBQUssd0VBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBOEQ7QUFBQSxxQkFGaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLG1CQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBU0E7QUFBQSxpQkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVlBO0FBQUEsWUFDQSx1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLHFCQUFtQixnQ0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUNBLEtBbENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUNBO0FBQUEsVUFJRHJMLG1CQUFtQixjQUNsQix1QkFBQyxTQUFJLFdBQVUsNEJBQ2IsaUNBQUMsVUFBSyxVQUFVc0ssb0JBQW9CLFdBQVUsNEJBQzVDO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEscUNBQUMsV0FBTSxnQ0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1QjtBQUFBLGNBQ3ZCO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ1YsYUFBWTtBQUFBLGtCQUNaLE9BQU9ySSxhQUFhRTtBQUFBQSxrQkFDcEIsVUFBVSxDQUFDc0YsTUFBTXZGLGdCQUFnQixFQUFFLEdBQUdELGNBQWNFLFNBQVNzRixFQUFFa0QsT0FBT0MsTUFBTSxDQUFDO0FBQUE7QUFBQSxnQkFML0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS2lGO0FBQUEsaUJBUG5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBU0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLHFDQUFDLFdBQU0sNEJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUI7QUFBQSxjQUNuQjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsV0FBVTtBQUFBLGtCQUNWLGFBQVk7QUFBQSxrQkFDWixPQUFPM0ksYUFBYUc7QUFBQUEsa0JBQ3BCLFVBQVUsQ0FBQ3FGLE1BQU12RixnQkFBZ0IsRUFBRSxHQUFHRCxjQUFjRyxLQUFLcUYsRUFBRWtELE9BQU9DLE1BQU0sQ0FBQztBQUFBO0FBQUEsZ0JBTDNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUs2RTtBQUFBLGlCQVAvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVNBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSxxQ0FBQyxXQUFNLG9DQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJCO0FBQUEsY0FDM0I7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFDVixhQUFZO0FBQUEsa0JBQ1osT0FBTzNJLGFBQWFJO0FBQUFBLGtCQUNwQixVQUFVLENBQUNvRixNQUFNdkYsZ0JBQWdCLEVBQUUsR0FBR0QsY0FBY0ksU0FBU29GLEVBQUVrRCxPQUFPQyxNQUFNLENBQUM7QUFBQTtBQUFBLGdCQUwvRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLaUY7QUFBQSxpQkFQbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFTQTtBQUFBLFlBQ0EsdUJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSxxQkFBb0IsT0FBTyxFQUFFZ0MsWUFBWSxTQUFTLEdBQUUsK0JBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQWpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtDQSxLQW5DRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW9DQTtBQUFBLFVBSUR0SyxtQkFDQyx1QkFBQyxTQUFJLE9BQU87QUFBQSxZQUNWNEksV0FBVztBQUFBLFlBQ1hDLFNBQVM7QUFBQSxZQUNUQyxZQUFZO0FBQUEsWUFDWjFILE9BQU87QUFBQSxZQUNQaUksY0FBYztBQUFBLFlBQ2ROLFVBQVU7QUFBQSxZQUNWQyxZQUFZO0FBQUEsWUFDWk0sV0FBVztBQUFBLFlBQ1hDLFFBQVE7QUFBQSxZQUNSQyxXQUFXO0FBQUEsVUFDYixHQUNHeEosNkJBWkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFhQTtBQUFBLGFBbk1KO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFxTUEsS0F0TUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXVNQTtBQUFBLFFBTUQxQyxjQUFjLGtCQUNiLHVCQUFDLFNBQUksV0FBVSxVQUFTLE9BQU8sRUFBRWtNLFdBQVcsdUJBQXVCLEdBQ2pFO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsbUNBQUMsUUFBRyxXQUFVLGlCQUFnQiwwQ0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0Q7QUFBQSxZQUN2RHpOLFlBQVlMLFNBQVMsV0FDcEIsdUJBQUMsVUFBSyxPQUFPLEVBQUVxTixVQUFVLFdBQVczSCxPQUFPLHlCQUF5QjRILFlBQVksS0FBS0gsU0FBUyxlQUFlQyxZQUFZLDJCQUEyQk8sY0FBYyxPQUFPLEdBQUUsaURBQTNLO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUVEdE4sWUFBWUwsU0FBUyxZQUNwQix1QkFBQyxVQUFLLE9BQU8sRUFBRXFOLFVBQVUsV0FBVzNILE9BQU8seUJBQXlCNEgsWUFBWSxLQUFLSCxTQUFTLGVBQWVDLFlBQVksdUJBQXVCTyxjQUFjLE9BQU8sR0FBRSx1Q0FBdks7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBVko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFZQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGlCQUNiLGlDQUFDLFdBQU0sV0FBVSxnQkFDZjtBQUFBLG1DQUFDLFdBQ0MsaUNBQUMsUUFDQztBQUFBLHFDQUFDLFFBQUcseUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBYTtBQUFBLGNBQ2IsdUJBQUMsUUFBRyw2QkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpQjtBQUFBLGNBQ2pCLHVCQUFDLFFBQUcsMkJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZTtBQUFBLGNBQ2YsdUJBQUMsUUFBRyxxQ0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5QjtBQUFBLGNBQ3pCLHVCQUFDLFFBQUcsdUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBVztBQUFBLGlCQUxiO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsWUFDQSx1QkFBQyxXQUNFckwsZ0JBQ0UwSTtBQUFBQSxjQUFPLENBQUF2RCxTQUNOLENBQUN2RixnQkFDQXVGLEtBQUsxSCxRQUFRLElBQUlzQixZQUFZLEVBQUUrTSxTQUFTbE0sWUFBWWIsWUFBWSxDQUFDLE1BQ2pFb0csS0FBS2hILFNBQVMsSUFBSVksWUFBWSxFQUFFK00sU0FBU2xNLFlBQVliLFlBQVksQ0FBQyxNQUNsRW9HLEtBQUt6SCxRQUFRLElBQUlxQixZQUFZLEVBQUUrTSxTQUFTbE0sWUFBWWIsWUFBWSxDQUFDLE1BQ2pFb0csS0FBS3pFLE1BQU0sSUFBSTBILFNBQVMsRUFBRXJKLFlBQVksRUFBRStNLFNBQVNsTSxZQUFZYixZQUFZLENBQUM7QUFBQSxZQUM3RSxFQUNDbUM7QUFBQUEsY0FBSSxDQUFDaUUsU0FDSix1QkFBQyxRQUNEO0FBQUEsdUNBQUMsUUFBRyxPQUFPLEVBQUVzRixTQUFTLFFBQVFzQixZQUFZLFVBQVVwQixLQUFLLFVBQVUsR0FDakU7QUFBQSx5Q0FBQyxTQUFJLE9BQU87QUFBQSxvQkFDVnFCLE9BQU87QUFBQSxvQkFDUHhCLFFBQVE7QUFBQSxvQkFDUmEsY0FBYztBQUFBLG9CQUNkUCxZQUFZO0FBQUEsb0JBQ1oxSCxPQUFPO0FBQUEsb0JBQ1BxSCxTQUFTO0FBQUEsb0JBQ1RzQixZQUFZO0FBQUEsb0JBQ1pLLGdCQUFnQjtBQUFBLG9CQUNoQnBCLFlBQVk7QUFBQSxvQkFDWkQsVUFBVTtBQUFBLGtCQUNaLEdBQ0c1RixlQUFLMUgsS0FBS29QLE9BQU8sQ0FBQyxFQUFFQyxZQUFZLEtBWm5DO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBYUE7QUFBQSxrQkFDQSx1QkFBQyxTQUNDO0FBQUEsMkNBQUMsU0FBSSxPQUFPLEVBQUU5QixZQUFZLElBQUksR0FBSTdGLGVBQUsxSCxRQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE0QztBQUFBLG9CQUM1Qyx1QkFBQyxTQUFJLE9BQU8sRUFBRXNOLFVBQVUsV0FBVzNILE9BQU8sd0JBQXdCLEdBQUc7QUFBQTtBQUFBLHNCQUFLK0IsS0FBS3pFO0FBQUFBLHlCQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFrRjtBQUFBLHVCQUZwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEscUJBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBbUJBO0FBQUEsZ0JBQ0EsdUJBQUMsUUFBSXlFLGVBQUtoSCxTQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdCO0FBQUEsZ0JBQ2hCLHVCQUFDLFFBQ0MsaUNBQUMsVUFBSyxXQUFXLGdCQUNmZ0gsS0FBS3pILFNBQVMsVUFBVSxXQUN4QnlILEtBQUt6SCxTQUFTLFdBQVcsWUFBWSxTQUFTLElBQzVDLE9BQU87QUFBQSxrQkFDVG9OLFlBQVkzRixLQUFLekgsU0FBUyxVQUFVLDZCQUE2QnlILEtBQUt6SCxTQUFTLFdBQVcsNkJBQTZCO0FBQUEsa0JBQ3ZIMEYsT0FBTytCLEtBQUt6SCxTQUFTLFVBQVUsWUFBWXlILEtBQUt6SCxTQUFTLFdBQVcsWUFBWTtBQUFBLGtCQUNoRm1OLFNBQVM7QUFBQSxnQkFDWCxHQUNHMUYsZUFBS3pILFFBUlI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFTQSxLQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBV0E7QUFBQSxnQkFDQSx1QkFBQyxRQUNDLGlDQUFDLFNBQUksT0FBTyxFQUFFK00sU0FBUyxRQUFRRSxLQUFLLFVBQVVvQyxVQUFVLE9BQU8sR0FDNURDLGlCQUFPQyxRQUFROUgsS0FBSy9HLGVBQWUsQ0FBQyxDQUFDLEVBQUU4QztBQUFBQSxrQkFBSSxDQUFDLENBQUNnTSxLQUFLQyxHQUFHLE1BQ3BEO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUVDLE9BQU87QUFBQSx3QkFDTHBDLFVBQVU7QUFBQSx3QkFDVkYsU0FBUztBQUFBLHdCQUNUUSxjQUFjO0FBQUEsd0JBQ2RQLFlBQVlxQyxNQUFNLDZCQUE2QjtBQUFBLHdCQUMvQy9KLE9BQU8rSixNQUFNLFlBQVk7QUFBQSx3QkFDekI1QixRQUFRLGFBQWE0QixNQUFNLDRCQUE0Qix3QkFBd0I7QUFBQSx3QkFDL0UxQyxTQUFTO0FBQUEsd0JBQ1RzQixZQUFZO0FBQUEsd0JBQ1pwQixLQUFLO0FBQUEsd0JBQ0xLLFlBQVk7QUFBQSxzQkFDZDtBQUFBLHNCQUVBO0FBQUEsK0NBQUMsVUFBSyxPQUFPO0FBQUEsMEJBQ1hnQixPQUFPO0FBQUEsMEJBQ1B4QixRQUFRO0FBQUEsMEJBQ1JhLGNBQWM7QUFBQSwwQkFDZFAsWUFBWXFDLE1BQU0sWUFBWTtBQUFBLHdCQUNoQyxLQUxBO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBS0c7QUFBQSx3QkFDRkQsSUFBSXJFLFFBQVEsV0FBVyxFQUFFLEVBQUVBLFFBQVEsU0FBUyxFQUFFO0FBQUE7QUFBQTtBQUFBLG9CQXBCMUNxRTtBQUFBQSxvQkFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQXNCQTtBQUFBLGdCQUNELEtBekJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBMEJBLEtBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBNEJBO0FBQUEsZ0JBQ0EsdUJBQUMsUUFDRW5QLHNCQUFZTCxTQUFTLFVBQ3BCO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFTLE1BQU13SCx5QkFBeUJDLElBQUk7QUFBQSxvQkFDNUMsT0FBTTtBQUFBLG9CQUNOLE9BQU8sRUFBRTJGLFlBQVksMkJBQTJCMUgsT0FBTyx5QkFBeUI0SSxPQUFPLFFBQVF4QixRQUFRLFFBQVFhLGNBQWMsT0FBT1osU0FBUyxRQUFRc0IsWUFBWSxVQUFVSyxnQkFBZ0IsU0FBUztBQUFBLG9CQUVwTSxpQ0FBQyxZQUFTLE1BQU0sTUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBbUI7QUFBQTtBQUFBLGtCQU5yQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBT0EsSUFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUyxNQUFNbEgseUJBQXlCQyxJQUFJO0FBQUEsb0JBQzVDLE9BQU07QUFBQSxvQkFDTixPQUFPLEVBQUUyRixZQUFZLDZCQUE2QjFILE9BQU8sV0FBVzRJLE9BQU8sUUFBUXhCLFFBQVEsUUFBUWEsY0FBYyxPQUFPWixTQUFTLFFBQVFzQixZQUFZLFVBQVVLLGdCQUFnQixTQUFTO0FBQUEsb0JBRXhMLGlDQUFDLFVBQU8sTUFBTSxNQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlCO0FBQUE7QUFBQSxrQkFObkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU9BLEtBbEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBb0JBO0FBQUEsbUJBbkZTakgsS0FBS3pFLElBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFvRkY7QUFBQSxZQUNELEtBL0ZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZ0dBO0FBQUEsZUExR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEyR0EsS0E1R0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE2R0E7QUFBQSxhQTVIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNkhBO0FBQUEsUUFHRHBCLGNBQWMsZ0JBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDO0FBQUEsWUFDQTtBQUFBLFlBQ0Esa0JBQWtCLENBQUNxSSxVQUFVbEYsZ0JBQWdCLENBQUFzQyxTQUFRLENBQUM0QyxPQUFPLEdBQUc1QyxJQUFJLENBQUM7QUFBQSxZQUNyRSxxQkFBcUIsQ0FBQ3FFLFFBQVFnRSxlQUFlO0FBQzNDakwsdUJBQVMsQ0FBQTRDLFNBQVFBLEtBQUs3RCxJQUFJLENBQUFnSSxNQUFLQSxFQUFFeEksT0FBTzBJLFNBQVMsRUFBRSxHQUFHRixHQUFHOUcsU0FBU2dMLFdBQVcsSUFBSWxFLENBQUMsQ0FBQztBQUFBLFlBQ3JGO0FBQUEsWUFDQSxtQkFBbUIsQ0FBQ21FLG9CQUFvQjtBQUN0QzVNLCtCQUFpQixDQUFBc0UsU0FBUSxDQUFDc0ksaUJBQWlCLEdBQUd0SSxJQUFJLENBQUM7QUFBQSxZQUNyRDtBQUFBO0FBQUEsVUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFTSTtBQUFBLFdBN3hDUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ3lDQTtBQUFBLFNBOTJDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBKzJDQTtBQUFBLElBS0NrQixlQUNDLHVCQUFDLFNBQUksV0FBVSxrQkFBaUIsU0FBUyxNQUFNQyxlQUFlLEtBQUssR0FDakUsaUNBQUMsU0FBSSxXQUFVLG1CQUFrQixTQUFTLENBQUNpQixNQUFNQSxFQUFFbUcsZ0JBQWdCLEdBQ2pFO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEsK0JBQUMsUUFBSW5ILHNCQUFZLHFCQUFxQix3QkFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyRDtBQUFBLFFBQzNELHVCQUFDLFlBQU8sV0FBVSxtQkFBa0IsU0FBUyxNQUFNRCxlQUFlLEtBQUssR0FDckUsaUNBQUMsS0FBRSxNQUFNLE1BQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFZLEtBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNBLHVCQUFDLFVBQUssVUFBVW1DLGdCQUFnQixPQUFPLEVBQUVvQyxTQUFTLFFBQVErQixlQUFlLFVBQVU3QixLQUFLLE9BQU8sR0FDN0Y7QUFBQSwrQkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSxpQ0FBQyxXQUFNLDJCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtCO0FBQUEsVUFDbEI7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQSxjQUNWLGFBQVk7QUFBQSxjQUNaLE9BQU90RSxPQUFPM0Q7QUFBQUEsY0FDZCxVQUFVLENBQUN5RSxNQUFNYixVQUFVLEVBQUUsR0FBR0QsUUFBUTNELE1BQU15RSxFQUFFa0QsT0FBT0MsTUFBTSxDQUFDO0FBQUEsY0FDOUQsVUFBUTtBQUFBO0FBQUEsWUFOVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNVTtBQUFBLGFBUlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSxpQ0FBQyxXQUFNLDBCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlCO0FBQUEsVUFDakI7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQSxjQUNWLGFBQVk7QUFBQSxjQUNaLE9BQU9qRSxPQUFPdkQ7QUFBQUEsY0FDZCxVQUFVLENBQUNxRSxNQUFNYixVQUFVLEVBQUUsR0FBR0QsUUFBUXZELFFBQVFxRSxFQUFFa0QsT0FBT0MsTUFBTSxDQUFDO0FBQUEsY0FDaEUsVUFBUTtBQUFBO0FBQUEsWUFQVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPVTtBQUFBLGFBVFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRUcsU0FBUyxRQUFRQyxxQkFBcUIsV0FBV0MsS0FBSyxPQUFPLEdBQ3pFO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsbUNBQUMsV0FBTSxvQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFXO0FBQUEsWUFDWDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixPQUFPdEUsT0FBT3hGO0FBQUFBLGdCQUNkLFVBQVUsQ0FBQ3NHLE1BQU1iLFVBQVUsRUFBRSxHQUFHRCxRQUFReEYsTUFBTXNHLEVBQUVrRCxPQUFPQyxNQUFNLENBQUM7QUFBQSxnQkFFOUQ7QUFBQSx5Q0FBQyxZQUFPLE9BQU0sV0FBVSwyQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBbUM7QUFBQSxrQkFDbkMsdUJBQUMsWUFBTyxPQUFNLFVBQVMsMEJBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWlDO0FBQUE7QUFBQTtBQUFBLGNBTm5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9BO0FBQUEsZUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSxtQ0FBQyxXQUFNLHNCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWE7QUFBQSxZQUNiO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLE9BQU9qRSxPQUFPdEQ7QUFBQUEsZ0JBQ2QsVUFBVSxDQUFDb0UsTUFBTWIsVUFBVSxFQUFFLEdBQUdELFFBQVF0RCxRQUFRb0UsRUFBRWtELE9BQU9DLE1BQU0sQ0FBQztBQUFBLGdCQUVoRTtBQUFBLHlDQUFDLFlBQU8sT0FBTSxXQUFVLHVCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUErQjtBQUFBLGtCQUMvQix1QkFBQyxZQUFPLE9BQU0sV0FBVSx1QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0I7QUFBQSxrQkFDL0IsdUJBQUMsWUFBTyxPQUFNLFVBQVMsc0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTZCO0FBQUE7QUFBQTtBQUFBLGNBUC9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVFBO0FBQUEsZUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVdBO0FBQUEsYUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdCQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUVHLFNBQVMsUUFBUUMscUJBQXFCLFdBQVdDLEtBQUssT0FBTyxHQUN6RTtBQUFBLGlDQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLG1DQUFDLFdBQU0sd0JBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZTtBQUFBLFlBQ2Y7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsT0FBT3RFLE9BQU94RDtBQUFBQSxnQkFDZCxVQUFVLENBQUNzRSxNQUFNYixVQUFVLEVBQUUsR0FBR0QsUUFBUXhELFVBQVVzRSxFQUFFa0QsT0FBT0MsTUFBTSxDQUFDO0FBQUEsZ0JBRWxFO0FBQUEseUNBQUMsWUFBTyxPQUFNLFdBQVUsdUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQStCO0FBQUEsa0JBQy9CLHVCQUFDLFlBQU8sT0FBTSxZQUFXLHdCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpQztBQUFBLGtCQUNqQyx1QkFBQyxZQUFPLE9BQU0saUJBQWdCLDZCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyQztBQUFBLGtCQUMzQyx1QkFBQyxZQUFPLE9BQU0sWUFBVyx3QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUM7QUFBQSxrQkFDakMsdUJBQUMsWUFBTyxPQUFNLFVBQVMsc0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTZCO0FBQUEsa0JBQzdCLHVCQUFDLFlBQU8sT0FBTSxhQUFZLHlCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFtQztBQUFBLGtCQUNuQyx1QkFBQyxZQUFPLE9BQU0sVUFBUyxzQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNkI7QUFBQTtBQUFBO0FBQUEsY0FYL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBWUE7QUFBQSxlQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZUE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLG1DQUFDLFdBQU0sc0JBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBYTtBQUFBLFlBQ2I7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsT0FBT2pFLE9BQU96RDtBQUFBQSxnQkFDZCxVQUFVLENBQUN1RSxNQUFNYixVQUFVLEVBQUUsR0FBR0QsUUFBUXpELFFBQVF1RSxFQUFFa0QsT0FBT0MsTUFBTSxDQUFDO0FBQUEsZ0JBRWhFO0FBQUEseUNBQUMsWUFBTyxPQUFNLFFBQU8sb0JBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXlCO0FBQUEsa0JBQ3pCLHVCQUFDLFlBQU8sT0FBTSxVQUFTLHNCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2QjtBQUFBLGtCQUM3Qix1QkFBQyxZQUFPLE9BQU0saUJBQWdCLDZCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyQztBQUFBO0FBQUE7QUFBQSxjQVA3QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFRQTtBQUFBLGVBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLGFBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE2QkE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLGlDQUFDLFdBQU0sb0JBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBVztBQUFBLFVBQ1g7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQSxjQUNWLE9BQU9qRSxPQUFPMUQ7QUFBQUEsY0FDZCxVQUFVLENBQUN3RSxNQUFNYixVQUFVLEVBQUUsR0FBR0QsUUFBUTFELE1BQU13RSxFQUFFa0QsT0FBT0MsTUFBTSxDQUFDO0FBQUEsY0FDOUQsVUFBUTtBQUFBO0FBQUEsWUFMVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLVTtBQUFBLGFBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQSxpQ0FBQyxZQUFPLE1BQUssVUFBUyxXQUFVLG9CQUFtQixTQUFTLE1BQU1wRSxlQUFlLEtBQUssR0FBRyxzQkFBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0Y7QUFBQSxVQUMvRix1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLGdCQUFlLE9BQU8sRUFBRXlGLFFBQVEsR0FBR2QsU0FBUyxlQUFlLEdBQ3hGMUUsc0JBQVksaUJBQWlCLFlBRGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFdBOUZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUErRkE7QUFBQSxTQXRHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUdBLEtBeEdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5R0E7QUFBQSxJQU1ETSxpQkFDQyx1QkFBQyxTQUFJLFdBQVUsa0JBQWlCLFNBQVMsTUFBTUMsaUJBQWlCLEtBQUssR0FDbkUsaUNBQUMsU0FBSSxXQUFVLG1CQUFrQixTQUFTLENBQUNTLE1BQU1BLEVBQUVtRyxnQkFBZ0IsR0FDakU7QUFBQSw2QkFBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQSwrQkFBQyxRQUFHLGdDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0I7QUFBQSxRQUNwQix1QkFBQyxZQUFPLFdBQVUsbUJBQWtCLFNBQVMsTUFBTTVHLGlCQUFpQixLQUFLLEdBQ3ZFLGlDQUFDLEtBQUUsTUFBTSxNQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBWSxLQURkO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQSx1QkFBQyxVQUFLLFVBQVV1Qyx3QkFBd0IsT0FBTyxFQUFFd0IsU0FBUyxRQUFRK0IsZUFBZSxVQUFVN0IsS0FBSyxPQUFPLEdBQ3JHO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsaUNBQUMsV0FBTSxnQ0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1QjtBQUFBLFVBQ3ZCO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxXQUFVO0FBQUEsY0FDVixhQUFZO0FBQUEsY0FDWixPQUFPOUQsU0FBU3hFO0FBQUFBLGNBQ2hCLFVBQVUsQ0FBQzhFLE1BQU1MLFlBQVksRUFBRSxHQUFHRCxVQUFVeEUsUUFBUThFLEVBQUVrRCxPQUFPQyxNQUFNLENBQUM7QUFBQSxjQUNwRSxVQUFRO0FBQUE7QUFBQSxZQU5WO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1VO0FBQUEsYUFSWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLGlDQUFDLFdBQU0sMkJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0I7QUFBQSxVQUNsQjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQ1YsYUFBWTtBQUFBLGNBQ1osT0FBT3pELFNBQVN6RTtBQUFBQSxjQUNoQixVQUFVLENBQUMrRSxNQUFNTCxZQUFZLEVBQUUsR0FBR0QsVUFBVXpFLFNBQVMrRSxFQUFFa0QsT0FBT0MsTUFBTSxDQUFDO0FBQUEsY0FDckUsVUFBUTtBQUFBO0FBQUEsWUFOVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNVTtBQUFBLGFBUlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRUcsU0FBUyxRQUFRQyxxQkFBcUIsV0FBV0MsS0FBSyxPQUFPLEdBQ3pFO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsbUNBQUMsV0FBTSwyQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrQjtBQUFBLFlBQ2xCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFDVixhQUFZO0FBQUEsZ0JBQ1osV0FBVTtBQUFBLGdCQUNWLE9BQU85RCxTQUFTdEU7QUFBQUEsZ0JBQ2hCLFVBQVUsQ0FBQzRFLE1BQU1MLFlBQVksRUFBRSxHQUFHRCxVQUFVdEUsUUFBUTRFLEVBQUVrRCxPQUFPQyxNQUFNLENBQUM7QUFBQSxnQkFDcEUsVUFBUTtBQUFBO0FBQUEsY0FQVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPVTtBQUFBLGVBVFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsbUNBQUMsV0FBTSwwQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpQjtBQUFBLFlBQ2pCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLE9BQU96RCxTQUFTaEc7QUFBQUEsZ0JBQ2hCLFVBQVUsQ0FBQ3NHLE1BQU1MLFlBQVksRUFBRSxHQUFHRCxVQUFVaEcsTUFBTXNHLEVBQUVrRCxPQUFPQyxNQUFNLENBQUM7QUFBQSxnQkFFbEU7QUFBQSx5Q0FBQyxZQUFPLE9BQU0sUUFBTyw2QkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBa0M7QUFBQSxrQkFDbEMsdUJBQUMsWUFBTyxPQUFNLFNBQVEsNEJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWtDO0FBQUEsa0JBQ2xDLHVCQUFDLFlBQU8sT0FBTSxTQUFRLDZCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFtQztBQUFBLGtCQUNuQyx1QkFBQyxZQUFPLE9BQU0sVUFBUyw0QkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBbUM7QUFBQTtBQUFBO0FBQUEsY0FSckM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBU0E7QUFBQSxlQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxhQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMEJBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSxpQ0FBQyxXQUFNLHVDQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThCO0FBQUEsVUFDOUI7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQSxjQUNWLGFBQVk7QUFBQSxjQUNaLFdBQVU7QUFBQSxjQUNWLE9BQU96RCxTQUFTdkU7QUFBQUEsY0FDaEIsVUFBVSxDQUFDNkUsTUFBTUwsWUFBWSxFQUFFLEdBQUdELFVBQVV2RSxRQUFRNkUsRUFBRWtELE9BQU9DLE1BQU0sQ0FBQztBQUFBLGNBQ3BFLFVBQVE7QUFBQTtBQUFBLFlBUFY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT1U7QUFBQSxhQVRaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEsaUNBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSxvQkFBbUIsU0FBUyxNQUFNNUQsaUJBQWlCLEtBQUssR0FBRyxzQkFBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUc7QUFBQSxVQUNqRyx1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLGdCQUFlLE9BQU8sRUFBRWlGLFFBQVEsR0FBR2QsU0FBUyxlQUFlLEdBQUUsNEJBQTdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFdBbkVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvRUE7QUFBQSxTQTNFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNEVBLEtBN0VGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4RUE7QUFBQSxJQUtEM0ssaUJBQWlCRSxlQUNoQix1QkFBQyxTQUFJLFdBQVUsa0JBQWlCLFNBQVMsTUFBTUQsaUJBQWlCLEtBQUssR0FDbkUsaUNBQUMsU0FBSSxXQUFVLG1CQUFrQixTQUFTLENBQUNnSCxNQUFNQSxFQUFFbUcsZ0JBQWdCLEdBQUcsT0FBTyxFQUFFQyxVQUFVLFFBQVEsR0FDL0Y7QUFBQSw2QkFBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQSwrQkFBQyxRQUFJeFAsc0JBQVlMLFNBQVMsVUFBVSx5QkFBeUIsd0JBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0Y7QUFBQSxRQUNsRix1QkFBQyxZQUFPLFdBQVUsbUJBQWtCLFNBQVMsTUFBTXlDLGlCQUFpQixLQUFLLEdBQ3ZFLGlDQUFDLEtBQUUsTUFBTSxNQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBWSxLQURkO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLE9BQU8sRUFBRXNMLGNBQWMsV0FBV2lCLGVBQWUsUUFBUWhCLGNBQWMsZ0NBQWdDLEdBQzFHO0FBQUEsK0JBQUMsU0FBSSxPQUFPLEVBQUVWLFlBQVksS0FBS0QsVUFBVSxVQUFVM0gsT0FBTyxzQkFBc0IsR0FBSWhELHNCQUFZM0MsUUFBaEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRztBQUFBLFFBQ3JHLHVCQUFDLFNBQUksT0FBTyxFQUFFc04sVUFBVSxXQUFXM0gsT0FBTyx5QkFBeUJ3SCxXQUFXLFVBQVUsR0FBSXhLLHNCQUFZakMsU0FBeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4RztBQUFBLFdBRmhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BRUEsdUJBQUMsVUFBSyxVQUFVLENBQUNnSixNQUFNO0FBQ3JCQSxVQUFFQyxlQUFlO0FBQ2pCLFlBQUlySixZQUFZTCxTQUFTLFNBQVM7QUFDaEN5QywyQkFBaUIsS0FBSztBQUN0QjtBQUFBLFFBQ0Y7QUFDQW9FLGdDQUF3Qm5FLFlBQVlNLElBQUlKLFNBQVM1QyxNQUFNNEMsU0FBU2xDLFdBQVc7QUFBQSxNQUM3RSxHQUFHLE9BQU8sRUFBRXFNLFNBQVMsUUFBUStCLGVBQWUsVUFBVTdCLEtBQUssVUFBVSxHQUVuRTtBQUFBLCtCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLGlDQUFDLFdBQU0sT0FBTyxFQUFFSyxZQUFZLElBQUksR0FBRywyQkFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEM7QUFBQSxVQUM5QztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsT0FBTzFLLFNBQVM1QztBQUFBQSxjQUNoQixVQUFVLENBQUN5SixNQUFNO0FBQ2Ysc0JBQU1xRyxVQUFVckcsRUFBRWtELE9BQU9DO0FBQ3pCLG9CQUFJbUQsaUJBQWlCLEVBQUUsR0FBR25OLFNBQVNsQyxZQUFZO0FBQy9DLG9CQUFJb1AsWUFBWSxTQUFTO0FBQ3ZCQyxtQ0FBaUI7QUFBQSxvQkFDZnBQLGdCQUFnQjtBQUFBLG9CQUNoQkMsV0FBVztBQUFBLG9CQUNYQyxjQUFjO0FBQUEsb0JBQ2RDLGNBQWM7QUFBQSxvQkFDZEMsaUJBQWlCO0FBQUEsb0JBQ2pCQyxjQUFjO0FBQUEsa0JBQ2hCO0FBQUEsZ0JBQ0YsV0FBVzhPLFlBQVksVUFBVTtBQUMvQkMsbUNBQWlCO0FBQUEsb0JBQ2ZwUCxnQkFBZ0I7QUFBQSxvQkFDaEJDLFdBQVc7QUFBQSxvQkFDWEMsY0FBYztBQUFBLG9CQUNkQyxjQUFjO0FBQUEsb0JBQ2RDLGlCQUFpQjtBQUFBLG9CQUNqQkMsY0FBYztBQUFBLGtCQUNoQjtBQUFBLGdCQUNGLFdBQVc4TyxZQUFZLFVBQVU7QUFDL0JDLG1DQUFpQjtBQUFBLG9CQUNmcFAsZ0JBQWdCO0FBQUEsb0JBQ2hCQyxXQUFXO0FBQUEsb0JBQ1hDLGNBQWM7QUFBQSxvQkFDZEMsY0FBYztBQUFBLG9CQUNkQyxpQkFBaUI7QUFBQSxvQkFDakJDLGNBQWM7QUFBQSxrQkFDaEI7QUFBQSxnQkFDRjtBQUNBNkIsNEJBQVksRUFBRTdDLE1BQU04UCxTQUFTcFAsYUFBYXFQLGVBQWUsQ0FBQztBQUFBLGNBQzVEO0FBQUEsY0FDQSxVQUFVMVAsWUFBWUwsU0FBUztBQUFBLGNBRS9CO0FBQUEsdUNBQUMsWUFBTyxPQUFNLFNBQVEseUNBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStDO0FBQUEsZ0JBQy9DLHVCQUFDLFlBQU8sT0FBTSxVQUFTLGdEQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1RDtBQUFBLGdCQUN2RCx1QkFBQyxZQUFPLE9BQU0sVUFBUyx5Q0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0Q7QUFBQTtBQUFBO0FBQUEsWUF4Q2xEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQXlDQTtBQUFBLGFBM0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0Q0E7QUFBQSxRQUVBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLE9BQU8sRUFBRStNLFNBQVMsU0FBU08sWUFBWSxLQUFLUyxjQUFjLFdBQVdWLFVBQVUsVUFBVSxHQUFHLGdEQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtSTtBQUFBLFVBRW5JLHVCQUFDLFNBQUksT0FBTyxFQUFFTixTQUFTLFFBQVErQixlQUFlLFVBQVU3QixLQUFLLFdBQVdHLFlBQVkscUJBQXFCRCxTQUFTLFFBQVFRLGNBQWMsUUFBUUUsUUFBUSxnQ0FBZ0MsR0FHdEw7QUFBQSxtQ0FBQyxTQUFJLE9BQU8sRUFBRWQsU0FBUyxRQUFRc0IsWUFBWSxVQUFVSyxnQkFBZ0IsZ0JBQWdCLEdBQ25GO0FBQUEscUNBQUMsU0FDQztBQUFBLHVDQUFDLFNBQUksT0FBTyxFQUFFcEIsWUFBWSxLQUFLRCxVQUFVLFVBQVUsR0FBRyxrQ0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0U7QUFBQSxnQkFDeEUsdUJBQUMsU0FBSSxPQUFPLEVBQUVBLFVBQVUsV0FBVzNILE9BQU8sd0JBQXdCLEdBQUcsb0VBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlIO0FBQUEsbUJBRjNIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLFdBQU0sV0FBVSxnQkFBZSxPQUFPLEVBQUVnSSxlQUFlck4sWUFBWUwsU0FBUyxVQUFVLFNBQVMsT0FBTyxHQUNyRztBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUFTNEMsU0FBU2xDLFlBQVlDO0FBQUFBLG9CQUM5QixVQUFVLENBQUM4SSxNQUFNNUcsWUFBWTtBQUFBLHNCQUMzQixHQUFHRDtBQUFBQSxzQkFDSGxDLGFBQWEsRUFBRSxHQUFHa0MsU0FBU2xDLGFBQWFDLGdCQUFnQjhJLEVBQUVrRCxPQUFPcUQsUUFBUTtBQUFBLG9CQUMzRSxDQUFDO0FBQUEsb0JBQ0QsVUFBVTNQLFlBQVlMLFNBQVM7QUFBQTtBQUFBLGtCQVBqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBT3lDO0FBQUEsZ0JBRXpDLHVCQUFDLFVBQUssV0FBVSxtQkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQSxtQkFWbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFXQTtBQUFBLGlCQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlCQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxPQUFPLEVBQUUrTSxTQUFTLFFBQVFzQixZQUFZLFVBQVVLLGdCQUFnQixpQkFBaUJ1QixXQUFXLDhCQUE4QkMsWUFBWSxVQUFVLEdBQ25KO0FBQUEscUNBQUMsU0FDQztBQUFBLHVDQUFDLFNBQUksT0FBTyxFQUFFNUMsWUFBWSxLQUFLRCxVQUFVLFVBQVUsR0FBRyx1Q0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkU7QUFBQSxnQkFDN0UsdUJBQUMsU0FBSSxPQUFPLEVBQUVBLFVBQVUsV0FBVzNILE9BQU8sd0JBQXdCLEdBQUcsdUVBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTRIO0FBQUEsbUJBRjlIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLFdBQU0sV0FBVSxnQkFBZSxPQUFPLEVBQUVnSSxlQUFlck4sWUFBWUwsU0FBUyxVQUFVLFNBQVMsT0FBTyxHQUNyRztBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUFTNEMsU0FBU2xDLFlBQVlFO0FBQUFBLG9CQUM5QixVQUFVLENBQUM2SSxNQUFNNUcsWUFBWTtBQUFBLHNCQUMzQixHQUFHRDtBQUFBQSxzQkFDSGxDLGFBQWEsRUFBRSxHQUFHa0MsU0FBU2xDLGFBQWFFLFdBQVc2SSxFQUFFa0QsT0FBT3FELFFBQVE7QUFBQSxvQkFDdEUsQ0FBQztBQUFBLG9CQUNELFVBQVUzUCxZQUFZTCxTQUFTO0FBQUE7QUFBQSxrQkFQakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU95QztBQUFBLGdCQUV6Qyx1QkFBQyxVQUFLLFdBQVUsbUJBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdDO0FBQUEsbUJBVmxDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBV0E7QUFBQSxpQkFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpQkE7QUFBQSxZQUdBLHVCQUFDLFNBQUksT0FBTyxFQUFFK00sU0FBUyxRQUFRc0IsWUFBWSxVQUFVSyxnQkFBZ0IsaUJBQWlCdUIsV0FBVyw4QkFBOEJDLFlBQVksVUFBVSxHQUNuSjtBQUFBLHFDQUFDLFNBQ0M7QUFBQSx1Q0FBQyxTQUFJLE9BQU8sRUFBRTVDLFlBQVksS0FBS0QsVUFBVSxVQUFVLEdBQUcsdUNBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZFO0FBQUEsZ0JBQzdFLHVCQUFDLFNBQUksT0FBTyxFQUFFQSxVQUFVLFdBQVczSCxPQUFPLHdCQUF3QixHQUFHLG1FQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3SDtBQUFBLG1CQUYxSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyxXQUFNLFdBQVUsZ0JBQWUsT0FBTyxFQUFFZ0ksZUFBZXJOLFlBQVlMLFNBQVMsVUFBVSxTQUFTLE9BQU8sR0FDckc7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBUzRDLFNBQVNsQyxZQUFZRztBQUFBQSxvQkFDOUIsVUFBVSxDQUFDNEksTUFBTTVHLFlBQVk7QUFBQSxzQkFDM0IsR0FBR0Q7QUFBQUEsc0JBQ0hsQyxhQUFhLEVBQUUsR0FBR2tDLFNBQVNsQyxhQUFhRyxjQUFjNEksRUFBRWtELE9BQU9xRCxRQUFRO0FBQUEsb0JBQ3pFLENBQUM7QUFBQSxvQkFDRCxVQUFVM1AsWUFBWUwsU0FBUztBQUFBO0FBQUEsa0JBUGpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPeUM7QUFBQSxnQkFFekMsdUJBQUMsVUFBSyxXQUFVLG1CQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQztBQUFBLG1CQVZsQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVdBO0FBQUEsaUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaUJBO0FBQUEsWUFHQSx1QkFBQyxTQUFJLE9BQU8sRUFBRStNLFNBQVMsUUFBUXNCLFlBQVksVUFBVUssZ0JBQWdCLGlCQUFpQnVCLFdBQVcsOEJBQThCQyxZQUFZLFVBQVUsR0FDbko7QUFBQSxxQ0FBQyxTQUNDO0FBQUEsdUNBQUMsU0FBSSxPQUFPLEVBQUU1QyxZQUFZLEtBQUtELFVBQVUsVUFBVSxHQUFHLDZDQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtRjtBQUFBLGdCQUNuRix1QkFBQyxTQUFJLE9BQU8sRUFBRUEsVUFBVSxXQUFXM0gsT0FBTyx3QkFBd0IsR0FBRyxrRUFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUg7QUFBQSxtQkFGekg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsV0FBTSxXQUFVLGdCQUFlLE9BQU8sRUFBRWdJLGVBQWVyTixZQUFZTCxTQUFTLFVBQVUsU0FBUyxPQUFPLEdBQ3JHO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVM0QyxTQUFTbEMsWUFBWUk7QUFBQUEsb0JBQzlCLFVBQVUsQ0FBQzJJLE1BQU01RyxZQUFZO0FBQUEsc0JBQzNCLEdBQUdEO0FBQUFBLHNCQUNIbEMsYUFBYSxFQUFFLEdBQUdrQyxTQUFTbEMsYUFBYUksY0FBYzJJLEVBQUVrRCxPQUFPcUQsUUFBUTtBQUFBLG9CQUN6RSxDQUFDO0FBQUEsb0JBQ0QsVUFBVTNQLFlBQVlMLFNBQVM7QUFBQTtBQUFBLGtCQVBqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBT3lDO0FBQUEsZ0JBRXpDLHVCQUFDLFVBQUssV0FBVSxtQkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQSxtQkFWbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFXQTtBQUFBLGlCQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlCQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxPQUFPLEVBQUUrTSxTQUFTLFFBQVFzQixZQUFZLFVBQVVLLGdCQUFnQixpQkFBaUJ1QixXQUFXLDhCQUE4QkMsWUFBWSxVQUFVLEdBQ25KO0FBQUEscUNBQUMsU0FDQztBQUFBLHVDQUFDLFNBQUksT0FBTyxFQUFFNUMsWUFBWSxLQUFLRCxVQUFVLFVBQVUsR0FBRyxtQ0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUU7QUFBQSxnQkFDekUsdUJBQUMsU0FBSSxPQUFPLEVBQUVBLFVBQVUsV0FBVzNILE9BQU8sd0JBQXdCLEdBQUcscUZBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBJO0FBQUEsbUJBRjVJO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLFdBQU0sV0FBVSxnQkFBZSxPQUFPLEVBQUVnSSxlQUFlck4sWUFBWUwsU0FBUyxVQUFVLFNBQVMsT0FBTyxHQUNyRztBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUFTNEMsU0FBU2xDLFlBQVlLO0FBQUFBLG9CQUM5QixVQUFVLENBQUMwSSxNQUFNNUcsWUFBWTtBQUFBLHNCQUMzQixHQUFHRDtBQUFBQSxzQkFDSGxDLGFBQWEsRUFBRSxHQUFHa0MsU0FBU2xDLGFBQWFLLGlCQUFpQjBJLEVBQUVrRCxPQUFPcUQsUUFBUTtBQUFBLG9CQUM1RSxDQUFDO0FBQUEsb0JBQ0QsVUFBVTNQLFlBQVlMLFNBQVM7QUFBQTtBQUFBLGtCQVBqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBT3lDO0FBQUEsZ0JBRXpDLHVCQUFDLFVBQUssV0FBVSxtQkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQSxtQkFWbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFXQTtBQUFBLGlCQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlCQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxPQUFPLEVBQUUrTSxTQUFTLFFBQVFzQixZQUFZLFVBQVVLLGdCQUFnQixpQkFBaUJ1QixXQUFXLDhCQUE4QkMsWUFBWSxVQUFVLEdBQ25KO0FBQUEscUNBQUMsU0FDQztBQUFBLHVDQUFDLFNBQUksT0FBTyxFQUFFNUMsWUFBWSxLQUFLRCxVQUFVLFVBQVUsR0FBRyw2Q0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBbUY7QUFBQSxnQkFDbkYsdUJBQUMsU0FBSSxPQUFPLEVBQUVBLFVBQVUsV0FBVzNILE9BQU8sd0JBQXdCLEdBQUcsdUZBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTRJO0FBQUEsbUJBRjlJO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLFdBQU0sV0FBVSxnQkFBZSxPQUFPLEVBQUVnSSxlQUFlck4sWUFBWUwsU0FBUyxVQUFVLFNBQVMsT0FBTyxHQUNyRztBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUFTNEMsU0FBU2xDLFlBQVlNO0FBQUFBLG9CQUM5QixVQUFVLENBQUN5SSxNQUFNNUcsWUFBWTtBQUFBLHNCQUMzQixHQUFHRDtBQUFBQSxzQkFDSGxDLGFBQWEsRUFBRSxHQUFHa0MsU0FBU2xDLGFBQWFNLGNBQWN5SSxFQUFFa0QsT0FBT3FELFFBQVE7QUFBQSxvQkFDekUsQ0FBQztBQUFBLG9CQUNELFVBQVUzUCxZQUFZTCxTQUFTO0FBQUE7QUFBQSxrQkFQakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU95QztBQUFBLGdCQUV6Qyx1QkFBQyxVQUFLLFdBQVUsbUJBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdDO0FBQUEsbUJBVmxDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBV0E7QUFBQSxpQkFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpQkE7QUFBQSxlQXhIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTBIQTtBQUFBLGFBN0hGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE4SEE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBLGlDQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsb0JBQW1CLFNBQVMsTUFBTXlDLGlCQUFpQixLQUFLLEdBQ3JGcEMsc0JBQVlMLFNBQVMsVUFBVSxXQUFXLFdBRDdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNDSyxZQUFZTCxTQUFTLFdBQ3BCLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsZ0JBQWUsT0FBTyxFQUFFaU8sUUFBUSxHQUFHZCxTQUFTLGVBQWUsR0FBRSw0QkFBN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsV0FoTUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWlNQTtBQUFBLFNBOU1GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0ErTUEsS0FoTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlOQTtBQUFBLE9BenpESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMnpEQTtBQUVKO0FBRUFoTixHQS82RU1ELFdBQVM7QUFBQSxVQUNJbkMsYUE2VWlCQyxPQUFPO0FBQUE7QUFBQSxLQTlVckNrQztBQWc3RU4sTUFBTXFNLFlBQVk7QUFBQSxFQUNoQixFQUFFeE0sTUFBTSxhQUFhMk0sTUFBTXpPLGdCQUFnQjtBQUFBLEVBQzNDLEVBQUU4QixNQUFNLGdCQUFnQjJNLE1BQU14TyxlQUFlO0FBQUEsRUFDN0MsRUFBRTZCLE1BQU0sY0FBYzJNLE1BQU05TSxLQUFLO0FBQUEsRUFDakMsRUFBRUcsTUFBTSxZQUFZMk0sTUFBTXZPLEtBQUs7QUFBQSxFQUMvQixFQUFFNEIsTUFBTSxlQUFlMk0sTUFBTXJPLFVBQVU7QUFBQSxFQUN2QyxFQUFFMEIsTUFBTSxnQkFBZ0IyTSxNQUFNcE8sV0FBVztBQUFBLEVBQ3pDLEVBQUV5QixNQUFNLFNBQVMyTSxNQUFNbk8sVUFBVTtBQUFBLEVBQ2pDLEVBQUV3QixNQUFNLFlBQVkyTSxNQUFNbE8sT0FBTztBQUFBLEVBQ2pDLEVBQUV1QixNQUFNLGlCQUFpQjJNLE1BQU1qTyxVQUFVO0FBQUEsRUFDekMsRUFBRXNCLE1BQU0sZ0JBQWdCMk0sTUFBTXRPLE1BQU07QUFBQSxFQUNwQyxFQUFFMkIsTUFBTSxXQUFXMk0sTUFBTWhPLFNBQVM7QUFBQztBQUdyQyxlQUFld0I7QUFBVSxJQUFBaVE7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VOYXZpZ2F0ZSIsInVzZUF1dGgiLCJMYXlvdXREYXNoYm9hcmQiLCJBcnJvd0xlZnRSaWdodCIsIlVzZXIiLCJVc2VycyIsIkxpbmVDaGFydCIsIkNyZWRpdENhcmQiLCJIYW5kQ29pbnMiLCJXcmVuY2giLCJMaWdodGJ1bGIiLCJTZXR0aW5ncyIsIkxvZ091dCIsIkJlbGwiLCJTZWFyY2giLCJTZW5kIiwiQ2hldnJvblJpZ2h0IiwiUGx1cyIsIlRyZW5kaW5nVXAiLCJEb2xsYXJTaWduIiwiQnJpZWZjYXNlIiwiU2hpZWxkQ2hlY2siLCJTbWFydHBob25lIiwiU3BhcmtsZXMiLCJMb2NrIiwiRWRpdDIiLCJUcmFzaDIiLCJHbG9iZSIsIlgiLCJTY2FuIiwiUXJTY2FubmVyVGFiIiwicXVpY2tUcmFuc2ZlclVzZXJzIiwibmFtZSIsInJvbGUiLCJhdmF0YXIiLCJEYXNoYm9hcmQiLCJfcyIsIm5hdmlnYXRlIiwidXNlclNlc3Npb24iLCJyYXciLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwiZW1haWwiLCJwZXJtaXNzaW9ucyIsInZpZXdfZGFzaGJvYXJkIiwibWFuYWdlX3R4IiwibWFuYWdlX2NhcmRzIiwibWFuYWdlX2xvYW5zIiwibWFuYWdlX3NlcnZpY2VzIiwibWFuYWdlX3VzZXJzIiwicGFyc2VkIiwiSlNPTiIsInBhcnNlIiwiZW1haWxMb3dlciIsInRvTG93ZXJDYXNlIiwiaXNBZG1pbiIsIkNBUkRTX0tFWSIsIlRYU19LRVkiLCJQUk9GSUxFX0tFWSIsIlNFUlZJQ0VTX0tFWSIsIkxPQU5TX0tFWSIsImFjdGl2ZVRhYiIsInNldEFjdGl2ZVRhYiIsInNhdmVkIiwicmVtb3ZlSXRlbSIsInNldHRpbmdzU3ViVGFiIiwic2V0U2V0dGluZ3NTdWJUYWIiLCJzZWFyY2hRdWVyeSIsInNldFNlYXJjaFF1ZXJ5IiwidHJhbnNhY3Rpb25UeXBlRmlsdGVyIiwic2V0VHJhbnNhY3Rpb25UeXBlRmlsdGVyIiwidXNlcnMiLCJzZXRVc2VycyIsInVzZXJNb2RhbE9wZW4iLCJzZXRVc2VyTW9kYWxPcGVuIiwiZWRpdGluZ1VzZXIiLCJzZXRFZGl0aW5nVXNlciIsInVzZXJGb3JtIiwic2V0VXNlckZvcm0iLCJub3RpZmljYXRpb25zIiwic2V0Tm90aWZpY2F0aW9ucyIsImlkIiwidGV4dCIsInRpbWUiLCJ0eXBlIiwidW5yZWFkIiwibm90aWZpY2F0aW9uc09wZW4iLCJzZXROb3RpZmljYXRpb25zT3BlbiIsImhhbmRsZU1hcmtBbGxSZWFkIiwibWFwIiwibiIsInByb2ZpbGUiLCJzZXRQcm9maWxlIiwicGhvbmUiLCJkb2IiLCJhZGRyZXNzIiwidGVtcFByb2ZpbGUiLCJzZXRUZW1wUHJvZmlsZSIsInBhc3N3b3JkRm9ybSIsInNldFBhc3N3b3JkRm9ybSIsImN1cnJlbnQiLCJuZXciLCJjb25maXJtIiwic2V0dGluZ3NTdWNjZXNzIiwic2V0U2V0dGluZ3NTdWNjZXNzIiwiY2FyZHMiLCJzZXRDYXJkcyIsImJhbGFuY2UiLCJob2xkZXIiLCJudW1iZXIiLCJleHBpcnkiLCJ0cmFuc2FjdGlvbnMiLCJzZXRUcmFuc2FjdGlvbnMiLCJkZXNjIiwiZGF0ZSIsIm1ldGhvZCIsImNhdGVnb3J5IiwiYW1vdW50Iiwic3RhdHVzIiwic2VydmljZXMiLCJzZXRTZXJ2aWNlcyIsInRpdGxlIiwiZW5hYmxlZCIsImNvbG9yIiwiaWNvbk5hbWUiLCJpY29uTWFwIiwibG9hbnMiLCJzZXRMb2FucyIsImluc3RhbGxtZW50IiwiZHVyYXRpb24iLCJzZXRJdGVtIiwic3RyaW5naWZ5IiwiZmV0Y2hVc2VycyIsInJlc3BvbnNlIiwiZmV0Y2giLCJoZWFkZXJzIiwib2siLCJkYXRhIiwianNvbiIsImNvbnNvbGUiLCJlcnJvciIsImVyciIsImhhbmRsZVVwZGF0ZVBlcm1pc3Npb25zIiwidXNlcklkIiwidXBkYXRlZFJvbGUiLCJ1cGRhdGVkUGVybWlzc2lvbnMiLCJib2R5IiwiYWxlcnQiLCJtZXNzYWdlIiwidXBkYXRlZFVzZXIiLCJwcmV2IiwiRGF0ZSIsIm5vdyIsIm9wZW5Vc2VyUGVybWlzc2lvbnNNb2RhbCIsInVzZXIiLCJuZXdDYXJkRm9ybSIsInNldE5ld0NhcmRGb3JtIiwibG9hbkNhbGMiLCJzZXRMb2FuQ2FsYyIsInJhdGUiLCJ0ZXJtIiwib3V0cHV0IiwidHJhbnNmZXJBbW91bnQiLCJzZXRUcmFuc2ZlckFtb3VudCIsInRyYW5zZmVyU3VjY2VzcyIsInNldFRyYW5zZmVyU3VjY2VzcyIsInNlbGVjdGVkVXNlckluZGV4Iiwic2V0U2VsZWN0ZWRVc2VySW5kZXgiLCJ0eE1vZGFsT3BlbiIsInNldFR4TW9kYWxPcGVuIiwiZWRpdGluZ1R4Iiwic2V0RWRpdGluZ1R4IiwidHhGb3JtIiwic2V0VHhGb3JtIiwidG9JU09TdHJpbmciLCJzcGxpdCIsImNhcmRNb2RhbE9wZW4iLCJzZXRDYXJkTW9kYWxPcGVuIiwiZWRpdGluZ0NhcmQiLCJzZXRFZGl0aW5nQ2FyZCIsImNhcmRGb3JtIiwic2V0Q2FyZEZvcm0iLCJsb2dvdXQiLCJjb250ZXh0TG9nb3V0IiwiaGFuZGxlTG9nb3V0IiwiaGFuZGxlUXVpY2tUcmFuc2ZlciIsImUiLCJwcmV2ZW50RGVmYXVsdCIsImFtdCIsInBhcnNlRmxvYXQiLCJpc05hTiIsImxlbmd0aCIsInJlY2lwaWVudCIsInVwZGF0ZWRDYXJkcyIsIm5ld1R4IiwiTWF0aCIsImZsb29yIiwicmFuZG9tIiwidG9Mb2NhbGVTdHJpbmciLCJzZXRUaW1lb3V0Iiwib3BlblR4Q3JlYXRlTW9kYWwiLCJvcGVuVHhFZGl0TW9kYWwiLCJ0eCIsInRvU3RyaW5nIiwiaGFuZGxlVHhTdWJtaXQiLCJ0IiwiaGFuZGxlRGVsZXRlVHgiLCJ0eElkIiwid2luZG93IiwiZmlsdGVyIiwiaGFuZGxlQWRkQ2FyZCIsIm5ld0NhcmQiLCJyZXBsYWNlIiwidHJpbSIsIm9wZW5DYXJkRWRpdE1vZGFsIiwiY2FyZCIsImhhbmRsZUNhcmRVcGRhdGVTdWJtaXQiLCJjIiwiaGFuZGxlRGVsZXRlQ2FyZCIsImNhcmRJZCIsImNhbGN1bGF0ZUxvYW4iLCJQIiwiciIsInBhcnNlSW50IiwibW9udGhseUluc3RhbGxtZW50IiwicG93IiwidG9GaXhlZCIsInRvZ2dsZVNlcnZpY2UiLCJzcnZJZCIsInNydiIsImhhbmRsZVByb2ZpbGVTYXZlIiwiaGFuZGxlU2VjdXJpdHlTYXZlIiwibWVudUl0ZW1zIiwiaXRlbSIsIkljb24iLCJpY29uIiwidGFyZ2V0IiwidmFsdWUiLCJzbGljZSIsImhlaWdodCIsImRpc3BsYXkiLCJncmlkVGVtcGxhdGVDb2x1bW5zIiwiZ2FwIiwibWFyZ2luVG9wIiwicGFkZGluZyIsImJhY2tncm91bmQiLCJmb250U2l6ZSIsImZvbnRXZWlnaHQiLCJpZHgiLCJvcGFjaXR5IiwiY3Vyc29yIiwicG9pbnRlckV2ZW50cyIsImJvcmRlclJhZGl1cyIsInRleHRBbGlnbiIsImJvcmRlciIsImFuaW1hdGlvbiIsIm1hcmdpbkJvdHRvbSIsImJvcmRlckJvdHRvbSIsIm1hcmdpbiIsIm1hcmdpblJpZ2h0IiwidmVydGljYWxBbGlnbiIsImluY2x1ZGVzIiwiYWxpZ25JdGVtcyIsIndpZHRoIiwidHJhbnNmb3JtIiwicmVkdWNlIiwiYWNjIiwianVzdGlmeUNvbnRlbnQiLCJtaW5IZWlnaHQiLCJncmlkQ29sdW1uIiwibG9hbiIsImZsZXhEaXJlY3Rpb24iLCJTcnZJY29uIiwicGFkZGluZ0JvdHRvbSIsIm5ld0F2YXRhciIsInByb21wdCIsImNoYXJBdCIsInRvVXBwZXJDYXNlIiwiZmxleFdyYXAiLCJPYmplY3QiLCJlbnRyaWVzIiwia2V5IiwidmFsIiwibmV3QmFsYW5jZSIsIm5ld05vdGlmaWNhdGlvbiIsInN0b3BQcm9wYWdhdGlvbiIsIm1heFdpZHRoIiwibmV3Um9sZSIsIm5ld1Blcm1pc3Npb25zIiwiY2hlY2tlZCIsImJvcmRlclRvcCIsInBhZGRpbmdUb3AiLCJfYyJdLCJzb3VyY2VzIjpbIkRhc2hib2FyZC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vQXBwJztcbmltcG9ydCB7IFxuICBMYXlvdXREYXNoYm9hcmQsIFxuICBBcnJvd0xlZnRSaWdodCwgXG4gIFVzZXIsIFxuICBVc2VycyxcbiAgTGluZUNoYXJ0LCBcbiAgQ3JlZGl0Q2FyZCwgXG4gIEhhbmRDb2lucywgXG4gIFdyZW5jaCwgXG4gIExpZ2h0YnVsYiwgXG4gIFNldHRpbmdzLCBcbiAgTG9nT3V0LCBcbiAgQmVsbCwgXG4gIFNlYXJjaCwgXG4gIFNlbmQsIFxuICBDaGV2cm9uUmlnaHQsXG4gIFBsdXMsXG4gIFRyZW5kaW5nVXAsXG4gIERvbGxhclNpZ24sXG4gIEJyaWVmY2FzZSxcbiAgU2hpZWxkQ2hlY2ssXG4gIFNtYXJ0cGhvbmUsXG4gIFNwYXJrbGVzLFxuICBMb2NrLFxuICBFZGl0MixcbiAgVHJhc2gyLFxuICBHbG9iZSxcbiAgWCxcbiAgU2NhblxufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IFFyU2Nhbm5lclRhYiBmcm9tICcuL1FyU2Nhbm5lclRhYic7XG5pbXBvcnQgJy4uL2Rhc2hib2FyZC5jc3MnO1xuXG5jb25zdCBxdWlja1RyYW5zZmVyVXNlcnMgPSBbXG4gIHtcbiAgICBuYW1lOiAnTGl2aWEgQmF0b3InLFxuICAgIHJvbGU6ICdDRU8nLFxuICAgIGF2YXRhcjogJ2h0dHBzOi8vaW1hZ2VzLnVuc3BsYXNoLmNvbS9waG90by0xNTQ0MDA1MzEzLTk0ZGRmMDI4NmRmMj93PTEyMCZoPTEyMCZmaXQ9Y3JvcCdcbiAgfSxcbiAge1xuICAgIG5hbWU6ICdSYW5keSBQcmVzcycsXG4gICAgcm9sZTogJ0RpcmVjdG9yJyxcbiAgICBhdmF0YXI6ICdodHRwczovL2ltYWdlcy51bnNwbGFzaC5jb20vcGhvdG8tMTUwNjc5NDc3ODIwMi1jYWQ4NGNmNDVmMWQ/dz0xMjAmaD0xMjAmZml0PWNyb3AnXG4gIH0sXG4gIHtcbiAgICBuYW1lOiAnV29ya3UgTWVsZXNlJyxcbiAgICByb2xlOiAnRGVzaWduZXInLFxuICAgIGF2YXRhcjogJ2h0dHBzOi8vaW1hZ2VzLnVuc3BsYXNoLmNvbS9waG90by0xNTA3MDAzMjExMTY5LTBhMWRkNzIyOGYyZD93PTEyMCZoPTEyMCZmaXQ9Y3JvcCdcbiAgfSxcbiAge1xuICAgIG5hbWU6ICdLZXZpbiBQZXRlcnNvbicsXG4gICAgcm9sZTogJ0RldmVsb3BlcicsXG4gICAgYXZhdGFyOiAnaHR0cHM6Ly9pbWFnZXMudW5zcGxhc2guY29tL3Bob3RvLTE0OTI1NjIwODAwMjMtYWIzZGI5NWJmYmNlP3c9MTIwJmg9MTIwJmZpdD1jcm9wJ1xuICB9XG5dO1xuXG5jb25zdCBEYXNoYm9hcmQgPSAoKSA9PiB7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgXG4gIC8vIDEuIEdldCBMb2dnZWQtaW4gVXNlciBTZXNzaW9uIERldGFpbHMgd2l0aCBsZWdhY3kgY29tcGF0aWJpbGl0eVxuICBjb25zdCB1c2VyU2Vzc2lvbiA9ICgoKSA9PiB7XG4gICAgY29uc3QgcmF3ID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3VzZXInKTtcbiAgICBpZiAoIXJhdykge1xuICAgICAgcmV0dXJuIHsgXG4gICAgICAgIG5hbWU6ICdKb2huIERvZScsIFxuICAgICAgICBlbWFpbDogJ2pvaG4uZG9lQGdtYWlsLmNvbScsXG4gICAgICAgIHJvbGU6ICdWaWV3ZXInLFxuICAgICAgICBwZXJtaXNzaW9uczoge1xuICAgICAgICAgIHZpZXdfZGFzaGJvYXJkOiB0cnVlLFxuICAgICAgICAgIG1hbmFnZV90eDogZmFsc2UsXG4gICAgICAgICAgbWFuYWdlX2NhcmRzOiBmYWxzZSxcbiAgICAgICAgICBtYW5hZ2VfbG9hbnM6IGZhbHNlLFxuICAgICAgICAgIG1hbmFnZV9zZXJ2aWNlczogZmFsc2UsXG4gICAgICAgICAgbWFuYWdlX3VzZXJzOiBmYWxzZVxuICAgICAgICB9XG4gICAgICB9O1xuICAgIH1cbiAgICBjb25zdCBwYXJzZWQgPSBKU09OLnBhcnNlKHJhdyk7XG4gICAgY29uc3QgZW1haWxMb3dlciA9IChwYXJzZWQuZW1haWwgfHwgJycpLnRvTG93ZXJDYXNlKCk7XG4gICAgY29uc3QgaXNBZG1pbiA9IGVtYWlsTG93ZXIgPT09ICdhZG1pbkBnbWFpbC5jb20nO1xuICAgIHJldHVybiB7XG4gICAgICAuLi5wYXJzZWQsXG4gICAgICByb2xlOiBwYXJzZWQucm9sZSB8fCAoaXNBZG1pbiA/ICdBZG1pbicgOiAnVmlld2VyJyksXG4gICAgICBwZXJtaXNzaW9uczogcGFyc2VkLnBlcm1pc3Npb25zIHx8IHtcbiAgICAgICAgdmlld19kYXNoYm9hcmQ6IHRydWUsXG4gICAgICAgIG1hbmFnZV90eDogaXNBZG1pbixcbiAgICAgICAgbWFuYWdlX2NhcmRzOiBpc0FkbWluLFxuICAgICAgICBtYW5hZ2VfbG9hbnM6IGlzQWRtaW4sXG4gICAgICAgIG1hbmFnZV9zZXJ2aWNlczogaXNBZG1pbixcbiAgICAgICAgbWFuYWdlX3VzZXJzOiBpc0FkbWluXG4gICAgICB9XG4gICAgfTtcbiAgfSkoKTtcbiAgXG4gIC8vIFN0b3JhZ2UgS2V5cyBzY29wZWQgdG8gdGhlIGN1cnJlbnQgdXNlcidzIGVtYWlsXG4gIGNvbnN0IENBUkRTX0tFWSA9IGBiYW5rZGFzaF9jYXJkc18ke3VzZXJTZXNzaW9uLmVtYWlsLnRvTG93ZXJDYXNlKCl9YDtcbiAgY29uc3QgVFhTX0tFWSA9IGBiYW5rZGFzaF90eHNfJHt1c2VyU2Vzc2lvbi5lbWFpbC50b0xvd2VyQ2FzZSgpfWA7XG4gIGNvbnN0IFBST0ZJTEVfS0VZID0gYGJhbmtkYXNoX3Byb2ZpbGVfJHt1c2VyU2Vzc2lvbi5lbWFpbC50b0xvd2VyQ2FzZSgpfWA7XG4gIGNvbnN0IFNFUlZJQ0VTX0tFWSA9IGBiYW5rZGFzaF9zZXJ2aWNlc18ke3VzZXJTZXNzaW9uLmVtYWlsLnRvTG93ZXJDYXNlKCl9YDtcbiAgY29uc3QgTE9BTlNfS0VZID0gYGJhbmtkYXNoX2xvYW5zXyR7dXNlclNlc3Npb24uZW1haWwudG9Mb3dlckNhc2UoKX1gO1xuXG4gIC8vIDIuIE5hdmlnYXRpb24gU3RhdGVcbiAgY29uc3QgW2FjdGl2ZVRhYiwgc2V0QWN0aXZlVGFiXSA9IHVzZVN0YXRlKCgpID0+IHtcbiAgICBjb25zdCBzYXZlZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKCdkYXNoYm9hcmRfYWN0aXZlX3RhYicpO1xuICAgIGlmIChzYXZlZCkge1xuICAgICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oJ2Rhc2hib2FyZF9hY3RpdmVfdGFiJyk7XG4gICAgICByZXR1cm4gc2F2ZWQ7XG4gICAgfVxuICAgIHJldHVybiAnRGFzaGJvYXJkJztcbiAgfSk7XG4gIGNvbnN0IFtzZXR0aW5nc1N1YlRhYiwgc2V0U2V0dGluZ3NTdWJUYWJdID0gdXNlU3RhdGUoJ0VkaXQgUHJvZmlsZScpO1xuICBcbiAgLy8gU2VhcmNoIHN0YXRlIGZvciB0cmFuc2FjdGlvbnMgcGFnZVxuICBjb25zdCBbc2VhcmNoUXVlcnksIHNldFNlYXJjaFF1ZXJ5XSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3RyYW5zYWN0aW9uVHlwZUZpbHRlciwgc2V0VHJhbnNhY3Rpb25UeXBlRmlsdGVyXSA9IHVzZVN0YXRlKCdBbGwnKTtcblxuICAvLyAzLiBVc2VyIE1hbmFnZW1lbnQgU3RhdGVzXG4gIGNvbnN0IFt1c2Vycywgc2V0VXNlcnNdID0gdXNlU3RhdGUoW10pO1xuICBjb25zdCBbdXNlck1vZGFsT3Blbiwgc2V0VXNlck1vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtlZGl0aW5nVXNlciwgc2V0RWRpdGluZ1VzZXJdID0gdXNlU3RhdGUobnVsbCk7XG4gIGNvbnN0IFt1c2VyRm9ybSwgc2V0VXNlckZvcm1dID0gdXNlU3RhdGUoe1xuICAgIHJvbGU6ICdWaWV3ZXInLFxuICAgIHBlcm1pc3Npb25zOiB7XG4gICAgICB2aWV3X2Rhc2hib2FyZDogdHJ1ZSxcbiAgICAgIG1hbmFnZV90eDogZmFsc2UsXG4gICAgICBtYW5hZ2VfY2FyZHM6IGZhbHNlLFxuICAgICAgbWFuYWdlX2xvYW5zOiBmYWxzZSxcbiAgICAgIG1hbmFnZV9zZXJ2aWNlczogZmFsc2UsXG4gICAgICBtYW5hZ2VfdXNlcnM6IGZhbHNlXG4gICAgfVxuICB9KTtcblxuICAvLyAzYi4gTm90aWZpY2F0aW9ucyBTdGF0ZVxuICBjb25zdCBbbm90aWZpY2F0aW9ucywgc2V0Tm90aWZpY2F0aW9uc10gPSB1c2VTdGF0ZSgoKSA9PiB7XG4gICAgY29uc3QgaXNBZG1pbiA9IHVzZXJTZXNzaW9uLnJvbGUgPT09ICdBZG1pbic7XG4gICAgaWYgKGlzQWRtaW4pIHtcbiAgICAgIHJldHVybiBbXG4gICAgICAgIHsgaWQ6IDEsIHRleHQ6IFwiU3lzdGVtIEFsZXJ0OiAzIHBsYXRmb3JtIHVzZXJzIHJlZ2lzdGVyZWQgZGF0YWJhc2Ugc3luY2VkLlwiLCB0aW1lOiBcIkp1c3Qgbm93XCIsIHR5cGU6IFwic3VjY2Vzc1wiLCB1bnJlYWQ6IHRydWUgfSxcbiAgICAgICAgeyBpZDogMiwgdGV4dDogXCJSb2xlIHNldHRpbmdzIGFkanVzdGVkIGZvciAnVGVzdCBVc2VyJyAoVmlld2VyIHByaXZpbGVnZXMpLlwiLCB0aW1lOiBcIjUgbWlucyBhZ29cIiwgdHlwZTogXCJpbmZvXCIsIHVucmVhZDogdHJ1ZSB9LFxuICAgICAgICB7IGlkOiAzLCB0ZXh0OiBcIk5ldyBjb250YWN0IHF1ZXJ5IHJlY2VpdmVkIGZyb20gJ1NhcmFoIEplbmtpbnMnLlwiLCB0aW1lOiBcIjEgaG91ciBhZ29cIiwgdHlwZTogXCJ3YXJuaW5nXCIsIHVucmVhZDogdHJ1ZSB9XG4gICAgICBdO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gW1xuICAgICAgICB7IGlkOiAxLCB0ZXh0OiBcIlNlY3VyaXR5IE5vdGljZTogT25saW5lIEJhbmtpbmcgTUZBIGlzIG9wZXJhdGlvbmFsLlwiLCB0aW1lOiBcIjIgbWlucyBhZ29cIiwgdHlwZTogXCJzdWNjZXNzXCIsIHVucmVhZDogdHJ1ZSB9LFxuICAgICAgICB7IGlkOiAyLCB0ZXh0OiBcIlJvbGUgbGltaXRzIGNvbmZpZ3VyZWQ6IEFjY291bnQgVmlld2VyIG1vZGUgYWN0aXZhdGVkLlwiLCB0aW1lOiBcIjEwIG1pbnMgYWdvXCIsIHR5cGU6IFwiaW5mb1wiLCB1bnJlYWQ6IHRydWUgfSxcbiAgICAgICAgeyBpZDogMywgdGV4dDogXCJXZWxjb21lIHRvIEJhbmtEYXNoISBDdXN0b21pemUgeW91ciBwcm9maWxlIGF2YXRhci5cIiwgdGltZTogXCIxIGRheSBhZ29cIiwgdHlwZTogXCJpbmZvXCIsIHVucmVhZDogZmFsc2UgfVxuICAgICAgXTtcbiAgICB9XG4gIH0pO1xuICBjb25zdCBbbm90aWZpY2F0aW9uc09wZW4sIHNldE5vdGlmaWNhdGlvbnNPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICBjb25zdCBoYW5kbGVNYXJrQWxsUmVhZCA9ICgpID0+IHtcbiAgICBzZXROb3RpZmljYXRpb25zKG5vdGlmaWNhdGlvbnMubWFwKG4gPT4gKHsgLi4ubiwgdW5yZWFkOiBmYWxzZSB9KSkpO1xuICB9O1xuXG4gIC8vIDQuIFByb2ZpbGUgU3RhdGVcbiAgY29uc3QgW3Byb2ZpbGUsIHNldFByb2ZpbGVdID0gdXNlU3RhdGUoKCkgPT4ge1xuICAgIGNvbnN0IHNhdmVkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oUFJPRklMRV9LRVkpO1xuICAgIGlmIChzYXZlZCkgcmV0dXJuIEpTT04ucGFyc2Uoc2F2ZWQpO1xuICAgIHJldHVybiB7XG4gICAgICBuYW1lOiB1c2VyU2Vzc2lvbi5uYW1lIHx8ICdKb2huIERvZScsXG4gICAgICBlbWFpbDogdXNlclNlc3Npb24uZW1haWwgfHwgJ2pvaG4uZG9lQGdtYWlsLmNvbScsXG4gICAgICBwaG9uZTogJysxICg1NTUpIDAxOS0yODM0JyxcbiAgICAgIGRvYjogJzE5OTUtMDgtMTInLFxuICAgICAgYWRkcmVzczogJzg4IFRlY2ggQm91bGV2YXJkLCBTaWxpY29uIFZhbGxleSwgQ0EnLFxuICAgICAgYXZhdGFyOiAnaHR0cHM6Ly9pbWFnZXMudW5zcGxhc2guY29tL3Bob3RvLTE1MzQ1Mjg3NDE3NzUtNTM5OTRhNjlkYWViP3c9MTIwJmg9MTIwJmZpdD1jcm9wJ1xuICAgIH07XG4gIH0pO1xuXG4gIC8vIFNldHRpbmdzIEZvcm1zIFRlbXAgU3RhdGVzXG4gIGNvbnN0IFt0ZW1wUHJvZmlsZSwgc2V0VGVtcFByb2ZpbGVdID0gdXNlU3RhdGUoeyAuLi5wcm9maWxlIH0pO1xuICBjb25zdCBbcGFzc3dvcmRGb3JtLCBzZXRQYXNzd29yZEZvcm1dID0gdXNlU3RhdGUoeyBjdXJyZW50OiAnJywgbmV3OiAnJywgY29uZmlybTogJycgfSk7XG4gIGNvbnN0IFtzZXR0aW5nc1N1Y2Nlc3MsIHNldFNldHRpbmdzU3VjY2Vzc10gPSB1c2VTdGF0ZSgnJyk7XG5cbiAgLy8gNC4gQ2FyZHMgU3RhdGVcbiAgY29uc3QgW2NhcmRzLCBzZXRDYXJkc10gPSB1c2VTdGF0ZSgoKSA9PiB7XG4gICAgY29uc3Qgc2F2ZWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShDQVJEU19LRVkpO1xuICAgIGlmIChzYXZlZCkgcmV0dXJuIEpTT04ucGFyc2Uoc2F2ZWQpO1xuICAgIHJldHVybiBbXG4gICAgICB7IGlkOiAxLCBiYWxhbmNlOiA1NzU2LCBob2xkZXI6IHVzZXJTZXNzaW9uLm5hbWUgfHwgJ0pvaG4gRG9lJywgbnVtYmVyOiAnMzc3OCAqKioqICoqKiogMTIzNCcsIGV4cGlyeTogJzEyLzI4JywgdHlwZTogJ2RhcmsnIH0sXG4gICAgICB7IGlkOiAyLCBiYWxhbmNlOiAzNTAyLCBob2xkZXI6IHVzZXJTZXNzaW9uLm5hbWUgfHwgJ0pvaG4gRG9lJywgbnVtYmVyOiAnNDUzMiAqKioqICoqKiogNTY3OCcsIGV4cGlyeTogJzA2LzI3JywgdHlwZTogJ2xpZ2h0JyB9LFxuICAgICAgeyBpZDogMywgYmFsYW5jZTogODIxMCwgaG9sZGVyOiB1c2VyU2Vzc2lvbi5uYW1lIHx8ICdKb2huIERvZScsIG51bWJlcjogJzU0MTIgKioqKiAqKioqIDkwMTInLCBleHBpcnk6ICcxMC8yOScsIHR5cGU6ICdwdXJwbGUnIH0sXG4gICAgICB7IGlkOiA0LCBiYWxhbmNlOiAxNDIwLCBob2xkZXI6IHVzZXJTZXNzaW9uLm5hbWUgfHwgJ0pvaG4gRG9lJywgbnVtYmVyOiAnMzc5OSAqKioqICoqKiogMzQ1NicsIGV4cGlyeTogJzA0LzI2JywgdHlwZTogJ2dyZWVuJyB9XG4gICAgXTtcbiAgfSk7XG5cbiAgLy8gNS4gVHJhbnNhY3Rpb25zIFN0YXRlXG4gIGNvbnN0IFt0cmFuc2FjdGlvbnMsIHNldFRyYW5zYWN0aW9uc10gPSB1c2VTdGF0ZSgoKSA9PiB7XG4gICAgY29uc3Qgc2F2ZWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShUWFNfS0VZKTtcbiAgICBpZiAoc2F2ZWQpIHJldHVybiBKU09OLnBhcnNlKHNhdmVkKTtcbiAgICByZXR1cm4gW1xuICAgICAgeyBpZDogJ1RYMDAxJywgZGVzYzogJ0RlcG9zaXQgZnJvbSBDYXJkJywgZGF0ZTogJzIwMjEtMDEtMjgnLCB0eXBlOiAnaW5jb21lJywgbWV0aG9kOiAnQ2FyZCcsIGNhdGVnb3J5OiAnRGVwb3NpdCcsIGFtb3VudDogODUwLCBzdGF0dXM6ICdTdWNjZXNzJyB9LFxuICAgICAgeyBpZDogJ1RYMDAyJywgZGVzYzogJ0RlcG9zaXQgUGF5cGFsJywgZGF0ZTogJzIwMjEtMDEtMjUnLCB0eXBlOiAnaW5jb21lJywgbWV0aG9kOiAnUGF5cGFsJywgY2F0ZWdvcnk6ICdEZXBvc2l0JywgYW1vdW50OiAyNTAwLCBzdGF0dXM6ICdTdWNjZXNzJyB9LFxuICAgICAgeyBpZDogJ1RYMDAzJywgZGVzYzogJ0plbWkgV2lsc29uJywgZGF0ZTogJzIwMjEtMDEtMjEnLCB0eXBlOiAnaW5jb21lJywgbWV0aG9kOiAnV2lyZSBUcmFuc2ZlcicsIGNhdGVnb3J5OiAnVHJhbnNmZXInLCBhbW91bnQ6IDU0MDAsIHN0YXR1czogJ1N1Y2Nlc3MnIH0sXG4gICAgICB7IGlkOiAnVFgwMDQnLCBkZXNjOiAnU3BvdGlmeSBQcmVtaXVtJywgZGF0ZTogJzIwMjEtMDEtMTknLCB0eXBlOiAnZXhwZW5zZScsIG1ldGhvZDogJ0NhcmQnLCBjYXRlZ29yeTogJ0VudGVydGFpbm1lbnQnLCBhbW91bnQ6IDE1LCBzdGF0dXM6ICdTdWNjZXNzJyB9LFxuICAgICAgeyBpZDogJ1RYMDA1JywgZGVzYzogJ05ldGZsaXggU3Vic2NyaXB0aW9uJywgZGF0ZTogJzIwMjEtMDEtMTUnLCB0eXBlOiAnZXhwZW5zZScsIG1ldGhvZDogJ1BheXBhbCcsIGNhdGVnb3J5OiAnRW50ZXJ0YWlubWVudCcsIGFtb3VudDogMjAsIHN0YXR1czogJ1N1Y2Nlc3MnIH0sXG4gICAgICB7IGlkOiAnVFgwMDYnLCBkZXNjOiAnU2FsYXJ5IFBheW1lbnQnLCBkYXRlOiAnMjAyMS0wMS0wMScsIHR5cGU6ICdpbmNvbWUnLCBtZXRob2Q6ICdXaXJlIFRyYW5zZmVyJywgY2F0ZWdvcnk6ICdTYWxhcnknLCBhbW91bnQ6IDgwMDAsIHN0YXR1czogJ1N1Y2Nlc3MnIH0sXG4gICAgICB7IGlkOiAnVFgwMDcnLCBkZXNjOiAnQW1hem9uIFB1cmNoYXNlJywgZGF0ZTogJzIwMjAtMTItMjgnLCB0eXBlOiAnZXhwZW5zZScsIG1ldGhvZDogJ0NhcmQnLCBjYXRlZ29yeTogJ1Nob3BwaW5nJywgYW1vdW50OiAxMjAsIHN0YXR1czogJ1BlbmRpbmcnIH0sXG4gICAgICB7IGlkOiAnVFgwMDgnLCBkZXNjOiAnVWJlciBSaWRlJywgZGF0ZTogJzIwMjAtMTItMjUnLCB0eXBlOiAnZXhwZW5zZScsIG1ldGhvZDogJ0NhcmQnLCBjYXRlZ29yeTogJ1RyYW5zcG9ydCcsIGFtb3VudDogMzUsIHN0YXR1czogJ0ZhaWxlZCcgfSxcbiAgICAgIHsgaWQ6ICdUWDAwOScsIGRlc2M6ICdHb29nbGUgQ2xvdWQgUGxhdGZvcm0nLCBkYXRlOiAnMjAyMC0xMi0yMCcsIHR5cGU6ICdleHBlbnNlJywgbWV0aG9kOiAnQ2FyZCcsIGNhdGVnb3J5OiAnSG9zdGluZycsIGFtb3VudDogMzEyLCBzdGF0dXM6ICdTdWNjZXNzJyB9LFxuICAgICAgeyBpZDogJ1RYMDEwJywgZGVzYzogJ1Vwd29yayBQYXltZW50IFJlY2VpdmVkJywgZGF0ZTogJzIwMjAtMTItMTgnLCB0eXBlOiAnaW5jb21lJywgbWV0aG9kOiAnV2lyZSBUcmFuc2ZlcicsIGNhdGVnb3J5OiAnU2FsYXJ5JywgYW1vdW50OiAxNDUwLCBzdGF0dXM6ICdTdWNjZXNzJyB9LFxuICAgICAgeyBpZDogJ1RYMDExJywgZGVzYzogJ1N0YXJidWNrcyBDb2ZmZWUnLCBkYXRlOiAnMjAyMC0xMi0xNScsIHR5cGU6ICdleHBlbnNlJywgbWV0aG9kOiAnQ2FyZCcsIGNhdGVnb3J5OiAnRm9vZCAmIERpbmluZycsIGFtb3VudDogMTIsIHN0YXR1czogJ1N1Y2Nlc3MnIH0sXG4gICAgICB7IGlkOiAnVFgwMTInLCBkZXNjOiAnT2ZmaWNlIFN1cHBsaWVzIEluYycsIGRhdGU6ICcyMDIwLTEyLTEwJywgdHlwZTogJ2V4cGVuc2UnLCBtZXRob2Q6ICdDYXJkJywgY2F0ZWdvcnk6ICdCdXNpbmVzcycsIGFtb3VudDogODksIHN0YXR1czogJ1N1Y2Nlc3MnIH0sXG4gICAgICB7IGlkOiAnVFgwMTMnLCBkZXNjOiAnQWlyYm5iIEJvb2tpbmcgUmVmdW5kJywgZGF0ZTogJzIwMjAtMTItMDUnLCB0eXBlOiAnaW5jb21lJywgbWV0aG9kOiAnUGF5cGFsJywgY2F0ZWdvcnk6ICdUcmF2ZWwnLCBhbW91bnQ6IDQ1MCwgc3RhdHVzOiAnU3VjY2VzcycgfSxcbiAgICAgIHsgaWQ6ICdUWDAxNCcsIGRlc2M6ICdBZG9iZSBDcmVhdGl2ZSBTdWl0ZScsIGRhdGU6ICcyMDIwLTEyLTAxJywgdHlwZTogJ2V4cGVuc2UnLCBtZXRob2Q6ICdDYXJkJywgY2F0ZWdvcnk6ICdTb2Z0d2FyZScsIGFtb3VudDogNTUsIHN0YXR1czogJ1N1Y2Nlc3MnIH1cbiAgICBdO1xuICB9KTtcblxuICAvLyA2LiBTZXJ2aWNlcyBTdGF0ZVxuICBjb25zdCBbc2VydmljZXMsIHNldFNlcnZpY2VzXSA9IHVzZVN0YXRlKCgpID0+IHtcbiAgICBjb25zdCBzYXZlZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFNFUlZJQ0VTX0tFWSk7XG4gICAgaWYgKHNhdmVkKSByZXR1cm4gSlNPTi5wYXJzZShzYXZlZCk7XG4gICAgcmV0dXJuIFtcbiAgICAgIHsgaWQ6ICdzcnYtMScsIHRpdGxlOiAnT25saW5lIEJhbmtpbmcgU2VjdXJpdHknLCBkZXNjOiAnRW5hYmxlIG11bHRpLWZhY3RvciBhdXRob3JpemF0aW9uIGFuZCBzZWN1cml0eSBub3RpZmljYXRpb25zJywgZW5hYmxlZDogdHJ1ZSwgY29sb3I6ICcjMzk2QUZGJywgaWNvbk5hbWU6ICdTaGllbGRDaGVjaycgfSxcbiAgICAgIHsgaWQ6ICdzcnYtMicsIHRpdGxlOiAnTW9iaWxlIE5vdGlmaWNhdGlvbiBBbGVydHMnLCBkZXNjOiAnR2V0IFNNUyBub3RpZmljYXRpb25zIGZvciBldmVyeSBkZWJpdCBhbmQgY3JlZGl0IHRyYW5zZmVyJywgZW5hYmxlZDogdHJ1ZSwgY29sb3I6ICcjRkZCQjM4JywgaWNvbk5hbWU6ICdTbWFydHBob25lJyB9LFxuICAgICAgeyBpZDogJ3Nydi0zJywgdGl0bGU6ICdXZWVrbHkgQXV0byBTYXZlJywgZGVzYzogJ0F1dG9tYXRpY2FsbHkgdHJhbnNmZXIgNSUgb2Ygd2Vla2x5IGluY29tZSBpbnRvIHNhdmluZ3MgYWNjb3VudCcsIGVuYWJsZWQ6IGZhbHNlLCBjb2xvcjogJyMxNkRCQUEnLCBpY29uTmFtZTogJ0RvbGxhclNpZ24nIH0sXG4gICAgICB7IGlkOiAnc3J2LTQnLCB0aXRsZTogJ01vbnRobHkgRXhwZW5zZSBSZXBvcnQnLCBkZXNjOiAnUmVjZWl2ZSBpbnRlcmFjdGl2ZSBtb250aGx5IGJyZWFrZG93biBQREYgdmlhIGVtYWlsJywgZW5hYmxlZDogZmFsc2UsIGNvbG9yOiAnI0ZGNEI0QScsIGljb25OYW1lOiAnQnJpZWZjYXNlJyB9LFxuICAgICAgeyBpZDogJ3Nydi01JywgdGl0bGU6ICdUcmF2ZWwgTW9kZSBWZXJpZmljYXRpb24nLCBkZXNjOiAnQWxsb3dzIGdsb2JhbCBwdXJjaGFzZXMgd2l0aG91dCByYWlzaW5nIGZyYXVkIGRldGVjdGlvbiB0cmlnZ2VycycsIGVuYWJsZWQ6IGZhbHNlLCBjb2xvcjogJyNBODU1RjcnLCBpY29uTmFtZTogJ0dsb2JlJyB9LFxuICAgICAgeyBpZDogJ3Nydi02JywgdGl0bGU6ICdDcnlwdG8gQnV5IEFsbG93YW5jZXMnLCBkZXNjOiAnR3JhbnQgd2FsbGV0IHBlcm1pc3Npb24gdG8gZGlyZWN0bHkgaW50ZXJhY3Qgd2l0aCBjcnlwdG8gZ2F0ZXdheXMnLCBlbmFibGVkOiBmYWxzZSwgY29sb3I6ICcjRUM0ODk5JywgaWNvbk5hbWU6ICdDcmVkaXRDYXJkJyB9XG4gICAgXTtcbiAgfSk7XG5cbiAgLy8gSGVscGVyIG1hcCBmb3IgaWNvbnMgaW4gc2VydmljZXNcbiAgY29uc3QgaWNvbk1hcCA9IHtcbiAgICBTaGllbGRDaGVjazogU2hpZWxkQ2hlY2ssXG4gICAgU21hcnRwaG9uZTogU21hcnRwaG9uZSxcbiAgICBEb2xsYXJTaWduOiBEb2xsYXJTaWduLFxuICAgIEJyaWVmY2FzZTogQnJpZWZjYXNlLFxuICAgIEdsb2JlOiBHbG9iZSxcbiAgICBDcmVkaXRDYXJkOiBDcmVkaXRDYXJkXG4gIH07XG5cbiAgLy8gNy4gTG9hbnMgU3RhdGVcbiAgY29uc3QgW2xvYW5zLCBzZXRMb2Fuc10gPSB1c2VTdGF0ZSgoKSA9PiB7XG4gICAgY29uc3Qgc2F2ZWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShMT0FOU19LRVkpO1xuICAgIGlmIChzYXZlZCkgcmV0dXJuIEpTT04ucGFyc2Uoc2F2ZWQpO1xuICAgIHJldHVybiBbXG4gICAgICB7IGlkOiAnTDAwMScsIHR5cGU6ICdQZXJzb25hbCBMb2FuJywgYW1vdW50OiAyMDAwMCwgYmFsYW5jZTogMTI1MDAsIGluc3RhbGxtZW50OiA1NTAsIGR1cmF0aW9uOiAnMzYgTW9udGhzJyB9LFxuICAgICAgeyBpZDogJ0wwMDInLCB0eXBlOiAnQ2FyIExvYW4nLCBhbW91bnQ6IDM1MDAwLCBiYWxhbmNlOiAyODAwMCwgaW5zdGFsbG1lbnQ6IDcyMCwgZHVyYXRpb246ICc2MCBNb250aHMnIH0sXG4gICAgICB7IGlkOiAnTDAwMycsIHR5cGU6ICdIb21lIExvYW4nLCBhbW91bnQ6IDI1MDAwMCwgYmFsYW5jZTogMjM1MDAwLCBpbnN0YWxsbWVudDogMTIwMCwgZHVyYXRpb246ICcyNDAgTW9udGhzJyB9LFxuICAgICAgeyBpZDogJ0wwMDQnLCB0eXBlOiAnRWR1Y2F0aW9uIExvYW4nLCBhbW91bnQ6IDE1MDAwLCBiYWxhbmNlOiA5MjAwLCBpbnN0YWxsbWVudDogMzIwLCBkdXJhdGlvbjogJzQ4IE1vbnRocycgfSxcbiAgICAgIHsgaWQ6ICdMMDA1JywgdHlwZTogJ0J1c2luZXNzIEV4cGFuc2lvbicsIGFtb3VudDogMTIwMDAwLCBiYWxhbmNlOiAxMTAwMDAsIGluc3RhbGxtZW50OiAyNDAwLCBkdXJhdGlvbjogJzYwIE1vbnRocycgfSxcbiAgICAgIHsgaWQ6ICdMMDA2JywgdHlwZTogJ01lZGljYWwgRW1lcmdlbmN5JywgYW1vdW50OiA4MDAwLCBiYWxhbmNlOiAwLCBpbnN0YWxsbWVudDogNDAwLCBkdXJhdGlvbjogJzIwIE1vbnRocycgfVxuICAgIF07XG4gIH0pO1xuXG4gIC8vIFN5bmMgc3RhdGUgY2hhbmdlcyB3aXRoIGxvY2FsU3RvcmFnZVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFBST0ZJTEVfS0VZLCBKU09OLnN0cmluZ2lmeShwcm9maWxlKSk7XG4gIH0sIFtwcm9maWxlLCBQUk9GSUxFX0tFWV0pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oQ0FSRFNfS0VZLCBKU09OLnN0cmluZ2lmeShjYXJkcykpO1xuICB9LCBbY2FyZHMsIENBUkRTX0tFWV0pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oVFhTX0tFWSwgSlNPTi5zdHJpbmdpZnkodHJhbnNhY3Rpb25zKSk7XG4gIH0sIFt0cmFuc2FjdGlvbnMsIFRYU19LRVldKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFNFUlZJQ0VTX0tFWSwgSlNPTi5zdHJpbmdpZnkoc2VydmljZXMpKTtcbiAgfSwgW3NlcnZpY2VzLCBTRVJWSUNFU19LRVldKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKExPQU5TX0tFWSwgSlNPTi5zdHJpbmdpZnkobG9hbnMpKTtcbiAgfSwgW2xvYW5zLCBMT0FOU19LRVldKTtcblxuICAvLyBTeW5jIHByb2ZpbGUgZGV0YWlscyBpZiBjaGFuZ2VkIGVsc2V3aGVyZVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHNldFRlbXBQcm9maWxlKHsgLi4ucHJvZmlsZSB9KTtcbiAgfSwgW3Byb2ZpbGVdKTtcblxuICAvLyBVcGdyYWRlIGxlZ2FjeSBzZXNzaW9uIGRldGFpbHMgaW4gbG9jYWxTdG9yYWdlIGlmIG5lZWRlZFxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IHJhdyA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKCd1c2VyJyk7XG4gICAgaWYgKHJhdykge1xuICAgICAgY29uc3QgcGFyc2VkID0gSlNPTi5wYXJzZShyYXcpO1xuICAgICAgaWYgKCFwYXJzZWQucm9sZSB8fCAhcGFyc2VkLnBlcm1pc3Npb25zKSB7XG4gICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCd1c2VyJywgSlNPTi5zdHJpbmdpZnkodXNlclNlc3Npb24pKTtcbiAgICAgIH1cbiAgICB9XG4gIH0sIFt1c2VyU2Vzc2lvbl0pO1xuXG4gIGNvbnN0IGZldGNoVXNlcnMgPSBhc3luYyAoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goJ2h0dHA6Ly9sb2NhbGhvc3Q6NTAwMC9hcGkvdXNlcnMnLCB7XG4gICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAneC11c2VyLXJvbGUnOiB1c2VyU2Vzc2lvbi5yb2xlXG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgaWYgKHJlc3BvbnNlLm9rKSB7XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIHNldFVzZXJzKGRhdGEpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc29sZS5lcnJvcignRmFpbGVkIHRvIGZldGNoIHVzZXJzJyk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBmZXRjaGluZyB1c2VyczonLCBlcnIpO1xuICAgIH1cbiAgfTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChhY3RpdmVUYWIgPT09ICdVc2VyIERldGFpbHMnKSB7XG4gICAgICBmZXRjaFVzZXJzKCk7XG4gICAgfVxuICB9LCBbYWN0aXZlVGFiXSk7XG5cbiAgY29uc3QgaGFuZGxlVXBkYXRlUGVybWlzc2lvbnMgPSBhc3luYyAodXNlcklkLCB1cGRhdGVkUm9sZSwgdXBkYXRlZFBlcm1pc3Npb25zKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYGh0dHA6Ly9sb2NhbGhvc3Q6NTAwMC9hcGkvdXNlcnMvJHt1c2VySWR9L3Blcm1pc3Npb25zYCwge1xuICAgICAgICBtZXRob2Q6ICdQVVQnLFxuICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgICAneC11c2VyLXJvbGUnOiB1c2VyU2Vzc2lvbi5yb2xlXG4gICAgICAgIH0sXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICByb2xlOiB1cGRhdGVkUm9sZSxcbiAgICAgICAgICBwZXJtaXNzaW9uczogdXBkYXRlZFBlcm1pc3Npb25zXG4gICAgICAgIH0pXG4gICAgICB9KTtcblxuICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICAgIGlmIChyZXNwb25zZS5vaykge1xuICAgICAgICBhbGVydChkYXRhLm1lc3NhZ2UgfHwgJ1Blcm1pc3Npb25zIHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5IScpO1xuICAgICAgICBpZiAodXNlcklkID09PSB1c2VyU2Vzc2lvbi5pZCkge1xuICAgICAgICAgIGNvbnN0IHVwZGF0ZWRVc2VyID0geyAuLi51c2VyU2Vzc2lvbiwgcm9sZTogdXBkYXRlZFJvbGUsIHBlcm1pc3Npb25zOiB1cGRhdGVkUGVybWlzc2lvbnMgfTtcbiAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgndXNlcicsIEpTT04uc3RyaW5naWZ5KHVwZGF0ZWRVc2VyKSk7XG4gICAgICAgIH1cbiAgICAgICAgc2V0Tm90aWZpY2F0aW9ucyhwcmV2ID0+IFtcbiAgICAgICAgICB7IGlkOiBEYXRlLm5vdygpLCB0ZXh0OiBgUm9sZSAmIGFjY2VzcyByaWdodHMgdXBkYXRlZCBmb3IgdXNlciAke2VkaXRpbmdVc2VyPy5uYW1lIHx8IHVzZXJJZH0uYCwgdGltZTogXCJKdXN0IG5vd1wiLCB0eXBlOiBcIndhcm5pbmdcIiwgdW5yZWFkOiB0cnVlIH0sXG4gICAgICAgICAgLi4ucHJldlxuICAgICAgICBdKTtcbiAgICAgICAgZmV0Y2hVc2VycygpO1xuICAgICAgICBzZXRVc2VyTW9kYWxPcGVuKGZhbHNlKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGFsZXJ0KGRhdGEuZXJyb3IgfHwgJ0ZhaWxlZCB0byB1cGRhdGUgcGVybWlzc2lvbnMnKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIHVwZGF0aW5nIHBlcm1pc3Npb25zOicsIGVycik7XG4gICAgICBhbGVydCgnRXJyb3IgdXBkYXRpbmcgcGVybWlzc2lvbnMnKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3Qgb3BlblVzZXJQZXJtaXNzaW9uc01vZGFsID0gKHVzZXIpID0+IHtcbiAgICBzZXRFZGl0aW5nVXNlcih1c2VyKTtcbiAgICBzZXRVc2VyRm9ybSh7XG4gICAgICByb2xlOiB1c2VyLnJvbGUsXG4gICAgICBwZXJtaXNzaW9uczogeyAuLi51c2VyLnBlcm1pc3Npb25zIH1cbiAgICB9KTtcbiAgICBzZXRVc2VyTW9kYWxPcGVuKHRydWUpO1xuICB9O1xuXG4gIC8vIENhcmQgQWRkIEZvcm0gU3RhdGVcbiAgY29uc3QgW25ld0NhcmRGb3JtLCBzZXROZXdDYXJkRm9ybV0gPSB1c2VTdGF0ZSh7IGJhbGFuY2U6ICcnLCBob2xkZXI6ICcnLCBudW1iZXI6ICcnLCBleHBpcnk6ICcnLCB0eXBlOiAnZGFyaycgfSk7XG5cbiAgLy8gTG9hbiBDYWxjdWxhdG9yIFN0YXRlXG4gIGNvbnN0IFtsb2FuQ2FsYywgc2V0TG9hbkNhbGNdID0gdXNlU3RhdGUoeyBhbW91bnQ6ICcxMDAwMCcsIHJhdGU6ICc1JywgdGVybTogJzEyJywgb3V0cHV0OiAnODU2LjA3JyB9KTtcblxuICAvLyBRdWljayBUcmFuc2ZlciBXaWRnZXQgU3RhdGVzXG4gIGNvbnN0IFt0cmFuc2ZlckFtb3VudCwgc2V0VHJhbnNmZXJBbW91bnRdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbdHJhbnNmZXJTdWNjZXNzLCBzZXRUcmFuc2ZlclN1Y2Nlc3NdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbc2VsZWN0ZWRVc2VySW5kZXgsIHNldFNlbGVjdGVkVXNlckluZGV4XSA9IHVzZVN0YXRlKDApO1xuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIENSVUQgTU9EQUxTIFNUQVRFU1xuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyBUcmFuc2FjdGlvbiBNb2RhbCBTdGF0ZVxuICBjb25zdCBbdHhNb2RhbE9wZW4sIHNldFR4TW9kYWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2VkaXRpbmdUeCwgc2V0RWRpdGluZ1R4XSA9IHVzZVN0YXRlKG51bGwpOyAvLyBudWxsIGZvciBjcmVhdGUsIG9iamVjdCBmb3IgZWRpdFxuICBjb25zdCBbdHhGb3JtLCBzZXRUeEZvcm1dID0gdXNlU3RhdGUoe1xuICAgIGRlc2M6ICcnLFxuICAgIGFtb3VudDogJycsXG4gICAgdHlwZTogJ2V4cGVuc2UnLFxuICAgIGNhdGVnb3J5OiAnRGVwb3NpdCcsXG4gICAgbWV0aG9kOiAnQ2FyZCcsXG4gICAgZGF0ZTogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KCdUJylbMF0sXG4gICAgc3RhdHVzOiAnU3VjY2VzcydcbiAgfSk7XG5cbiAgLy8gQ3JlZGl0IENhcmQgTW9kYWwgU3RhdGVcbiAgY29uc3QgW2NhcmRNb2RhbE9wZW4sIHNldENhcmRNb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbZWRpdGluZ0NhcmQsIHNldEVkaXRpbmdDYXJkXSA9IHVzZVN0YXRlKG51bGwpO1xuICBjb25zdCBbY2FyZEZvcm0sIHNldENhcmRGb3JtXSA9IHVzZVN0YXRlKHtcbiAgICBiYWxhbmNlOiAnJyxcbiAgICBob2xkZXI6ICcnLFxuICAgIG51bWJlcjogJycsXG4gICAgZXhwaXJ5OiAnJyxcbiAgICB0eXBlOiAnZGFyaydcbiAgfSk7XG5cbiAgY29uc3QgeyBsb2dvdXQ6IGNvbnRleHRMb2dvdXQgfSA9IHVzZUF1dGgoKTtcblxuICBjb25zdCBoYW5kbGVMb2dvdXQgPSAoKSA9PiB7XG4gICAgY29udGV4dExvZ291dCgpO1xuICAgIG5hdmlnYXRlKCcvbG9naW4nKTtcbiAgfTtcblxuICAvLyBBY3Rpb246IFF1aWNrIFRyYW5zZmVyIFN1Ym1pc3Npb25cbiAgY29uc3QgaGFuZGxlUXVpY2tUcmFuc2ZlciA9IChlKSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIGNvbnN0IGFtdCA9IHBhcnNlRmxvYXQodHJhbnNmZXJBbW91bnQpO1xuICAgIGlmICghdHJhbnNmZXJBbW91bnQgfHwgaXNOYU4oYW10KSB8fCBhbXQgPD0gMCkge1xuICAgICAgYWxlcnQoJ1BsZWFzZSBlbnRlciBhIHZhbGlkIHRyYW5zZmVyIGFtb3VudC4nKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAoY2FyZHMubGVuZ3RoID09PSAwKSB7XG4gICAgICBhbGVydCgnWW91IG11c3QgaGF2ZSBhdCBsZWFzdCBvbmUgY3JlZGl0IGNhcmQgdG8gbWFrZSBhIHRyYW5zZmVyLicpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmIChjYXJkc1swXS5iYWxhbmNlIDwgYW10KSB7XG4gICAgICBhbGVydChgSW5zdWZmaWNpZW50IGZ1bmRzIGluIHlvdXIgcHJpbWFyeSAke2NhcmRzWzBdLnR5cGV9IGNhcmQhYCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgcmVjaXBpZW50ID0gcXVpY2tUcmFuc2ZlclVzZXJzW3NlbGVjdGVkVXNlckluZGV4XS5uYW1lO1xuICAgIFxuICAgIC8vIERlZHVjdCBmcm9tIHByaW1hcnkgY2FyZCBiYWxhbmNlXG4gICAgY29uc3QgdXBkYXRlZENhcmRzID0gWy4uLmNhcmRzXTtcbiAgICB1cGRhdGVkQ2FyZHNbMF0uYmFsYW5jZSAtPSBhbXQ7XG4gICAgc2V0Q2FyZHModXBkYXRlZENhcmRzKTtcblxuICAgIC8vIFByZXBlbmQgbmV3IHRyYW5zYWN0aW9uXG4gICAgY29uc3QgbmV3VHggPSB7XG4gICAgICBpZDogYFRYJHtNYXRoLmZsb29yKDEwMCArIE1hdGgucmFuZG9tKCkgKiA5MDApfWAsXG4gICAgICBkZXNjOiBgVHJhbnNmZXIgdG8gJHtyZWNpcGllbnR9YCxcbiAgICAgIGRhdGU6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdCgnVCcpWzBdLFxuICAgICAgdHlwZTogJ2V4cGVuc2UnLFxuICAgICAgbWV0aG9kOiAnUGF5cGFsJyxcbiAgICAgIGNhdGVnb3J5OiAnVHJhbnNmZXInLFxuICAgICAgYW1vdW50OiBhbXQsXG4gICAgICBzdGF0dXM6ICdTdWNjZXNzJ1xuICAgIH07XG4gICAgc2V0VHJhbnNhY3Rpb25zKFtuZXdUeCwgLi4udHJhbnNhY3Rpb25zXSk7XG5cbiAgICBzZXROb3RpZmljYXRpb25zKHByZXYgPT4gW1xuICAgICAgeyBpZDogRGF0ZS5ub3coKSwgdGV4dDogYFF1aWNrIFRyYW5zZmVyIG9mICQke2FtdC50b0xvY2FsZVN0cmluZygpfSB0byAke3JlY2lwaWVudH0gY29tcGxldGVkLmAsIHRpbWU6IFwiSnVzdCBub3dcIiwgdHlwZTogXCJzdWNjZXNzXCIsIHVucmVhZDogdHJ1ZSB9LFxuICAgICAgLi4ucHJldlxuICAgIF0pO1xuXG4gICAgc2V0VHJhbnNmZXJTdWNjZXNzKGBTdWNjZXNzZnVsbHkgc2VudCAkJHthbXQudG9Mb2NhbGVTdHJpbmcoKX0gdG8gJHtyZWNpcGllbnR9IWApO1xuICAgIHNldFRyYW5zZmVyQW1vdW50KCcnKTtcblxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgc2V0VHJhbnNmZXJTdWNjZXNzKCcnKTtcbiAgICB9LCA0MDAwKTtcbiAgfTtcblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyBUUkFOU0FDVElPTiBDUlVEIE9QRVJBVElPTlNcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgY29uc3Qgb3BlblR4Q3JlYXRlTW9kYWwgPSAoKSA9PiB7XG4gICAgc2V0RWRpdGluZ1R4KG51bGwpO1xuICAgIHNldFR4Rm9ybSh7XG4gICAgICBkZXNjOiAnJyxcbiAgICAgIGFtb3VudDogJycsXG4gICAgICB0eXBlOiAnZXhwZW5zZScsXG4gICAgICBjYXRlZ29yeTogJ0RlcG9zaXQnLFxuICAgICAgbWV0aG9kOiAnQ2FyZCcsXG4gICAgICBkYXRlOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXSxcbiAgICAgIHN0YXR1czogJ1N1Y2Nlc3MnXG4gICAgfSk7XG4gICAgc2V0VHhNb2RhbE9wZW4odHJ1ZSk7XG4gIH07XG5cbiAgY29uc3Qgb3BlblR4RWRpdE1vZGFsID0gKHR4KSA9PiB7XG4gICAgc2V0RWRpdGluZ1R4KHR4KTtcbiAgICBzZXRUeEZvcm0oe1xuICAgICAgZGVzYzogdHguZGVzYyxcbiAgICAgIGFtb3VudDogdHguYW1vdW50LnRvU3RyaW5nKCksXG4gICAgICB0eXBlOiB0eC50eXBlLFxuICAgICAgY2F0ZWdvcnk6IHR4LmNhdGVnb3J5LFxuICAgICAgbWV0aG9kOiB0eC5tZXRob2QsXG4gICAgICBkYXRlOiB0eC5kYXRlLFxuICAgICAgc3RhdHVzOiB0eC5zdGF0dXNcbiAgICB9KTtcbiAgICBzZXRUeE1vZGFsT3Blbih0cnVlKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVUeFN1Ym1pdCA9IChlKSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIGlmICghdHhGb3JtLmRlc2MgfHwgIXR4Rm9ybS5hbW91bnQgfHwgaXNOYU4ocGFyc2VGbG9hdCh0eEZvcm0uYW1vdW50KSkpIHtcbiAgICAgIGFsZXJ0KCdQbGVhc2UgZmlsbCBvdXQgYWxsIGZpZWxkcyB3aXRoIHZhbGlkIGRhdGEuJyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgaWYgKGVkaXRpbmdUeCkge1xuICAgICAgLy8gVVBEQVRFXG4gICAgICBzZXRUcmFuc2FjdGlvbnModHJhbnNhY3Rpb25zLm1hcCh0ID0+IHtcbiAgICAgICAgaWYgKHQuaWQgPT09IGVkaXRpbmdUeC5pZCkge1xuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAuLi50LFxuICAgICAgICAgICAgZGVzYzogdHhGb3JtLmRlc2MsXG4gICAgICAgICAgICBhbW91bnQ6IHBhcnNlRmxvYXQodHhGb3JtLmFtb3VudCksXG4gICAgICAgICAgICB0eXBlOiB0eEZvcm0udHlwZSxcbiAgICAgICAgICAgIGNhdGVnb3J5OiB0eEZvcm0uY2F0ZWdvcnksXG4gICAgICAgICAgICBtZXRob2Q6IHR4Rm9ybS5tZXRob2QsXG4gICAgICAgICAgICBkYXRlOiB0eEZvcm0uZGF0ZSxcbiAgICAgICAgICAgIHN0YXR1czogdHhGb3JtLnN0YXR1c1xuICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHQ7XG4gICAgICB9KSk7XG4gICAgICBzZXROb3RpZmljYXRpb25zKHByZXYgPT4gW1xuICAgICAgICB7IGlkOiBEYXRlLm5vdygpLCB0ZXh0OiBgVHJhbnNhY3Rpb24gXCIke3R4Rm9ybS5kZXNjfVwiIHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5LmAsIHRpbWU6IFwiSnVzdCBub3dcIiwgdHlwZTogXCJpbmZvXCIsIHVucmVhZDogdHJ1ZSB9LFxuICAgICAgICAuLi5wcmV2XG4gICAgICBdKTtcbiAgICAgIGFsZXJ0KCdUcmFuc2FjdGlvbiB1cGRhdGVkIHN1Y2Nlc3NmdWxseSEnKTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gQ1JFQVRFXG4gICAgICBjb25zdCBuZXdUeCA9IHtcbiAgICAgICAgaWQ6IGBUWCR7TWF0aC5mbG9vcigxMDAgKyBNYXRoLnJhbmRvbSgpICogOTAwKX1gLFxuICAgICAgICBkZXNjOiB0eEZvcm0uZGVzYyxcbiAgICAgICAgYW1vdW50OiBwYXJzZUZsb2F0KHR4Rm9ybS5hbW91bnQpLFxuICAgICAgICB0eXBlOiB0eEZvcm0udHlwZSxcbiAgICAgICAgY2F0ZWdvcnk6IHR4Rm9ybS5jYXRlZ29yeSxcbiAgICAgICAgbWV0aG9kOiB0eEZvcm0ubWV0aG9kLFxuICAgICAgICBkYXRlOiB0eEZvcm0uZGF0ZSxcbiAgICAgICAgc3RhdHVzOiB0eEZvcm0uc3RhdHVzXG4gICAgICB9O1xuICAgICAgc2V0VHJhbnNhY3Rpb25zKFtuZXdUeCwgLi4udHJhbnNhY3Rpb25zXSk7XG4gICAgICBzZXROb3RpZmljYXRpb25zKHByZXYgPT4gW1xuICAgICAgICB7IGlkOiBEYXRlLm5vdygpLCB0ZXh0OiBgTmV3IHRyYW5zYWN0aW9uIFwiJHt0eEZvcm0uZGVzY31cIiAoJCR7cGFyc2VGbG9hdCh0eEZvcm0uYW1vdW50KS50b0xvY2FsZVN0cmluZygpfSkgY3JlYXRlZC5gLCB0aW1lOiBcIkp1c3Qgbm93XCIsIHR5cGU6IFwic3VjY2Vzc1wiLCB1bnJlYWQ6IHRydWUgfSxcbiAgICAgICAgLi4ucHJldlxuICAgICAgXSk7XG4gICAgICBhbGVydCgnVHJhbnNhY3Rpb24gY3JlYXRlZCBzdWNjZXNzZnVsbHkhJyk7XG4gICAgfVxuICAgIHNldFR4TW9kYWxPcGVuKGZhbHNlKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVEZWxldGVUeCA9ICh0eElkKSA9PiB7XG4gICAgaWYgKHdpbmRvdy5jb25maXJtKCdBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gZGVsZXRlIHRoaXMgdHJhbnNhY3Rpb24/JykpIHtcbiAgICAgIHNldFRyYW5zYWN0aW9ucyh0cmFuc2FjdGlvbnMuZmlsdGVyKHQgPT4gdC5pZCAhPT0gdHhJZCkpO1xuICAgICAgc2V0Tm90aWZpY2F0aW9ucyhwcmV2ID0+IFtcbiAgICAgICAgeyBpZDogRGF0ZS5ub3coKSwgdGV4dDogYFRyYW5zYWN0aW9uIHJlbW92ZWQgc3VjY2Vzc2Z1bGx5LmAsIHRpbWU6IFwiSnVzdCBub3dcIiwgdHlwZTogXCJ3YXJuaW5nXCIsIHVucmVhZDogdHJ1ZSB9LFxuICAgICAgICAuLi5wcmV2XG4gICAgICBdKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gQ1JFRElUIENBUkQgQ1JVRCBPUEVSQVRJT05TXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIGNvbnN0IGhhbmRsZUFkZENhcmQgPSAoZSkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBpZiAoIW5ld0NhcmRGb3JtLmJhbGFuY2UgfHwgIW5ld0NhcmRGb3JtLmhvbGRlciB8fCAhbmV3Q2FyZEZvcm0ubnVtYmVyIHx8ICFuZXdDYXJkRm9ybS5leHBpcnkpIHtcbiAgICAgIGFsZXJ0KCdQbGVhc2UgZmlsbCBvdXQgYWxsIGZpZWxkcyB0byBhZGQgYSBjcmVkaXQgY2FyZC4nKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCBuZXdDYXJkID0ge1xuICAgICAgaWQ6IERhdGUubm93KCksXG4gICAgICBiYWxhbmNlOiBwYXJzZUZsb2F0KG5ld0NhcmRGb3JtLmJhbGFuY2UpIHx8IDAsXG4gICAgICBob2xkZXI6IG5ld0NhcmRGb3JtLmhvbGRlcixcbiAgICAgIG51bWJlcjogbmV3Q2FyZEZvcm0ubnVtYmVyLnJlcGxhY2UoLyhcXGR7NH0pL2csICckMSAnKS50cmltKCksXG4gICAgICBleHBpcnk6IG5ld0NhcmRGb3JtLmV4cGlyeSxcbiAgICAgIHR5cGU6IG5ld0NhcmRGb3JtLnR5cGVcbiAgICB9O1xuXG4gICAgc2V0Q2FyZHMoWy4uLmNhcmRzLCBuZXdDYXJkXSk7XG4gICAgc2V0Tm90aWZpY2F0aW9ucyhwcmV2ID0+IFtcbiAgICAgIHsgaWQ6IERhdGUubm93KCksIHRleHQ6IGBOZXcgY3JlZGl0IGNhcmQgY3JlYXRlZCBmb3IgJHtuZXdDYXJkLmhvbGRlcn0uYCwgdGltZTogXCJKdXN0IG5vd1wiLCB0eXBlOiBcInN1Y2Nlc3NcIiwgdW5yZWFkOiB0cnVlIH0sXG4gICAgICAuLi5wcmV2XG4gICAgXSk7XG4gICAgc2V0TmV3Q2FyZEZvcm0oeyBiYWxhbmNlOiAnJywgaG9sZGVyOiAnJywgbnVtYmVyOiAnJywgZXhwaXJ5OiAnJywgdHlwZTogJ2RhcmsnIH0pO1xuICAgIGFsZXJ0KCdDYXJkIHN1Y2Nlc3NmdWxseSBhZGRlZCEnKTtcbiAgfTtcblxuICBjb25zdCBvcGVuQ2FyZEVkaXRNb2RhbCA9IChjYXJkKSA9PiB7XG4gICAgc2V0RWRpdGluZ0NhcmQoY2FyZCk7XG4gICAgc2V0Q2FyZEZvcm0oe1xuICAgICAgYmFsYW5jZTogY2FyZC5iYWxhbmNlLnRvU3RyaW5nKCksXG4gICAgICBob2xkZXI6IGNhcmQuaG9sZGVyLFxuICAgICAgbnVtYmVyOiBjYXJkLm51bWJlci5yZXBsYWNlKC9cXHMrL2csICcnKSxcbiAgICAgIGV4cGlyeTogY2FyZC5leHBpcnksXG4gICAgICB0eXBlOiBjYXJkLnR5cGVcbiAgICB9KTtcbiAgICBzZXRDYXJkTW9kYWxPcGVuKHRydWUpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUNhcmRVcGRhdGVTdWJtaXQgPSAoZSkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBpZiAoIWNhcmRGb3JtLmhvbGRlciB8fCAhY2FyZEZvcm0uYmFsYW5jZSB8fCAhY2FyZEZvcm0ubnVtYmVyIHx8ICFjYXJkRm9ybS5leHBpcnkpIHtcbiAgICAgIGFsZXJ0KCdQbGVhc2UgZW50ZXIgdmFsaWQgaW5wdXRzLicpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHNldENhcmRzKGNhcmRzLm1hcChjID0+IHtcbiAgICAgIGlmIChjLmlkID09PSBlZGl0aW5nQ2FyZC5pZCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIC4uLmMsXG4gICAgICAgICAgaG9sZGVyOiBjYXJkRm9ybS5ob2xkZXIsXG4gICAgICAgICAgYmFsYW5jZTogcGFyc2VGbG9hdChjYXJkRm9ybS5iYWxhbmNlKSxcbiAgICAgICAgICBudW1iZXI6IGNhcmRGb3JtLm51bWJlci5yZXBsYWNlKC8oXFxkezR9KS9nLCAnJDEgJykudHJpbSgpLFxuICAgICAgICAgIGV4cGlyeTogY2FyZEZvcm0uZXhwaXJ5LFxuICAgICAgICAgIHR5cGU6IGNhcmRGb3JtLnR5cGVcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBjO1xuICAgIH0pKTtcbiAgICBzZXRDYXJkTW9kYWxPcGVuKGZhbHNlKTtcbiAgICBzZXROb3RpZmljYXRpb25zKHByZXYgPT4gW1xuICAgICAgeyBpZDogRGF0ZS5ub3coKSwgdGV4dDogYENyZWRpdCBjYXJkIGRldGFpbHMgZm9yICR7Y2FyZEZvcm0uaG9sZGVyfSB1cGRhdGVkLmAsIHRpbWU6IFwiSnVzdCBub3dcIiwgdHlwZTogXCJpbmZvXCIsIHVucmVhZDogdHJ1ZSB9LFxuICAgICAgLi4ucHJldlxuICAgIF0pO1xuICAgIGFsZXJ0KCdDYXJkIHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5IScpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZURlbGV0ZUNhcmQgPSAoY2FyZElkKSA9PiB7XG4gICAgaWYgKHdpbmRvdy5jb25maXJtKCdBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gZGVsZXRlIHRoaXMgY3JlZGl0IGNhcmQ/JykpIHtcbiAgICAgIHNldENhcmRzKGNhcmRzLmZpbHRlcihjID0+IGMuaWQgIT09IGNhcmRJZCkpO1xuICAgICAgc2V0Tm90aWZpY2F0aW9ucyhwcmV2ID0+IFtcbiAgICAgICAgeyBpZDogRGF0ZS5ub3coKSwgdGV4dDogYENyZWRpdCBjYXJkIHJlbW92ZWQgc3VjY2Vzc2Z1bGx5LmAsIHRpbWU6IFwiSnVzdCBub3dcIiwgdHlwZTogXCJ3YXJuaW5nXCIsIHVucmVhZDogdHJ1ZSB9LFxuICAgICAgICAuLi5wcmV2XG4gICAgICBdKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gTE9BTlMgQ0FMQ1VMQVRPUiAmIE9USEVSIE9QRVJBVElPTlNcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgY29uc3QgY2FsY3VsYXRlTG9hbiA9IChlKSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIGNvbnN0IFAgPSBwYXJzZUZsb2F0KGxvYW5DYWxjLmFtb3VudCk7XG4gICAgY29uc3QgciA9IHBhcnNlRmxvYXQobG9hbkNhbGMucmF0ZSkgLyAxMiAvIDEwMDtcbiAgICBjb25zdCBuID0gcGFyc2VJbnQobG9hbkNhbGMudGVybSk7XG5cbiAgICBpZiAoaXNOYU4oUCkgfHwgaXNOYU4ocikgfHwgaXNOYU4obikgfHwgUCA8PSAwIHx8IHIgPD0gMCB8fCBuIDw9IDApIHtcbiAgICAgIGFsZXJ0KCdQbGVhc2UgZW50ZXIgdmFsaWQgY2FsY3VsYXRvciBpbnB1dHMuJyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgbW9udGhseUluc3RhbGxtZW50ID0gKFAgKiByICogTWF0aC5wb3coMSArIHIsIG4pKSAvIChNYXRoLnBvdygxICsgciwgbikgLSAxKTtcbiAgICBzZXRMb2FuQ2FsYyh7IC4uLmxvYW5DYWxjLCBvdXRwdXQ6IG1vbnRobHlJbnN0YWxsbWVudC50b0ZpeGVkKDIpIH0pO1xuICB9O1xuXG4gIC8vIEFjdGlvbjogU2VydmljZSBTdGF0dXMgVG9nZ2xlXG4gIGNvbnN0IHRvZ2dsZVNlcnZpY2UgPSAoc3J2SWQpID0+IHtcbiAgICBzZXRTZXJ2aWNlcyhzZXJ2aWNlcy5tYXAoc3J2ID0+IHtcbiAgICAgIGlmIChzcnYuaWQgPT09IHNydklkKSB7XG4gICAgICAgIHJldHVybiB7IC4uLnNydiwgZW5hYmxlZDogIXNydi5lbmFibGVkIH07XG4gICAgICB9XG4gICAgICByZXR1cm4gc3J2O1xuICAgIH0pKTtcbiAgfTtcblxuICAvLyBBY3Rpb246IFByb2ZpbGUgU2F2ZSBTdWJtaXNzaW9uXG4gIGNvbnN0IGhhbmRsZVByb2ZpbGVTYXZlID0gKGUpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgc2V0UHJvZmlsZSh7IC4uLnRlbXBQcm9maWxlIH0pO1xuICAgIHNldE5vdGlmaWNhdGlvbnMocHJldiA9PiBbXG4gICAgICB7IGlkOiBEYXRlLm5vdygpLCB0ZXh0OiBcIlByb2ZpbGUgZGV0YWlscyB1cGRhdGVkIHN1Y2Nlc3NmdWxseS5cIiwgdGltZTogXCJKdXN0IG5vd1wiLCB0eXBlOiBcInN1Y2Nlc3NcIiwgdW5yZWFkOiB0cnVlIH0sXG4gICAgICAuLi5wcmV2XG4gICAgXSk7XG4gICAgc2V0U2V0dGluZ3NTdWNjZXNzKCdQcm9maWxlIHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5IScpO1xuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0U2V0dGluZ3NTdWNjZXNzKCcnKSwgMzAwMCk7XG4gIH07XG5cbiAgLy8gQWN0aW9uOiBTZWN1cml0eSBDaGFuZ2UgUGFzc3dvcmQgU3VibWlzc2lvblxuICBjb25zdCBoYW5kbGVTZWN1cml0eVNhdmUgPSAoZSkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBpZiAoIXBhc3N3b3JkRm9ybS5jdXJyZW50IHx8ICFwYXNzd29yZEZvcm0ubmV3IHx8ICFwYXNzd29yZEZvcm0uY29uZmlybSkge1xuICAgICAgYWxlcnQoJ1BsZWFzZSBmaWxsIGluIGFsbCBwYXNzd29yZCBmaWVsZHMuJyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmIChwYXNzd29yZEZvcm0ubmV3ICE9PSBwYXNzd29yZEZvcm0uY29uZmlybSkge1xuICAgICAgYWxlcnQoJ05ldyBwYXNzd29yZCBhbmQgY29uZmlybSBwYXNzd29yZCBkbyBub3QgbWF0Y2ghJyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHNldFBhc3N3b3JkRm9ybSh7IGN1cnJlbnQ6ICcnLCBuZXc6ICcnLCBjb25maXJtOiAnJyB9KTtcbiAgICBzZXROb3RpZmljYXRpb25zKHByZXYgPT4gW1xuICAgICAgeyBpZDogRGF0ZS5ub3coKSwgdGV4dDogXCJTZWN1cml0eSBjcmVkZW50aWFscyAvIFBhc3N3b3JkIGNoYW5nZWQgc3VjY2Vzc2Z1bGx5LlwiLCB0aW1lOiBcIkp1c3Qgbm93XCIsIHR5cGU6IFwic3VjY2Vzc1wiLCB1bnJlYWQ6IHRydWUgfSxcbiAgICAgIC4uLnByZXZcbiAgICBdKTtcbiAgICBzZXRTZXR0aW5nc1N1Y2Nlc3MoJ1Bhc3N3b3JkIGNoYW5nZWQgc3VjY2Vzc2Z1bGx5IScpO1xuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0U2V0dGluZ3NTdWNjZXNzKCcnKSwgMzAwMCk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImRhc2hib2FyZC1jb250YWluZXJcIj5cbiAgICAgIHsvKiBTaWRlYmFyICovfVxuICAgICAgPGFzaWRlIGNsYXNzTmFtZT1cInNpZGViYXJcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaWRlYmFyLWhlYWRlclwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibG9nby1pY29uXCI+XG4gICAgICAgICAgICA8c3ZnIHdpZHRoPVwiMjBcIiBoZWlnaHQ9XCIyMFwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBmaWxsPVwibm9uZVwiIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIj5cbiAgICAgICAgICAgICAgPHBhdGggZD1cIk0xMiAyTDIgN0wxMiAxMkwyMiA3TDEyIDJaXCIgZmlsbD1cIndoaXRlXCIgc3Ryb2tlPVwid2hpdGVcIiBzdHJva2VXaWR0aD1cIjJcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIvPlxuICAgICAgICAgICAgICA8cGF0aCBkPVwiTTIgMTdMMTIgMjJMMjIgMTdcIiBzdHJva2U9XCJ3aGl0ZVwiIHN0cm9rZVdpZHRoPVwiMlwiIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIi8+XG4gICAgICAgICAgICAgIDxwYXRoIGQ9XCJNMiAxMkwxMiAxN0wyMiAxMlwiIHN0cm9rZT1cIndoaXRlXCIgc3Ryb2tlV2lkdGg9XCIyXCIgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiLz5cbiAgICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJsb2dvLXRleHRcIj5CYW5rRGFzaC48L2gxPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgXG4gICAgICAgIDxuYXYgY2xhc3NOYW1lPVwic2lkZWJhci1uYXZcIj5cbiAgICAgICAgICB7bWVudUl0ZW1zXG4gICAgICAgICAgICAuZmlsdGVyKChpdGVtKSA9PiB7XG4gICAgICAgICAgICAgIGlmIChpdGVtLm5hbWUgPT09ICdVc2VyIERldGFpbHMnKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHVzZXJTZXNzaW9uLnJvbGUgPT09ICdBZG1pbicgfHwgdXNlclNlc3Npb24ucm9sZSA9PT0gJ0VkaXRvcic7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgLm1hcCgoaXRlbSkgPT4ge1xuICAgICAgICAgICAgICBjb25zdCBJY29uID0gaXRlbS5pY29uO1xuICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgIDxhIFxuICAgICAgICAgICAgICAgICAga2V5PXtpdGVtLm5hbWV9IFxuICAgICAgICAgICAgICAgICAgaHJlZj1cIiNcIiBcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiB7IGUucHJldmVudERlZmF1bHQoKTsgc2V0QWN0aXZlVGFiKGl0ZW0ubmFtZSk7IH19XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BuYXYtaXRlbSAke2FjdGl2ZVRhYiA9PT0gaXRlbS5uYW1lID8gJ2FjdGl2ZScgOiAnJ31gfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxJY29uIHNpemU9ezIwfSAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+e2l0ZW0ubmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfSl9XG4gICAgICAgIDwvbmF2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2lkZWJhci1mb290ZXJcIj5cbiAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e2hhbmRsZUxvZ291dH0gY2xhc3NOYW1lPVwibG9nb3V0LWJ0blwiPlxuICAgICAgICAgICAgPExvZ091dCBzaXplPXsxOH0gLz5cbiAgICAgICAgICAgIDxzcGFuPkxvZ291dDwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2FzaWRlPlxuXG4gICAgICB7LyogTWFpbiBDb250ZW50IEFyZWEgKi99XG4gICAgICA8bWFpbiBjbGFzc05hbWU9XCJtYWluLWNvbnRlbnRcIj5cbiAgICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJ0b3BiYXJcIj5cbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwicGFnZS10aXRsZVwiPnthY3RpdmVUYWIgPT09ICdEYXNoYm9hcmQnID8gJ092ZXJ2aWV3JyA6IGFjdGl2ZVRhYn08L2gyPlxuICAgICAgICAgIFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidG9wYmFyLWFjdGlvbnNcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VhcmNoLWJhclwiPlxuICAgICAgICAgICAgICA8U2VhcmNoIHNpemU9ezE4fSBjbGFzc05hbWU9XCJzZWFyY2gtaWNvblwiIC8+XG4gICAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiIFxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIGZvciBzb21ldGhpbmdcIiBcbiAgICAgICAgICAgICAgICB2YWx1ZT17c2VhcmNoUXVlcnl9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWFyY2hRdWVyeShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIFxuICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJpY29uLWJ0blwiIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYignU2V0dGluZycpfSBhcmlhLWxhYmVsPVwiU2V0dGluZ3NcIj5cbiAgICAgICAgICAgICAgPFNldHRpbmdzIHNpemU9ezIwfSAvPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaWNvbi1idG4tY29udGFpbmVyXCI+XG4gICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgaWNvbi1idG4gJHtub3RpZmljYXRpb25zT3BlbiA/ICdhY3RpdmUnIDogJyd9YH0gXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Tm90aWZpY2F0aW9uc09wZW4oIW5vdGlmaWNhdGlvbnNPcGVuKX0gXG4gICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIk5vdGlmaWNhdGlvbnNcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPEJlbGwgc2l6ZT17MjB9IC8+XG4gICAgICAgICAgICAgICAge25vdGlmaWNhdGlvbnMuZmlsdGVyKG4gPT4gbi51bnJlYWQpLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibm90aWZpY2F0aW9uLWJhZGdlXCI+XG4gICAgICAgICAgICAgICAgICAgIHtub3RpZmljYXRpb25zLmZpbHRlcihuID0+IG4udW5yZWFkKS5sZW5ndGh9XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAge25vdGlmaWNhdGlvbnNPcGVuICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm5vdGlmaWNhdGlvbi1kcm9wZG93blwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJub3RpZmljYXRpb24taGVhZGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIDxoND5Ob3RpZmljYXRpb25zPC9oND5cbiAgICAgICAgICAgICAgICAgICAge25vdGlmaWNhdGlvbnMuZmlsdGVyKG4gPT4gbi51bnJlYWQpLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiY2xlYXItbm90aWZpY2F0aW9ucy1idG5cIiBvbkNsaWNrPXtoYW5kbGVNYXJrQWxsUmVhZH0+XG4gICAgICAgICAgICAgICAgICAgICAgICBNYXJrIGFsbCBhcyByZWFkXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJub3RpZmljYXRpb24tbGlzdFwiPlxuICAgICAgICAgICAgICAgICAgICB7bm90aWZpY2F0aW9ucy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgPGxpIGNsYXNzTmFtZT1cIm5vdGlmaWNhdGlvbi1lbXB0eVwiPk5vIG5vdGlmaWNhdGlvbnM8L2xpPlxuICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgIG5vdGlmaWNhdGlvbnMubWFwKG4gPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGxpIFxuICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e24uaWR9IFxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Bub3RpZmljYXRpb24taXRlbSAke24udW5yZWFkID8gJ3VucmVhZCcgOiAnJ31gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0Tm90aWZpY2F0aW9ucyhub3RpZmljYXRpb25zLm1hcChpdGVtID0+IGl0ZW0uaWQgPT09IG4uaWQgPyB7IC4uLml0ZW0sIHVucmVhZDogZmFsc2UgfSA6IGl0ZW0pKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgbm90aWZpY2F0aW9uLXN0YXR1cy1kb3Qgc3RhdHVzLWRvdC0ke24udHlwZX1gfT48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibm90aWZpY2F0aW9uLWl0ZW0tY29udGVudFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm5vdGlmaWNhdGlvbi1pdGVtLXRleHRcIj57bi50ZXh0fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJub3RpZmljYXRpb24taXRlbS10aW1lXCI+e24udGltZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgICAgICApKVxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVzZXItcHJvZmlsZVwiIG9uQ2xpY2s9eygpID0+IHsgc2V0QWN0aXZlVGFiKCdTZXR0aW5nJyk7IHNldFNldHRpbmdzU3ViVGFiKCdFZGl0IFByb2ZpbGUnKTsgfX0+XG4gICAgICAgICAgICAgIDxpbWcgXG4gICAgICAgICAgICAgICAgc3JjPXtwcm9maWxlLmF2YXRhcn0gXG4gICAgICAgICAgICAgICAgYWx0PVwiVXNlciBQcm9maWxlXCIgXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYXZhdGFyLWltZ1wiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9oZWFkZXI+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkYXNoYm9hcmQtY29udGVudFwiPlxuICAgICAgICAgIHsvKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgICAgICAgICAgICBQQUdFOiBEQVNIQk9BUkQgKE9WRVJWSUVXKVxuICAgICAgICAgICAgID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxuICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdEYXNoYm9hcmQnICYmIChcbiAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgIHsvKiBSb3cgMSAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkYXNoYm9hcmQtc2VjdGlvbi1yb3dcIj5cbiAgICAgICAgICAgICAgICB7LyogTXkgQ2FyZHMgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtOFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWN0aW9uLWhlYWRlclwiPlxuICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwic2VjdGlvbi10aXRsZVwiPk15IENhcmRzPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cIiNcIiBjbGFzc05hbWU9XCJzZWUtYWxsLWxpbmtcIiBvbkNsaWNrPXsoZSkgPT4geyBlLnByZXZlbnREZWZhdWx0KCk7IHNldEFjdGl2ZVRhYignQ3JlZGl0IENhcmRzJyk7IH19PlNlZSBBbGw8L2E+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZHMtY29udGFpbmVyXCI+XG4gICAgICAgICAgICAgICAgICAgIHtjYXJkcy5tYXAoKGNhcmQpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17Y2FyZC5pZH0gY2xhc3NOYW1lPXtgY3JlZGl0LWNhcmQgJHtjYXJkLnR5cGV9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogSG92ZXIgT3ZlcmxheSBDUlVEIGFjdGlvbnMgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICB7dXNlclNlc3Npb24ucGVybWlzc2lvbnM/Lm1hbmFnZV9jYXJkcyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1hY3Rpb25zLW92ZXJsYXlcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImNhcmQtbWluaS1idG5cIiBvbkNsaWNrPXsoKSA9PiBvcGVuQ2FyZEVkaXRNb2RhbChjYXJkKX0gdGl0bGU9XCJFZGl0IENhcmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxFZGl0MiBzaXplPXsxM30gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImNhcmQtbWluaS1idG5cIiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEZWxldGVDYXJkKGNhcmQuaWQpfSB0aXRsZT1cIkRlbGV0ZSBDYXJkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VHJhc2gyIHNpemU9ezEzfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1oZWFkZXItcm93XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkLWxhYmVsXCI+QmFsYW5jZTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1iYWxhbmNlXCI+JHtjYXJkLmJhbGFuY2UudG9Mb2NhbGVTdHJpbmcoKX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbWcgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPXtjYXJkLnR5cGUgPT09ICdsaWdodCcgPyAnaHR0cHM6Ly9pbWcuaWNvbnM4LmNvbS9pb3MvNTAvMzQzYzZhL2NoaXAucG5nJyA6ICdodHRwczovL2ltZy5pY29uczguY29tL2lvcy1maWxsZWQvNTAvZmZmZmZmL2NoaXAucG5nJ30gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PVwiQ2hpcFwiIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNhcmQtY2hpcFwiIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQtbWlkZGxlLXJvd1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQtaG9sZGVyLWluZm9cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQtbGFiZWxcIj5DYXJkIEhvbGRlcjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC12YWx1ZVwiPntjYXJkLmhvbGRlcn08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1leHBpcnktaW5mb1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1sYWJlbFwiPlZhbGlkIFRocnU8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQtdmFsdWVcIj57Y2FyZC5leHBpcnl9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQtZm9vdGVyLXJvd1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQtbnVtYmVyXCI+e2NhcmQubnVtYmVyfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cImNhcmQtbG9nb1wiIHdpZHRoPVwiNDRcIiBoZWlnaHQ9XCIzMFwiIHZpZXdCb3g9XCIwIDAgNDQgMzBcIiBmaWxsPVwibm9uZVwiIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Y2lyY2xlIGN4PVwiMTVcIiBjeT1cIjE1XCIgcj1cIjE1XCIgZmlsbD17Y2FyZC50eXBlID09PSAnbGlnaHQnID8gJyM5MTk5QUYnIDogJ3doaXRlJ30gZmlsbE9wYWNpdHk9XCIwLjVcIi8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGNpcmNsZSBjeD1cIjI5XCIgY3k9XCIxNVwiIHI9XCIxNVwiIGZpbGw9e2NhcmQudHlwZSA9PT0gJ2xpZ2h0JyA/ICcjOTE5OUFGJyA6ICd3aGl0ZSd9IGZpbGxPcGFjaXR5PVwiMC41XCIvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIFJlY2VudCBUcmFuc2FjdGlvbnMgTGlzdCAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC00XCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlY3Rpb24taGVhZGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJzZWN0aW9uLXRpdGxlXCI+UmVjZW50IFRyYW5zYWN0aW9uPC9oMz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYW5lbFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRyYW5zYWN0aW9ucy1saXN0XCI+XG4gICAgICAgICAgICAgICAgICAgICAge3RyYW5zYWN0aW9ucy5zbGljZSgwLCAzKS5tYXAoKHR4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17dHguaWR9IGNsYXNzTmFtZT1cInRyYW5zYWN0aW9uLWl0ZW1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0cmFuc2FjdGlvbi1sZWZ0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2B0cmFuc2FjdGlvbi1pY29uLXdyYXBwZXIgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR4LmNhdGVnb3J5ID09PSAnRGVwb3NpdCcgPyAnYmx1ZScgOiBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR4LmNhdGVnb3J5ID09PSAnVHJhbnNmZXInID8gJ2dyZWVuJyA6ICd5ZWxsb3cnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3R4LmNhdGVnb3J5ID09PSAnRGVwb3NpdCcgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgd2lkdGg9XCIyMFwiIGhlaWdodD1cIjIwXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlV2lkdGg9XCIyLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBkPVwiTTEyIDJ2MjBNMTcgNUg5LjVhMy41IDMuNSAwIDAgMCAwIDdoNWEzLjUgMy41IDAgMCAxIDAgN0g2XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogdHguY2F0ZWdvcnkgPT09ICdUcmFuc2ZlcicgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgd2lkdGg9XCIyMFwiIGhlaWdodD1cIjIwXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlV2lkdGg9XCIyLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBkPVwiTTIyIDJMMTEgMTNNMjIgMmwtNyAyMC00LTktOS00IDIwLTd6XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIHdpZHRoPVwiMjBcIiBoZWlnaHQ9XCIyMFwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZVdpZHRoPVwiMi41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHJlY3QgeD1cIjJcIiB5PVwiNVwiIHdpZHRoPVwiMjBcIiBoZWlnaHQ9XCIxNFwiIHJ4PVwiMlwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpbmUgeDE9XCIyXCIgeTE9XCIxMFwiIHgyPVwiMjJcIiB5Mj1cIjEwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidHJhbnNhY3Rpb24tZGV0YWlsc1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGg0Pnt0eC5kZXNjfTwvaDQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cD57dHguZGF0ZX08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHRyYW5zYWN0aW9uLWFtb3VudCAke3R4LnR5cGUgPT09ICdleHBlbnNlJyA/ICduZWdhdGl2ZScgOiAncG9zaXRpdmUnfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0eC50eXBlID09PSAnZXhwZW5zZScgPyAnLScgOiAnKyd9JHt0eC5hbW91bnQudG9Mb2NhbGVTdHJpbmcoKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIFJvdyAyICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRhc2hib2FyZC1zZWN0aW9uLXJvd1wiPlxuICAgICAgICAgICAgICAgIHsvKiBXZWVrbHkgQWN0aXZpdHkgQ2hhcnQgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtOFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWN0aW9uLWhlYWRlclwiPlxuICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwic2VjdGlvbi10aXRsZVwiPldlZWtseSBBY3Rpdml0eTwvaDM+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGFuZWxcIiBzdHlsZT17eyBoZWlnaHQ6ICczMjBweCcgfX0+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2hhcnQtbGVnZW5kXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZWdlbmQtaXRlbVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibGVnZW5kLWNvbG9yIHdpdGhkcmF3XCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+V2l0aGRyYXc8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZWdlbmQtaXRlbVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibGVnZW5kLWNvbG9yIGRlcG9zaXRcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5EZXBvc2l0PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3ZWVrbHktY2hhcnQtc3ZnXCIgdmlld0JveD1cIjAgMCA2MDAgMjIwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGxpbmUgeDE9XCI1MFwiIHkxPVwiMzBcIiB4Mj1cIjU2MFwiIHkyPVwiMzBcIiBzdHJva2U9XCIjRjNGM0Y1XCIgc3Ryb2tlV2lkdGg9XCIxXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8bGluZSB4MT1cIjUwXCIgeTE9XCI3MFwiIHgyPVwiNTYwXCIgeTI9XCI3MFwiIHN0cm9rZT1cIiNGM0YzRjVcIiBzdHJva2VXaWR0aD1cIjFcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxsaW5lIHgxPVwiNTBcIiB5MT1cIjExMFwiIHgyPVwiNTYwXCIgeTI9XCIxMTBcIiBzdHJva2U9XCIjRjNGM0Y1XCIgc3Ryb2tlV2lkdGg9XCIxXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8bGluZSB4MT1cIjUwXCIgeTE9XCIxNTBcIiB4Mj1cIjU2MFwiIHkyPVwiMTUwXCIgc3Ryb2tlPVwiI0YzRjNGNVwiIHN0cm9rZVdpZHRoPVwiMVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPGxpbmUgeDE9XCI1MFwiIHkxPVwiMTkwXCIgeDI9XCI1NjBcIiB5Mj1cIjE5MFwiIHN0cm9rZT1cIiNFNkVGRjVcIiBzdHJva2VXaWR0aD1cIjEuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgICAgPHRleHQgeD1cIjM1XCIgeT1cIjM0XCIgZmlsbD1cIiM3MThFQkZcIiBmb250U2l6ZT1cIjEyXCIgZm9udFdlaWdodD1cIjUwMFwiIHRleHRBbmNob3I9XCJlbmRcIj41MDA8L3RleHQ+XG4gICAgICAgICAgICAgICAgICAgICAgPHRleHQgeD1cIjM1XCIgeT1cIjc0XCIgZmlsbD1cIiM3MThFQkZcIiBmb250U2l6ZT1cIjEyXCIgZm9udFdlaWdodD1cIjUwMFwiIHRleHRBbmNob3I9XCJlbmRcIj4zMDA8L3RleHQ+XG4gICAgICAgICAgICAgICAgICAgICAgPHRleHQgeD1cIjM1XCIgeT1cIjExNFwiIGZpbGw9XCIjNzE4RUJGXCIgZm9udFNpemU9XCIxMlwiIGZvbnRXZWlnaHQ9XCI1MDBcIiB0ZXh0QW5jaG9yPVwiZW5kXCI+MjAwPC90ZXh0PlxuICAgICAgICAgICAgICAgICAgICAgIDx0ZXh0IHg9XCIzNVwiIHk9XCIxNTRcIiBmaWxsPVwiIzcxOEVCRlwiIGZvbnRTaXplPVwiMTJcIiBmb250V2VpZ2h0PVwiNTAwXCIgdGV4dEFuY2hvcj1cImVuZFwiPjEwMDwvdGV4dD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGV4dCB4PVwiMzVcIiB5PVwiMTk0XCIgZmlsbD1cIiM3MThFQkZcIiBmb250U2l6ZT1cIjEyXCIgZm9udFdlaWdodD1cIjUwMFwiIHRleHRBbmNob3I9XCJlbmRcIj4wPC90ZXh0PlxuXG4gICAgICAgICAgICAgICAgICAgICAgPGcgY2xhc3NOYW1lPVwiYmFyLWdyb3VwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cmVjdCB4PVwiODVcIiB5PVwiNjJcIiB3aWR0aD1cIjE0XCIgaGVpZ2h0PVwiMTI4XCIgcng9XCI0XCIgZmlsbD1cIiMzNDNDNkFcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHJlY3QgeD1cIjEwM1wiIHk9XCIxMjJcIiB3aWR0aD1cIjE0XCIgaGVpZ2h0PVwiNjhcIiByeD1cIjRcIiBmaWxsPVwiIzM5NkFGRlwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGV4dCB4PVwiMTAxXCIgeT1cIjIxMFwiIGZpbGw9XCIjNzE4RUJGXCIgZm9udFNpemU9XCIxMlwiIGZvbnRXZWlnaHQ9XCI1MDBcIiB0ZXh0QW5jaG9yPVwibWlkZGxlXCI+U2F0PC90ZXh0PlxuICAgICAgICAgICAgICAgICAgICAgIDwvZz5cbiAgICAgICAgICAgICAgICAgICAgICA8ZyBjbGFzc05hbWU9XCJiYXItZ3JvdXBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxyZWN0IHg9XCIxNTVcIiB5PVwiOTRcIiB3aWR0aD1cIjE0XCIgaGVpZ2h0PVwiOTZcIiByeD1cIjRcIiBmaWxsPVwiIzM0M0M2QVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cmVjdCB4PVwiMTczXCIgeT1cIjE1OFwiIHdpZHRoPVwiMTRcIiBoZWlnaHQ9XCIzMlwiIHJ4PVwiNFwiIGZpbGw9XCIjMzk2QUZGXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZXh0IHg9XCIxNzFcIiB5PVwiMjEwXCIgZmlsbD1cIiM3MThFQkZcIiBmb250U2l6ZT1cIjEyXCIgZm9udFdlaWdodD1cIjUwMFwiIHRleHRBbmNob3I9XCJtaWRkbGVcIj5TdW48L3RleHQ+XG4gICAgICAgICAgICAgICAgICAgICAgPC9nPlxuICAgICAgICAgICAgICAgICAgICAgIDxnIGNsYXNzTmFtZT1cImJhci1ncm91cFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHJlY3QgeD1cIjIyNVwiIHk9XCIxMDJcIiB3aWR0aD1cIjE0XCIgaGVpZ2h0PVwiODhcIiByeD1cIjRcIiBmaWxsPVwiIzM0M0M2QVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cmVjdCB4PVwiMjQzXCIgeT1cIjExOFwiIHdpZHRoPVwiMTRcIiBoZWlnaHQ9XCI3MlwiIHJ4PVwiNFwiIGZpbGw9XCIjMzk2QUZGXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZXh0IHg9XCIyNDFcIiB5PVwiMjEwXCIgZmlsbD1cIiM3MThFQkZcIiBmb250U2l6ZT1cIjEyXCIgZm9udFdlaWdodD1cIjUwMFwiIHRleHRBbmNob3I9XCJtaWRkbGVcIj5Nb248L3RleHQ+XG4gICAgICAgICAgICAgICAgICAgICAgPC9nPlxuICAgICAgICAgICAgICAgICAgICAgIDxnIGNsYXNzTmFtZT1cImJhci1ncm91cFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHJlY3QgeD1cIjI5NVwiIHk9XCI2MlwiIHdpZHRoPVwiMTRcIiBoZWlnaHQ9XCIxMjhcIiByeD1cIjRcIiBmaWxsPVwiIzM0M0M2QVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cmVjdCB4PVwiMzEzXCIgeT1cIjkwXCIgd2lkdGg9XCIxNFwiIGhlaWdodD1cIjEwMFwiIHJ4PVwiNFwiIGZpbGw9XCIjMzk2QUZGXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZXh0IHg9XCIzMTFcIiB5PVwiMjEwXCIgZmlsbD1cIiM3MThFQkZcIiBmb250U2l6ZT1cIjEyXCIgZm9udFdlaWdodD1cIjUwMFwiIHRleHRBbmNob3I9XCJtaWRkbGVcIj5UdWU8L3RleHQ+XG4gICAgICAgICAgICAgICAgICAgICAgPC9nPlxuICAgICAgICAgICAgICAgICAgICAgIDxnIGNsYXNzTmFtZT1cImJhci1ncm91cFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHJlY3QgeD1cIjM2NVwiIHk9XCIxNDZcIiB3aWR0aD1cIjE0XCIgaGVpZ2h0PVwiNDRcIiByeD1cIjRcIiBmaWxsPVwiIzM0M0M2QVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cmVjdCB4PVwiMzgzXCIgeT1cIjEyMlwiIHdpZHRoPVwiMTRcIiBoZWlnaHQ9XCI2OFwiIHJ4PVwiNFwiIGZpbGw9XCIjMzk2QUZGXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZXh0IHg9XCIzODFcIiB5PVwiMjEwXCIgZmlsbD1cIiM3MThFQkZcIiBmb250U2l6ZT1cIjEyXCIgZm9udFdlaWdodD1cIjUwMFwiIHRleHRBbmNob3I9XCJtaWRkbGVcIj5XZWQ8L3RleHQ+XG4gICAgICAgICAgICAgICAgICAgICAgPC9nPlxuICAgICAgICAgICAgICAgICAgICAgIDxnIGNsYXNzTmFtZT1cImJhci1ncm91cFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHJlY3QgeD1cIjQzNVwiIHk9XCI4NlwiIHdpZHRoPVwiMTRcIiBoZWlnaHQ9XCIxMDRcIiByeD1cIjRcIiBmaWxsPVwiIzM0M0M2QVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cmVjdCB4PVwiNDUzXCIgeT1cIjEyMlwiIHdpZHRoPVwiMTRcIiBoZWlnaHQ9XCI2OFwiIHJ4PVwiNFwiIGZpbGw9XCIjMzk2QUZGXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZXh0IHg9XCI0NTFcIiB5PVwiMjEwXCIgZmlsbD1cIiM3MThFQkZcIiBmb250U2l6ZT1cIjEyXCIgZm9udFdlaWdodD1cIjUwMFwiIHRleHRBbmNob3I9XCJtaWRkbGVcIj5UaHU8L3RleHQ+XG4gICAgICAgICAgICAgICAgICAgICAgPC9nPlxuICAgICAgICAgICAgICAgICAgICAgIDxnIGNsYXNzTmFtZT1cImJhci1ncm91cFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHJlY3QgeD1cIjUwNVwiIHk9XCI4MlwiIHdpZHRoPVwiMTRcIiBoZWlnaHQ9XCIxMDhcIiByeD1cIjRcIiBmaWxsPVwiIzM0M0M2QVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cmVjdCB4PVwiNTIzXCIgeT1cIjEwMlwiIHdpZHRoPVwiMTRcIiBoZWlnaHQ9XCI4OFwiIHJ4PVwiNFwiIGZpbGw9XCIjMzk2QUZGXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZXh0IHg9XCI1MjFcIiB5PVwiMjEwXCIgZmlsbD1cIiM3MThFQkZcIiBmb250U2l6ZT1cIjEyXCIgZm9udFdlaWdodD1cIjUwMFwiIHRleHRBbmNob3I9XCJtaWRkbGVcIj5Gcmk8L3RleHQ+XG4gICAgICAgICAgICAgICAgICAgICAgPC9nPlxuICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIEV4cGVuc2UgU3RhdGlzdGljcyAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC00XCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlY3Rpb24taGVhZGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJzZWN0aW9uLXRpdGxlXCI+RXhwZW5zZSBTdGF0aXN0aWNzPC9oMz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYW5lbFwiIHN0eWxlPXt7IGhlaWdodDogJzMyMHB4JyB9fT5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJleHBlbnNlLWRvbnV0LWNvbnRhaW5lclwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwiZG9udXQtY2hhcnQtc3ZnXCIgdmlld0JveD1cIjAgMCAyMDAgMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Y2lyY2xlIGN4PVwiMTAwXCIgY3k9XCIxMDBcIiByPVwiODVcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cIiNGNUY3RkFcIiBzdHJva2VXaWR0aD1cIjE2XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxjaXJjbGUgY2xhc3NOYW1lPVwiZG9udXQtc2VnbWVudFwiIGN4PVwiMTAwXCIgY3k9XCIxMDBcIiByPVwiNzBcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cIiMzOTZBRkZcIiBzdHJva2VXaWR0aD1cIjIwXCIgc3Ryb2tlRGFzaGFycmF5PVwiMTUzLjkgNDQwXCIgc3Ryb2tlRGFzaG9mZnNldD1cIjBcIiB0cmFuc2Zvcm09XCJyb3RhdGUoLTkwIDEwMCAxMDApXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxjaXJjbGUgY2xhc3NOYW1lPVwiZG9udXQtc2VnbWVudFwiIGN4PVwiMTAwXCIgY3k9XCIxMDBcIiByPVwiNzBcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cIiMzNDNDNkFcIiBzdHJva2VXaWR0aD1cIjIwXCIgc3Ryb2tlRGFzaGFycmF5PVwiMTMyIDQ0MFwiIHN0cm9rZURhc2hvZmZzZXQ9XCItMTUzLjlcIiB0cmFuc2Zvcm09XCJyb3RhdGUoLTkwIDEwMCAxMDApXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxjaXJjbGUgY2xhc3NOYW1lPVwiZG9udXQtc2VnbWVudFwiIGN4PVwiMTAwXCIgY3k9XCIxMDBcIiByPVwiNzBcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cIiNGQzc5MDBcIiBzdHJva2VXaWR0aD1cIjIwXCIgc3Ryb2tlRGFzaGFycmF5PVwiODggNDQwXCIgc3Ryb2tlRGFzaG9mZnNldD1cIi0yODUuOVwiIHRyYW5zZm9ybT1cInJvdGF0ZSgtOTAgMTAwIDEwMClcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGNpcmNsZSBjbGFzc05hbWU9XCJkb251dC1zZWdtZW50XCIgY3g9XCIxMDBcIiBjeT1cIjEwMFwiIHI9XCI3MFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiIzE2REJBQVwiIHN0cm9rZVdpZHRoPVwiMjBcIiBzdHJva2VEYXNoYXJyYXk9XCI2NiA0NDBcIiBzdHJva2VEYXNob2Zmc2V0PVwiLTM3My45XCIgdHJhbnNmb3JtPVwicm90YXRlKC05MCAxMDAgMTAwKVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZXh0IHg9XCIxMDBcIiB5PVwiOTVcIiBjbGFzc05hbWU9XCJjaGFydC1jZW50ZXItdGV4dFwiIGZpbGw9XCIjMzQzQzZBXCIgZm9udFNpemU9XCIxOFwiIGZvbnRXZWlnaHQ9XCI3MDBcIj4zMCU8L3RleHQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGV4dCB4PVwiMTAwXCIgeT1cIjExNVwiIGNsYXNzTmFtZT1cImNoYXJ0LWNlbnRlci10ZXh0XCIgZmlsbD1cIiM3MThFQkZcIiBmb250U2l6ZT1cIjExXCIgZm9udFdlaWdodD1cIjYwMFwiIGxldHRlclNwYWNpbmc9XCIwLjVcIj5FbnRlcnRhaW5tZW50PC90ZXh0PlxuICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZ3JpZCcsIGdyaWRUZW1wbGF0ZUNvbHVtbnM6ICcxZnIgMWZyJywgZ2FwOiAnMC41cmVtIDFyZW0nLCBtYXJnaW5Ub3A6ICcwLjVyZW0nLCBwYWRkaW5nOiAnMCAwLjVyZW0nIH19PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGVnZW5kLWl0ZW1cIj48c3BhbiBjbGFzc05hbWU9XCJsZWdlbmQtY29sb3JcIiBzdHlsZT17eyBiYWNrZ3JvdW5kOiAnIzM0M0M2QScgfX0+PC9zcGFuPjxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiAnMC44cmVtJywgZm9udFdlaWdodDogNjAwIH19PjMwJSBFbnQuPC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGVnZW5kLWl0ZW1cIj48c3BhbiBjbGFzc05hbWU9XCJsZWdlbmQtY29sb3JcIiBzdHlsZT17eyBiYWNrZ3JvdW5kOiAnIzM5NkFGRicgfX0+PC9zcGFuPjxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiAnMC44cmVtJywgZm9udFdlaWdodDogNjAwIH19PjM1JSBPdGhlcnM8L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZWdlbmQtaXRlbVwiPjxzcGFuIGNsYXNzTmFtZT1cImxlZ2VuZC1jb2xvclwiIHN0eWxlPXt7IGJhY2tncm91bmQ6ICcjRkM3OTAwJyB9fT48L3NwYW4+PHNwYW4gc3R5bGU9e3sgZm9udFNpemU6ICcwLjhyZW0nLCBmb250V2VpZ2h0OiA2MDAgfX0+MjAlIEludi48L3NwYW4+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZWdlbmQtaXRlbVwiPjxzcGFuIGNsYXNzTmFtZT1cImxlZ2VuZC1jb2xvclwiIHN0eWxlPXt7IGJhY2tncm91bmQ6ICcjMTZEQkFBJyB9fT48L3NwYW4+PHNwYW4gc3R5bGU9e3sgZm9udFNpemU6ICcwLjhyZW0nLCBmb250V2VpZ2h0OiA2MDAgfX0+MTUlIEJpbGxzPC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogUm93IDMgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGFzaGJvYXJkLXNlY3Rpb24tcm93XCI+XG4gICAgICAgICAgICAgICAgey8qIFF1aWNrIFRyYW5zZmVyIFdpZGdldCAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC01XCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlY3Rpb24taGVhZGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJzZWN0aW9uLXRpdGxlXCI+UXVpY2sgVHJhbnNmZXI8L2gzPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBhbmVsXCIgc3R5bGU9e3sgaGVpZ2h0OiAnMjgwcHgnIH19PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInF1aWNrLXRyYW5zZmVyLWNvbnRhaW5lclwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidXNlcnMtc2xpZGVyLXJvd1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1c2Vycy1zbGlkZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge3F1aWNrVHJhbnNmZXJVc2Vycy5tYXAoKHVzZXIsIGlkeCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e3VzZXIubmFtZX0gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BzbGlkZXItdXNlciAke3NlbGVjdGVkVXNlckluZGV4ID09PSBpZHggPyAnc2VsZWN0ZWQnIDogJyd9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkVXNlckluZGV4KGlkeCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGltZyBzcmM9e3VzZXIuYXZhdGFyfSBhbHQ9e3VzZXIubmFtZX0gY2xhc3NOYW1lPVwidXNlci1hdmF0YXJcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidXNlci1uYW1lXCI+e3VzZXIubmFtZS5zcGxpdCgnICcpWzBdfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInVzZXItcm9sZVwiPnt1c2VyLnJvbGV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJzbGlkZXItYXJyb3ctYnRuXCIgYXJpYS1sYWJlbD1cIk5leHQgVXNlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hldnJvblJpZ2h0IHNpemU9ezIwfSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlUXVpY2tUcmFuc2Zlcn0gY2xhc3NOYW1lPVwidHJhbnNmZXItYWN0aW9uLXJvd1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidHJhbnNmZXItbGFiZWxcIj5Xcml0ZSBBbW91bnQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFtb3VudC1pbnB1dC13cmFwcGVyXCIgc3R5bGU9eyF1c2VyU2Vzc2lvbi5wZXJtaXNzaW9ucz8ubWFuYWdlX3R4ID8geyBvcGFjaXR5OiAwLjcgfSA6IHt9fT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCIgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e3VzZXJTZXNzaW9uLnBlcm1pc3Npb25zPy5tYW5hZ2VfdHggPyBcIjUyNS41MFwiIDogXCJEaXNhYmxlZCAoUmVhZC1Pbmx5KVwifSBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dHJhbnNmZXJBbW91bnR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRUcmFuc2ZlckFtb3VudChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyF1c2VyU2Vzc2lvbi5wZXJtaXNzaW9ucz8ubWFuYWdlX3R4fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBjbGFzc05hbWU9XCJzZW5kLWJ0blwiIGRpc2FibGVkPXshdXNlclNlc3Npb24ucGVybWlzc2lvbnM/Lm1hbmFnZV90eH0gc3R5bGU9eyF1c2VyU2Vzc2lvbi5wZXJtaXNzaW9ucz8ubWFuYWdlX3R4ID8geyBvcGFjaXR5OiAwLjUsIGN1cnNvcjogJ25vdC1hbGxvd2VkJywgcG9pbnRlckV2ZW50czogJ25vbmUnIH0gOiB7fX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+U2VuZDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VuZCBzaXplPXsxNX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgICAgICAgICAgICAge3RyYW5zZmVyU3VjY2VzcyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IFxuICAgICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW5Ub3A6ICcwLjc1cmVtJywgXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6ICcwLjVyZW0gMXJlbScsIFxuICAgICAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAncmdiYSgyMiwgMjE5LCAxNzAsIDAuMTIpJywgXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiAnIzBlOTA2ZicsIFxuICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6ICcxMnB4JywgXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiAnMC44NXJlbScsIFxuICAgICAgICAgICAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiA2MDAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRleHRBbGlnbjogJ2NlbnRlcicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlcjogJzFweCBzb2xpZCByZ2JhKDIyLCAyMTksIDE3MCwgMC4yNSknLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBhbmltYXRpb246ICdzbGlkZVVwIDAuM3MgZWFzZS1vdXQnXG4gICAgICAgICAgICAgICAgICAgICAgICB9fT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge3RyYW5zZmVyU3VjY2Vzc31cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7LyogQmFsYW5jZSBIaXN0b3J5ICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLTdcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VjdGlvbi1oZWFkZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInNlY3Rpb24tdGl0bGVcIj5CYWxhbmNlIEhpc3Rvcnk8L2gzPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBhbmVsXCIgc3R5bGU9e3sgaGVpZ2h0OiAnMjgwcHgnIH19PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJhbGFuY2UtY2hhcnQtY29udGFpbmVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJiYWxhbmNlLWNoYXJ0LXN2Z1wiIHZpZXdCb3g9XCIwIDAgNjAwIDIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRlZnM+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsaW5lYXJHcmFkaWVudCBpZD1cImJhbGFuY2VHcmFkaWVudFwiIHgxPVwiMFwiIHkxPVwiMFwiIHgyPVwiMFwiIHkyPVwiMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdG9wIG9mZnNldD1cIjAlXCIgc3RvcENvbG9yPVwiIzE4MTRGM1wiIHN0b3BPcGFjaXR5PVwiMC4yMlwiLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3RvcCBvZmZzZXQ9XCIxMDAlXCIgc3RvcENvbG9yPVwiIzE4MTRGM1wiIHN0b3BPcGFjaXR5PVwiMC4wXCIvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xpbmVhckdyYWRpZW50PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kZWZzPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGluZSBjbGFzc05hbWU9XCJiYWxhbmNlLWdyaWQtbGluZVwiIHgxPVwiNDBcIiB5MT1cIjMwXCIgeDI9XCI1NzBcIiB5Mj1cIjMwXCIgc3Ryb2tlPVwiI0YzRjNGNVwiIHN0cm9rZVdpZHRoPVwiMVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGluZSBjbGFzc05hbWU9XCJiYWxhbmNlLWdyaWQtbGluZVwiIHgxPVwiNDBcIiB5MT1cIjc1XCIgeDI9XCI1NzBcIiB5Mj1cIjc1XCIgc3Ryb2tlPVwiI0YzRjNGNVwiIHN0cm9rZVdpZHRoPVwiMVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGluZSBjbGFzc05hbWU9XCJiYWxhbmNlLWdyaWQtbGluZVwiIHgxPVwiNDBcIiB5MT1cIjEyMFwiIHgyPVwiNTcwXCIgeTI9XCIxMjBcIiBzdHJva2U9XCIjRjNGM0Y1XCIgc3Ryb2tlV2lkdGg9XCIxXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsaW5lIGNsYXNzTmFtZT1cImJhbGFuY2UtZ3JpZC1saW5lXCIgeDE9XCI0MFwiIHkxPVwiMTY1XCIgeDI9XCI1NzBcIiB5Mj1cIjE2NVwiIHN0cm9rZT1cIiNFNkVGRjVcIiBzdHJva2VXaWR0aD1cIjEuNVwiIC8+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZXh0IHg9XCIzMFwiIHk9XCIzNFwiIGZpbGw9XCIjNzE4RUJGXCIgZm9udFNpemU9XCIxMlwiIGZvbnRXZWlnaHQ9XCI1MDBcIiB0ZXh0QW5jaG9yPVwiZW5kXCI+ODAwPC90ZXh0PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRleHQgeD1cIjMwXCIgeT1cIjc5XCIgZmlsbD1cIiM3MThFQkZcIiBmb250U2l6ZT1cIjEyXCIgZm9udFdlaWdodD1cIjUwMFwiIHRleHRBbmNob3I9XCJlbmRcIj40MDA8L3RleHQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGV4dCB4PVwiMzBcIiB5PVwiMTI0XCIgZmlsbD1cIiM3MThFQkZcIiBmb250U2l6ZT1cIjEyXCIgZm9udFdlaWdodD1cIjUwMFwiIHRleHRBbmNob3I9XCJlbmRcIj4yMDA8L3RleHQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGV4dCB4PVwiMzBcIiB5PVwiMTY5XCIgZmlsbD1cIiM3MThFQkZcIiBmb250U2l6ZT1cIjEyXCIgZm9udFdlaWdodD1cIjUwMFwiIHRleHRBbmNob3I9XCJlbmRcIj4wPC90ZXh0PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGV4dCB4PVwiNjBcIiB5PVwiMTkwXCIgZmlsbD1cIiM3MThFQkZcIiBmb250U2l6ZT1cIjEyXCIgZm9udFdlaWdodD1cIjUwMFwiIHRleHRBbmNob3I9XCJtaWRkbGVcIj5KdWw8L3RleHQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGV4dCB4PVwiMTQ1XCIgeT1cIjE5MFwiIGZpbGw9XCIjNzE4RUJGXCIgZm9udFNpemU9XCIxMlwiIGZvbnRXZWlnaHQ9XCI1MDBcIiB0ZXh0QW5jaG9yPVwibWlkZGxlXCI+QXVnPC90ZXh0PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRleHQgeD1cIjIzMFwiIHk9XCIxOTBcIiBmaWxsPVwiIzcxOEVCRlwiIGZvbnRTaXplPVwiMTJcIiBmb250V2VpZ2h0PVwiNTAwXCIgdGV4dEFuY2hvcj1cIm1pZGRsZVwiPlNlcDwvdGV4dD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZXh0IHg9XCIzMTVcIiB5PVwiMTkwXCIgZmlsbD1cIiM3MThFQkZcIiBmb250U2l6ZT1cIjEyXCIgZm9udFdlaWdodD1cIjUwMFwiIHRleHRBbmNob3I9XCJtaWRkbGVcIj5PY3Q8L3RleHQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGV4dCB4PVwiNDAwXCIgeT1cIjE5MFwiIGZpbGw9XCIjNzE4RUJGXCIgZm9udFNpemU9XCIxMlwiIGZvbnRXZWlnaHQ9XCI1MDBcIiB0ZXh0QW5jaG9yPVwibWlkZGxlXCI+Tm92PC90ZXh0PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRleHQgeD1cIjQ4NVwiIHk9XCIxOTBcIiBmaWxsPVwiIzcxOEVCRlwiIGZvbnRTaXplPVwiMTJcIiBmb250V2VpZ2h0PVwiNTAwXCIgdGV4dEFuY2hvcj1cIm1pZGRsZVwiPkRlYzwvdGV4dD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZXh0IHg9XCI1NjBcIiB5PVwiMTkwXCIgZmlsbD1cIiM3MThFQkZcIiBmb250U2l6ZT1cIjEyXCIgZm9udFdlaWdodD1cIjUwMFwiIHRleHRBbmNob3I9XCJtaWRkbGVcIj5KYW48L3RleHQ+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxwYXRoIFxuICAgICAgICAgICAgICAgICAgICAgICAgICBkPVwiTSA2MCAxNjUgQyAxMDIuNSAxNTAsIDEwMi41IDExMCwgMTQ1IDExMCBDIDE4Ny41IDExMCwgMTg3LjUgMTMwLCAyMzAgMTMwIEMgMjcyLjUgMTMwLCAyNzIuNSA2MCwgMzE1IDYwIEMgMzU3LjUgNjAsIDM1Ny41IDEyMCwgNDAwIDEyMCBDIDQ0Mi41IDEyMCwgNDQyLjUgODAsIDQ4NSA4MCBDIDUyNy41IDgwLCA1MjcuNSA1MCwgNTYwIDUwIEwgNTYwIDE2NSBaXCIgXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZpbGw9XCJ1cmwoI2JhbGFuY2VHcmFkaWVudClcIiBcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxwYXRoIFxuICAgICAgICAgICAgICAgICAgICAgICAgICBkPVwiTSA2MCAxNjUgQyAxMDIuNSAxNTAsIDEwMi41IDExMCwgMTQ1IDExMCBDIDE4Ny41IDExMCwgMTg3LjUgMTMwLCAyMzAgMTMwIEMgMjcyLjUgMTMwLCAyNzIuNSA2MCwgMzE1IDYwIEMgMzU3LjUgNjAsIDM1Ny41IDEyMCwgNDAwIDEyMCBDIDQ0Mi41IDEyMCwgNDQyLjUgODAsIDQ4NSA4MCBDIDUyNy41IDgwLCA1MjcuNSA1MCwgNTYwIDUwXCIgXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCIgXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZT1cIiMxODE0RjNcIiBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIzLjVcIiBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICA8Y2lyY2xlIGN4PVwiMzE1XCIgY3k9XCI2MFwiIHI9XCI1XCIgZmlsbD1cIiMxODE0RjNcIiBzdHJva2U9XCIjRkZGRkZGXCIgc3Ryb2tlV2lkdGg9XCIyXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxjaXJjbGUgY3g9XCI1NjBcIiBjeT1cIjUwXCIgcj1cIjVcIiBmaWxsPVwiIzE4MTRGM1wiIHN0cm9rZT1cIiNGRkZGRkZcIiBzdHJva2VXaWR0aD1cIjJcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvPlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICAgICAgICAgICAgUEFHRTogVFJBTlNBQ1RJT05TXG4gICAgICAgICAgICAgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XG4gICAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ1RyYW5zYWN0aW9ucycgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtMTJcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWN0aW9uLWhlYWRlclwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmlsdGVyLXRhYnNcIiBzdHlsZT17eyBtYXJnaW5Cb3R0b206IDAsIGJvcmRlckJvdHRvbTogJ25vbmUnIH19PlxuICAgICAgICAgICAgICAgICAgPGRpdiBcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmlsdGVyLXRhYiAke3RyYW5zYWN0aW9uVHlwZUZpbHRlciA9PT0gJ0FsbCcgPyAnYWN0aXZlJyA6ICcnfWB9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFRyYW5zYWN0aW9uVHlwZUZpbHRlcignQWxsJyl9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIEFsbCBUcmFuc2FjdGlvbnNcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmlsdGVyLXRhYiAke3RyYW5zYWN0aW9uVHlwZUZpbHRlciA9PT0gJ2luY29tZScgPyAnYWN0aXZlJyA6ICcnfWB9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFRyYW5zYWN0aW9uVHlwZUZpbHRlcignaW5jb21lJyl9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIEluY29tZVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IFxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmaWx0ZXItdGFiICR7dHJhbnNhY3Rpb25UeXBlRmlsdGVyID09PSAnZXhwZW5zZScgPyAnYWN0aXZlJyA6ICcnfWB9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFRyYW5zYWN0aW9uVHlwZUZpbHRlcignZXhwZW5zZScpfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICBFeHBlbnNlXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICB7LyogQ1JFQVRFIGFjdGlvbiB0cmlnZ2VyICovfVxuICAgICAgICAgICAgICAgIHt1c2VyU2Vzc2lvbi5wZXJtaXNzaW9ucz8ubWFuYWdlX3R4ICYmIChcbiAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwic2V0dGluZ3Mtc2F2ZS1idG5cIiBzdHlsZT17eyBtYXJnaW46IDAsIHBhZGRpbmc6ICcwLjZyZW0gMS41cmVtJywgYm9yZGVyUmFkaXVzOiAnNDBweCcgfX0gb25DbGljaz17b3BlblR4Q3JlYXRlTW9kYWx9PlxuICAgICAgICAgICAgICAgICAgICA8UGx1cyBzaXplPXsxNn0gc3R5bGU9e3sgbWFyZ2luUmlnaHQ6ICcwLjRyZW0nLCB2ZXJ0aWNhbEFsaWduOiAnbWlkZGxlJyB9fSAvPlxuICAgICAgICAgICAgICAgICAgICBBZGQgVHJhbnNhY3Rpb25cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGFibGUtd3JhcHBlclwiPlxuICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJjdXN0b20tdGFibGVcIj5cbiAgICAgICAgICAgICAgICAgIDx0aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgIDx0aD5EZXNjcmlwdGlvbjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgPHRoPlRyYW5zYWN0aW9uIElEPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGg+Q2F0ZWdvcnk8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgIDx0aD5NZXRob2Q8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgIDx0aD5EYXRlPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGg+QW1vdW50PC90aD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGg+U3RhdHVzPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGg+QWN0aW9uczwvdGg+XG4gICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgPHRib2R5PlxuICAgICAgICAgICAgICAgICAgICB7dHJhbnNhY3Rpb25zXG4gICAgICAgICAgICAgICAgICAgICAgLmZpbHRlcih0eCA9PiB0cmFuc2FjdGlvblR5cGVGaWx0ZXIgPT09ICdBbGwnIHx8IHR4LnR5cGUgPT09IHRyYW5zYWN0aW9uVHlwZUZpbHRlcilcbiAgICAgICAgICAgICAgICAgICAgICAuZmlsdGVyKHR4ID0+IFxuICAgICAgICAgICAgICAgICAgICAgICAgdHguZGVzYy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaFF1ZXJ5LnRvTG93ZXJDYXNlKCkpIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICB0eC5pZC50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaFF1ZXJ5LnRvTG93ZXJDYXNlKCkpIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICB0eC5jYXRlZ29yeS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaFF1ZXJ5LnRvTG93ZXJDYXNlKCkpXG4gICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgIC5tYXAoKHR4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXt0eC5pZH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBnYXA6ICcwLjc1cmVtJyB9fT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHRyYW5zYWN0aW9uLWljb24td3JhcHBlciAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHgudHlwZSA9PT0gJ2luY29tZScgPyAnZ3JlZW4nIDogJ3JlZCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH0gc3R5bGU9e3sgd2lkdGg6ICczNnB4JywgaGVpZ2h0OiAnMzZweCcgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dHgudHlwZSA9PT0gJ2luY29tZScgPyA8VHJlbmRpbmdVcCBzaXplPXsxNn0gLz4gOiA8VHJlbmRpbmdVcCBzaXplPXsxNn0gc3R5bGU9e3sgdHJhbnNmb3JtOiAncm90YXRlKDE4MGRlZyknIH19IC8+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt0eC5kZXNjfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIHN0eWxlPXt7IGNvbG9yOiAnIzcxOEVCRicgfX0+e3R4LmlkfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD57dHguY2F0ZWdvcnl9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkPnt0eC5tZXRob2R9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIHN0eWxlPXt7IGNvbG9yOiAnIzcxOEVCRicgfX0+e3R4LmRhdGV9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIHN0eWxlPXt7IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6ICc3MDAnLCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogdHgudHlwZSA9PT0gJ2V4cGVuc2UnID8gJ3ZhcigtLWVycm9yKScgOiAndmFyKC0tc3VjY2VzcyknXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH19PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0eC50eXBlID09PSAnZXhwZW5zZScgPyAnLScgOiAnKyd9JHt0eC5hbW91bnQudG9Mb2NhbGVTdHJpbmcoKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHN0YXR1cy1iYWRnZSAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHguc3RhdHVzID09PSAnU3VjY2VzcycgPyAnc3VjY2VzcycgOiBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR4LnN0YXR1cyA9PT0gJ1BlbmRpbmcnID8gJ3BlbmRpbmcnIDogJ2ZhaWxlZCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dHguc3RhdHVzfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBVUERBVEUgJiBERUxFVEUgQWN0aW9ucyAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dXNlclNlc3Npb24ucGVybWlzc2lvbnM/Lm1hbmFnZV90eCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWN0aW9uLWJ0bi1ncm91cFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cInRhYmxlLWFjdGlvbi1idG4gZWRpdFwiIG9uQ2xpY2s9eygpID0+IG9wZW5UeEVkaXRNb2RhbCh0eCl9IHRpdGxlPVwiRWRpdFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxFZGl0MiBzaXplPXsxNX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwidGFibGUtYWN0aW9uLWJ0biBkZWxldGVcIiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEZWxldGVUeCh0eC5pZCl9IHRpdGxlPVwiRGVsZXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRyYXNoMiBzaXplPXsxNX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6ICcjOTRhM2I4JywgZm9udFNpemU6ICcwLjg1cmVtJywgZm9udFdlaWdodDogNjAwIH19PlJlYWQtT25seTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgICAgICAgICAgIFBBR0U6IEFDQ09VTlRTXG4gICAgICAgICAgICAgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XG4gICAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ0FjY291bnRzJyAmJiAoXG4gICAgICAgICAgICA8PlxuICAgICAgICAgICAgICB7LyogQWNjb3VudCBzdW1tYXJ5IGNhcmRzICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN1bW1hcnktY2FyZHMtZ3JpZFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3VtbWFyeS1jYXJkXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN1bW1hcnktaWNvbi1ib3hcIiBzdHlsZT17eyBiYWNrZ3JvdW5kOiAnI0ZGRjVFOScsIGNvbG9yOiAnI0ZGQkIzOCcgfX0+XG4gICAgICAgICAgICAgICAgICAgIDxEb2xsYXJTaWduIHNpemU9ezI0fSAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN1bW1hcnktbGFiZWxcIj5NeSBCYWxhbmNlPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3VtbWFyeS12YWxcIj4keyhjYXJkcy5yZWR1Y2UoKGFjYywgYykgPT4gYWNjICsgYy5iYWxhbmNlLCAwKSkudG9Mb2NhbGVTdHJpbmcoKX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdW1tYXJ5LWNhcmRcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3VtbWFyeS1pY29uLWJveFwiIHN0eWxlPXt7IGJhY2tncm91bmQ6ICcjRTdGM0ZGJywgY29sb3I6ICcjMzk2QUZGJyB9fT5cbiAgICAgICAgICAgICAgICAgICAgPFRyZW5kaW5nVXAgc2l6ZT17MjR9IC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3VtbWFyeS1sYWJlbFwiPkluY29tZSBHcm93dGg8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdW1tYXJ5LXZhbFwiPisxNS44JTwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN1bW1hcnktY2FyZFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdW1tYXJ5LWljb24tYm94XCIgc3R5bGU9e3sgYmFja2dyb3VuZDogJyNEQ0ZDRTcnLCBjb2xvcjogJyMxMEI5ODEnIH19PlxuICAgICAgICAgICAgICAgICAgICA8Q3JlZGl0Q2FyZCBzaXplPXsyNH0gLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdW1tYXJ5LWxhYmVsXCI+VG90YWwgQWNjb3VudHM8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdW1tYXJ5LXZhbFwiPntjYXJkcy5sZW5ndGh9IEFjdGl2ZTwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBBY2NvdW50cyBDb250ZW50IGxheW91dCAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkYXNoYm9hcmQtc2VjdGlvbi1yb3dcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC04XCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlY3Rpb24taGVhZGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJzZWN0aW9uLXRpdGxlXCI+UmVjZW50IERlcG9zaXRzPC9oMz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0YWJsZS13cmFwcGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJjdXN0b20tdGFibGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8dGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0aD5EZXNjcmlwdGlvbjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0aD5EYXRlPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoPk1ldGhvZDwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0aD5BbW91bnQ8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgICAgIHt0cmFuc2FjdGlvbnNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmZpbHRlcih0eCA9PiB0eC50eXBlID09PSAnaW5jb21lJylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnNsaWNlKDAsIDQpXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5tYXAoKHR4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17dHguaWR9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkPnt0eC5kZXNjfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgc3R5bGU9e3sgY29sb3I6ICcjNzE4RUJGJyB9fT57dHguZGF0ZX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkPnt0eC5tZXRob2R9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBzdHlsZT17eyBjb2xvcjogJ3ZhcigtLXN1Y2Nlc3MpJywgZm9udFdlaWdodDogJzcwMCcgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICske3R4LmFtb3VudC50b0xvY2FsZVN0cmluZygpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7LyogQ2FzaCBGbG93IHN1bW1hcnkgYmxvY2sgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtNFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWN0aW9uLWhlYWRlclwiPlxuICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwic2VjdGlvbi10aXRsZVwiPldlZWtseSBDYXNoIEZsb3c8L2gzPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBhbmVsXCIgc3R5bGU9e3sgcGFkZGluZzogJzJyZW0nLCBqdXN0aWZ5Q29udGVudDogJ3NwYWNlLWFyb3VuZCcgfX0+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogJzAuODVyZW0nLCBjb2xvcjogJyM3MThFQkYnIH19PkF2ZXJhZ2UgRGVwb3NpdDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFNpemU6ICcxLjc1cmVtJywgZm9udFdlaWdodDogNzAwLCBjb2xvcjogJ3ZhcigtLXN1Y2Nlc3MpJywgbWFyZ2luVG9wOiAnMC4yNXJlbScgfX0+KyQzLDQ1MDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiAnMC44NXJlbScsIGNvbG9yOiAnIzcxOEVCRicgfX0+QXZlcmFnZSBXaXRoZHJhd2FsPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogJzEuNzVyZW0nLCBmb250V2VpZ2h0OiA3MDAsIGNvbG9yOiAndmFyKC0tZXJyb3IpJywgbWFyZ2luVG9wOiAnMC4yNXJlbScgfX0+LSQ0MTI8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8Lz5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgICAgICAgICAgIFBBR0U6IElOVkVTVE1FTlRTXG4gICAgICAgICAgICAgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XG4gICAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ0ludmVzdG1lbnRzJyAmJiAoXG4gICAgICAgICAgICA8PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN1bW1hcnktY2FyZHMtZ3JpZFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3VtbWFyeS1jYXJkXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN1bW1hcnktaWNvbi1ib3hcIiBzdHlsZT17eyBiYWNrZ3JvdW5kOiAnI0U3RjNGRicsIGNvbG9yOiAnIzM5NkFGRicgfX0+XG4gICAgICAgICAgICAgICAgICAgIDxCcmllZmNhc2Ugc2l6ZT17MjR9IC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3VtbWFyeS1sYWJlbFwiPlRvdGFsIFZhbHVlPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3VtbWFyeS12YWxcIj4kNjUsMjQwPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN1bW1hcnktY2FyZFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdW1tYXJ5LWljb24tYm94XCIgc3R5bGU9e3sgYmFja2dyb3VuZDogJyNEQ0ZDRTcnLCBjb2xvcjogJyMxMEI5ODEnIH19PlxuICAgICAgICAgICAgICAgICAgICA8VHJlbmRpbmdVcCBzaXplPXsyNH0gLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdW1tYXJ5LWxhYmVsXCI+TmV0IEdyb3d0aDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN1bW1hcnktdmFsXCI+KyQ4LDI0MSAoMTIuNCUpPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN1bW1hcnktY2FyZFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdW1tYXJ5LWljb24tYm94XCIgc3R5bGU9e3sgYmFja2dyb3VuZDogJyNGRkY1RTknLCBjb2xvcjogJyNGRkJCMzgnIH19PlxuICAgICAgICAgICAgICAgICAgICA8U3BhcmtsZXMgc2l6ZT17MjR9IC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3VtbWFyeS1sYWJlbFwiPkFzc2V0cyBDb3VudDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN1bW1hcnktdmFsXCI+NCBBY3RpdmU8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRhc2hib2FyZC1zZWN0aW9uLXJvd1wiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLTdcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VjdGlvbi1oZWFkZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInNlY3Rpb24tdGl0bGVcIj5NeSBQb3J0Zm9saW88L2gzPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBhbmVsXCIgc3R5bGU9e3sgaGVpZ2h0OiAnMzAwcHgnIH19PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN0b2Nrcy1saXN0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdG9jay1yb3ctaXRlbVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdG9jay1uYW1lLWNvbFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN0b2NrLWljb24td3JhcHBlclwiIHN0eWxlPXt7IGJhY2tncm91bmQ6ICcjMDAwMDAwJyB9fT5BPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdG9jay10aXRsZVwiPkFwcGxlIEluYy48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN0b2NrLWRlc2NcIj5BQVBMIChOYXNkYXEpPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN0b2NrLXZhbC1ib3hcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdG9jay1wcmljZVwiPiQxNzQuMTI8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdG9jay1jaGFuZ2UtcGVyY2VudCBwb3NpdGl2ZVwiPisxLjg1JTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdG9jay1yb3ctaXRlbVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdG9jay1uYW1lLWNvbFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN0b2NrLWljb24td3JhcHBlclwiIHN0eWxlPXt7IGJhY2tncm91bmQ6ICcjRTgyMTI3JyB9fT5UPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdG9jay10aXRsZVwiPlRlc2xhIEluYy48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN0b2NrLWRlc2NcIj5UU0xBIChOYXNkYXEpPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN0b2NrLXZhbC1ib3hcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdG9jay1wcmljZVwiPiQxODUuMDA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdG9jay1jaGFuZ2UtcGVyY2VudCBuZWdhdGl2ZVwiPi0yLjQwJTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdG9jay1yb3ctaXRlbVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdG9jay1uYW1lLWNvbFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN0b2NrLWljb24td3JhcHBlclwiIHN0eWxlPXt7IGJhY2tncm91bmQ6ICcjNDI4NUY0JyB9fT5HPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdG9jay10aXRsZVwiPkFscGhhYmV0IEluYy48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN0b2NrLWRlc2NcIj5HT09HTCAoTmFzZGFxKTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdG9jay12YWwtYm94XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3RvY2stcHJpY2VcIj4kMTU0LjIwPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3RvY2stY2hhbmdlLXBlcmNlbnQgcG9zaXRpdmVcIj4rMC45NSU8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtNVwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWN0aW9uLWhlYWRlclwiPlxuICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwic2VjdGlvbi10aXRsZVwiPkludmVzdG1lbnQgR3Jvd3RoIENoYXJ0PC9oMz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYW5lbFwiIHN0eWxlPXt7IGhlaWdodDogJzMwMHB4JywgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywganVzdGlmeUNvbnRlbnQ6ICdjZW50ZXInIH19PlxuICAgICAgICAgICAgICAgICAgICA8c3ZnIHdpZHRoPVwiMjIwXCIgaGVpZ2h0PVwiMTUwXCIgdmlld0JveD1cIjAgMCAyMjAgMTUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD1cIk0gMTAgMTMwIEMgNTAgMTEwLCA4MCA0MCwgMTIwIDcwIEMgMTYwIDEwMCwgMTgwIDIwLCAyMTAgMTBcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cInZhcigtLWFjY2VudC1wcmltYXJ5KVwiIHN0cm9rZVdpZHRoPVwiNFwiIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPGNpcmNsZSBjeD1cIjIxMFwiIGN5PVwiMTBcIiByPVwiNlwiIGZpbGw9XCJ2YXIoLS1hY2NlbnQtcHJpbWFyeSlcIiBzdHJva2U9XCIjRkZGRkZGXCIgc3Ryb2tlV2lkdGg9XCIyXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8dGV4dCB4PVwiMTBcIiB5PVwiMTQ1XCIgZmlsbD1cIiM3MThFQkZcIiBmb250U2l6ZT1cIjEwXCI+MjAyMTwvdGV4dD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGV4dCB4PVwiMjEwXCIgeT1cIjE0NVwiIGZpbGw9XCIjNzE4RUJGXCIgZm9udFNpemU9XCIxMFwiIHRleHRBbmNob3I9XCJlbmRcIj4yMDI2PC90ZXh0PlxuICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvPlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICAgICAgICAgICAgUEFHRTogQ1JFRElUIENBUkRTXG4gICAgICAgICAgICAgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XG4gICAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ0NyZWRpdCBDYXJkcycgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkYXNoYm9hcmQtc2VjdGlvbi1yb3dcIj5cbiAgICAgICAgICAgICAgey8qIENhcmQgTGlzdCBpbiBhIGdyaWQgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLTdcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlY3Rpb24taGVhZGVyXCI+XG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwic2VjdGlvbi10aXRsZVwiPk15IENhcmRzPC9oMz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdncmlkJywgZ3JpZFRlbXBsYXRlQ29sdW1uczogJ3JlcGVhdChhdXRvLWZpbGwsIG1pbm1heCgyOTBweCwgMWZyKSknLCBnYXA6ICcxLjVyZW0nIH19PlxuICAgICAgICAgICAgICAgICAge2NhcmRzLm1hcCgoY2FyZCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17Y2FyZC5pZH0gY2xhc3NOYW1lPXtgY3JlZGl0LWNhcmQgJHtjYXJkLnR5cGV9YH0gc3R5bGU9e3sgd2lkdGg6ICcxMDAlJyB9fT5cbiAgICAgICAgICAgICAgICAgICAgICB7LyogSG92ZXIgT3ZlcmxheSBDUlVEIGFjdGlvbnMgKi99XG4gICAgICAgICAgICAgICAgICAgICAge3VzZXJTZXNzaW9uLnBlcm1pc3Npb25zPy5tYW5hZ2VfY2FyZHMgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkLWFjdGlvbnMtb3ZlcmxheVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImNhcmQtbWluaS1idG5cIiBvbkNsaWNrPXsoKSA9PiBvcGVuQ2FyZEVkaXRNb2RhbChjYXJkKX0gdGl0bGU9XCJFZGl0IENhcmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RWRpdDIgc2l6ZT17MTN9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImNhcmQtbWluaS1idG5cIiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEZWxldGVDYXJkKGNhcmQuaWQpfSB0aXRsZT1cIkRlbGV0ZSBDYXJkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRyYXNoMiBzaXplPXsxM30gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkLWhlYWRlci1yb3dcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1sYWJlbFwiPkJhbGFuY2U8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkLWJhbGFuY2VcIj4ke2NhcmQuYmFsYW5jZS50b0xvY2FsZVN0cmluZygpfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aW1nIFxuICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9e2NhcmQudHlwZSA9PT0gJ2xpZ2h0JyA/ICdodHRwczovL2ltZy5pY29uczguY29tL2lvcy81MC8zNDNjNmEvY2hpcC5wbmcnIDogJ2h0dHBzOi8vaW1nLmljb25zOC5jb20vaW9zLWZpbGxlZC81MC9mZmZmZmYvY2hpcC5wbmcnfSBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PVwiQ2hpcFwiIFxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjYXJkLWNoaXBcIiBcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkLW1pZGRsZS1yb3dcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1ob2xkZXItaW5mb1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQtbGFiZWxcIj5DYXJkIEhvbGRlcjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQtdmFsdWVcIj57Y2FyZC5ob2xkZXJ9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1leHBpcnktaW5mb1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQtbGFiZWxcIj5WYWxpZCBUaHJ1PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC12YWx1ZVwiPntjYXJkLmV4cGlyeX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1mb290ZXItcm93XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQtbnVtYmVyXCI+e2NhcmQubnVtYmVyfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJjYXJkLWxvZ29cIiB3aWR0aD1cIjQ0XCIgaGVpZ2h0PVwiMzBcIiB2aWV3Qm94PVwiMCAwIDQ0IDMwXCIgZmlsbD1cIm5vbmVcIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxjaXJjbGUgY3g9XCIxNVwiIGN5PVwiMTVcIiByPVwiMTVcIiBmaWxsPXtjYXJkLnR5cGUgPT09ICdsaWdodCcgPyAnIzkxOTlBRicgOiAnd2hpdGUnfSBmaWxsT3BhY2l0eT1cIjAuNVwiLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGNpcmNsZSBjeD1cIjI5XCIgY3k9XCIxNVwiIHI9XCIxNVwiIGZpbGw9e2NhcmQudHlwZSA9PT0gJ2xpZ2h0JyA/ICcjOTE5OUFGJyA6ICd3aGl0ZSd9IGZpbGxPcGFjaXR5PVwiMC41XCIvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBGb3JtIHRvIEFkZCBOZXcgQ2FyZCAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtNVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VjdGlvbi1oZWFkZXJcIj5cbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJzZWN0aW9uLXRpdGxlXCI+QWRkIE5ldyBDYXJkPC9oMz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBhbmVsXCIgc3R5bGU9e3sgbWluSGVpZ2h0OiAnMzQwcHgnIH19PlxuICAgICAgICAgICAgICAgICAgeyF1c2VyU2Vzc2lvbi5wZXJtaXNzaW9ucz8ubWFuYWdlX2NhcmRzICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBjb2xvcjogJ3ZhcigtLWVycm9yKScsIGJhY2tncm91bmQ6ICdyZ2JhKDI1NSwgNzUsIDc0LCAwLjA4KScsIGJvcmRlcjogJzFweCBzb2xpZCByZ2JhKDI1NSwgNzUsIDc0LCAwLjIpJywgcGFkZGluZzogJzAuNzVyZW0nLCBib3JkZXJSYWRpdXM6ICcxMnB4JywgZm9udFNpemU6ICcwLjg1cmVtJywgZm9udFdlaWdodDogNjAwLCBtYXJnaW5Cb3R0b206ICcxcmVtJywgdGV4dEFsaWduOiAnY2VudGVyJyB9fT5cbiAgICAgICAgICAgICAgICAgICAgICBSZWFkLU9ubHk6IENhcmQgY3JlYXRpb24gaXMgZGlzYWJsZWQuXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVBZGRDYXJkfSBjbGFzc05hbWU9XCJhZGQtY2FyZC1mb3JtXCIgc3R5bGU9eyF1c2VyU2Vzc2lvbi5wZXJtaXNzaW9ucz8ubWFuYWdlX2NhcmRzID8geyBvcGFjaXR5OiAwLjYgfSA6IHt9fT5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZXR0aW5ncy1pbnB1dC1ncm91cFwiIHN0eWxlPXt7IGdyaWRDb2x1bW46ICdzcGFuIDInIH19PlxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbD5DYXJkIEhvbGRlciBOYW1lPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiIFxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic2V0dGluZ3MtZm9ybS1pbnB1dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkpvaG4gRG9lXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtuZXdDYXJkRm9ybS5ob2xkZXJ9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE5ld0NhcmRGb3JtKHsgLi4ubmV3Q2FyZEZvcm0sIGhvbGRlcjogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IXVzZXJTZXNzaW9uLnBlcm1pc3Npb25zPy5tYW5hZ2VfY2FyZHN9XG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2V0dGluZ3MtaW5wdXQtZ3JvdXBcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWw+U3RhcnRpbmcgQmFsYW5jZSAoJCk8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIiBcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNldHRpbmdzLWZvcm0taW5wdXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCIyNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtuZXdDYXJkRm9ybS5iYWxhbmNlfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROZXdDYXJkRm9ybSh7IC4uLm5ld0NhcmRGb3JtLCBiYWxhbmNlOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshdXNlclNlc3Npb24ucGVybWlzc2lvbnM/Lm1hbmFnZV9jYXJkc31cbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZXR0aW5ncy1pbnB1dC1ncm91cFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbD5FeHBpcnkgRGF0ZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIiBcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNldHRpbmdzLWZvcm0taW5wdXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJNTS9ZWVwiXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXhMZW5ndGg9XCI1XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtuZXdDYXJkRm9ybS5leHBpcnl9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE5ld0NhcmRGb3JtKHsgLi4ubmV3Q2FyZEZvcm0sIGV4cGlyeTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IXVzZXJTZXNzaW9uLnBlcm1pc3Npb25zPy5tYW5hZ2VfY2FyZHN9XG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2V0dGluZ3MtaW5wdXQtZ3JvdXBcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWw+Q2FyZCBOdW1iZXIgKDE2IERpZ2l0cyk8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCIgXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzZXR0aW5ncy1mb3JtLWlucHV0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiNDgxMjM4NDkxMDI5Mzg0N1wiXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXhMZW5ndGg9XCIxNlwiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17bmV3Q2FyZEZvcm0ubnVtYmVyfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROZXdDYXJkRm9ybSh7IC4uLm5ld0NhcmRGb3JtLCBudW1iZXI6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyF1c2VyU2Vzc2lvbi5wZXJtaXNzaW9ucz8ubWFuYWdlX2NhcmRzfVxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNldHRpbmdzLWlucHV0LWdyb3VwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsPkNhcmQgQ29sb3IgdGhlbWU8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3QgXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzZXR0aW5ncy1mb3JtLWlucHV0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtuZXdDYXJkRm9ybS50eXBlfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROZXdDYXJkRm9ybSh7IC4uLm5ld0NhcmRGb3JtLCB0eXBlOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshdXNlclNlc3Npb24ucGVybWlzc2lvbnM/Lm1hbmFnZV9jYXJkc31cbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiZGFya1wiPkRhcmsgR3JhZGllbnQ8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJsaWdodFwiPkxpZ2h0IEJvcmRlcjwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImdyZWVuXCI+RW1lcmFsZCBHcmVlbjwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cInB1cnBsZVwiPlJveWFsIFB1cnBsZTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgY2xhc3NOYW1lPVwiYWRkLWNhcmQtYnRuXCIgZGlzYWJsZWQ9eyF1c2VyU2Vzc2lvbi5wZXJtaXNzaW9ucz8ubWFuYWdlX2NhcmRzfSBzdHlsZT17IXVzZXJTZXNzaW9uLnBlcm1pc3Npb25zPy5tYW5hZ2VfY2FyZHMgPyB7IG9wYWNpdHk6IDAuNSwgY3Vyc29yOiAnbm90LWFsbG93ZWQnLCBwb2ludGVyRXZlbnRzOiAnbm9uZScgfSA6IHt9fT5cbiAgICAgICAgICAgICAgICAgICAgICBDcmVhdGUgQ3JlZGl0IENhcmRcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHsvKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgICAgICAgICAgICBQQUdFOiBMT0FOU1xuICAgICAgICAgICAgID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxuICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdMb2FucycgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkYXNoYm9hcmQtc2VjdGlvbi1yb3dcIj5cbiAgICAgICAgICAgICAgey8qIEFjdGl2ZSBMb2FucyBUYWJsZSAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtOFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VjdGlvbi1oZWFkZXJcIj5cbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJzZWN0aW9uLXRpdGxlXCI+QWN0aXZlIExvYW5zPC9oMz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRhYmxlLXdyYXBwZXJcIj5cbiAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJjdXN0b20tdGFibGVcIj5cbiAgICAgICAgICAgICAgICAgICAgPHRoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aD5Mb2FuIElEPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aD5Mb2FuIFR5cGU8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoPlByaW5jaXBhbCBBbW91bnQ8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoPk91dHN0YW5kaW5nIEJhbGFuY2U8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoPkluc3RhbGxtZW50PC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aD5UZXJtIExlZnQ8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgIDx0Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgICB7bG9hbnMubWFwKChsb2FuKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtsb2FuLmlkfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIHN0eWxlPXt7IGNvbG9yOiAnIzcxOEVCRicgfX0+e2xvYW4uaWR9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIHN0eWxlPXt7IGZvbnRXZWlnaHQ6ICc2MDAnIH19Pntsb2FuLnR5cGV9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkPiR7bG9hbi5hbW91bnQudG9Mb2NhbGVTdHJpbmcoKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQ+JHtsb2FuLmJhbGFuY2UudG9Mb2NhbGVTdHJpbmcoKX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgc3R5bGU9e3sgY29sb3I6ICd2YXIoLS1lcnJvciknIH19PiR7bG9hbi5pbnN0YWxsbWVudH0vbW88L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQ+e2xvYW4uZHVyYXRpb259PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogU2ltcGxlIExvYW4gQ2FsY3VsYXRvciAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtNFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VjdGlvbi1oZWFkZXJcIj5cbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJzZWN0aW9uLXRpdGxlXCI+TG9hbiBDYWxjdWxhdG9yPC9oMz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBhbmVsXCIgc3R5bGU9e3sgbWluSGVpZ2h0OiAnMzQwcHgnIH19PlxuICAgICAgICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2NhbGN1bGF0ZUxvYW59IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsIGdhcDogJzFyZW0nLCBvcGFjaXR5OiAhdXNlclNlc3Npb24ucGVybWlzc2lvbnM/Lm1hbmFnZV9sb2FucyA/IDAuOCA6IDEgfX0+XG4gICAgICAgICAgICAgICAgICAgIHshdXNlclNlc3Npb24ucGVybWlzc2lvbnM/Lm1hbmFnZV9sb2FucyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBjb2xvcjogJ3ZhcigtLWVycm9yKScsIGJhY2tncm91bmQ6ICdyZ2JhKDI1NSwgNzUsIDc0LCAwLjA4KScsIGJvcmRlcjogJzFweCBzb2xpZCByZ2JhKDI1NSwgNzUsIDc0LCAwLjIpJywgcGFkZGluZzogJzAuNnJlbScsIGJvcmRlclJhZGl1czogJzEwcHgnLCBmb250U2l6ZTogJzAuOHJlbScsIGZvbnRXZWlnaHQ6IDYwMCwgdGV4dEFsaWduOiAnY2VudGVyJyB9fT5cbiAgICAgICAgICAgICAgICAgICAgICAgIFJlYWQtT25seTogQ2FsY3VsYXRvciBkaXNhYmxlZC5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZXR0aW5ncy1pbnB1dC1ncm91cFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbD5QcmluY2lwYWwgQW1vdW50ICgkKTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiIFxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic2V0dGluZ3MtZm9ybS1pbnB1dFwiIFxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2xvYW5DYWxjLmFtb3VudH1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TG9hbkNhbGMoeyAuLi5sb2FuQ2FsYywgYW1vdW50OiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshdXNlclNlc3Npb24ucGVybWlzc2lvbnM/Lm1hbmFnZV9sb2Fuc31cbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZXR0aW5ncy1pbnB1dC1ncm91cFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbD5JbnRlcmVzdCBSYXRlICglIEFubnVhbCk8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIiBcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0ZXA9XCIwLjFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic2V0dGluZ3MtZm9ybS1pbnB1dFwiIFxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2xvYW5DYWxjLnJhdGV9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldExvYW5DYWxjKHsgLi4ubG9hbkNhbGMsIHJhdGU6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyF1c2VyU2Vzc2lvbi5wZXJtaXNzaW9ucz8ubWFuYWdlX2xvYW5zfVxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNldHRpbmdzLWlucHV0LWdyb3VwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsPkR1cmF0aW9uIChNb250aHMpPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCIgXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzZXR0aW5ncy1mb3JtLWlucHV0XCIgXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17bG9hbkNhbGMudGVybX1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TG9hbkNhbGMoeyAuLi5sb2FuQ2FsYywgdGVybTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IXVzZXJTZXNzaW9uLnBlcm1pc3Npb25zPy5tYW5hZ2VfbG9hbnN9XG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIGNsYXNzTmFtZT1cImFkZC1jYXJkLWJ0blwiIGRpc2FibGVkPXshdXNlclNlc3Npb24ucGVybWlzc2lvbnM/Lm1hbmFnZV9sb2Fuc30gc3R5bGU9eyF1c2VyU2Vzc2lvbi5wZXJtaXNzaW9ucz8ubWFuYWdlX2xvYW5zID8geyBncmlkQ29sdW1uOiAnc3BhbiAxJywgb3BhY2l0eTogMC41LCBjdXJzb3I6ICdub3QtYWxsb3dlZCcsIHBvaW50ZXJFdmVudHM6ICdub25lJyB9IDogeyBncmlkQ29sdW1uOiAnc3BhbiAxJyB9fT5cbiAgICAgICAgICAgICAgICAgICAgICBDYWxjdWxhdGUgSW5zdGFsbG1lbnRcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIHtsb2FuQ2FsYy5vdXRwdXQgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luVG9wOiAnMC41cmVtJywgdGV4dEFsaWduOiAnY2VudGVyJyB9fT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFNpemU6ICcwLjhyZW0nLCBjb2xvcjogJyM3MThFQkYnIH19PkVzdGltYXRlZCBJbnN0YWxsbWVudDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogJzEuNXJlbScsIGZvbnRXZWlnaHQ6ICc3MDAnLCBjb2xvcjogJ3ZhcigtLWFjY2VudC1wcmltYXJ5KScgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICR7bG9hbkNhbGMub3V0cHV0fSAvIG1vXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgICAgICAgICAgIFBBR0U6IFNFUlZJQ0VTXG4gICAgICAgICAgICAgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XG4gICAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ1NlcnZpY2VzJyAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC0xMlwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlY3Rpb24taGVhZGVyXCI+XG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInNlY3Rpb24tdGl0bGVcIj5NYW5hZ2UgU2VydmljZXM8L2gzPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZXJ2aWNlcy1saXN0XCI+XG4gICAgICAgICAgICAgICAge3NlcnZpY2VzLm1hcCgoc3J2KSA9PiB7XG4gICAgICAgICAgICAgICAgICBjb25zdCBTcnZJY29uID0gaWNvbk1hcFtzcnYuaWNvbk5hbWVdIHx8IFNoaWVsZENoZWNrO1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e3Nydi5pZH0gY2xhc3NOYW1lPVwic2VydmljZS1pdGVtLWJveFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VydmljZS1pY29uLWJveFwiIHN0eWxlPXt7IGJhY2tncm91bmQ6IGAke3Nydi5jb2xvcn0xNWAsIGNvbG9yOiBzcnYuY29sb3IgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgICA8U3J2SWNvbiBzaXplPXsyNH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlcnZpY2UtdGV4dFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGg0PntzcnYudGl0bGV9PC9oND5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxwPntzcnYuZGVzY308L3A+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJzd2l0Y2gtbGFiZWxcIiBzdHlsZT17eyBwb2ludGVyRXZlbnRzOiB1c2VyU2Vzc2lvbi5wZXJtaXNzaW9ucz8ubWFuYWdlX3NlcnZpY2VzID8gJ2F1dG8nIDogJ25vbmUnLCBvcGFjaXR5OiB1c2VyU2Vzc2lvbi5wZXJtaXNzaW9ucz8ubWFuYWdlX3NlcnZpY2VzID8gMSA6IDAuNiB9fT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3Nydi5lbmFibGVkfSBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT4gdG9nZ2xlU2VydmljZShzcnYuaWQpfSBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IXVzZXJTZXNzaW9uLnBlcm1pc3Npb25zPy5tYW5hZ2Vfc2VydmljZXN9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInN3aXRjaC1zbGlkZXJcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHsvKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgICAgICAgICAgICBQQUdFOiBNWSBQUklWSUxFR0VTXG4gICAgICAgICAgICAgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XG4gICAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ015IFByaXZpbGVnZXMnICYmIChcbiAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3VtbWFyeS1jYXJkcy1ncmlkXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdW1tYXJ5LWNhcmRcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3VtbWFyeS1pY29uLWJveFwiIHN0eWxlPXt7IGJhY2tncm91bmQ6ICcjRTdGM0ZGJywgY29sb3I6ICcjMzk2QUZGJyB9fT5cbiAgICAgICAgICAgICAgICAgICAgPFNwYXJrbGVzIHNpemU9ezI0fSAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN1bW1hcnktbGFiZWxcIj5Mb3lhbHR5IFRpZXI8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdW1tYXJ5LXZhbFwiPkdvbGQgTWVtYmVyPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN1bW1hcnktY2FyZFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdW1tYXJ5LWljb24tYm94XCIgc3R5bGU9e3sgYmFja2dyb3VuZDogJyNGRkY1RTknLCBjb2xvcjogJyNGRkJCMzgnIH19PlxuICAgICAgICAgICAgICAgICAgICA8VHJlbmRpbmdVcCBzaXplPXsyNH0gLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdW1tYXJ5LWxhYmVsXCI+UmV3YXJkIFBvaW50cyBCYWxhbmNlPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3VtbWFyeS12YWxcIj4xMiw0NTAgcHRzPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkYXNoYm9hcmQtc2VjdGlvbi1yb3dcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC0xMlwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWN0aW9uLWhlYWRlclwiPlxuICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwic2VjdGlvbi10aXRsZVwiPlRpZXIgQmVuZWZpdHMgJiBQcml2aWxlZ2VzPC9oMz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYW5lbFwiIHN0eWxlPXt7IGhlaWdodDogJ2F1dG8nLCBnYXA6ICcxLjI1cmVtJyB9fT5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGdhcDogJzEuNXJlbScsIGJvcmRlckJvdHRvbTogJzFweCBzb2xpZCB2YXIoLS1ib3JkZXItY29sb3IpJywgcGFkZGluZ0JvdHRvbTogJzFyZW0nIH19PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgYmFja2dyb3VuZDogJ3JnYmEoMjQsIDIwLCAyNDMsIDAuMDUpJywgYm9yZGVyUmFkaXVzOiAnNTAlJywgd2lkdGg6ICc0MHB4JywgaGVpZ2h0OiAnNDBweCcsIGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGp1c3RpZnlDb250ZW50OiAnY2VudGVyJywgY29sb3I6ICd2YXIoLS1hY2NlbnQtcHJpbWFyeSknLCBmb250V2VpZ2h0OiAnNzAwJyB9fT4xPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxoNCBzdHlsZT17eyBjb2xvcjogJ3ZhcigtLXRleHQtcHJpbWFyeSknLCBmb250V2VpZ2h0OiA2MDAgfX0+MCUgVHJhbnNhY3Rpb24gRmVlczwvaDQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBzdHlsZT17eyBjb2xvcjogJ3ZhcigtLXRleHQtc2Vjb25kYXJ5KScsIGZvbnRTaXplOiAnMC44NXJlbScsIG1hcmdpblRvcDogJzAuMnJlbScgfX0+RW5qb3kgZnJlZSB3aXJlIHRyYW5zZmVycyBhbmQgY3JlZGl0IGNhcmQgcGF5bWVudHMgdG8gYWxsIGludGVybmF0aW9uYWwgYmFua3MuPC9wPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGdhcDogJzEuNXJlbScsIGJvcmRlckJvdHRvbTogJzFweCBzb2xpZCB2YXIoLS1ib3JkZXItY29sb3IpJywgcGFkZGluZ0JvdHRvbTogJzFyZW0nIH19PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgYmFja2dyb3VuZDogJ3JnYmEoMjQsIDIwLCAyNDMsIDAuMDUpJywgYm9yZGVyUmFkaXVzOiAnNTAlJywgd2lkdGg6ICc0MHB4JywgaGVpZ2h0OiAnNDBweCcsIGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGp1c3RpZnlDb250ZW50OiAnY2VudGVyJywgY29sb3I6ICd2YXIoLS1hY2NlbnQtcHJpbWFyeSknLCBmb250V2VpZ2h0OiAnNzAwJyB9fT4yPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxoNCBzdHlsZT17eyBjb2xvcjogJ3ZhcigtLXRleHQtcHJpbWFyeSknLCBmb250V2VpZ2h0OiA2MDAgfX0+UHJpb3JpdHkgU3VwcG9ydDwvaDQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBzdHlsZT17eyBjb2xvcjogJ3ZhcigtLXRleHQtc2Vjb25kYXJ5KScsIGZvbnRTaXplOiAnMC44NXJlbScsIG1hcmdpblRvcDogJzAuMnJlbScgfX0+MjQvNyBkZWRpY2F0ZWQgc3VwcG9ydCBkZXNrIHdpdGggY2hhdCByZXNwb25zZXMgaW4gdW5kZXIgMSBtaW51dGUuPC9wPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGdhcDogJzEuNXJlbScgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBiYWNrZ3JvdW5kOiAncmdiYSgyNCwgMjAsIDI0MywgMC4wNSknLCBib3JkZXJSYWRpdXM6ICc1MCUnLCB3aWR0aDogJzQwcHgnLCBoZWlnaHQ6ICc0MHB4JywgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywganVzdGlmeUNvbnRlbnQ6ICdjZW50ZXInLCBjb2xvcjogJ3ZhcigtLWFjY2VudC1wcmltYXJ5KScsIGZvbnRXZWlnaHQ6ICc3MDAnIH19PjM8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGg0IHN0eWxlPXt7IGNvbG9yOiAndmFyKC0tdGV4dC1wcmltYXJ5KScsIGZvbnRXZWlnaHQ6IDYwMCB9fT5BaXJwb3J0IExvdW5nZSBBY2Nlc3M8L2g0PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgc3R5bGU9e3sgY29sb3I6ICd2YXIoLS10ZXh0LXNlY29uZGFyeSknLCBmb250U2l6ZTogJzAuODVyZW0nLCBtYXJnaW5Ub3A6ICcwLjJyZW0nIH19PkNvbXBsaW1lbnRhcnkgZ2xvYmFsIGFjY2VzcyB0byBwcmVtaXVtIGFpcnBvcnQgbG91bmdlcyB3aXRoIHlvdXIgcHJpbWFyeSBkYXJrIGNhcmQuPC9wPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvPlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICAgICAgICAgICAgUEFHRTogU0VUVElOR1xuICAgICAgICAgICAgID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxuICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdTZXR0aW5nJyAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC0xMlwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNldHRpbmdzLXBhbmVsXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZXR0aW5ncy10YWJzXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IFxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BzZXR0aW5ncy10YWIgJHtzZXR0aW5nc1N1YlRhYiA9PT0gJ0VkaXQgUHJvZmlsZScgPyAnYWN0aXZlJyA6ICcnfWB9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNldHRpbmdzU3ViVGFiKCdFZGl0IFByb2ZpbGUnKX1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgRWRpdCBQcm9maWxlXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHNldHRpbmdzLXRhYiAke3NldHRpbmdzU3ViVGFiID09PSAnUHJlZmVyZW5jZScgPyAnYWN0aXZlJyA6ICcnfWB9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNldHRpbmdzU3ViVGFiKCdQcmVmZXJlbmNlJyl9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIFByZWZlcmVuY2VzXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHNldHRpbmdzLXRhYiAke3NldHRpbmdzU3ViVGFiID09PSAnU2VjdXJpdHknID8gJ2FjdGl2ZScgOiAnJ31gfVxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZXR0aW5nc1N1YlRhYignU2VjdXJpdHknKX1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgU2VjdXJpdHlcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIFN1YiBUYWI6IEVkaXQgUHJvZmlsZSAqL31cbiAgICAgICAgICAgICAgICB7c2V0dGluZ3NTdWJUYWIgPT09ICdFZGl0IFByb2ZpbGUnICYmIChcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2V0dGluZ3MtY29udGVudC13cmFwcGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIHsvKiBBdmF0YXIgcGlja2VyIHNlY3Rpb24gKi99XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZmlsZS1hdmF0YXItc2VjdGlvblwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXZhdGFyLWVkaXQtd3JhcHBlclwiIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IG5ld0F2YXRhciA9IHByb21wdChcIkVudGVyIGEgVVJMIGZvciB5b3VyIHByb2ZpbGUgaW1hZ2U6XCIsIHRlbXBQcm9maWxlLmF2YXRhcik7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAobmV3QXZhdGFyKSBzZXRUZW1wUHJvZmlsZSh7IC4uLnRlbXBQcm9maWxlLCBhdmF0YXI6IG5ld0F2YXRhciB9KTtcbiAgICAgICAgICAgICAgICAgICAgICB9fT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbWcgXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNyYz17dGVtcFByb2ZpbGUuYXZhdGFyfSBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PVwiRWRpdCBBdmF0YXJcIiBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYXZhdGFyLWVkaXQtaW1nXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImF2YXRhci1lZGl0LWJhZGdlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgd2lkdGg9XCIxNFwiIGhlaWdodD1cIjE0XCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlV2lkdGg9XCIyLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBkPVwiTTEyIDIwaDlNMTYuNSAzLjVhMi4xMjEgMi4xMjEgMCAwIDEgMyAzTDcgMTlsLTQgMSAxLTRMMTYuNSAzLjV6XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogJzAuNzVyZW0nLCBjb2xvcjogJ3ZhcigtLXRleHQtc2Vjb25kYXJ5KScsIG1hcmdpblRvcDogJzAuNzVyZW0nLCBmb250V2VpZ2h0OiA2MDAgfX0+Q2xpY2sgdG8gQ2hhbmdlIFBob3RvPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICB7LyogUHJvZmlsZSBGaWVsZHMgRm9ybSAqL31cbiAgICAgICAgICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVByb2ZpbGVTYXZlfSBjbGFzc05hbWU9XCJzZXR0aW5ncy1mb3JtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZXR0aW5ncy1pbnB1dC1ncm91cFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsPllvdXIgTmFtZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCIgXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNldHRpbmdzLWZvcm0taW5wdXRcIiBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3RlbXBQcm9maWxlLm5hbWV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VGVtcFByb2ZpbGUoeyAuLi50ZW1wUHJvZmlsZSwgbmFtZTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2V0dGluZ3MtaW5wdXQtZ3JvdXBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbD5FbWFpbCBBZGRyZXNzPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCIgXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNldHRpbmdzLWZvcm0taW5wdXRcIiBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3RlbXBQcm9maWxlLmVtYWlsfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFRlbXBQcm9maWxlKHsgLi4udGVtcFByb2ZpbGUsIGVtYWlsOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZXR0aW5ncy1pbnB1dC1ncm91cFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsPlBob25lIE51bWJlcjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCIgXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNldHRpbmdzLWZvcm0taW5wdXRcIiBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3RlbXBQcm9maWxlLnBob25lfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFRlbXBQcm9maWxlKHsgLi4udGVtcFByb2ZpbGUsIHBob25lOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZXR0aW5ncy1pbnB1dC1ncm91cFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsPkRhdGUgb2YgQmlydGg8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiIFxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzZXR0aW5ncy1mb3JtLWlucHV0XCIgXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt0ZW1wUHJvZmlsZS5kb2J9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VGVtcFByb2ZpbGUoeyAuLi50ZW1wUHJvZmlsZSwgZG9iOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZXR0aW5ncy1pbnB1dC1ncm91cFwiIHN0eWxlPXt7IGdyaWRDb2x1bW46ICdzcGFuIDInIH19PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsPkFkZHJlc3M8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiIFxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzZXR0aW5ncy1mb3JtLWlucHV0XCIgXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt0ZW1wUHJvZmlsZS5hZGRyZXNzfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFRlbXBQcm9maWxlKHsgLi4udGVtcFByb2ZpbGUsIGFkZHJlc3M6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBjbGFzc05hbWU9XCJzZXR0aW5ncy1zYXZlLWJ0blwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgU2F2ZSBQcm9maWxlIERldGFpbHNcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgIHsvKiBTdWIgVGFiOiBQcmVmZXJlbmNlcyAqL31cbiAgICAgICAgICAgICAgICB7c2V0dGluZ3NTdWJUYWIgPT09ICdQcmVmZXJlbmNlJyAmJiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNldHRpbmdzLWNvbnRlbnQtd3JhcHBlclwiPlxuICAgICAgICAgICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17KGUpID0+IHsgZS5wcmV2ZW50RGVmYXVsdCgpOyBzZXRTZXR0aW5nc1N1Y2Nlc3MoJ1ByZWZlcmVuY2VzIHNhdmVkIScpOyBzZXRUaW1lb3V0KCgpID0+IHNldFNldHRpbmdzU3VjY2VzcygnJyksIDMwMDApOyB9fSBjbGFzc05hbWU9XCJzZXR0aW5ncy1mb3JtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZXR0aW5ncy1pbnB1dC1ncm91cFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsPkRlZmF1bHQgQ3VycmVuY3k8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdCBjbGFzc05hbWU9XCJzZXR0aW5ncy1mb3JtLWlucHV0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJVU0RcIj5VU0QgKCQpIC0gVVMgRG9sbGFyPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJFVVJcIj5FVVIgKOKCrCkgLSBFdXJvPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJHQlBcIj5HQlAgKMKjKSAtIEJyaXRpc2ggUG91bmQ8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2V0dGluZ3MtaW5wdXQtZ3JvdXBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbD5EZWZhdWx0IFRpbWUgWm9uZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0IGNsYXNzTmFtZT1cInNldHRpbmdzLWZvcm0taW5wdXRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkVTVFwiPkdNVC01IChFU1QpIC0gRWFzdGVybiBUaW1lPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJHTVRcIj5HTVQrMCAoR01UKSAtIExvbmRvbiBUaW1lPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJJU1RcIj5HTVQrNTozMCAoSVNUKSAtIEluZGlhIFRpbWU8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2V0dGluZ3MtaW5wdXQtZ3JvdXBcIiBzdHlsZT17eyBncmlkQ29sdW1uOiAnc3BhbiAyJywgbWFyZ2luVG9wOiAnMXJlbScgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aDQgc3R5bGU9e3sgZm9udFNpemU6ICcwLjk1cmVtJywgZm9udFdlaWdodDogNjAwLCBjb2xvcjogJ3ZhcigtLXRleHQtcHJpbWFyeSknLCBtYXJnaW5Cb3R0b206ICcxcmVtJyB9fT5Ob3RpZmljYXRpb24gUHJlZmVyZW5jZXM8L2g0PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nLCBnYXA6ICcxcmVtJyB9fT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGdhcDogJzAuNzVyZW0nLCBjdXJzb3I6ICdwb2ludGVyJywgZm9udFNpemU6ICcwLjlyZW0nIH19PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiY2hlY2tib3hcIiBkZWZhdWx0Q2hlY2tlZCAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkkgd2FudCB0byByZWNlaXZlIHdlZWtseSBlbWFpbCBzdGF0ZW1lbnQgc3VtbWFyaWVzLjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGdhcDogJzAuNzVyZW0nLCBjdXJzb3I6ICdwb2ludGVyJywgZm9udFNpemU6ICcwLjlyZW0nIH19PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiY2hlY2tib3hcIiBkZWZhdWx0Q2hlY2tlZCAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPk5vdGlmeSBtZSBhYm91dCBsb2dpbiBhY3Rpb25zIGZyb20gdW5yZWNvZ25pemVkIGRldmljZXMuPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgY2xhc3NOYW1lPVwic2V0dGluZ3Mtc2F2ZS1idG5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIFNhdmUgUHJlZmVyZW5jZXNcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgIHsvKiBTdWIgVGFiOiBTZWN1cml0eSAqL31cbiAgICAgICAgICAgICAgICB7c2V0dGluZ3NTdWJUYWIgPT09ICdTZWN1cml0eScgJiYgKFxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZXR0aW5ncy1jb250ZW50LXdyYXBwZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVNlY3VyaXR5U2F2ZX0gY2xhc3NOYW1lPVwic2V0dGluZ3MtZm9ybSBmdWxsLXdpZHRoXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZXR0aW5ncy1pbnB1dC1ncm91cFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsPkN1cnJlbnQgUGFzc3dvcmQ8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIiBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic2V0dGluZ3MtZm9ybS1pbnB1dFwiIFxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIuKAouKAouKAouKAouKAouKAouKAouKAolwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwYXNzd29yZEZvcm0uY3VycmVudH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQYXNzd29yZEZvcm0oeyAuLi5wYXNzd29yZEZvcm0sIGN1cnJlbnQ6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNldHRpbmdzLWlucHV0LWdyb3VwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWw+TmV3IFBhc3N3b3JkPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCIgXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNldHRpbmdzLWZvcm0taW5wdXRcIiBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCLigKLigKLigKLigKLigKLigKLigKLigKJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cGFzc3dvcmRGb3JtLm5ld31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQYXNzd29yZEZvcm0oeyAuLi5wYXNzd29yZEZvcm0sIG5ldzogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2V0dGluZ3MtaW5wdXQtZ3JvdXBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbD5Db25maXJtIE5ldyBQYXNzd29yZDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiIFxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzZXR0aW5ncy1mb3JtLWlucHV0XCIgXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwi4oCi4oCi4oCi4oCi4oCi4oCi4oCi4oCiXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3Bhc3N3b3JkRm9ybS5jb25maXJtfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFBhc3N3b3JkRm9ybSh7IC4uLnBhc3N3b3JkRm9ybSwgY29uZmlybTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIGNsYXNzTmFtZT1cInNldHRpbmdzLXNhdmUtYnRuXCIgc3R5bGU9e3sgZ3JpZENvbHVtbjogJ3NwYW4gMScgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgICBVcGRhdGUgUGFzc3dvcmRcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgIHsvKiBHbG9iYWwgU3VjY2VzcyBJbmRpY2F0b3IgKi99XG4gICAgICAgICAgICAgICAge3NldHRpbmdzU3VjY2VzcyAmJiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IFxuICAgICAgICAgICAgICAgICAgICBtYXJnaW5Ub3A6ICcxLjVyZW0nLCBcbiAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogJzAuOHJlbSAxLjVyZW0nLCBcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogJ3JnYmEoMjIsIDIxOSwgMTcwLCAwLjEyKScsIFxuICAgICAgICAgICAgICAgICAgICBjb2xvcjogJyMwZTkwNmYnLCBcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAnMTJweCcsIFxuICAgICAgICAgICAgICAgICAgICBmb250U2l6ZTogJzAuOTVyZW0nLCBcbiAgICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogNjAwLFxuICAgICAgICAgICAgICAgICAgICB0ZXh0QWxpZ246ICdjZW50ZXInLFxuICAgICAgICAgICAgICAgICAgICBib3JkZXI6ICcxcHggc29saWQgcmdiYSgyMiwgMjE5LCAxNzAsIDAuMjUpJyxcbiAgICAgICAgICAgICAgICAgICAgYW5pbWF0aW9uOiAnc2xpZGVVcCAwLjNzIGVhc2Utb3V0J1xuICAgICAgICAgICAgICAgICAgfX0+XG4gICAgICAgICAgICAgICAgICAgIHtzZXR0aW5nc1N1Y2Nlc3N9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICAgICAgICAgICAgUEFHRTogVVNFUiBERVRBSUxTXG4gICAgICAgICAgICAgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XG4gICAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ1VzZXIgRGV0YWlscycgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtMTJcIiBzdHlsZT17eyBhbmltYXRpb246ICdmYWRlSW4gMC40cyBlYXNlLW91dCcgfX0+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VjdGlvbi1oZWFkZXJcIj5cbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwic2VjdGlvbi10aXRsZVwiPlVzZXIgUm9sZXMgJiBBY2Nlc3MgUmlnaHRzPC9oMz5cbiAgICAgICAgICAgICAgICB7dXNlclNlc3Npb24ucm9sZSA9PT0gJ0FkbWluJyAmJiAoXG4gICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogJzAuODVyZW0nLCBjb2xvcjogJ3ZhcigtLWFjY2VudC1wcmltYXJ5KScsIGZvbnRXZWlnaHQ6IDYwMCwgcGFkZGluZzogJzAuNHJlbSAxcmVtJywgYmFja2dyb3VuZDogJ3JnYmEoMjQsIDIwLCAyNDMsIDAuMDUpJywgYm9yZGVyUmFkaXVzOiAnMjBweCcgfX0+XG4gICAgICAgICAgICAgICAgICAgIEFkbWluaXN0cmF0b3IgTW9kZSAoV3JpdGUgQWNjZXNzKVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAge3VzZXJTZXNzaW9uLnJvbGUgPT09ICdFZGl0b3InICYmIChcbiAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiAnMC44NXJlbScsIGNvbG9yOiAndmFyKC0tdGV4dC1zZWNvbmRhcnkpJywgZm9udFdlaWdodDogNjAwLCBwYWRkaW5nOiAnMC40cmVtIDFyZW0nLCBiYWNrZ3JvdW5kOiAncmdiYSgwLCAwLCAwLCAwLjA1KScsIGJvcmRlclJhZGl1czogJzIwcHgnIH19PlxuICAgICAgICAgICAgICAgICAgICBFZGl0b3IgTW9kZSAoUmVhZCBPbmx5KVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGFibGUtd3JhcHBlclwiPlxuICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJjdXN0b20tdGFibGVcIj5cbiAgICAgICAgICAgICAgICAgIDx0aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgIDx0aD5Vc2VyIEluZm88L3RoPlxuICAgICAgICAgICAgICAgICAgICAgIDx0aD5FbWFpbCBBZGRyZXNzPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGg+U3lzdGVtIFJvbGU8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgIDx0aD5BY2Nlc3MgUmlnaHRzIFN1bW1hcnk8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgIDx0aD5BY3Rpb25zPC90aD5cbiAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgICA8dGJvZHk+XG4gICAgICAgICAgICAgICAgICAgIHt1c2Vyc1xuICAgICAgICAgICAgICAgICAgICAgIC5maWx0ZXIodXNlciA9PiBcbiAgICAgICAgICAgICAgICAgICAgICAgICFzZWFyY2hRdWVyeSB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgKHVzZXIubmFtZSB8fCAnJykudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hRdWVyeS50b0xvd2VyQ2FzZSgpKSB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgKHVzZXIuZW1haWwgfHwgJycpLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoUXVlcnkudG9Mb3dlckNhc2UoKSkgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgICh1c2VyLnJvbGUgfHwgJycpLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoUXVlcnkudG9Mb3dlckNhc2UoKSkgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgICh1c2VyLmlkIHx8ICcnKS50b1N0cmluZygpLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoUXVlcnkudG9Mb3dlckNhc2UoKSlcbiAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgLm1hcCgodXNlcikgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17dXNlci5pZH0+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgZ2FwOiAnMC43NXJlbScgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB3aWR0aDogJzM2cHgnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogJzM2cHgnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogJzUwJScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogJ2xpbmVhci1ncmFkaWVudCgxMzVkZWcsIHZhcigtLWFjY2VudC1wcmltYXJ5KSAwJSwgIzE4MTRGMyAxMDAlKScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6ICcjZmZmZmZmJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5OiAnZmxleCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWxpZ25JdGVtczogJ2NlbnRlcicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ6ICdjZW50ZXInLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IDYwMCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZTogJzAuOXJlbSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3VzZXIubmFtZS5jaGFyQXQoMCkudG9VcHBlckNhc2UoKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250V2VpZ2h0OiA2MDAgfX0+e3VzZXIubmFtZX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiAnMC43NXJlbScsIGNvbG9yOiAndmFyKC0tdGV4dC1zZWNvbmRhcnkpJyB9fT5JRDoge3VzZXIuaWR9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD57dXNlci5lbWFpbH08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BzdGF0dXMtYmFkZ2UgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VyLnJvbGUgPT09ICdBZG1pbicgPyAnZmFpbGVkJyA6IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVzZXIucm9sZSA9PT0gJ0VkaXRvcicgPyAncGVuZGluZycgOiAnc3VjY2VzcydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9IHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogdXNlci5yb2xlID09PSAnQWRtaW4nID8gJ3JnYmEoMTM5LCA5MiwgMjQ2LCAwLjEyKScgOiB1c2VyLnJvbGUgPT09ICdFZGl0b3InID8gJ3JnYmEoNTcsIDEwNiwgMjU1LCAwLjEyKScgOiAncmdiYSgxMDcsIDExNCwgMTI4LCAwLjEyKScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IHVzZXIucm9sZSA9PT0gJ0FkbWluJyA/ICcjOEI1Q0Y2JyA6IHVzZXIucm9sZSA9PT0gJ0VkaXRvcicgPyAnIzM5NkFGRicgOiAnIzZCNzI4MCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogJzAuMzVyZW0gMC44NXJlbSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3VzZXIucm9sZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGdhcDogJzAuNXJlbScsIGZsZXhXcmFwOiAnd3JhcCcgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge09iamVjdC5lbnRyaWVzKHVzZXIucGVybWlzc2lvbnMgfHwge30pLm1hcCgoW2tleSwgdmFsXSkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17a2V5fSBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6ICcwLjc1cmVtJywgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogJzAuMTVyZW0gMC41cmVtJywgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAnNnB4JywgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogdmFsID8gJ3JnYmEoMTYsIDE4NSwgMTI5LCAwLjA4KScgOiAncmdiYSgyMzksIDY4LCA2OCwgMC4wOCknLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiB2YWwgPyAnIzEwQjk4MScgOiAnI0VGNDQ0NCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiBgMXB4IHNvbGlkICR7dmFsID8gJ3JnYmEoMTYsIDE4NSwgMTI5LCAwLjIpJyA6ICdyZ2JhKDIzOSwgNjgsIDY4LCAwLjIpJ31gLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXk6ICdpbmxpbmUtZmxleCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWxpZ25JdGVtczogJ2NlbnRlcicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ2FwOiAnMC4yNXJlbScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogNjAwXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdpZHRoOiAnNXB4JywgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiAnNXB4JywgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAnNTAlJywgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogdmFsID8gJyMxMEI5ODEnIDogJyNFRjQ0NDQnIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fT48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtrZXkucmVwbGFjZSgnbWFuYWdlXycsICcnKS5yZXBsYWNlKCd2aWV3XycsICcnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7dXNlclNlc3Npb24ucm9sZSA9PT0gJ0FkbWluJyA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGFibGUtYWN0aW9uLWJ0biBlZGl0XCIgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvcGVuVXNlclBlcm1pc3Npb25zTW9kYWwodXNlcil9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIk1hbmFnZSBQZXJtaXNzaW9uc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kOiAncmdiYSgyNCwgMjAsIDI0MywgMC4wOCknLCBjb2xvcjogJ3ZhcigtLWFjY2VudC1wcmltYXJ5KScsIHdpZHRoOiAnMzZweCcsIGhlaWdodDogJzM2cHgnLCBib3JkZXJSYWRpdXM6ICc4cHgnLCBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2V0dGluZ3Mgc2l6ZT17MTZ9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRhYmxlLWFjdGlvbi1idG4gZWRpdFwiIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb3BlblVzZXJQZXJtaXNzaW9uc01vZGFsKHVzZXIpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJWaWV3IFBlcm1pc3Npb25zXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmQ6ICdyZ2JhKDEwNywgMTE0LCAxMjgsIDAuMDgpJywgY29sb3I6ICcjNkI3MjgwJywgd2lkdGg6ICczNnB4JywgaGVpZ2h0OiAnMzZweCcsIGJvcmRlclJhZGl1czogJzhweCcsIGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGp1c3RpZnlDb250ZW50OiAnY2VudGVyJyB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWFyY2ggc2l6ZT17MTZ9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7YWN0aXZlVGFiID09PSAnU2NhbiAmIFBheScgJiYgKFxuICAgICAgICAgICAgPFFyU2Nhbm5lclRhYiBcbiAgICAgICAgICAgICAgdXNlclNlc3Npb249e3VzZXJTZXNzaW9ufVxuICAgICAgICAgICAgICBjYXJkcz17Y2FyZHN9XG4gICAgICAgICAgICAgIG9uQWRkVHJhbnNhY3Rpb249eyhuZXdUeCkgPT4gc2V0VHJhbnNhY3Rpb25zKHByZXYgPT4gW25ld1R4LCAuLi5wcmV2XSl9XG4gICAgICAgICAgICAgIG9uVXBkYXRlQ2FyZEJhbGFuY2U9eyhjYXJkSWQsIG5ld0JhbGFuY2UpID0+IHtcbiAgICAgICAgICAgICAgICBzZXRDYXJkcyhwcmV2ID0+IHByZXYubWFwKGMgPT4gYy5pZCA9PT0gY2FyZElkID8geyAuLi5jLCBiYWxhbmNlOiBuZXdCYWxhbmNlIH0gOiBjKSk7XG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgIG9uQWRkTm90aWZpY2F0aW9uPXsobmV3Tm90aWZpY2F0aW9uKSA9PiB7XG4gICAgICAgICAgICAgICAgc2V0Tm90aWZpY2F0aW9ucyhwcmV2ID0+IFtuZXdOb3RpZmljYXRpb24sIC4uLnByZXZdKTtcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L21haW4+XG5cbiAgICAgIHsvKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgICAgICAgIFRSQU5TQUNUSU9OIENSVUQgTU9EQUwgV0lORE9XXG4gICAgICAgICA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cbiAgICAgIHt0eE1vZGFsT3BlbiAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibW9kYWwtYmFja2Ryb3BcIiBvbkNsaWNrPXsoKSA9PiBzZXRUeE1vZGFsT3BlbihmYWxzZSl9PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibW9kYWwtY29udGFpbmVyXCIgb25DbGljaz17KGUpID0+IGUuc3RvcFByb3BhZ2F0aW9uKCl9PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtb2RhbC1oZWFkZXJcIj5cbiAgICAgICAgICAgICAgPGgzPntlZGl0aW5nVHggPyAnRWRpdCBUcmFuc2FjdGlvbicgOiAnQ3JlYXRlIFRyYW5zYWN0aW9uJ308L2gzPlxuICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cIm1vZGFsLWNsb3NlLWJ0blwiIG9uQ2xpY2s9eygpID0+IHNldFR4TW9kYWxPcGVuKGZhbHNlKX0+XG4gICAgICAgICAgICAgICAgPFggc2l6ZT17MTh9IC8+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlVHhTdWJtaXR9IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsIGdhcDogJzFyZW0nIH19PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNldHRpbmdzLWlucHV0LWdyb3VwXCI+XG4gICAgICAgICAgICAgICAgPGxhYmVsPkRlc2NyaXB0aW9uPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXQgXG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiIFxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic2V0dGluZ3MtZm9ybS1pbnB1dFwiIFxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIFNwb3RpZnkgUHJlbWl1bVwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dHhGb3JtLmRlc2N9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFR4Rm9ybSh7IC4uLnR4Rm9ybSwgZGVzYzogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNldHRpbmdzLWlucHV0LWdyb3VwXCI+XG4gICAgICAgICAgICAgICAgPGxhYmVsPkFtb3VudCAoJCk8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIiBcbiAgICAgICAgICAgICAgICAgIHN0ZXA9XCIwLjAxXCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNldHRpbmdzLWZvcm0taW5wdXRcIiBcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiAxNS4wMFwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dHhGb3JtLmFtb3VudH1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VHhGb3JtKHsgLi4udHhGb3JtLCBhbW91bnQ6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZ3JpZCcsIGdyaWRUZW1wbGF0ZUNvbHVtbnM6ICcxZnIgMWZyJywgZ2FwOiAnMXJlbScgfX0+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZXR0aW5ncy1pbnB1dC1ncm91cFwiPlxuICAgICAgICAgICAgICAgICAgPGxhYmVsPlR5cGU8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPHNlbGVjdCBcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic2V0dGluZ3MtZm9ybS1pbnB1dFwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt0eEZvcm0udHlwZX1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRUeEZvcm0oeyAuLi50eEZvcm0sIHR5cGU6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiZXhwZW5zZVwiPkV4cGVuc2UgKC0pPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJpbmNvbWVcIj5JbmNvbWUgKCspPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNldHRpbmdzLWlucHV0LWdyb3VwXCI+XG4gICAgICAgICAgICAgICAgICA8bGFiZWw+U3RhdHVzPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxzZWxlY3QgXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNldHRpbmdzLWZvcm0taW5wdXRcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dHhGb3JtLnN0YXR1c31cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRUeEZvcm0oeyAuLi50eEZvcm0sIHN0YXR1czogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJTdWNjZXNzXCI+U3VjY2Vzczwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiUGVuZGluZ1wiPlBlbmRpbmc8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkZhaWxlZFwiPkZhaWxlZDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdncmlkJywgZ3JpZFRlbXBsYXRlQ29sdW1uczogJzFmciAxZnInLCBnYXA6ICcxcmVtJyB9fT5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNldHRpbmdzLWlucHV0LWdyb3VwXCI+XG4gICAgICAgICAgICAgICAgICA8bGFiZWw+Q2F0ZWdvcnk8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPHNlbGVjdCBcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic2V0dGluZ3MtZm9ybS1pbnB1dFwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt0eEZvcm0uY2F0ZWdvcnl9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VHhGb3JtKHsgLi4udHhGb3JtLCBjYXRlZ29yeTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJEZXBvc2l0XCI+RGVwb3NpdDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiVHJhbnNmZXJcIj5UcmFuc2Zlcjwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiRW50ZXJ0YWlubWVudFwiPkVudGVydGFpbm1lbnQ8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlNob3BwaW5nXCI+U2hvcHBpbmc8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlNhbGFyeVwiPlNhbGFyeTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiVHJhbnNwb3J0XCI+VHJhbnNwb3J0PC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJPdGhlcnNcIj5PdGhlcnM8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2V0dGluZ3MtaW5wdXQtZ3JvdXBcIj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbD5NZXRob2Q8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPHNlbGVjdCBcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic2V0dGluZ3MtZm9ybS1pbnB1dFwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt0eEZvcm0ubWV0aG9kfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFR4Rm9ybSh7IC4uLnR4Rm9ybSwgbWV0aG9kOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkNhcmRcIj5DYXJkPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJQYXlwYWxcIj5QYXlwYWw8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIldpcmUgVHJhbnNmZXJcIj5XaXJlIFRyYW5zZmVyPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2V0dGluZ3MtaW5wdXQtZ3JvdXBcIj5cbiAgICAgICAgICAgICAgICA8bGFiZWw+RGF0ZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIiBcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNldHRpbmdzLWZvcm0taW5wdXRcIiBcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt0eEZvcm0uZGF0ZX1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VHhGb3JtKHsgLi4udHhGb3JtLCBkYXRlOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibW9kYWwtZm9vdGVyXCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwibW9kYWwtYnRuLWNhbmNlbFwiIG9uQ2xpY2s9eygpID0+IHNldFR4TW9kYWxPcGVuKGZhbHNlKX0+Q2FuY2VsPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgY2xhc3NOYW1lPVwiYWRkLWNhcmQtYnRuXCIgc3R5bGU9e3sgbWFyZ2luOiAwLCBwYWRkaW5nOiAnMC43NXJlbSAycmVtJyB9fT5cbiAgICAgICAgICAgICAgICAgIHtlZGl0aW5nVHggPyAnU2F2ZSBDaGFuZ2VzJyA6ICdDcmVhdGUnfVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICAgICAgICBDUkVESVQgQ0FSRCBDUlVEIE1PREFMIFdJTkRPV1xuICAgICAgICAgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XG4gICAgICB7Y2FyZE1vZGFsT3BlbiAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibW9kYWwtYmFja2Ryb3BcIiBvbkNsaWNrPXsoKSA9PiBzZXRDYXJkTW9kYWxPcGVuKGZhbHNlKX0+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtb2RhbC1jb250YWluZXJcIiBvbkNsaWNrPXsoZSkgPT4gZS5zdG9wUHJvcGFnYXRpb24oKX0+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1vZGFsLWhlYWRlclwiPlxuICAgICAgICAgICAgICA8aDM+RWRpdCBDcmVkaXQgQ2FyZDwvaDM+XG4gICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwibW9kYWwtY2xvc2UtYnRuXCIgb25DbGljaz17KCkgPT4gc2V0Q2FyZE1vZGFsT3BlbihmYWxzZSl9PlxuICAgICAgICAgICAgICAgIDxYIHNpemU9ezE4fSAvPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZUNhcmRVcGRhdGVTdWJtaXR9IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsIGdhcDogJzFyZW0nIH19PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNldHRpbmdzLWlucHV0LWdyb3VwXCI+XG4gICAgICAgICAgICAgICAgPGxhYmVsPkNhcmQgSG9sZGVyIE5hbWU8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCIgXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzZXR0aW5ncy1mb3JtLWlucHV0XCIgXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gSm9obiBEb2VcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2NhcmRGb3JtLmhvbGRlcn1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q2FyZEZvcm0oeyAuLi5jYXJkRm9ybSwgaG9sZGVyOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2V0dGluZ3MtaW5wdXQtZ3JvdXBcIj5cbiAgICAgICAgICAgICAgICA8bGFiZWw+QmFsYW5jZSAoJCk8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIiBcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNldHRpbmdzLWZvcm0taW5wdXRcIiBcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiA1MDAwXCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtjYXJkRm9ybS5iYWxhbmNlfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDYXJkRm9ybSh7IC4uLmNhcmRGb3JtLCBiYWxhbmNlOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogJ2dyaWQnLCBncmlkVGVtcGxhdGVDb2x1bW5zOiAnMWZyIDFmcicsIGdhcDogJzFyZW0nIH19PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2V0dGluZ3MtaW5wdXQtZ3JvdXBcIj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbD5FeHBpcnkgRGF0ZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8aW5wdXQgXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCIgXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNldHRpbmdzLWZvcm0taW5wdXRcIiBcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJNTS9ZWVwiXG4gICAgICAgICAgICAgICAgICAgIG1heExlbmd0aD1cIjVcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y2FyZEZvcm0uZXhwaXJ5fVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldENhcmRGb3JtKHsgLi4uY2FyZEZvcm0sIGV4cGlyeTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2V0dGluZ3MtaW5wdXQtZ3JvdXBcIj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbD5DYXJkIFN0eWxlPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxzZWxlY3QgXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNldHRpbmdzLWZvcm0taW5wdXRcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y2FyZEZvcm0udHlwZX1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDYXJkRm9ybSh7IC4uLmNhcmRGb3JtLCB0eXBlOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImRhcmtcIj5EYXJrIEdyYWRpZW50PC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJsaWdodFwiPkxpZ2h0IEJvcmRlcjwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiZ3JlZW5cIj5FbWVyYWxkIEdyZWVuPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJwdXJwbGVcIj5Sb3lhbCBQdXJwbGU8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZXR0aW5ncy1pbnB1dC1ncm91cFwiPlxuICAgICAgICAgICAgICAgIDxsYWJlbD5DYXJkIE51bWJlciAoMTYgRGlnaXRzKTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIiBcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNldHRpbmdzLWZvcm0taW5wdXRcIiBcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiNDgxMjM4NDkxMDI5Mzg0N1wiXG4gICAgICAgICAgICAgICAgICBtYXhMZW5ndGg9XCIxNlwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Y2FyZEZvcm0ubnVtYmVyfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDYXJkRm9ybSh7IC4uLmNhcmRGb3JtLCBudW1iZXI6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtb2RhbC1mb290ZXJcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJtb2RhbC1idG4tY2FuY2VsXCIgb25DbGljaz17KCkgPT4gc2V0Q2FyZE1vZGFsT3BlbihmYWxzZSl9PkNhbmNlbDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIGNsYXNzTmFtZT1cImFkZC1jYXJkLWJ0blwiIHN0eWxlPXt7IG1hcmdpbjogMCwgcGFkZGluZzogJzAuNzVyZW0gMnJlbScgfX0+XG4gICAgICAgICAgICAgICAgICBTYXZlIENoYW5nZXNcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICAgIHsvKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgICAgICAgIFVTRVIgUEVSTUlTU0lPTlMgTU9EQUwgV0lORE9XXG4gICAgICAgICA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cbiAgICAgIHt1c2VyTW9kYWxPcGVuICYmIGVkaXRpbmdVc2VyICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtb2RhbC1iYWNrZHJvcFwiIG9uQ2xpY2s9eygpID0+IHNldFVzZXJNb2RhbE9wZW4oZmFsc2UpfT5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1vZGFsLWNvbnRhaW5lclwiIG9uQ2xpY2s9eyhlKSA9PiBlLnN0b3BQcm9wYWdhdGlvbigpfSBzdHlsZT17eyBtYXhXaWR0aDogJzUyMHB4JyB9fT5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibW9kYWwtaGVhZGVyXCI+XG4gICAgICAgICAgICAgIDxoMz57dXNlclNlc3Npb24ucm9sZSA9PT0gJ0FkbWluJyA/ICdNYW5hZ2UgQWNjZXNzIFJpZ2h0cycgOiAnVmlldyBBY2Nlc3MgUmlnaHRzJ308L2gzPlxuICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cIm1vZGFsLWNsb3NlLWJ0blwiIG9uQ2xpY2s9eygpID0+IHNldFVzZXJNb2RhbE9wZW4oZmFsc2UpfT5cbiAgICAgICAgICAgICAgICA8WCBzaXplPXsxOH0gLz5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIFxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW5Cb3R0b206ICcxLjI1cmVtJywgcGFkZGluZ0JvdHRvbTogJzFyZW0nLCBib3JkZXJCb3R0b206ICcxcHggc29saWQgdmFyKC0tYm9yZGVyLWNvbG9yKScgfX0+XG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFdlaWdodDogNzAwLCBmb250U2l6ZTogJzEuMXJlbScsIGNvbG9yOiAndmFyKC0tdGV4dC1wcmltYXJ5KScgfX0+e2VkaXRpbmdVc2VyLm5hbWV9PC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFNpemU6ICcwLjg1cmVtJywgY29sb3I6ICd2YXIoLS10ZXh0LXNlY29uZGFyeSknLCBtYXJnaW5Ub3A6ICcwLjE1cmVtJyB9fT57ZWRpdGluZ1VzZXIuZW1haWx9PC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9eyhlKSA9PiB7XG4gICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgICAgaWYgKHVzZXJTZXNzaW9uLnJvbGUgIT09ICdBZG1pbicpIHtcbiAgICAgICAgICAgICAgICBzZXRVc2VyTW9kYWxPcGVuKGZhbHNlKTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgaGFuZGxlVXBkYXRlUGVybWlzc2lvbnMoZWRpdGluZ1VzZXIuaWQsIHVzZXJGb3JtLnJvbGUsIHVzZXJGb3JtLnBlcm1pc3Npb25zKTtcbiAgICAgICAgICAgIH19IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsIGdhcDogJzEuMjVyZW0nIH19PlxuICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZXR0aW5ncy1pbnB1dC1ncm91cFwiPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBzdHlsZT17eyBmb250V2VpZ2h0OiA2MDAgfX0+U3lzdGVtIFJvbGU8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxzZWxlY3QgXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzZXR0aW5ncy1mb3JtLWlucHV0XCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt1c2VyRm9ybS5yb2xlfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IG5ld1JvbGUgPSBlLnRhcmdldC52YWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IG5ld1Blcm1pc3Npb25zID0geyAuLi51c2VyRm9ybS5wZXJtaXNzaW9ucyB9O1xuICAgICAgICAgICAgICAgICAgICBpZiAobmV3Um9sZSA9PT0gJ0FkbWluJykge1xuICAgICAgICAgICAgICAgICAgICAgIG5ld1Blcm1pc3Npb25zID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmlld19kYXNoYm9hcmQ6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBtYW5hZ2VfdHg6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBtYW5hZ2VfY2FyZHM6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBtYW5hZ2VfbG9hbnM6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBtYW5hZ2Vfc2VydmljZXM6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBtYW5hZ2VfdXNlcnM6IHRydWVcbiAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKG5ld1JvbGUgPT09ICdWaWV3ZXInKSB7XG4gICAgICAgICAgICAgICAgICAgICAgbmV3UGVybWlzc2lvbnMgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2aWV3X2Rhc2hib2FyZDogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIG1hbmFnZV90eDogZmFsc2UsXG4gICAgICAgICAgICAgICAgICAgICAgICBtYW5hZ2VfY2FyZHM6IGZhbHNlLFxuICAgICAgICAgICAgICAgICAgICAgICAgbWFuYWdlX2xvYW5zOiBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIG1hbmFnZV9zZXJ2aWNlczogZmFsc2UsXG4gICAgICAgICAgICAgICAgICAgICAgICBtYW5hZ2VfdXNlcnM6IGZhbHNlXG4gICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChuZXdSb2xlID09PSAnRWRpdG9yJykge1xuICAgICAgICAgICAgICAgICAgICAgIG5ld1Blcm1pc3Npb25zID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmlld19kYXNoYm9hcmQ6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBtYW5hZ2VfdHg6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBtYW5hZ2VfY2FyZHM6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBtYW5hZ2VfbG9hbnM6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBtYW5hZ2Vfc2VydmljZXM6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBtYW5hZ2VfdXNlcnM6IGZhbHNlXG4gICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBzZXRVc2VyRm9ybSh7IHJvbGU6IG5ld1JvbGUsIHBlcm1pc3Npb25zOiBuZXdQZXJtaXNzaW9ucyB9KTtcbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17dXNlclNlc3Npb24ucm9sZSAhPT0gJ0FkbWluJ31cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQWRtaW5cIj5BZG1pbiAoRnVsbCBXcml0ZSBBY2Nlc3MpPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiRWRpdG9yXCI+RWRpdG9yIChSZWFkL1dyaXRlIGV4Y2VwdCBVc2Vycyk8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJWaWV3ZXJcIj5WaWV3ZXIgKFJlYWQtT25seSBBY2Nlc3MpPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIHN0eWxlPXt7IGRpc3BsYXk6ICdibG9jaycsIGZvbnRXZWlnaHQ6IDYwMCwgbWFyZ2luQm90dG9tOiAnMC43NXJlbScsIGZvbnRTaXplOiAnMC45NXJlbScgfX0+SW5kaXZpZHVhbCBGZWF0dXJlIEFjY2VzcyBSaWdodHM8L2xhYmVsPlxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBmbGV4RGlyZWN0aW9uOiAnY29sdW1uJywgZ2FwOiAnMC43NXJlbScsIGJhY2tncm91bmQ6ICd2YXIoLS1iZy1wcmltYXJ5KScsIHBhZGRpbmc6ICcxcmVtJywgYm9yZGVyUmFkaXVzOiAnMTVweCcsIGJvcmRlcjogJzFweCBzb2xpZCB2YXIoLS1ib3JkZXItY29sb3IpJyB9fT5cbiAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgey8qIFBlcm1pc3Npb246IFZpZXcgRGFzaGJvYXJkICovfVxuICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBqdXN0aWZ5Q29udGVudDogJ3NwYWNlLWJldHdlZW4nIH19PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFdlaWdodDogNjAwLCBmb250U2l6ZTogJzAuODVyZW0nIH19PkRhc2hib2FyZCBPdmVydmlldzwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFNpemU6ICcwLjc1cmVtJywgY29sb3I6ICd2YXIoLS10ZXh0LXNlY29uZGFyeSknIH19PkFsbG93IHZpZXdpbmcgc3RhbmRhcmQgZGFzaGJvYXJkIG1ldHJpY3MgYW5kIGNoYXJ0cy48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJzd2l0Y2gtbGFiZWxcIiBzdHlsZT17eyBwb2ludGVyRXZlbnRzOiB1c2VyU2Vzc2lvbi5yb2xlICE9PSAnQWRtaW4nID8gJ25vbmUnIDogJ2F1dG8nIH19PlxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiIFxuICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dXNlckZvcm0ucGVybWlzc2lvbnMudmlld19kYXNoYm9hcmR9IFxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRVc2VyRm9ybSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVzZXJGb3JtLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBwZXJtaXNzaW9uczogeyAuLi51c2VyRm9ybS5wZXJtaXNzaW9ucywgdmlld19kYXNoYm9hcmQ6IGUudGFyZ2V0LmNoZWNrZWQgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17dXNlclNlc3Npb24ucm9sZSAhPT0gJ0FkbWluJ31cbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInN3aXRjaC1zbGlkZXJcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgey8qIFBlcm1pc3Npb246IE1hbmFnZSBUcmFuc2FjdGlvbnMgKi99XG4gICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGp1c3RpZnlDb250ZW50OiAnc3BhY2UtYmV0d2VlbicsIGJvcmRlclRvcDogJzFweCBzb2xpZCByZ2JhKDAsMCwwLDAuMDUpJywgcGFkZGluZ1RvcDogJzAuNzVyZW0nIH19PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFdlaWdodDogNjAwLCBmb250U2l6ZTogJzAuODVyZW0nIH19PlRyYW5zYWN0aW9ucyBNYW5hZ2VtZW50PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogJzAuNzVyZW0nLCBjb2xvcjogJ3ZhcigtLXRleHQtc2Vjb25kYXJ5KScgfX0+QWxsb3cgYWRkaW5nLCBlZGl0aW5nLCBkZWxldGluZyBhbmQgdHJhbnNmZXJyaW5nIGZ1bmRzLjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInN3aXRjaC1sYWJlbFwiIHN0eWxlPXt7IHBvaW50ZXJFdmVudHM6IHVzZXJTZXNzaW9uLnJvbGUgIT09ICdBZG1pbicgPyAnbm9uZScgOiAnYXV0bycgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCIgXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt1c2VyRm9ybS5wZXJtaXNzaW9ucy5tYW5hZ2VfdHh9IFxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRVc2VyRm9ybSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVzZXJGb3JtLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBwZXJtaXNzaW9uczogeyAuLi51c2VyRm9ybS5wZXJtaXNzaW9ucywgbWFuYWdlX3R4OiBlLnRhcmdldC5jaGVja2VkIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3VzZXJTZXNzaW9uLnJvbGUgIT09ICdBZG1pbid9XG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzd2l0Y2gtc2xpZGVyXCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIHsvKiBQZXJtaXNzaW9uOiBNYW5hZ2UgQ2FyZHMgKi99XG4gICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGp1c3RpZnlDb250ZW50OiAnc3BhY2UtYmV0d2VlbicsIGJvcmRlclRvcDogJzFweCBzb2xpZCByZ2JhKDAsMCwwLDAuMDUpJywgcGFkZGluZ1RvcDogJzAuNzVyZW0nIH19PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFdlaWdodDogNjAwLCBmb250U2l6ZTogJzAuODVyZW0nIH19PkNyZWRpdCBDYXJkcyBNYW5hZ2VtZW50PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogJzAuNzVyZW0nLCBjb2xvcjogJ3ZhcigtLXRleHQtc2Vjb25kYXJ5KScgfX0+QWxsb3cgY3JlYXRpbmcsIG1vZGlmeWluZyBvciByZW1vdmluZyBjcmVkaXQgY2FyZHMuPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwic3dpdGNoLWxhYmVsXCIgc3R5bGU9e3sgcG9pbnRlckV2ZW50czogdXNlclNlc3Npb24ucm9sZSAhPT0gJ0FkbWluJyA/ICdub25lJyA6ICdhdXRvJyB9fT5cbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIiBcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3VzZXJGb3JtLnBlcm1pc3Npb25zLm1hbmFnZV9jYXJkc30gXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFVzZXJGb3JtKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4udXNlckZvcm0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBlcm1pc3Npb25zOiB7IC4uLnVzZXJGb3JtLnBlcm1pc3Npb25zLCBtYW5hZ2VfY2FyZHM6IGUudGFyZ2V0LmNoZWNrZWQgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17dXNlclNlc3Npb24ucm9sZSAhPT0gJ0FkbWluJ31cbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInN3aXRjaC1zbGlkZXJcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgey8qIFBlcm1pc3Npb246IE1hbmFnZSBMb2FucyAqL31cbiAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywganVzdGlmeUNvbnRlbnQ6ICdzcGFjZS1iZXR3ZWVuJywgYm9yZGVyVG9wOiAnMXB4IHNvbGlkIHJnYmEoMCwwLDAsMC4wNSknLCBwYWRkaW5nVG9wOiAnMC43NXJlbScgfX0+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250V2VpZ2h0OiA2MDAsIGZvbnRTaXplOiAnMC44NXJlbScgfX0+TG9hbnMgQ2FsY3VsYXRvciAmIE1hbmFnZW1lbnQ8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiAnMC43NXJlbScsIGNvbG9yOiAndmFyKC0tdGV4dC1zZWNvbmRhcnkpJyB9fT5BbGxvdyBjYWxjdWxhdGlvbnMgYW5kIHVwZGF0ZXMgb2YgbG9hbiBzdHJ1Y3R1cmVzLjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInN3aXRjaC1sYWJlbFwiIHN0eWxlPXt7IHBvaW50ZXJFdmVudHM6IHVzZXJTZXNzaW9uLnJvbGUgIT09ICdBZG1pbicgPyAnbm9uZScgOiAnYXV0bycgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCIgXG4gICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt1c2VyRm9ybS5wZXJtaXNzaW9ucy5tYW5hZ2VfbG9hbnN9IFxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRVc2VyRm9ybSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVzZXJGb3JtLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBwZXJtaXNzaW9uczogeyAuLi51c2VyRm9ybS5wZXJtaXNzaW9ucywgbWFuYWdlX2xvYW5zOiBlLnRhcmdldC5jaGVja2VkIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3VzZXJTZXNzaW9uLnJvbGUgIT09ICdBZG1pbid9XG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzd2l0Y2gtc2xpZGVyXCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIHsvKiBQZXJtaXNzaW9uOiBNYW5hZ2UgU2VydmljZXMgKi99XG4gICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGp1c3RpZnlDb250ZW50OiAnc3BhY2UtYmV0d2VlbicsIGJvcmRlclRvcDogJzFweCBzb2xpZCByZ2JhKDAsMCwwLDAuMDUpJywgcGFkZGluZ1RvcDogJzAuNzVyZW0nIH19PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFdlaWdodDogNjAwLCBmb250U2l6ZTogJzAuODVyZW0nIH19PlNlcnZpY2VzIEFjdGl2YXRpb248L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiAnMC43NXJlbScsIGNvbG9yOiAndmFyKC0tdGV4dC1zZWNvbmRhcnkpJyB9fT5BbGxvdyB0b2dnbGluZyBhY2NvdW50LXNwZWNpZmljIG1vYmlsZSBzZWN1cml0eSBhbmQgc2F2aW5ncyBzZXJ2aWNlcy48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJzd2l0Y2gtbGFiZWxcIiBzdHlsZT17eyBwb2ludGVyRXZlbnRzOiB1c2VyU2Vzc2lvbi5yb2xlICE9PSAnQWRtaW4nID8gJ25vbmUnIDogJ2F1dG8nIH19PlxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiIFxuICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dXNlckZvcm0ucGVybWlzc2lvbnMubWFuYWdlX3NlcnZpY2VzfSBcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VXNlckZvcm0oe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi51c2VyRm9ybSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGVybWlzc2lvbnM6IHsgLi4udXNlckZvcm0ucGVybWlzc2lvbnMsIG1hbmFnZV9zZXJ2aWNlczogZS50YXJnZXQuY2hlY2tlZCB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXt1c2VyU2Vzc2lvbi5yb2xlICE9PSAnQWRtaW4nfVxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic3dpdGNoLXNsaWRlclwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICB7LyogUGVybWlzc2lvbjogTWFuYWdlIFVzZXJzICovfVxuICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBqdXN0aWZ5Q29udGVudDogJ3NwYWNlLWJldHdlZW4nLCBib3JkZXJUb3A6ICcxcHggc29saWQgcmdiYSgwLDAsMCwwLjA1KScsIHBhZGRpbmdUb3A6ICcwLjc1cmVtJyB9fT5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRXZWlnaHQ6IDYwMCwgZm9udFNpemU6ICcwLjg1cmVtJyB9fT5Vc2VyIFByb2ZpbGVzICYgQWNjZXNzIFJpZ2h0czwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFNpemU6ICcwLjc1cmVtJywgY29sb3I6ICd2YXIoLS10ZXh0LXNlY29uZGFyeSknIH19PkFsbG93IG1hbmFnaW5nIHJvbGVzIGFuZCBtb2RpZnlpbmcgYXV0aG9yaXphdGlvbiBhY2Nlc3Mgb2Ygb3RoZXIgdXNlcnMuPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwic3dpdGNoLWxhYmVsXCIgc3R5bGU9e3sgcG9pbnRlckV2ZW50czogdXNlclNlc3Npb24ucm9sZSAhPT0gJ0FkbWluJyA/ICdub25lJyA6ICdhdXRvJyB9fT5cbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIiBcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3VzZXJGb3JtLnBlcm1pc3Npb25zLm1hbmFnZV91c2Vyc30gXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFVzZXJGb3JtKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4udXNlckZvcm0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBlcm1pc3Npb25zOiB7IC4uLnVzZXJGb3JtLnBlcm1pc3Npb25zLCBtYW5hZ2VfdXNlcnM6IGUudGFyZ2V0LmNoZWNrZWQgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17dXNlclNlc3Npb24ucm9sZSAhPT0gJ0FkbWluJ31cbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInN3aXRjaC1zbGlkZXJcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1vZGFsLWZvb3RlclwiPlxuICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cIm1vZGFsLWJ0bi1jYW5jZWxcIiBvbkNsaWNrPXsoKSA9PiBzZXRVc2VyTW9kYWxPcGVuKGZhbHNlKX0+XG4gICAgICAgICAgICAgICAgICB7dXNlclNlc3Npb24ucm9sZSA9PT0gJ0FkbWluJyA/ICdDYW5jZWwnIDogJ0Nsb3NlJ31cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICB7dXNlclNlc3Npb24ucm9sZSA9PT0gJ0FkbWluJyAmJiAoXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBjbGFzc05hbWU9XCJhZGQtY2FyZC1idG5cIiBzdHlsZT17eyBtYXJnaW46IDAsIHBhZGRpbmc6ICcwLjc1cmVtIDJyZW0nIH19PlxuICAgICAgICAgICAgICAgICAgICBTYXZlIENoYW5nZXNcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG4vLyBTaWRlYmFyIG5hdmlnYXRpb24gc3RydWN0dXJlIGhlbHBlciBsaXN0XG5jb25zdCBtZW51SXRlbXMgPSBbXG4gIHsgbmFtZTogJ0Rhc2hib2FyZCcsIGljb246IExheW91dERhc2hib2FyZCB9LFxuICB7IG5hbWU6ICdUcmFuc2FjdGlvbnMnLCBpY29uOiBBcnJvd0xlZnRSaWdodCB9LFxuICB7IG5hbWU6ICdTY2FuICYgUGF5JywgaWNvbjogU2NhbiB9LFxuICB7IG5hbWU6ICdBY2NvdW50cycsIGljb246IFVzZXIgfSxcbiAgeyBuYW1lOiAnSW52ZXN0bWVudHMnLCBpY29uOiBMaW5lQ2hhcnQgfSxcbiAgeyBuYW1lOiAnQ3JlZGl0IENhcmRzJywgaWNvbjogQ3JlZGl0Q2FyZCB9LFxuICB7IG5hbWU6ICdMb2FucycsIGljb246IEhhbmRDb2lucyB9LFxuICB7IG5hbWU6ICdTZXJ2aWNlcycsIGljb246IFdyZW5jaCB9LFxuICB7IG5hbWU6ICdNeSBQcml2aWxlZ2VzJywgaWNvbjogTGlnaHRidWxiIH0sXG4gIHsgbmFtZTogJ1VzZXIgRGV0YWlscycsIGljb246IFVzZXJzIH0sXG4gIHsgbmFtZTogJ1NldHRpbmcnLCBpY29uOiBTZXR0aW5ncyB9XG5dO1xuXG5leHBvcnQgZGVmYXVsdCBEYXNoYm9hcmQ7XG4iXSwiZmlsZSI6IkQ6L1JlYWN0X3Rlc3RfMTlfMDVfMjAyNi9zcmMvY29tcG9uZW50cy9EYXNoYm9hcmQuanN4In0=