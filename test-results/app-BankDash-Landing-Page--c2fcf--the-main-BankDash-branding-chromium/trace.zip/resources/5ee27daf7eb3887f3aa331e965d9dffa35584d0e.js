import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Contact.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=01f90aba"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/React_test_19_05_2026/src/components/Contact.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=01f90aba"; const useState = __vite__cjsImport3_react["useState"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=01f90aba";
import {
  Mail,
  Phone,
  MapPin,
  Send,
  ArrowLeft,
  Check,
  User,
  MessageSquare,
  Zap,
  Globe,
  Clock,
  ChevronRight
} from "/node_modules/.vite/deps/lucide-react.js?v=01f90aba";
import { useAuth } from "/src/App.jsx";
import { translations } from "/src/utils/translations.js";
import "/src/landing.css";
const Contact = () => {
  _s();
  const { isLoggedIn, visitCount, language, setLanguage } = useAuth();
  const t = translations[language] || translations.en;
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [activeBranch, setActiveBranch] = useState(0);
  const branches = [
    {
      name: language === "hi" ? "सैन फ्रांसिस्को मुख्यालय" : "San Francisco Headquarters",
      address: "100 Pine St, San Francisco, CA 94111",
      phone: "+1 (800) 555-0199",
      hours: "Mon-Fri: 9:00 AM - 5:00 PM",
      mapUrl: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3152.973419992389!2d-122.40243452422026!3d37.790695071981295!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8085808b8b0e8c07%3A0xe2cae2d53bfefeb4!2s100%20Pine%20St%2C%20San%20Francisco%2C%20CA%2094111!5e0!3m2!1sen!2sus!4v1716220000000!5m2!1sen!2sus"
    },
    {
      name: language === "hi" ? "न्यूयॉर्क वित्तीय केंद्र" : "New York Financial Hub",
      address: "120 Broadway, New York, NY 10271",
      phone: "+1 (212) 555-0245",
      hours: "Mon-Fri: 8:30 AM - 6:00 PM",
      mapUrl: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3024.3644400938166!2d-74.01256032402773!3d40.70792377933181!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25a172775f0a3%3A0x673cccd59c0be7cd!2s120%20Broadway%2C%20New%20York%2C%20NY%2010271!5e0!3m2!1sen!2sus!4v1716220100000!5m2!1sen!2sus"
    },
    {
      name: language === "hi" ? "लंदन ग्लोबल ऑफिस" : "London Global Office",
      address: "30 St Mary Axe, London EC3A 8BF, UK",
      phone: "+44 20 7555 0188",
      hours: "Mon-Fri: 9:00 AM - 5:30 PM",
      mapUrl: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2482.9078170068153!2d-0.08373372338048259!3d51.51449447181608!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4876034c54466b07%3A0x7d6f54c9c1b827e8!2s30%20St%20Mary%20Axe!5e0!3m2!1sen!2sus!4v1716220200000!5m2!1sen!2sus"
    }
  ];
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    setErrorMsg("");
    if (!formData.name.trim()) {
      setErrorMsg(t.val_name_req);
      return;
    }
    if (!formData.email.trim() || !formData.email.includes("@")) {
      setErrorMsg(t.val_email_req);
      return;
    }
    if (!formData.subject.trim()) {
      setErrorMsg(t.val_subj_req);
      return;
    }
    if (!formData.message.trim() || formData.message.length < 10) {
      setErrorMsg(t.val_msg_req);
      return;
    }
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 1200);
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "landing-body animate-fade", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "landing-bg-decor decor-purple" }, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
      lineNumber: 121,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "landing-bg-decor decor-cyan" }, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
      lineNumber: 122,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "landing-bg-decor decor-amber" }, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
      lineNumber: 123,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("header", { className: "landing-header", children: /* @__PURE__ */ jsxDEV("div", { className: "landing-nav-container", children: [
      /* @__PURE__ */ jsxDEV(Link, { to: "/", className: "landing-logo", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "logo-icon-box", children: /* @__PURE__ */ jsxDEV(Zap, { size: 22, fill: "white" }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
          lineNumber: 130,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
          lineNumber: 129,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: "BankDash" }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
          lineNumber: 132,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
        lineNumber: 128,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("ul", { className: "landing-nav-links", children: [
        /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(Link, { to: "/", children: language === "hi" ? "होम" : "Home" }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
          lineNumber: 136,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
          lineNumber: 136,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(Link, { to: "/#features", children: t.features }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
          lineNumber: 137,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
          lineNumber: 137,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(Link, { to: "/#calculator", children: t.calculator }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
          lineNumber: 138,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
          lineNumber: 138,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(Link, { to: "/contact", children: t.support }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
          lineNumber: 139,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
          lineNumber: 139,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
        lineNumber: 135,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "landing-nav-actions", children: [
        /* @__PURE__ */ jsxDEV(
          "select",
          {
            value: language,
            onChange: (e) => setLanguage(e.target.value),
            className: "lang-select",
            style: { marginRight: "0.5rem" },
            children: [
              /* @__PURE__ */ jsxDEV("option", { value: "en", children: "English 🇬🇧" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                lineNumber: 149,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "hi", children: "हिंदी 🇮🇳" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                lineNumber: 150,
                columnNumber: 15
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
            lineNumber: 143,
            columnNumber: 13
          },
          this
        ),
        isLoggedIn ? /* @__PURE__ */ jsxDEV(Link, { to: "/dashboard", className: "btn-nav-signup", children: t.dashboard }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
          lineNumber: 153,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV(Link, { to: "/login", className: "btn-nav-login", children: t.login }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
            lineNumber: 156,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Link, { to: "/register", className: "btn-nav-signup", children: t.signup }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
            lineNumber: 157,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
          lineNumber: 155,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
        lineNumber: 142,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
      lineNumber: 127,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
      lineNumber: 126,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "contact-container animate-slide", children: [
      /* @__PURE__ */ jsxDEV(Link, { to: "/", className: "back-home-link", children: [
        /* @__PURE__ */ jsxDEV(ArrowLeft, { size: 16 }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
          lineNumber: 167,
          columnNumber: 11
        }, this),
        " ",
        t.back_to_home
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
        lineNumber: 166,
        columnNumber: 9
      }, this),
      !isSubmitted ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "contact-header", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "section-tag", children: language === "hi" ? "संपर्क करें" : "GET IN TOUCH" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
            lineNumber: 173,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("h1", { className: "section-title", style: { fontSize: "3rem" }, children: t.contact_title }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
            lineNumber: 174,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "section-desc", style: { maxWidth: "580px", margin: "0 auto" }, children: t.contact_subtitle }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
            lineNumber: 175,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
          lineNumber: 172,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "contact-grid", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "contact-info-panel", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "contact-info-title", children: t.contact_info_title }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                lineNumber: 184,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "contact-info-desc", children: t.contact_info_desc }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                lineNumber: 185,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "contact-details-list", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "contact-detail-item", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "contact-icon-box", children: /* @__PURE__ */ jsxDEV(Mail, { size: 20 }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                    lineNumber: 192,
                    columnNumber: 25
                  }, this) }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                    lineNumber: 191,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "contact-detail-content", children: [
                    /* @__PURE__ */ jsxDEV("h5", { children: t.email_us }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                      lineNumber: 195,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { children: "support@bankdash.com" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                      lineNumber: 196,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                    lineNumber: 194,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                  lineNumber: 190,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "contact-detail-item", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "contact-icon-box", children: /* @__PURE__ */ jsxDEV(Phone, { size: 20 }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                    lineNumber: 202,
                    columnNumber: 25
                  }, this) }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                    lineNumber: 201,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "contact-detail-content", children: [
                    /* @__PURE__ */ jsxDEV("h5", { children: t.call_support }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                      lineNumber: 205,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { children: "+1 (800) 555-0199" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                      lineNumber: 206,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                    lineNumber: 204,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                  lineNumber: 200,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "contact-detail-item", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "contact-icon-box", children: /* @__PURE__ */ jsxDEV(MapPin, { size: 20 }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                    lineNumber: 212,
                    columnNumber: 25
                  }, this) }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                    lineNumber: 211,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "contact-detail-content", children: [
                    /* @__PURE__ */ jsxDEV("h5", { children: t.headquarters }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                      lineNumber: 215,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { children: "100 Pine St, San Francisco, CA" }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                      lineNumber: 216,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                    lineNumber: 214,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                  lineNumber: 210,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                lineNumber: 189,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
              lineNumber: 183,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "contact-socials", children: [
              /* @__PURE__ */ jsxDEV("a", { href: "https://twitter.com", target: "_blank", rel: "noopener noreferrer", className: "contact-social-btn", "aria-label": "Twitter", children: /* @__PURE__ */ jsxDEV("svg", { width: "18", height: "18", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: /* @__PURE__ */ jsxDEV("path", { d: "M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                lineNumber: 224,
                columnNumber: 164
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                lineNumber: 224,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                lineNumber: 223,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("a", { href: "https://github.com", target: "_blank", rel: "noopener noreferrer", className: "contact-social-btn", "aria-label": "Github", children: /* @__PURE__ */ jsxDEV("svg", { width: "18", height: "18", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: /* @__PURE__ */ jsxDEV("path", { d: "M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                lineNumber: 227,
                columnNumber: 164
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                lineNumber: 227,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                lineNumber: 226,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("a", { href: "https://linkedin.com", target: "_blank", rel: "noopener noreferrer", className: "contact-social-btn", "aria-label": "LinkedIn", children: /* @__PURE__ */ jsxDEV("svg", { width: "18", height: "18", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [
                /* @__PURE__ */ jsxDEV("path", { d: "M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                  lineNumber: 230,
                  columnNumber: 164
                }, this),
                /* @__PURE__ */ jsxDEV("rect", { x: "2", y: "9", width: "4", height: "12" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                  lineNumber: 230,
                  columnNumber: 255
                }, this),
                /* @__PURE__ */ jsxDEV("circle", { cx: "4", cy: "4", r: "2" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                  lineNumber: 230,
                  columnNumber: 297
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                lineNumber: 230,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                lineNumber: 229,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
              lineNumber: 222,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
            lineNumber: 182,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "contact-form-panel", children: [
            errorMsg && /* @__PURE__ */ jsxDEV("div", { style: { color: "#ef4444", backgroundColor: "rgba(239, 68, 68, 0.1)", padding: "0.85rem", borderRadius: "12px", border: "1px solid rgba(239, 68, 68, 0.2)", marginBottom: "1.5rem", fontSize: "0.9rem", fontWeight: 500 }, children: errorMsg }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
              lineNumber: 238,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("form", { className: "contact-form", onSubmit: handleSubmit, children: [
              /* @__PURE__ */ jsxDEV("div", { className: "form-row-2", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "contact-form-group", children: [
                  /* @__PURE__ */ jsxDEV("label", { htmlFor: "name", children: t.label_name }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                    lineNumber: 246,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "contact-input-wrapper", children: [
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "text",
                        id: "name",
                        name: "name",
                        className: "contact-form-input",
                        placeholder: t.placeholder_name,
                        value: formData.name,
                        onChange: handleChange
                      },
                      void 0,
                      false,
                      {
                        fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                        lineNumber: 248,
                        columnNumber: 25
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(User, { className: "contact-input-icon", size: 18 }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                      lineNumber: 257,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                    lineNumber: 247,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                  lineNumber: 245,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "contact-form-group", children: [
                  /* @__PURE__ */ jsxDEV("label", { htmlFor: "email", children: t.label_email }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                    lineNumber: 262,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "contact-input-wrapper", children: [
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "email",
                        id: "email",
                        name: "email",
                        className: "contact-form-input",
                        placeholder: t.placeholder_email,
                        value: formData.email,
                        onChange: handleChange
                      },
                      void 0,
                      false,
                      {
                        fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                        lineNumber: 264,
                        columnNumber: 25
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(Mail, { className: "contact-input-icon", size: 18 }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                      lineNumber: 273,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                    lineNumber: 263,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                  lineNumber: 261,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                lineNumber: 244,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "contact-form-group", children: [
                /* @__PURE__ */ jsxDEV("label", { htmlFor: "subject", children: t.label_subject }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                  lineNumber: 279,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "contact-input-wrapper", children: [
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      id: "subject",
                      name: "subject",
                      className: "contact-form-input",
                      placeholder: t.placeholder_subject,
                      value: formData.subject,
                      onChange: handleChange
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                      lineNumber: 281,
                      columnNumber: 23
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(MessageSquare, { className: "contact-input-icon", size: 18 }, void 0, false, {
                    fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                    lineNumber: 290,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                  lineNumber: 280,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                lineNumber: 278,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "contact-form-group", children: [
                /* @__PURE__ */ jsxDEV("label", { htmlFor: "message", children: t.label_message }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                  lineNumber: 295,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "textarea",
                  {
                    id: "message",
                    name: "message",
                    className: "contact-form-textarea",
                    placeholder: t.placeholder_message,
                    value: formData.message,
                    onChange: handleChange
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                    lineNumber: 296,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                lineNumber: 294,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "submit",
                  className: "btn-contact-submit",
                  disabled: isSubmitting,
                  style: isSubmitting ? { opacity: 0.8, cursor: "not-allowed" } : {},
                  children: [
                    isSubmitting ? t.btn_sending : t.btn_submit,
                    /* @__PURE__ */ jsxDEV(Send, { size: 18 }, void 0, false, {
                      fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                      lineNumber: 313,
                      columnNumber: 21
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                  lineNumber: 306,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
              lineNumber: 243,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
            lineNumber: 236,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
          lineNumber: 180,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "contact-map-section", style: { marginTop: "4rem" }, children: [
          /* @__PURE__ */ jsxDEV("div", { className: "section-head", style: { textAlign: "center", marginBottom: "2.5rem" }, children: [
            /* @__PURE__ */ jsxDEV("span", { className: "section-tag", children: t.branch_locator_tag }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
              lineNumber: 322,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("h2", { className: "section-title", style: { fontSize: "2rem", marginTop: "0.5rem" }, children: t.branch_locator_title }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
              lineNumber: 323,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "section-desc", style: { maxWidth: "600px", margin: "0.5rem auto 0 auto", fontSize: "0.95rem" }, children: t.branch_locator_desc }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
              lineNumber: 324,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
            lineNumber: 321,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "map-layout-grid", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "branch-list-panel", children: branches.map(
              (branch, idx) => /* @__PURE__ */ jsxDEV(
                "div",
                {
                  className: `branch-card-item ${activeBranch === idx ? "active" : ""}`,
                  onClick: () => setActiveBranch(idx),
                  children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "branch-card-header", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "branch-pin-indicator", children: /* @__PURE__ */ jsxDEV(MapPin, { size: 18 }, void 0, false, {
                        fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                        lineNumber: 340,
                        columnNumber: 27
                      }, this) }, void 0, false, {
                        fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                        lineNumber: 339,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("h4", { className: "branch-name-text", children: branch.name }, void 0, false, {
                        fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                        lineNumber: 342,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                      lineNumber: 338,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "branch-details-body", children: [
                      /* @__PURE__ */ jsxDEV("p", { className: "branch-detail-line", children: [
                        /* @__PURE__ */ jsxDEV("strong", { children: language === "hi" ? "पता:" : "Address:" }, void 0, false, {
                          fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                          lineNumber: 347,
                          columnNumber: 27
                        }, this),
                        " ",
                        branch.address
                      ] }, void 0, true, {
                        fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                        lineNumber: 346,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("p", { className: "branch-detail-line", children: [
                        /* @__PURE__ */ jsxDEV("strong", { children: [
                          t.branch_phone,
                          ":"
                        ] }, void 0, true, {
                          fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                          lineNumber: 350,
                          columnNumber: 27
                        }, this),
                        " ",
                        branch.phone
                      ] }, void 0, true, {
                        fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                        lineNumber: 349,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "branch-detail-line", style: { display: "flex", alignItems: "center", gap: "0.35rem", marginTop: "0.35rem" }, children: [
                        /* @__PURE__ */ jsxDEV(Clock, { size: 13, style: { color: "var(--ld-text-muted)", flexShrink: 0 } }, void 0, false, {
                          fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                          lineNumber: 353,
                          columnNumber: 27
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.85rem" }, children: branch.hours }, void 0, false, {
                          fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                          lineNumber: 354,
                          columnNumber: 27
                        }, this)
                      ] }, void 0, true, {
                        fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                        lineNumber: 352,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                      lineNumber: 345,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "branch-card-action", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "branch-action-text", children: t.branch_view_map }, void 0, false, {
                        fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                        lineNumber: 359,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV(ChevronRight, { size: 14, className: "branch-action-chevron" }, void 0, false, {
                        fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                        lineNumber: 360,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                      lineNumber: 358,
                      columnNumber: 23
                    }, this)
                  ]
                },
                idx,
                true,
                {
                  fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                  lineNumber: 333,
                  columnNumber: 17
                },
                this
              )
            ) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
              lineNumber: 331,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "branch-map-iframe-container", children: /* @__PURE__ */ jsxDEV(
              "iframe",
              {
                title: branches[activeBranch].name,
                src: branches[activeBranch].mapUrl,
                width: "100%",
                height: "100%",
                style: { border: 0 },
                allowFullScreen: "",
                loading: "lazy",
                referrerPolicy: "no-referrer-when-downgrade",
                className: "contact-map-iframe"
              },
              void 0,
              false,
              {
                fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
                lineNumber: 368,
                columnNumber: 19
              },
              this
            ) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
              lineNumber: 367,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
            lineNumber: 329,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
          lineNumber: 320,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
        lineNumber: 171,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "contact-grid", style: { gridTemplateColumns: "1fr" }, children: /* @__PURE__ */ jsxDEV("div", { className: "contact-success-card", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "success-icon-box", children: /* @__PURE__ */ jsxDEV(Check, { size: 40 }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
          lineNumber: 387,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
          lineNumber: 386,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { className: "section-title", style: { fontSize: "2.25rem", marginBottom: "1rem" }, children: t.success_title }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
          lineNumber: 389,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "section-desc", style: { maxWidth: "480px", marginBottom: "2.5rem" }, children: [
          t.alert_success,
          " ",
          language === "hi" ? "हम आपसे संपर्क करेंगे" : "We will reach out to you at",
          " ",
          /* @__PURE__ */ jsxDEV("strong", { children: formData.email }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
            lineNumber: 391,
            columnNumber: 113
          }, this),
          "."
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
          lineNumber: 390,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(Link, { to: "/", className: "btn-primary", children: t.return_home }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
          lineNumber: 393,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
        lineNumber: 385,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
        lineNumber: 384,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
      lineNumber: 165,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("footer", { className: "landing-footer", style: { marginTop: "5rem" }, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "footer-grid", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "footer-brand", children: [
          /* @__PURE__ */ jsxDEV(Link, { to: "/", className: "landing-logo", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "logo-icon-box", children: /* @__PURE__ */ jsxDEV(Zap, { size: 22, fill: "white" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
              lineNumber: 407,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
              lineNumber: 406,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: "BankDash" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
              lineNumber: 409,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
            lineNumber: 405,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "footer-desc", children: t.footer_desc }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
            lineNumber: 411,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
          lineNumber: 404,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "footer-col", children: [
          /* @__PURE__ */ jsxDEV("h5", { children: t.col_product }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
            lineNumber: 417,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("ul", { className: "footer-links", children: [
            /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(Link, { to: "/#features", children: t.features }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
              lineNumber: 419,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
              lineNumber: 419,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(Link, { to: "/#calculator", children: t.calculator }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
              lineNumber: 420,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
              lineNumber: 420,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(Link, { to: "/login", children: [
              t.dashboard,
              " Preview"
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
              lineNumber: 421,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
              lineNumber: 421,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
            lineNumber: 418,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
          lineNumber: 416,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "footer-col", children: [
          /* @__PURE__ */ jsxDEV("h5", { children: t.col_security }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
            lineNumber: 426,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("ul", { className: "footer-links", children: [
            /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV("a", { href: "#", children: "Encryption Standards" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
              lineNumber: 428,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
              lineNumber: 428,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV("a", { href: "#", children: "Access Management" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
              lineNumber: 429,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
              lineNumber: 429,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV("a", { href: "#", children: "Privacy Policy" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
              lineNumber: 430,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
              lineNumber: 430,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
            lineNumber: 427,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
          lineNumber: 425,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "footer-col", children: [
          /* @__PURE__ */ jsxDEV("h5", { children: t.col_company }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
            lineNumber: 435,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("ul", { className: "footer-links", children: [
            /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV("a", { href: "#", children: "About Us" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
              lineNumber: 437,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
              lineNumber: 437,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV("a", { href: "#", children: "Careers" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
              lineNumber: 438,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
              lineNumber: 438,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(Link, { to: "/contact", children: t.support }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
              lineNumber: 439,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
              lineNumber: 439,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
            lineNumber: 436,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
          lineNumber: 434,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
        lineNumber: 403,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "footer-bottom", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          "© ",
          (/* @__PURE__ */ new Date()).getFullYear(),
          " BankDash. All rights reserved."
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
          lineNumber: 445,
          columnNumber: 11
        }, this),
        visitCount > 0 && /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", gap: "0.5rem", background: "rgba(0,0,0,0.03)", padding: "0.4rem 0.8rem", borderRadius: "20px", border: "1px solid var(--ld-border)", fontSize: "0.85rem" }, children: [
          /* @__PURE__ */ jsxDEV("span", { style: { width: "8px", height: "8px", borderRadius: "50%", backgroundColor: "#10b981", boxShadow: "0 0 8px #10b981", display: "inline-block" } }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
            lineNumber: 449,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { style: { color: "var(--ld-text-muted)", fontWeight: 500 }, children: [
            t.visit_count,
            " ",
            /* @__PURE__ */ jsxDEV("strong", { style: { color: "var(--ld-text-main)" }, children: visitCount.toLocaleString() }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
              lineNumber: 450,
              columnNumber: 96
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
            lineNumber: 450,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
          lineNumber: 448,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: "1.5rem" }, children: [
          /* @__PURE__ */ jsxDEV("a", { href: "#", style: { color: "var(--ld-text-muted)", textDecoration: "none" }, children: t.terms }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
            lineNumber: 455,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("a", { href: "#", style: { color: "var(--ld-text-muted)", textDecoration: "none" }, children: t.privacy }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
            lineNumber: 456,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
          lineNumber: 454,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
        lineNumber: 444,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
      lineNumber: 402,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/React_test_19_05_2026/src/components/Contact.jsx",
    lineNumber: 119,
    columnNumber: 5
  }, this);
};
_s(Contact, "4PBZsb7ZQnkea1ad5/f5ywwDV1s=", false, function() {
  return [useAuth];
});
_c = Contact;
export default Contact;
var _c;
$RefreshReg$(_c, "Contact");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/React_test_19_05_2026/src/components/Contact.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/React_test_19_05_2026/src/components/Contact.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUdNLFNBa0NRLFVBbENSOzs7Ozs7Ozs7Ozs7Ozs7OztBQXJHTixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsWUFBWTtBQUNyQjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLG9CQUFvQjtBQUM3QixPQUFPO0FBRVAsTUFBTUMsVUFBVUEsTUFBTTtBQUFBQyxLQUFBO0FBQ3BCLFFBQU0sRUFBRUMsWUFBWUMsWUFBWUMsVUFBVUMsWUFBWSxJQUFJUCxRQUFRO0FBQ2xFLFFBQU1RLElBQUlQLGFBQWFLLFFBQVEsS0FBS0wsYUFBYVE7QUFFakQsUUFBTSxDQUFDQyxVQUFVQyxXQUFXLElBQUl6QixTQUFTO0FBQUEsSUFDdkMwQixNQUFNO0FBQUEsSUFDTkMsT0FBTztBQUFBLElBQ1BDLFNBQVM7QUFBQSxJQUNUQyxTQUFTO0FBQUEsRUFDWCxDQUFDO0FBRUQsUUFBTSxDQUFDQyxjQUFjQyxlQUFlLElBQUkvQixTQUFTLEtBQUs7QUFDdEQsUUFBTSxDQUFDZ0MsYUFBYUMsY0FBYyxJQUFJakMsU0FBUyxLQUFLO0FBQ3BELFFBQU0sQ0FBQ2tDLFVBQVVDLFdBQVcsSUFBSW5DLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNvQyxjQUFjQyxlQUFlLElBQUlyQyxTQUFTLENBQUM7QUFFbEQsUUFBTXNDLFdBQVc7QUFBQSxJQUNmO0FBQUEsTUFDRVosTUFBTU4sYUFBYSxPQUFPLDZCQUE2QjtBQUFBLE1BQ3ZEbUIsU0FBUztBQUFBLE1BQ1RDLE9BQU87QUFBQSxNQUNQQyxPQUFPO0FBQUEsTUFDUEMsUUFBUTtBQUFBLElBQ1Y7QUFBQSxJQUNBO0FBQUEsTUFDRWhCLE1BQU1OLGFBQWEsT0FBTyw2QkFBNkI7QUFBQSxNQUN2RG1CLFNBQVM7QUFBQSxNQUNUQyxPQUFPO0FBQUEsTUFDUEMsT0FBTztBQUFBLE1BQ1BDLFFBQVE7QUFBQSxJQUNWO0FBQUEsSUFDQTtBQUFBLE1BQ0VoQixNQUFNTixhQUFhLE9BQU8scUJBQXFCO0FBQUEsTUFDL0NtQixTQUFTO0FBQUEsTUFDVEMsT0FBTztBQUFBLE1BQ1BDLE9BQU87QUFBQSxNQUNQQyxRQUFRO0FBQUEsSUFDVjtBQUFBLEVBQUM7QUFHSCxRQUFNQyxlQUFlQSxDQUFDQyxNQUFNO0FBQzFCbkIsZ0JBQVk7QUFBQSxNQUNWLEdBQUdEO0FBQUFBLE1BQ0gsQ0FBQ29CLEVBQUVDLE9BQU9uQixJQUFJLEdBQUdrQixFQUFFQyxPQUFPQztBQUFBQSxJQUM1QixDQUFDO0FBQUEsRUFDSDtBQUVBLFFBQU1DLGVBQWVBLENBQUNILE1BQU07QUFDMUJBLE1BQUVJLGVBQWU7QUFDakJiLGdCQUFZLEVBQUU7QUFHZCxRQUFJLENBQUNYLFNBQVNFLEtBQUt1QixLQUFLLEdBQUc7QUFDekJkLGtCQUFZYixFQUFFNEIsWUFBWTtBQUMxQjtBQUFBLElBQ0Y7QUFDQSxRQUFJLENBQUMxQixTQUFTRyxNQUFNc0IsS0FBSyxLQUFLLENBQUN6QixTQUFTRyxNQUFNd0IsU0FBUyxHQUFHLEdBQUc7QUFDM0RoQixrQkFBWWIsRUFBRThCLGFBQWE7QUFDM0I7QUFBQSxJQUNGO0FBQ0EsUUFBSSxDQUFDNUIsU0FBU0ksUUFBUXFCLEtBQUssR0FBRztBQUM1QmQsa0JBQVliLEVBQUUrQixZQUFZO0FBQzFCO0FBQUEsSUFDRjtBQUNBLFFBQUksQ0FBQzdCLFNBQVNLLFFBQVFvQixLQUFLLEtBQUt6QixTQUFTSyxRQUFReUIsU0FBUyxJQUFJO0FBQzVEbkIsa0JBQVliLEVBQUVpQyxXQUFXO0FBQ3pCO0FBQUEsSUFDRjtBQUVBeEIsb0JBQWdCLElBQUk7QUFHcEJ5QixlQUFXLE1BQU07QUFDZnpCLHNCQUFnQixLQUFLO0FBQ3JCRSxxQkFBZSxJQUFJO0FBQUEsSUFDckIsR0FBRyxJQUFJO0FBQUEsRUFDVDtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLDZCQUViO0FBQUEsMkJBQUMsU0FBSSxXQUFVLG1DQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0M7QUFBQSxJQUMvQyx1QkFBQyxTQUFJLFdBQVUsaUNBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2QztBQUFBLElBQzdDLHVCQUFDLFNBQUksV0FBVSxrQ0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThDO0FBQUEsSUFHOUMsdUJBQUMsWUFBTyxXQUFVLGtCQUNoQixpQ0FBQyxTQUFJLFdBQVUseUJBQ2I7QUFBQSw2QkFBQyxRQUFLLElBQUcsS0FBSSxXQUFVLGdCQUNyQjtBQUFBLCtCQUFDLFNBQUksV0FBVSxpQkFDYixpQ0FBQyxPQUFJLE1BQU0sSUFBSSxNQUFLLFdBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkIsS0FEN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxVQUFLLHdCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBYztBQUFBLFdBSmhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BRUEsdUJBQUMsUUFBRyxXQUFVLHFCQUNaO0FBQUEsK0JBQUMsUUFBRyxpQ0FBQyxRQUFLLElBQUcsS0FBS2IsdUJBQWEsT0FBTyxRQUFRLFVBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUQsS0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RDtBQUFBLFFBQzVELHVCQUFDLFFBQUcsaUNBQUMsUUFBSyxJQUFHLGNBQWNFLFlBQUVtQyxZQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtDLEtBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkM7QUFBQSxRQUM3Qyx1QkFBQyxRQUFHLGlDQUFDLFFBQUssSUFBRyxnQkFBZ0JuQyxZQUFFb0MsY0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzQyxLQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlEO0FBQUEsUUFDakQsdUJBQUMsUUFBRyxpQ0FBQyxRQUFLLElBQUcsWUFBWXBDLFlBQUVxQyxXQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStCLEtBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEM7QUFBQSxXQUo1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSx1QkFDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFPdkM7QUFBQUEsWUFDUCxVQUFVLENBQUN3QixNQUFNdkIsWUFBWXVCLEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxZQUMzQyxXQUFVO0FBQUEsWUFDVixPQUFPLEVBQUVjLGFBQWEsU0FBUztBQUFBLFlBRS9CO0FBQUEscUNBQUMsWUFBTyxPQUFNLE1BQUssNEJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStCO0FBQUEsY0FDL0IsdUJBQUMsWUFBTyxPQUFNLE1BQUssMEJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZCO0FBQUE7QUFBQTtBQUFBLFVBUC9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVFBO0FBQUEsUUFDQzFDLGFBQ0MsdUJBQUMsUUFBSyxJQUFHLGNBQWEsV0FBVSxrQkFBa0JJLFlBQUV1QyxhQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThELElBRTlELG1DQUNFO0FBQUEsaUNBQUMsUUFBSyxJQUFHLFVBQVMsV0FBVSxpQkFBaUJ2QyxZQUFFd0MsU0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUQ7QUFBQSxVQUNyRCx1QkFBQyxRQUFLLElBQUcsYUFBWSxXQUFVLGtCQUFrQnhDLFlBQUV5QyxVQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRDtBQUFBLGFBRjVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBaEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrQkE7QUFBQSxTQWpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa0NBLEtBbkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvQ0E7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSxtQ0FDYjtBQUFBLDZCQUFDLFFBQUssSUFBRyxLQUFJLFdBQVUsa0JBQ3JCO0FBQUEsK0JBQUMsYUFBVSxNQUFNLE1BQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0I7QUFBQSxRQUFHO0FBQUEsUUFBRXpDLEVBQUUwQztBQUFBQSxXQUQ3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUVDLENBQUNoQyxjQUNBLG1DQUNFO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLGVBQWVaLHVCQUFhLE9BQU8sZ0JBQWdCLGtCQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRjtBQUFBLFVBQ2xGLHVCQUFDLFFBQUcsV0FBVSxpQkFBZ0IsT0FBTyxFQUFFNkMsVUFBVSxPQUFPLEdBQUkzQyxZQUFFNEMsaUJBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRFO0FBQUEsVUFDNUUsdUJBQUMsT0FBRSxXQUFVLGdCQUFlLE9BQU8sRUFBRUMsVUFBVSxTQUFTQyxRQUFRLFNBQVMsR0FDdEU5QyxZQUFFK0Msb0JBREw7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsZ0JBRWI7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsc0JBQ2I7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsUUFBRyxXQUFVLHNCQUFzQi9DLFlBQUVnRCxzQkFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUQ7QUFBQSxjQUN6RCx1QkFBQyxPQUFFLFdBQVUscUJBQ1ZoRCxZQUFFaUQscUJBREw7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBRUEsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLHVCQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLG9CQUNiLGlDQUFDLFFBQUssTUFBTSxNQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWUsS0FEakI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLDJDQUFDLFFBQUlqRCxZQUFFa0QsWUFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFnQjtBQUFBLG9CQUNoQix1QkFBQyxPQUFFLG9DQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXVCO0FBQUEsdUJBRnpCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxxQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVFBO0FBQUEsZ0JBRUEsdUJBQUMsU0FBSSxXQUFVLHVCQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLG9CQUNiLGlDQUFDLFNBQU0sTUFBTSxNQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdCLEtBRGxCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSwyQ0FBQyxRQUFJbEQsWUFBRW1ELGdCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW9CO0FBQUEsb0JBQ3BCLHVCQUFDLE9BQUUsaUNBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBb0I7QUFBQSx1QkFGdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLHFCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBUUE7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUsdUJBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsb0JBQ2IsaUNBQUMsVUFBTyxNQUFNLE1BQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUIsS0FEbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLDJDQUFDLFFBQUluRCxZQUFFb0QsZ0JBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBb0I7QUFBQSxvQkFDcEIsdUJBQUMsT0FBRSw4Q0FBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFpQztBQUFBLHVCQUZuQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEscUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFRQTtBQUFBLG1CQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQThCQTtBQUFBLGlCQXBDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXFDQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEscUNBQUMsT0FBRSxNQUFLLHVCQUFzQixRQUFPLFVBQVMsS0FBSSx1QkFBc0IsV0FBVSxzQkFBcUIsY0FBVyxXQUNoSCxpQ0FBQyxTQUFJLE9BQU0sTUFBSyxRQUFPLE1BQUssU0FBUSxhQUFZLE1BQUssUUFBTyxRQUFPLGdCQUFlLGFBQVksS0FBSSxlQUFjLFNBQVEsZ0JBQWUsU0FBUSxpQ0FBQyxVQUFLLEdBQUUsNklBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUosS0FBaFM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa1MsS0FEcFM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsT0FBRSxNQUFLLHNCQUFxQixRQUFPLFVBQVMsS0FBSSx1QkFBc0IsV0FBVSxzQkFBcUIsY0FBVyxVQUMvRyxpQ0FBQyxTQUFJLE9BQU0sTUFBSyxRQUFPLE1BQUssU0FBUSxhQUFZLE1BQUssUUFBTyxRQUFPLGdCQUFlLGFBQVksS0FBSSxlQUFjLFNBQVEsZ0JBQWUsU0FBUSxpQ0FBQyxVQUFLLEdBQUUsOFBBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa1EsS0FBalo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbVosS0FEclo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsT0FBRSxNQUFLLHdCQUF1QixRQUFPLFVBQVMsS0FBSSx1QkFBc0IsV0FBVSxzQkFBcUIsY0FBVyxZQUNqSCxpQ0FBQyxTQUFJLE9BQU0sTUFBSyxRQUFPLE1BQUssU0FBUSxhQUFZLE1BQUssUUFBTyxRQUFPLGdCQUFlLGFBQVksS0FBSSxlQUFjLFNBQVEsZ0JBQWUsU0FBUTtBQUFBLHVDQUFDLFVBQUssR0FBRSxvRkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3RjtBQUFBLGdCQUFFLHVCQUFDLFVBQUssR0FBRSxLQUFJLEdBQUUsS0FBSSxPQUFNLEtBQUksUUFBTyxRQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1QztBQUFBLGdCQUFFLHVCQUFDLFlBQU8sSUFBRyxLQUFJLElBQUcsS0FBSSxHQUFFLE9BQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJCO0FBQUEsbUJBQTdTO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStTLEtBRGpUO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVVBO0FBQUEsZUFsREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtREE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSxzQkFDWnhDO0FBQUFBLHdCQUNDLHVCQUFDLFNBQUksT0FBTyxFQUFFeUMsT0FBTyxXQUFXQyxpQkFBaUIsMEJBQTBCQyxTQUFTLFdBQVdDLGNBQWMsUUFBUUMsUUFBUSxvQ0FBb0NDLGNBQWMsVUFBVWYsVUFBVSxVQUFVZ0IsWUFBWSxJQUFJLEdBQzFOL0Msc0JBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBR0YsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLFVBQVVhLGNBQ3ZDO0FBQUEscUNBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsc0JBQ2I7QUFBQSx5Q0FBQyxXQUFNLFNBQVEsUUFBUXpCLFlBQUU0RCxjQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFvQztBQUFBLGtCQUNwQyx1QkFBQyxTQUFJLFdBQVUseUJBQ2I7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsSUFBRztBQUFBLHdCQUNILE1BQUs7QUFBQSx3QkFDTCxXQUFVO0FBQUEsd0JBQ1YsYUFBYTVELEVBQUU2RDtBQUFBQSx3QkFDZixPQUFPM0QsU0FBU0U7QUFBQUEsd0JBQ2hCLFVBQVVpQjtBQUFBQTtBQUFBQSxzQkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBT3lCO0FBQUEsb0JBRXpCLHVCQUFDLFFBQUssV0FBVSxzQkFBcUIsTUFBTSxNQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE4QztBQUFBLHVCQVZoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVdBO0FBQUEscUJBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFjQTtBQUFBLGdCQUVBLHVCQUFDLFNBQUksV0FBVSxzQkFDYjtBQUFBLHlDQUFDLFdBQU0sU0FBUSxTQUFTckIsWUFBRThELGVBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXNDO0FBQUEsa0JBQ3RDLHVCQUFDLFNBQUksV0FBVSx5QkFDYjtBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxJQUFHO0FBQUEsd0JBQ0gsTUFBSztBQUFBLHdCQUNMLFdBQVU7QUFBQSx3QkFDVixhQUFhOUQsRUFBRStEO0FBQUFBLHdCQUNmLE9BQU83RCxTQUFTRztBQUFBQSx3QkFDaEIsVUFBVWdCO0FBQUFBO0FBQUFBLHNCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFPeUI7QUFBQSxvQkFFekIsdUJBQUMsUUFBSyxXQUFVLHNCQUFxQixNQUFNLE1BQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQThDO0FBQUEsdUJBVmhEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBV0E7QUFBQSxxQkFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWNBO0FBQUEsbUJBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZ0NBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUsc0JBQ2I7QUFBQSx1Q0FBQyxXQUFNLFNBQVEsV0FBV3JCLFlBQUVnRSxpQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMEM7QUFBQSxnQkFDMUMsdUJBQUMsU0FBSSxXQUFVLHlCQUNiO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLElBQUc7QUFBQSxzQkFDSCxNQUFLO0FBQUEsc0JBQ0wsV0FBVTtBQUFBLHNCQUNWLGFBQWFoRSxFQUFFaUU7QUFBQUEsc0JBQ2YsT0FBTy9ELFNBQVNJO0FBQUFBLHNCQUNoQixVQUFVZTtBQUFBQTtBQUFBQSxvQkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBT3lCO0FBQUEsa0JBRXpCLHVCQUFDLGlCQUFjLFdBQVUsc0JBQXFCLE1BQU0sTUFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBdUQ7QUFBQSxxQkFWekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFXQTtBQUFBLG1CQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBY0E7QUFBQSxjQUVBLHVCQUFDLFNBQUksV0FBVSxzQkFDYjtBQUFBLHVDQUFDLFdBQU0sU0FBUSxXQUFXckIsWUFBRWtFLGlCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwQztBQUFBLGdCQUMxQztBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxJQUFHO0FBQUEsb0JBQ0gsTUFBSztBQUFBLG9CQUNMLFdBQVU7QUFBQSxvQkFDVixhQUFhbEUsRUFBRW1FO0FBQUFBLG9CQUNmLE9BQU9qRSxTQUFTSztBQUFBQSxvQkFDaEIsVUFBVWM7QUFBQUE7QUFBQUEsa0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU15QjtBQUFBLG1CQVIzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVVBO0FBQUEsY0FFQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsV0FBVTtBQUFBLGtCQUNWLFVBQVViO0FBQUFBLGtCQUNWLE9BQU9BLGVBQWUsRUFBRTRELFNBQVMsS0FBS0MsUUFBUSxjQUFjLElBQUksQ0FBQztBQUFBLGtCQUVoRTdEO0FBQUFBLG1DQUFlUixFQUFFc0UsY0FBY3RFLEVBQUV1RTtBQUFBQSxvQkFDbEMsdUJBQUMsUUFBSyxNQUFNLE1BQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZTtBQUFBO0FBQUE7QUFBQSxnQkFQakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBUUE7QUFBQSxpQkF2RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF3RUE7QUFBQSxlQS9FRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdGQTtBQUFBLGFBeElGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5SUE7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSx1QkFBc0IsT0FBTyxFQUFFQyxXQUFXLE9BQU8sR0FDOUQ7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsZ0JBQWUsT0FBTyxFQUFFQyxXQUFXLFVBQVVmLGNBQWMsU0FBUyxHQUNqRjtBQUFBLG1DQUFDLFVBQUssV0FBVSxlQUFlMUQsWUFBRTBFLHNCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRDtBQUFBLFlBQ3BELHVCQUFDLFFBQUcsV0FBVSxpQkFBZ0IsT0FBTyxFQUFFL0IsVUFBVSxRQUFRNkIsV0FBVyxTQUFTLEdBQUl4RSxZQUFFMkUsd0JBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdHO0FBQUEsWUFDeEcsdUJBQUMsT0FBRSxXQUFVLGdCQUFlLE9BQU8sRUFBRTlCLFVBQVUsU0FBU0MsUUFBUSxzQkFBc0JILFVBQVUsVUFBVSxHQUN2RzNDLFlBQUU0RSx1QkFETDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsbUJBRWI7QUFBQSxtQ0FBQyxTQUFJLFdBQVUscUJBQ1o1RCxtQkFBUzZEO0FBQUFBLGNBQUksQ0FBQ0MsUUFBUUMsUUFDckI7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBRUMsV0FBVyxvQkFBb0JqRSxpQkFBaUJpRSxNQUFNLFdBQVcsRUFBRTtBQUFBLGtCQUNuRSxTQUFTLE1BQU1oRSxnQkFBZ0JnRSxHQUFHO0FBQUEsa0JBRWxDO0FBQUEsMkNBQUMsU0FBSSxXQUFVLHNCQUNiO0FBQUEsNkNBQUMsU0FBSSxXQUFVLHdCQUNiLGlDQUFDLFVBQU8sTUFBTSxNQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlCLEtBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQSx1QkFBQyxRQUFHLFdBQVUsb0JBQW9CRCxpQkFBTzFFLFFBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQThDO0FBQUEseUJBSmhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBS0E7QUFBQSxvQkFFQSx1QkFBQyxTQUFJLFdBQVUsdUJBQ2I7QUFBQSw2Q0FBQyxPQUFFLFdBQVUsc0JBQ1g7QUFBQSwrQ0FBQyxZQUFRTix1QkFBYSxPQUFPLFNBQVMsY0FBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBaUQ7QUFBQSx3QkFBUztBQUFBLHdCQUFFZ0YsT0FBTzdEO0FBQUFBLDJCQURyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0EsdUJBQUMsT0FBRSxXQUFVLHNCQUNYO0FBQUEsK0NBQUMsWUFBUWpCO0FBQUFBLDRCQUFFZ0Y7QUFBQUEsMEJBQWE7QUFBQSw2QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBeUI7QUFBQSx3QkFBUztBQUFBLHdCQUFFRixPQUFPNUQ7QUFBQUEsMkJBRDdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQSx1QkFBQyxTQUFJLFdBQVUsc0JBQXFCLE9BQU8sRUFBRStELFNBQVMsUUFBUUMsWUFBWSxVQUFVQyxLQUFLLFdBQVdYLFdBQVcsVUFBVSxHQUN2SDtBQUFBLCtDQUFDLFNBQU0sTUFBTSxJQUFJLE9BQU8sRUFBRW5CLE9BQU8sd0JBQXdCK0IsWUFBWSxFQUFFLEtBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQXlFO0FBQUEsd0JBQ3pFLHVCQUFDLFVBQUssT0FBTyxFQUFFekMsVUFBVSxVQUFVLEdBQUltQyxpQkFBTzNELFNBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQW9EO0FBQUEsMkJBRnREO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBR0E7QUFBQSx5QkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVdBO0FBQUEsb0JBRUEsdUJBQUMsU0FBSSxXQUFVLHNCQUNiO0FBQUEsNkNBQUMsVUFBSyxXQUFVLHNCQUFzQm5CLFlBQUVxRixtQkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBd0Q7QUFBQSxzQkFDeEQsdUJBQUMsZ0JBQWEsTUFBTSxJQUFJLFdBQVUsMkJBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXlEO0FBQUEseUJBRjNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBR0E7QUFBQTtBQUFBO0FBQUEsZ0JBM0JLTjtBQUFBQSxnQkFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBNkJBO0FBQUEsWUFDRCxLQWhDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlDQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBTy9ELFNBQVNGLFlBQVksRUFBRVY7QUFBQUEsZ0JBQzlCLEtBQUtZLFNBQVNGLFlBQVksRUFBRU07QUFBQUEsZ0JBQzVCLE9BQU07QUFBQSxnQkFDTixRQUFPO0FBQUEsZ0JBQ1AsT0FBTyxFQUFFcUMsUUFBUSxFQUFFO0FBQUEsZ0JBQ25CLGlCQUFnQjtBQUFBLGdCQUNoQixTQUFRO0FBQUEsZ0JBQ1IsZ0JBQWU7QUFBQSxnQkFDZixXQUFVO0FBQUE7QUFBQSxjQVRaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVVDLEtBWEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFZQTtBQUFBLGVBbERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbURBO0FBQUEsYUE1REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTZEQTtBQUFBLFdBbE5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFtTkEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsZ0JBQWUsT0FBTyxFQUFFNkIscUJBQXFCLE1BQU0sR0FDaEUsaUNBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLG9CQUNiLGlDQUFDLFNBQU0sTUFBTSxNQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0IsS0FEbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxRQUFHLFdBQVUsaUJBQWdCLE9BQU8sRUFBRTNDLFVBQVUsV0FBV2UsY0FBYyxPQUFPLEdBQUkxRCxZQUFFdUYsaUJBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUc7QUFBQSxRQUNyRyx1QkFBQyxPQUFFLFdBQVUsZ0JBQWUsT0FBTyxFQUFFMUMsVUFBVSxTQUFTYSxjQUFjLFNBQVMsR0FDNUUxRDtBQUFBQSxZQUFFd0Y7QUFBQUEsVUFBYztBQUFBLFVBQUUxRixhQUFhLE9BQU8sMEJBQTBCO0FBQUEsVUFBOEI7QUFBQSxVQUFDLHVCQUFDLFlBQVFJLG1CQUFTRyxTQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3QjtBQUFBLFVBQVM7QUFBQSxhQURuSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFFBQUssSUFBRyxLQUFJLFdBQVUsZUFDcEJMLFlBQUV5RixlQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBLEtBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUEsU0F4T0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBPQTtBQUFBLElBR0EsdUJBQUMsWUFBTyxXQUFVLGtCQUFpQixPQUFPLEVBQUVqQixXQUFXLE9BQU8sR0FDNUQ7QUFBQSw2QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBLGlDQUFDLFFBQUssSUFBRyxLQUFJLFdBQVUsZ0JBQ3JCO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGlCQUNiLGlDQUFDLE9BQUksTUFBTSxJQUFJLE1BQUssV0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkIsS0FEN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsVUFBSyx3QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFjO0FBQUEsZUFKaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFVLGVBQ1Z4RSxZQUFFMEYsZUFETDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsaUNBQUMsUUFBSTFGLFlBQUUyRixlQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1CO0FBQUEsVUFDbkIsdUJBQUMsUUFBRyxXQUFVLGdCQUNaO0FBQUEsbUNBQUMsUUFBRyxpQ0FBQyxRQUFLLElBQUcsY0FBYzNGLFlBQUVtQyxZQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrQyxLQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2QztBQUFBLFlBQzdDLHVCQUFDLFFBQUcsaUNBQUMsUUFBSyxJQUFHLGdCQUFnQm5DLFlBQUVvQyxjQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzQyxLQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRDtBQUFBLFlBQ2pELHVCQUFDLFFBQUcsaUNBQUMsUUFBSyxJQUFHLFVBQVVwQztBQUFBQSxnQkFBRXVDO0FBQUFBLGNBQVU7QUFBQSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUMsS0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0Q7QUFBQSxlQUhwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsYUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsaUNBQUMsUUFBSXZDLFlBQUU0RixnQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvQjtBQUFBLFVBQ3BCLHVCQUFDLFFBQUcsV0FBVSxnQkFDWjtBQUFBLG1DQUFDLFFBQUcsaUNBQUMsT0FBRSxNQUFLLEtBQUksb0NBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0MsS0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0M7QUFBQSxZQUN4Qyx1QkFBQyxRQUFHLGlDQUFDLE9BQUUsTUFBSyxLQUFJLGlDQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZCLEtBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFDO0FBQUEsWUFDckMsdUJBQUMsUUFBRyxpQ0FBQyxPQUFFLE1BQUssS0FBSSw4QkFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwQixLQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrQztBQUFBLGVBSHBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxpQ0FBQyxRQUFJNUYsWUFBRTZGLGVBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUI7QUFBQSxVQUNuQix1QkFBQyxRQUFHLFdBQVUsZ0JBQ1o7QUFBQSxtQ0FBQyxRQUFHLGlDQUFDLE9BQUUsTUFBSyxLQUFJLHdCQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9CLEtBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRCO0FBQUEsWUFDNUIsdUJBQUMsUUFBRyxpQ0FBQyxPQUFFLE1BQUssS0FBSSx1QkFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtQixLQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyQjtBQUFBLFlBQzNCLHVCQUFDLFFBQUcsaUNBQUMsUUFBSyxJQUFHLFlBQVk3RixZQUFFcUMsV0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0IsS0FBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEM7QUFBQSxlQUg1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsYUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxXQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdUNBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSwrQkFBQyxTQUFJO0FBQUE7QUFBQSxXQUFHLG9CQUFJeUQsS0FBSyxHQUFFQyxZQUFZO0FBQUEsVUFBRTtBQUFBLGFBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0U7QUFBQSxRQUUvRGxHLGFBQWEsS0FDWix1QkFBQyxTQUFJLE9BQU8sRUFBRW9GLFNBQVMsUUFBUUMsWUFBWSxVQUFVQyxLQUFLLFVBQVVhLFlBQVksb0JBQW9CekMsU0FBUyxpQkFBaUJDLGNBQWMsUUFBUUMsUUFBUSw4QkFBOEJkLFVBQVUsVUFBVSxHQUM1TTtBQUFBLGlDQUFDLFVBQUssT0FBTyxFQUFFc0QsT0FBTyxPQUFPQyxRQUFRLE9BQU8xQyxjQUFjLE9BQU9GLGlCQUFpQixXQUFXNkMsV0FBVyxtQkFBbUJsQixTQUFTLGVBQWUsS0FBbko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0o7QUFBQSxVQUN0Six1QkFBQyxVQUFLLE9BQU8sRUFBRTVCLE9BQU8sd0JBQXdCTSxZQUFZLElBQUksR0FBSTNEO0FBQUFBLGNBQUVvRztBQUFBQSxZQUFZO0FBQUEsWUFBQyx1QkFBQyxZQUFPLE9BQU8sRUFBRS9DLE9BQU8sc0JBQXNCLEdBQUl4RCxxQkFBV3dHLGVBQWUsS0FBNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEU7QUFBQSxlQUEvSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3SztBQUFBLGFBRjFLO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBR0YsdUJBQUMsU0FBSSxPQUFPLEVBQUVwQixTQUFTLFFBQVFFLEtBQUssU0FBUyxHQUMzQztBQUFBLGlDQUFDLE9BQUUsTUFBSyxLQUFJLE9BQU8sRUFBRTlCLE9BQU8sd0JBQXdCaUQsZ0JBQWdCLE9BQU8sR0FBSXRHLFlBQUV1RyxTQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1RjtBQUFBLFVBQ3ZGLHVCQUFDLE9BQUUsTUFBSyxLQUFJLE9BQU8sRUFBRWxELE9BQU8sd0JBQXdCaUQsZ0JBQWdCLE9BQU8sR0FBSXRHLFlBQUV3RyxXQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RjtBQUFBLGFBRjNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWNBO0FBQUEsU0F4REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlEQTtBQUFBLE9BcFZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FxVkE7QUFFSjtBQUFFN0csR0F0YUlELFNBQU87QUFBQSxVQUMrQ0YsT0FBTztBQUFBO0FBQUEsS0FEN0RFO0FBd2FOLGVBQWVBO0FBQVEsSUFBQStHO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiTGluayIsIk1haWwiLCJQaG9uZSIsIk1hcFBpbiIsIlNlbmQiLCJBcnJvd0xlZnQiLCJDaGVjayIsIlVzZXIiLCJNZXNzYWdlU3F1YXJlIiwiWmFwIiwiR2xvYmUiLCJDbG9jayIsIkNoZXZyb25SaWdodCIsInVzZUF1dGgiLCJ0cmFuc2xhdGlvbnMiLCJDb250YWN0IiwiX3MiLCJpc0xvZ2dlZEluIiwidmlzaXRDb3VudCIsImxhbmd1YWdlIiwic2V0TGFuZ3VhZ2UiLCJ0IiwiZW4iLCJmb3JtRGF0YSIsInNldEZvcm1EYXRhIiwibmFtZSIsImVtYWlsIiwic3ViamVjdCIsIm1lc3NhZ2UiLCJpc1N1Ym1pdHRpbmciLCJzZXRJc1N1Ym1pdHRpbmciLCJpc1N1Ym1pdHRlZCIsInNldElzU3VibWl0dGVkIiwiZXJyb3JNc2ciLCJzZXRFcnJvck1zZyIsImFjdGl2ZUJyYW5jaCIsInNldEFjdGl2ZUJyYW5jaCIsImJyYW5jaGVzIiwiYWRkcmVzcyIsInBob25lIiwiaG91cnMiLCJtYXBVcmwiLCJoYW5kbGVDaGFuZ2UiLCJlIiwidGFyZ2V0IiwidmFsdWUiLCJoYW5kbGVTdWJtaXQiLCJwcmV2ZW50RGVmYXVsdCIsInRyaW0iLCJ2YWxfbmFtZV9yZXEiLCJpbmNsdWRlcyIsInZhbF9lbWFpbF9yZXEiLCJ2YWxfc3Vial9yZXEiLCJsZW5ndGgiLCJ2YWxfbXNnX3JlcSIsInNldFRpbWVvdXQiLCJmZWF0dXJlcyIsImNhbGN1bGF0b3IiLCJzdXBwb3J0IiwibWFyZ2luUmlnaHQiLCJkYXNoYm9hcmQiLCJsb2dpbiIsInNpZ251cCIsImJhY2tfdG9faG9tZSIsImZvbnRTaXplIiwiY29udGFjdF90aXRsZSIsIm1heFdpZHRoIiwibWFyZ2luIiwiY29udGFjdF9zdWJ0aXRsZSIsImNvbnRhY3RfaW5mb190aXRsZSIsImNvbnRhY3RfaW5mb19kZXNjIiwiZW1haWxfdXMiLCJjYWxsX3N1cHBvcnQiLCJoZWFkcXVhcnRlcnMiLCJjb2xvciIsImJhY2tncm91bmRDb2xvciIsInBhZGRpbmciLCJib3JkZXJSYWRpdXMiLCJib3JkZXIiLCJtYXJnaW5Cb3R0b20iLCJmb250V2VpZ2h0IiwibGFiZWxfbmFtZSIsInBsYWNlaG9sZGVyX25hbWUiLCJsYWJlbF9lbWFpbCIsInBsYWNlaG9sZGVyX2VtYWlsIiwibGFiZWxfc3ViamVjdCIsInBsYWNlaG9sZGVyX3N1YmplY3QiLCJsYWJlbF9tZXNzYWdlIiwicGxhY2Vob2xkZXJfbWVzc2FnZSIsIm9wYWNpdHkiLCJjdXJzb3IiLCJidG5fc2VuZGluZyIsImJ0bl9zdWJtaXQiLCJtYXJnaW5Ub3AiLCJ0ZXh0QWxpZ24iLCJicmFuY2hfbG9jYXRvcl90YWciLCJicmFuY2hfbG9jYXRvcl90aXRsZSIsImJyYW5jaF9sb2NhdG9yX2Rlc2MiLCJtYXAiLCJicmFuY2giLCJpZHgiLCJicmFuY2hfcGhvbmUiLCJkaXNwbGF5IiwiYWxpZ25JdGVtcyIsImdhcCIsImZsZXhTaHJpbmsiLCJicmFuY2hfdmlld19tYXAiLCJncmlkVGVtcGxhdGVDb2x1bW5zIiwic3VjY2Vzc190aXRsZSIsImFsZXJ0X3N1Y2Nlc3MiLCJyZXR1cm5faG9tZSIsImZvb3Rlcl9kZXNjIiwiY29sX3Byb2R1Y3QiLCJjb2xfc2VjdXJpdHkiLCJjb2xfY29tcGFueSIsIkRhdGUiLCJnZXRGdWxsWWVhciIsImJhY2tncm91bmQiLCJ3aWR0aCIsImhlaWdodCIsImJveFNoYWRvdyIsInZpc2l0X2NvdW50IiwidG9Mb2NhbGVTdHJpbmciLCJ0ZXh0RGVjb3JhdGlvbiIsInRlcm1zIiwicHJpdmFjeSIsIl9jIl0sInNvdXJjZXMiOlsiQ29udGFjdC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyBcbiAgTWFpbCwgXG4gIFBob25lLCBcbiAgTWFwUGluLCBcbiAgU2VuZCwgXG4gIEFycm93TGVmdCwgXG4gIENoZWNrLCBcbiAgVXNlciwgXG4gIE1lc3NhZ2VTcXVhcmUsIFxuICBaYXAsIFxuICBHbG9iZSxcbiAgQ2xvY2ssXG4gIENoZXZyb25SaWdodFxufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uL0FwcCc7XG5pbXBvcnQgeyB0cmFuc2xhdGlvbnMgfSBmcm9tICcuLi91dGlscy90cmFuc2xhdGlvbnMnO1xuaW1wb3J0ICcuLi9sYW5kaW5nLmNzcyc7XG5cbmNvbnN0IENvbnRhY3QgPSAoKSA9PiB7XG4gIGNvbnN0IHsgaXNMb2dnZWRJbiwgdmlzaXRDb3VudCwgbGFuZ3VhZ2UsIHNldExhbmd1YWdlIH0gPSB1c2VBdXRoKCk7XG4gIGNvbnN0IHQgPSB0cmFuc2xhdGlvbnNbbGFuZ3VhZ2VdIHx8IHRyYW5zbGF0aW9ucy5lbjtcblxuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcbiAgICBuYW1lOiAnJyxcbiAgICBlbWFpbDogJycsXG4gICAgc3ViamVjdDogJycsXG4gICAgbWVzc2FnZTogJydcbiAgfSk7XG4gIFxuICBjb25zdCBbaXNTdWJtaXR0aW5nLCBzZXRJc1N1Ym1pdHRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbaXNTdWJtaXR0ZWQsIHNldElzU3VibWl0dGVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2Vycm9yTXNnLCBzZXRFcnJvck1zZ10gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFthY3RpdmVCcmFuY2gsIHNldEFjdGl2ZUJyYW5jaF0gPSB1c2VTdGF0ZSgwKTtcblxuICBjb25zdCBicmFuY2hlcyA9IFtcbiAgICB7XG4gICAgICBuYW1lOiBsYW5ndWFnZSA9PT0gJ2hpJyA/ICfgpLjgpYjgpKgg4KSr4KWN4KSw4KS+4KSC4KS44KS/4KS44KWN4KSV4KWLIOCkruClgeCkluCljeCkr+CkvuCksuCkrycgOiAnU2FuIEZyYW5jaXNjbyBIZWFkcXVhcnRlcnMnLFxuICAgICAgYWRkcmVzczogJzEwMCBQaW5lIFN0LCBTYW4gRnJhbmNpc2NvLCBDQSA5NDExMScsXG4gICAgICBwaG9uZTogJysxICg4MDApIDU1NS0wMTk5JyxcbiAgICAgIGhvdXJzOiAnTW9uLUZyaTogOTowMCBBTSAtIDU6MDAgUE0nLFxuICAgICAgbWFwVXJsOiAnaHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS9tYXBzL2VtYmVkP3BiPSExbTE4ITFtMTIhMW0zITFkMzE1Mi45NzM0MTk5OTIzODkhMmQtMTIyLjQwMjQzNDUyNDIyMDI2ITNkMzcuNzkwNjk1MDcxOTgxMjk1ITJtMyExZjAhMmYwITNmMCEzbTIhMWkxMDI0ITJpNzY4ITRmMTMuMSEzbTMhMW0yITFzMHg4MDg1ODA4YjhiMGU4YzA3JTNBMHhlMmNhZTJkNTNiZmVmZWI0ITJzMTAwJTIwUGluZSUyMFN0JTJDJTIwU2FuJTIwRnJhbmNpc2NvJTJDJTIwQ0ElMjA5NDExMSE1ZTAhM20yITFzZW4hMnN1cyE0djE3MTYyMjAwMDAwMDAhNW0yITFzZW4hMnN1cydcbiAgICB9LFxuICAgIHtcbiAgICAgIG5hbWU6IGxhbmd1YWdlID09PSAnaGknID8gJ+CkqOCljeCkr+ClguCkr+ClieCksOCljeCklSDgpLXgpL/gpKTgpY3gpKTgpYDgpK8g4KSV4KWH4KSC4KSm4KWN4KSwJyA6ICdOZXcgWW9yayBGaW5hbmNpYWwgSHViJyxcbiAgICAgIGFkZHJlc3M6ICcxMjAgQnJvYWR3YXksIE5ldyBZb3JrLCBOWSAxMDI3MScsXG4gICAgICBwaG9uZTogJysxICgyMTIpIDU1NS0wMjQ1JyxcbiAgICAgIGhvdXJzOiAnTW9uLUZyaTogODozMCBBTSAtIDY6MDAgUE0nLFxuICAgICAgbWFwVXJsOiAnaHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS9tYXBzL2VtYmVkP3BiPSExbTE4ITFtMTIhMW0zITFkMzAyNC4zNjQ0NDAwOTM4MTY2ITJkLTc0LjAxMjU2MDMyNDAyNzczITNkNDAuNzA3OTIzNzc5MzMxODEhMm0zITFmMCEyZjAhM2YwITNtMiExaTEwMjQhMmk3NjghNGYxMy4xITNtMyExbTIhMXMweDg5YzI1YTE3Mjc3NWYwYTMlM0EweDY3M2NjY2Q1OWMwYmU3Y2QhMnMxMjAlMjBCcm9hZHdheSUyQyUyME5ldyUyMFlvcmslMkMlMjBOWSUyMDEwMjcxITVlMCEzbTIhMXNlbiEyc3VzITR2MTcxNjIyMDEwMDAwMCE1bTIhMXNlbiEyc3VzJ1xuICAgIH0sXG4gICAge1xuICAgICAgbmFtZTogbGFuZ3VhZ2UgPT09ICdoaScgPyAn4KSy4KSC4KSm4KSoIOCkl+CljeCksuCli+CkrOCksiDgpJHgpKvgpL/gpLgnIDogJ0xvbmRvbiBHbG9iYWwgT2ZmaWNlJyxcbiAgICAgIGFkZHJlc3M6ICczMCBTdCBNYXJ5IEF4ZSwgTG9uZG9uIEVDM0EgOEJGLCBVSycsXG4gICAgICBwaG9uZTogJys0NCAyMCA3NTU1IDAxODgnLFxuICAgICAgaG91cnM6ICdNb24tRnJpOiA5OjAwIEFNIC0gNTozMCBQTScsXG4gICAgICBtYXBVcmw6ICdodHRwczovL3d3dy5nb29nbGUuY29tL21hcHMvZW1iZWQ/cGI9ITFtMTghMW0xMiExbTMhMWQyNDgyLjkwNzgxNzAwNjgxNTMhMmQtMC4wODM3MzM3MjMzODA0ODI1OSEzZDUxLjUxNDQ5NDQ3MTgxNjA4ITJtMyExZjAhMmYwITNmMCEzbTIhMWkxMDI0ITJpNzY4ITRmMTMuMSEzbTMhMW0yITFzMHg0ODc2MDM0YzU0NDY2YjA3JTNBMHg3ZDZmNTRjOWMxYjgyN2U4ITJzMzAlMjBTdCUyME1hcnklMjBBeGUhNWUwITNtMiExc2VuITJzdXMhNHYxNzE2MjIwMjAwMDAwITVtMiExc2VuITJzdXMnXG4gICAgfVxuICBdO1xuXG4gIGNvbnN0IGhhbmRsZUNoYW5nZSA9IChlKSA9PiB7XG4gICAgc2V0Rm9ybURhdGEoe1xuICAgICAgLi4uZm9ybURhdGEsXG4gICAgICBbZS50YXJnZXQubmFtZV06IGUudGFyZ2V0LnZhbHVlXG4gICAgfSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gKGUpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgc2V0RXJyb3JNc2coJycpO1xuXG4gICAgLy8gQmFzaWMgVmFsaWRhdGlvblxuICAgIGlmICghZm9ybURhdGEubmFtZS50cmltKCkpIHtcbiAgICAgIHNldEVycm9yTXNnKHQudmFsX25hbWVfcmVxKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKCFmb3JtRGF0YS5lbWFpbC50cmltKCkgfHwgIWZvcm1EYXRhLmVtYWlsLmluY2x1ZGVzKCdAJykpIHtcbiAgICAgIHNldEVycm9yTXNnKHQudmFsX2VtYWlsX3JlcSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmICghZm9ybURhdGEuc3ViamVjdC50cmltKCkpIHtcbiAgICAgIHNldEVycm9yTXNnKHQudmFsX3N1YmpfcmVxKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKCFmb3JtRGF0YS5tZXNzYWdlLnRyaW0oKSB8fCBmb3JtRGF0YS5tZXNzYWdlLmxlbmd0aCA8IDEwKSB7XG4gICAgICBzZXRFcnJvck1zZyh0LnZhbF9tc2dfcmVxKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBzZXRJc1N1Ym1pdHRpbmcodHJ1ZSk7XG5cbiAgICAvLyBNb2NrIEFQSSByZXF1ZXN0IGRlbGF5XG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICBzZXRJc1N1Ym1pdHRpbmcoZmFsc2UpO1xuICAgICAgc2V0SXNTdWJtaXR0ZWQodHJ1ZSk7XG4gICAgfSwgMTIwMCk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImxhbmRpbmctYm9keSBhbmltYXRlLWZhZGVcIj5cbiAgICAgIHsvKiBCYWNrZ3JvdW5kIGdsb3dpbmcgZGVjb3JhdGlvbnMgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImxhbmRpbmctYmctZGVjb3IgZGVjb3ItcHVycGxlXCI+PC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImxhbmRpbmctYmctZGVjb3IgZGVjb3ItY3lhblwiPjwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJsYW5kaW5nLWJnLWRlY29yIGRlY29yLWFtYmVyXCI+PC9kaXY+XG5cbiAgICAgIHsvKiBIZWFkZXIgKi99XG4gICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImxhbmRpbmctaGVhZGVyXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGFuZGluZy1uYXYtY29udGFpbmVyXCI+XG4gICAgICAgICAgPExpbmsgdG89XCIvXCIgY2xhc3NOYW1lPVwibGFuZGluZy1sb2dvXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxvZ28taWNvbi1ib3hcIj5cbiAgICAgICAgICAgICAgPFphcCBzaXplPXsyMn0gZmlsbD1cIndoaXRlXCIgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPHNwYW4+QmFua0Rhc2g8L3NwYW4+XG4gICAgICAgICAgPC9MaW5rPlxuXG4gICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImxhbmRpbmctbmF2LWxpbmtzXCI+XG4gICAgICAgICAgICA8bGk+PExpbmsgdG89XCIvXCI+e2xhbmd1YWdlID09PSAnaGknID8gJ+CkueCli+CkricgOiAnSG9tZSd9PC9MaW5rPjwvbGk+XG4gICAgICAgICAgICA8bGk+PExpbmsgdG89XCIvI2ZlYXR1cmVzXCI+e3QuZmVhdHVyZXN9PC9MaW5rPjwvbGk+XG4gICAgICAgICAgICA8bGk+PExpbmsgdG89XCIvI2NhbGN1bGF0b3JcIj57dC5jYWxjdWxhdG9yfTwvTGluaz48L2xpPlxuICAgICAgICAgICAgPGxpPjxMaW5rIHRvPVwiL2NvbnRhY3RcIj57dC5zdXBwb3J0fTwvTGluaz48L2xpPlxuICAgICAgICAgIDwvdWw+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxhbmRpbmctbmF2LWFjdGlvbnNcIj5cbiAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgdmFsdWU9e2xhbmd1YWdlfVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldExhbmd1YWdlKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibGFuZy1zZWxlY3RcIlxuICAgICAgICAgICAgICBzdHlsZT17eyBtYXJnaW5SaWdodDogJzAuNXJlbScgfX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImVuXCI+RW5nbGlzaCDwn4es8J+Hpzwvb3B0aW9uPlxuICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiaGlcIj7gpLngpL/gpILgpKbgpYAg8J+HrvCfh7M8L29wdGlvbj5cbiAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAge2lzTG9nZ2VkSW4gPyAoXG4gICAgICAgICAgICAgIDxMaW5rIHRvPVwiL2Rhc2hib2FyZFwiIGNsYXNzTmFtZT1cImJ0bi1uYXYtc2lnbnVwXCI+e3QuZGFzaGJvYXJkfTwvTGluaz5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgPExpbmsgdG89XCIvbG9naW5cIiBjbGFzc05hbWU9XCJidG4tbmF2LWxvZ2luXCI+e3QubG9naW59PC9MaW5rPlxuICAgICAgICAgICAgICAgIDxMaW5rIHRvPVwiL3JlZ2lzdGVyXCIgY2xhc3NOYW1lPVwiYnRuLW5hdi1zaWdudXBcIj57dC5zaWdudXB9PC9MaW5rPlxuICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9oZWFkZXI+XG5cbiAgICAgIHsvKiBNYWluIENvbnRhaW5lciAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFjdC1jb250YWluZXIgYW5pbWF0ZS1zbGlkZVwiPlxuICAgICAgICA8TGluayB0bz1cIi9cIiBjbGFzc05hbWU9XCJiYWNrLWhvbWUtbGlua1wiPlxuICAgICAgICAgIDxBcnJvd0xlZnQgc2l6ZT17MTZ9IC8+IHt0LmJhY2tfdG9faG9tZX1cbiAgICAgICAgPC9MaW5rPlxuXG4gICAgICAgIHshaXNTdWJtaXR0ZWQgPyAoXG4gICAgICAgICAgPD5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFjdC1oZWFkZXJcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic2VjdGlvbi10YWdcIj57bGFuZ3VhZ2UgPT09ICdoaScgPyAn4KS44KSC4KSq4KSw4KWN4KSVIOCkleCksOClh+CkgicgOiAnR0VUIElOIFRPVUNIJ308L3NwYW4+XG4gICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJzZWN0aW9uLXRpdGxlXCIgc3R5bGU9e3sgZm9udFNpemU6ICczcmVtJyB9fT57dC5jb250YWN0X3RpdGxlfTwvaDE+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInNlY3Rpb24tZGVzY1wiIHN0eWxlPXt7IG1heFdpZHRoOiAnNTgwcHgnLCBtYXJnaW46ICcwIGF1dG8nIH19PlxuICAgICAgICAgICAgICAgIHt0LmNvbnRhY3Rfc3VidGl0bGV9XG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhY3QtZ3JpZFwiPlxuICAgICAgICAgICAgICB7LyogTGVmdCBDb2x1bW46IENvbnRhY3QgZGV0YWlscyAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWN0LWluZm8tcGFuZWxcIj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImNvbnRhY3QtaW5mby10aXRsZVwiPnt0LmNvbnRhY3RfaW5mb190aXRsZX08L2gzPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiY29udGFjdC1pbmZvLWRlc2NcIj5cbiAgICAgICAgICAgICAgICAgICAge3QuY29udGFjdF9pbmZvX2Rlc2N9XG4gICAgICAgICAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFjdC1kZXRhaWxzLWxpc3RcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWN0LWRldGFpbC1pdGVtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWN0LWljb24tYm94XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8TWFpbCBzaXplPXsyMH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhY3QtZGV0YWlsLWNvbnRlbnRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxoNT57dC5lbWFpbF91c308L2g1PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHA+c3VwcG9ydEBiYW5rZGFzaC5jb208L3A+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFjdC1kZXRhaWwtaXRlbVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFjdC1pY29uLWJveFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPFBob25lIHNpemU9ezIwfSAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFjdC1kZXRhaWwtY29udGVudFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGg1Pnt0LmNhbGxfc3VwcG9ydH08L2g1PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHA+KzEgKDgwMCkgNTU1LTAxOTk8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFjdC1kZXRhaWwtaXRlbVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFjdC1pY29uLWJveFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPE1hcFBpbiBzaXplPXsyMH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhY3QtZGV0YWlsLWNvbnRlbnRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxoNT57dC5oZWFkcXVhcnRlcnN9PC9oNT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxwPjEwMCBQaW5lIFN0LCBTYW4gRnJhbmNpc2NvLCBDQTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFjdC1zb2NpYWxzXCI+XG4gICAgICAgICAgICAgICAgICA8YSBocmVmPVwiaHR0cHM6Ly90d2l0dGVyLmNvbVwiIHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIiBjbGFzc05hbWU9XCJjb250YWN0LXNvY2lhbC1idG5cIiBhcmlhLWxhYmVsPVwiVHdpdHRlclwiPlxuICAgICAgICAgICAgICAgICAgICA8c3ZnIHdpZHRoPVwiMThcIiBoZWlnaHQ9XCIxOFwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZVdpZHRoPVwiMlwiIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIj48cGF0aCBkPVwiTTIyIDRzLS43IDIuMS0yIDMuNGMxLjYgMTAtOS40IDE3LjMtMTggMTEuNiAyLjIuMSA0LjQtLjYgNi0yQzMgMTUuNS41IDkuNiAzIDVjMi4yIDIuNiA1LjYgNC4xIDkgNC0uOS00LjIgNC02LjYgNy0zLjggMS4xIDAgMy0xLjIgMy0xLjJ6XCIvPjwvc3ZnPlxuICAgICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cImh0dHBzOi8vZ2l0aHViLmNvbVwiIHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIiBjbGFzc05hbWU9XCJjb250YWN0LXNvY2lhbC1idG5cIiBhcmlhLWxhYmVsPVwiR2l0aHViXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzdmcgd2lkdGg9XCIxOFwiIGhlaWdodD1cIjE4XCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlV2lkdGg9XCIyXCIgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiPjxwYXRoIGQ9XCJNMTUgMjJ2LTRhNC44IDQuOCAwIDAgMC0xLTMuNWMzIDAgNi0yIDYtNS41LjA4LTEuMjUtLjI3LTIuNDgtMS0zLjUuMjgtMS4xNS4yOC0yLjM1IDAtMy41IDAgMC0xIDAtMyAxLjUtMi42NC0uNS01LjM2LS41LTggMEM2IDIgNSAyIDUgMmMtLjMgMS4xNS0uMyAyLjM1IDAgMy41QTUuNDAzIDUuNDAzIDAgMCAwIDQgOWMwIDMuNSAzIDUuNSA2IDUuNS0uMzkuNDktLjY4IDEuMDUtLjg1IDEuNjUtLjE3LjYtLjIyIDEuMjMtLjE1IDEuODV2NFwiLz48L3N2Zz5cbiAgICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgICAgIDxhIGhyZWY9XCJodHRwczovL2xpbmtlZGluLmNvbVwiIHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIiBjbGFzc05hbWU9XCJjb250YWN0LXNvY2lhbC1idG5cIiBhcmlhLWxhYmVsPVwiTGlua2VkSW5cIj5cbiAgICAgICAgICAgICAgICAgICAgPHN2ZyB3aWR0aD1cIjE4XCIgaGVpZ2h0PVwiMThcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiBzdHJva2VXaWR0aD1cIjJcIiBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCI+PHBhdGggZD1cIk0xNiA4YTYgNiAwIDAgMSA2IDZ2N2gtNHYtN2EyIDIgMCAwIDAtMi0yIDIgMiAwIDAgMC0yIDJ2N2gtNHYtN2E2IDYgMCAwIDEgNi02elwiLz48cmVjdCB4PVwiMlwiIHk9XCI5XCIgd2lkdGg9XCI0XCIgaGVpZ2h0PVwiMTJcIi8+PGNpcmNsZSBjeD1cIjRcIiBjeT1cIjRcIiByPVwiMlwiLz48L3N2Zz5cbiAgICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIFJpZ2h0IENvbHVtbjogQ29udGFjdCBmb3JtICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhY3QtZm9ybS1wYW5lbFwiPlxuICAgICAgICAgICAgICAgIHtlcnJvck1zZyAmJiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGNvbG9yOiAnI2VmNDQ0NCcsIGJhY2tncm91bmRDb2xvcjogJ3JnYmEoMjM5LCA2OCwgNjgsIDAuMSknLCBwYWRkaW5nOiAnMC44NXJlbScsIGJvcmRlclJhZGl1czogJzEycHgnLCBib3JkZXI6ICcxcHggc29saWQgcmdiYSgyMzksIDY4LCA2OCwgMC4yKScsIG1hcmdpbkJvdHRvbTogJzEuNXJlbScsIGZvbnRTaXplOiAnMC45cmVtJywgZm9udFdlaWdodDogNTAwIH19PlxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JNc2d9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwiY29udGFjdC1mb3JtXCIgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tcm93LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWN0LWZvcm0tZ3JvdXBcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cIm5hbWVcIj57dC5sYWJlbF9uYW1lfTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWN0LWlucHV0LXdyYXBwZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIiBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJuYW1lXCIgXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJuYW1lXCIgXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNvbnRhY3QtZm9ybS1pbnB1dFwiIFxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17dC5wbGFjZWhvbGRlcl9uYW1lfVxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEubmFtZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8VXNlciBjbGFzc05hbWU9XCJjb250YWN0LWlucHV0LWljb25cIiBzaXplPXsxOH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWN0LWZvcm0tZ3JvdXBcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cImVtYWlsXCI+e3QubGFiZWxfZW1haWx9PC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhY3QtaW5wdXQtd3JhcHBlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIiBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJlbWFpbFwiIFxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZW1haWxcIiBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY29udGFjdC1mb3JtLWlucHV0XCIgXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXt0LnBsYWNlaG9sZGVyX2VtYWlsfVxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZW1haWx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPE1haWwgY2xhc3NOYW1lPVwiY29udGFjdC1pbnB1dC1pY29uXCIgc2l6ZT17MTh9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFjdC1mb3JtLWdyb3VwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwic3ViamVjdFwiPnt0LmxhYmVsX3N1YmplY3R9PC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWN0LWlucHV0LXdyYXBwZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiIFxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJzdWJqZWN0XCIgXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwic3ViamVjdFwiIFxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY29udGFjdC1mb3JtLWlucHV0XCIgXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17dC5wbGFjZWhvbGRlcl9zdWJqZWN0fVxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnN1YmplY3R9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPE1lc3NhZ2VTcXVhcmUgY2xhc3NOYW1lPVwiY29udGFjdC1pbnB1dC1pY29uXCIgc2l6ZT17MTh9IC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFjdC1mb3JtLWdyb3VwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwibWVzc2FnZVwiPnt0LmxhYmVsX21lc3NhZ2V9PC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPHRleHRhcmVhIFxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwibWVzc2FnZVwiIFxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJtZXNzYWdlXCIgXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY29udGFjdC1mb3JtLXRleHRhcmVhXCIgXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e3QucGxhY2Vob2xkZXJfbWVzc2FnZX1cbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEubWVzc2FnZX1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIiBcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLWNvbnRhY3Qtc3VibWl0XCIgXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc1N1Ym1pdHRpbmd9XG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPXtpc1N1Ym1pdHRpbmcgPyB7IG9wYWNpdHk6IDAuOCwgY3Vyc29yOiAnbm90LWFsbG93ZWQnIH0gOiB7fX1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge2lzU3VibWl0dGluZyA/IHQuYnRuX3NlbmRpbmcgOiB0LmJ0bl9zdWJtaXR9XG4gICAgICAgICAgICAgICAgICAgIDxTZW5kIHNpemU9ezE4fSAvPlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogQnJhbmNoIExvY2F0aW9ucyAmIE1hcCBTZWN0aW9uICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWN0LW1hcC1zZWN0aW9uXCIgc3R5bGU9e3sgbWFyZ2luVG9wOiAnNHJlbScgfX0+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VjdGlvbi1oZWFkXCIgc3R5bGU9e3sgdGV4dEFsaWduOiAnY2VudGVyJywgbWFyZ2luQm90dG9tOiAnMi41cmVtJyB9fT5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzZWN0aW9uLXRhZ1wiPnt0LmJyYW5jaF9sb2NhdG9yX3RhZ308L3NwYW4+XG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInNlY3Rpb24tdGl0bGVcIiBzdHlsZT17eyBmb250U2l6ZTogJzJyZW0nLCBtYXJnaW5Ub3A6ICcwLjVyZW0nIH19Pnt0LmJyYW5jaF9sb2NhdG9yX3RpdGxlfTwvaDI+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwic2VjdGlvbi1kZXNjXCIgc3R5bGU9e3sgbWF4V2lkdGg6ICc2MDBweCcsIG1hcmdpbjogJzAuNXJlbSBhdXRvIDAgYXV0bycsIGZvbnRTaXplOiAnMC45NXJlbScgfX0+XG4gICAgICAgICAgICAgICAgICB7dC5icmFuY2hfbG9jYXRvcl9kZXNjfVxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXAtbGF5b3V0LWdyaWRcIj5cbiAgICAgICAgICAgICAgICB7LyogQnJhbmNoIGRldGFpbHMgbGlzdCAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJyYW5jaC1saXN0LXBhbmVsXCI+XG4gICAgICAgICAgICAgICAgICB7YnJhbmNoZXMubWFwKChicmFuY2gsIGlkeCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IFxuICAgICAgICAgICAgICAgICAgICAgIGtleT17aWR4fSBcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BicmFuY2gtY2FyZC1pdGVtICR7YWN0aXZlQnJhbmNoID09PSBpZHggPyAnYWN0aXZlJyA6ICcnfWB9XG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlQnJhbmNoKGlkeCl9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJyYW5jaC1jYXJkLWhlYWRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJicmFuY2gtcGluLWluZGljYXRvclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8TWFwUGluIHNpemU9ezE4fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiYnJhbmNoLW5hbWUtdGV4dFwiPnticmFuY2gubmFtZX08L2g0PlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYnJhbmNoLWRldGFpbHMtYm9keVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiYnJhbmNoLWRldGFpbC1saW5lXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+e2xhbmd1YWdlID09PSAnaGknID8gJ+CkquCkpOCkvjonIDogJ0FkZHJlc3M6J308L3N0cm9uZz4ge2JyYW5jaC5hZGRyZXNzfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiYnJhbmNoLWRldGFpbC1saW5lXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+e3QuYnJhbmNoX3Bob25lfTo8L3N0cm9uZz4ge2JyYW5jaC5waG9uZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYnJhbmNoLWRldGFpbC1saW5lXCIgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgZ2FwOiAnMC4zNXJlbScsIG1hcmdpblRvcDogJzAuMzVyZW0nIH19PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2xvY2sgc2l6ZT17MTN9IHN0eWxlPXt7IGNvbG9yOiAndmFyKC0tbGQtdGV4dC1tdXRlZCknLCBmbGV4U2hyaW5rOiAwIH19IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiAnMC44NXJlbScgfX0+e2JyYW5jaC5ob3Vyc308L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYnJhbmNoLWNhcmQtYWN0aW9uXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJicmFuY2gtYWN0aW9uLXRleHRcIj57dC5icmFuY2hfdmlld19tYXB9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPENoZXZyb25SaWdodCBzaXplPXsxNH0gY2xhc3NOYW1lPVwiYnJhbmNoLWFjdGlvbi1jaGV2cm9uXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBNYXAgaWZyYW1lICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYnJhbmNoLW1hcC1pZnJhbWUtY29udGFpbmVyXCI+XG4gICAgICAgICAgICAgICAgICA8aWZyYW1lIFxuICAgICAgICAgICAgICAgICAgICB0aXRsZT17YnJhbmNoZXNbYWN0aXZlQnJhbmNoXS5uYW1lfVxuICAgICAgICAgICAgICAgICAgICBzcmM9e2JyYW5jaGVzW2FjdGl2ZUJyYW5jaF0ubWFwVXJsfVxuICAgICAgICAgICAgICAgICAgICB3aWR0aD1cIjEwMCVcIlxuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ9XCIxMDAlXCJcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgYm9yZGVyOiAwIH19XG4gICAgICAgICAgICAgICAgICAgIGFsbG93RnVsbFNjcmVlbj1cIlwiXG4gICAgICAgICAgICAgICAgICAgIGxvYWRpbmc9XCJsYXp5XCJcbiAgICAgICAgICAgICAgICAgICAgcmVmZXJyZXJQb2xpY3k9XCJuby1yZWZlcnJlci13aGVuLWRvd25ncmFkZVwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNvbnRhY3QtbWFwLWlmcmFtZVwiXG4gICAgICAgICAgICAgICAgICA+PC9pZnJhbWU+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC8+XG4gICAgICAgICkgOiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWN0LWdyaWRcIiBzdHlsZT17eyBncmlkVGVtcGxhdGVDb2x1bW5zOiAnMWZyJyB9fT5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFjdC1zdWNjZXNzLWNhcmRcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdWNjZXNzLWljb24tYm94XCI+XG4gICAgICAgICAgICAgICAgPENoZWNrIHNpemU9ezQwfSAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInNlY3Rpb24tdGl0bGVcIiBzdHlsZT17eyBmb250U2l6ZTogJzIuMjVyZW0nLCBtYXJnaW5Cb3R0b206ICcxcmVtJyB9fT57dC5zdWNjZXNzX3RpdGxlfTwvaDI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInNlY3Rpb24tZGVzY1wiIHN0eWxlPXt7IG1heFdpZHRoOiAnNDgwcHgnLCBtYXJnaW5Cb3R0b206ICcyLjVyZW0nIH19PlxuICAgICAgICAgICAgICAgIHt0LmFsZXJ0X3N1Y2Nlc3N9IHtsYW5ndWFnZSA9PT0gJ2hpJyA/ICfgpLngpK4g4KSG4KSq4KS44KWHIOCkuOCkguCkquCksOCljeCklSDgpJXgpLDgpYfgpILgpJfgpYcnIDogJ1dlIHdpbGwgcmVhY2ggb3V0IHRvIHlvdSBhdCd9IDxzdHJvbmc+e2Zvcm1EYXRhLmVtYWlsfTwvc3Ryb25nPi5cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8TGluayB0bz1cIi9cIiBjbGFzc05hbWU9XCJidG4tcHJpbWFyeVwiPlxuICAgICAgICAgICAgICAgIHt0LnJldHVybl9ob21lfVxuICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogRm9vdGVyICovfVxuICAgICAgPGZvb3RlciBjbGFzc05hbWU9XCJsYW5kaW5nLWZvb3RlclwiIHN0eWxlPXt7IG1hcmdpblRvcDogJzVyZW0nIH19PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvb3Rlci1ncmlkXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb290ZXItYnJhbmRcIj5cbiAgICAgICAgICAgIDxMaW5rIHRvPVwiL1wiIGNsYXNzTmFtZT1cImxhbmRpbmctbG9nb1wiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxvZ28taWNvbi1ib3hcIj5cbiAgICAgICAgICAgICAgICA8WmFwIHNpemU9ezIyfSBmaWxsPVwid2hpdGVcIiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPHNwYW4+QmFua0Rhc2g8L3NwYW4+XG4gICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb290ZXItZGVzY1wiPlxuICAgICAgICAgICAgICB7dC5mb290ZXJfZGVzY31cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9vdGVyLWNvbFwiPlxuICAgICAgICAgICAgPGg1Pnt0LmNvbF9wcm9kdWN0fTwvaDU+XG4gICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwiZm9vdGVyLWxpbmtzXCI+XG4gICAgICAgICAgICAgIDxsaT48TGluayB0bz1cIi8jZmVhdHVyZXNcIj57dC5mZWF0dXJlc308L0xpbms+PC9saT5cbiAgICAgICAgICAgICAgPGxpPjxMaW5rIHRvPVwiLyNjYWxjdWxhdG9yXCI+e3QuY2FsY3VsYXRvcn08L0xpbms+PC9saT5cbiAgICAgICAgICAgICAgPGxpPjxMaW5rIHRvPVwiL2xvZ2luXCI+e3QuZGFzaGJvYXJkfSBQcmV2aWV3PC9MaW5rPjwvbGk+XG4gICAgICAgICAgICA8L3VsPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb290ZXItY29sXCI+XG4gICAgICAgICAgICA8aDU+e3QuY29sX3NlY3VyaXR5fTwvaDU+XG4gICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwiZm9vdGVyLWxpbmtzXCI+XG4gICAgICAgICAgICAgIDxsaT48YSBocmVmPVwiI1wiPkVuY3J5cHRpb24gU3RhbmRhcmRzPC9hPjwvbGk+XG4gICAgICAgICAgICAgIDxsaT48YSBocmVmPVwiI1wiPkFjY2VzcyBNYW5hZ2VtZW50PC9hPjwvbGk+XG4gICAgICAgICAgICAgIDxsaT48YSBocmVmPVwiI1wiPlByaXZhY3kgUG9saWN5PC9hPjwvbGk+XG4gICAgICAgICAgICA8L3VsPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb290ZXItY29sXCI+XG4gICAgICAgICAgICA8aDU+e3QuY29sX2NvbXBhbnl9PC9oNT5cbiAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJmb290ZXItbGlua3NcIj5cbiAgICAgICAgICAgICAgPGxpPjxhIGhyZWY9XCIjXCI+QWJvdXQgVXM8L2E+PC9saT5cbiAgICAgICAgICAgICAgPGxpPjxhIGhyZWY9XCIjXCI+Q2FyZWVyczwvYT48L2xpPlxuICAgICAgICAgICAgICA8bGk+PExpbmsgdG89XCIvY29udGFjdFwiPnt0LnN1cHBvcnR9PC9MaW5rPjwvbGk+XG4gICAgICAgICAgICA8L3VsPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvb3Rlci1ib3R0b21cIj5cbiAgICAgICAgICA8ZGl2PsKpIHtuZXcgRGF0ZSgpLmdldEZ1bGxZZWFyKCl9IEJhbmtEYXNoLiBBbGwgcmlnaHRzIHJlc2VydmVkLjwvZGl2PlxuICAgICAgICAgIFxuICAgICAgICAgIHt2aXNpdENvdW50ID4gMCAmJiAoXG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGdhcDogJzAuNXJlbScsIGJhY2tncm91bmQ6ICdyZ2JhKDAsMCwwLDAuMDMpJywgcGFkZGluZzogJzAuNHJlbSAwLjhyZW0nLCBib3JkZXJSYWRpdXM6ICcyMHB4JywgYm9yZGVyOiAnMXB4IHNvbGlkIHZhcigtLWxkLWJvcmRlciknLCBmb250U2l6ZTogJzAuODVyZW0nIH19PlxuICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyB3aWR0aDogJzhweCcsIGhlaWdodDogJzhweCcsIGJvcmRlclJhZGl1czogJzUwJScsIGJhY2tncm91bmRDb2xvcjogJyMxMGI5ODEnLCBib3hTaGFkb3c6ICcwIDAgOHB4ICMxMGI5ODEnLCBkaXNwbGF5OiAnaW5saW5lLWJsb2NrJyB9fT48L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiAndmFyKC0tbGQtdGV4dC1tdXRlZCknLCBmb250V2VpZ2h0OiA1MDAgfX0+e3QudmlzaXRfY291bnR9IDxzdHJvbmcgc3R5bGU9e3sgY29sb3I6ICd2YXIoLS1sZC10ZXh0LW1haW4pJyB9fT57dmlzaXRDb3VudC50b0xvY2FsZVN0cmluZygpfTwvc3Ryb25nPjwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgZ2FwOiAnMS41cmVtJyB9fT5cbiAgICAgICAgICAgIDxhIGhyZWY9XCIjXCIgc3R5bGU9e3sgY29sb3I6ICd2YXIoLS1sZC10ZXh0LW11dGVkKScsIHRleHREZWNvcmF0aW9uOiAnbm9uZScgfX0+e3QudGVybXN9PC9hPlxuICAgICAgICAgICAgPGEgaHJlZj1cIiNcIiBzdHlsZT17eyBjb2xvcjogJ3ZhcigtLWxkLXRleHQtbXV0ZWQpJywgdGV4dERlY29yYXRpb246ICdub25lJyB9fT57dC5wcml2YWN5fTwvYT5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Zvb3Rlcj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IENvbnRhY3Q7XG4iXSwiZmlsZSI6IkQ6L1JlYWN0X3Rlc3RfMTlfMDVfMjAyNi9zcmMvY29tcG9uZW50cy9Db250YWN0LmpzeCJ9