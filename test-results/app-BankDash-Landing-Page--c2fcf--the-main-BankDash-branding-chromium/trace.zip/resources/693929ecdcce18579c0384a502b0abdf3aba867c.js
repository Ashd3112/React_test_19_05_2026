import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Login.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=01f90aba"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/React_test_19_05_2026/src/components/Login.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=01f90aba"; const useState = __vite__cjsImport3_react["useState"];
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=01f90aba";
import { Mail, Lock, LogIn } from "/node_modules/.vite/deps/lucide-react.js?v=01f90aba";
import { useAuth } from "/src/App.jsx";
const Login = () => {
  _s();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();
  const { login } = useAuth();
  const [error, setError] = useState("");
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    try {
      const response = await fetch("http://localhost:5000/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password })
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Login failed");
      }
      console.log("Login successful:", data);
      login(data.user);
      navigate("/dashboard");
    } catch (err) {
      setError(err.message);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "auth-page-wrapper", children: /* @__PURE__ */ jsxDEV("div", { className: "auth-container", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "auth-header", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "auth-icon-container", children: /* @__PURE__ */ jsxDEV(LogIn, { size: 28 }, void 0, false, {
        fileName: "D:/React_test_19_05_2026/src/components/Login.jsx",
        lineNumber: 63,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "D:/React_test_19_05_2026/src/components/Login.jsx",
        lineNumber: 62,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { className: "auth-title", children: "Welcome Back" }, void 0, false, {
        fileName: "D:/React_test_19_05_2026/src/components/Login.jsx",
        lineNumber: 65,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "auth-subtitle", children: "Sign in to continue to your account" }, void 0, false, {
        fileName: "D:/React_test_19_05_2026/src/components/Login.jsx",
        lineNumber: 66,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/React_test_19_05_2026/src/components/Login.jsx",
      lineNumber: 61,
      columnNumber: 9
    }, this),
    error && /* @__PURE__ */ jsxDEV("div", { style: { color: "#ef4444", backgroundColor: "rgba(239, 68, 68, 0.1)", padding: "0.75rem", borderRadius: "8px", marginBottom: "1rem", fontSize: "0.9rem", border: "1px solid rgba(239, 68, 68, 0.3)" }, children: error }, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/components/Login.jsx",
      lineNumber: 69,
      columnNumber: 19
    }, this),
    /* @__PURE__ */ jsxDEV("form", { className: "auth-form", onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "form-label", htmlFor: "email", children: "Email Address" }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Login.jsx",
          lineNumber: 73,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "input-wrapper", children: [
          /* @__PURE__ */ jsxDEV(Mail, { className: "input-icon", size: 20 }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Login.jsx",
            lineNumber: 75,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "email",
              id: "email",
              className: "form-input",
              placeholder: "name@example.com",
              value: email,
              onChange: (e) => setEmail(e.target.value),
              required: true
            },
            void 0,
            false,
            {
              fileName: "D:/React_test_19_05_2026/src/components/Login.jsx",
              lineNumber: 76,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Login.jsx",
          lineNumber: 74,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Login.jsx",
        lineNumber: 72,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "form-label", htmlFor: "password", children: "Password" }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/Login.jsx",
          lineNumber: 89,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "input-wrapper", children: [
          /* @__PURE__ */ jsxDEV(Lock, { className: "input-icon", size: 20 }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/Login.jsx",
            lineNumber: 91,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "password",
              id: "password",
              className: "form-input",
              placeholder: "••••••••",
              value: password,
              onChange: (e) => setPassword(e.target.value),
              required: true
            },
            void 0,
            false,
            {
              fileName: "D:/React_test_19_05_2026/src/components/Login.jsx",
              lineNumber: 92,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/Login.jsx",
          lineNumber: 90,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/Login.jsx",
        lineNumber: 88,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "submit-btn", children: "Sign In" }, void 0, false, {
        fileName: "D:/React_test_19_05_2026/src/components/Login.jsx",
        lineNumber: 104,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/React_test_19_05_2026/src/components/Login.jsx",
      lineNumber: 71,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "auth-footer", children: [
      "Don't have an account?",
      /* @__PURE__ */ jsxDEV(Link, { to: "/register", className: "auth-link", children: "Create one" }, void 0, false, {
        fileName: "D:/React_test_19_05_2026/src/components/Login.jsx",
        lineNumber: 111,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/React_test_19_05_2026/src/components/Login.jsx",
      lineNumber: 109,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "D:/React_test_19_05_2026/src/components/Login.jsx",
    lineNumber: 60,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "D:/React_test_19_05_2026/src/components/Login.jsx",
    lineNumber: 59,
    columnNumber: 5
  }, this);
};
_s(Login, "gBOOiQDUlh4MZzzRJdvR5kAeUEk=", false, function() {
  return [useNavigate, useAuth];
});
_c = Login;
export default Login;
var _c;
$RefreshReg$(_c, "Login");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/React_test_19_05_2026/src/components/Login.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/React_test_19_05_2026/src/components/Login.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkNZOzs7Ozs7Ozs7Ozs7Ozs7OztBQTNDWixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsTUFBTUMsbUJBQW1CO0FBQ2xDLFNBQVNDLE1BQU1DLE1BQU1DLGFBQWE7QUFDbEMsU0FBU0MsZUFBZTtBQUV4QixNQUFNQyxRQUFRQSxNQUFNO0FBQUFDLEtBQUE7QUFDbEIsUUFBTSxDQUFDQyxPQUFPQyxRQUFRLElBQUlWLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNXLFVBQVVDLFdBQVcsSUFBSVosU0FBUyxFQUFFO0FBQzNDLFFBQU1hLFdBQVdYLFlBQVk7QUFDN0IsUUFBTSxFQUFFWSxNQUFNLElBQUlSLFFBQVE7QUFFMUIsUUFBTSxDQUFDUyxPQUFPQyxRQUFRLElBQUloQixTQUFTLEVBQUU7QUFFckMsUUFBTWlCLGVBQWUsT0FBT0MsTUFBTTtBQUNoQ0EsTUFBRUMsZUFBZTtBQUNqQkgsYUFBUyxFQUFFO0FBRVgsUUFBSTtBQUNGLFlBQU1JLFdBQVcsTUFBTUMsTUFBTSxtQ0FBbUM7QUFBQSxRQUM5REMsUUFBUTtBQUFBLFFBQ1JDLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQW1CO0FBQUEsUUFDOUNDLE1BQU1DLEtBQUtDLFVBQVUsRUFBRWpCLE9BQU9FLFNBQVMsQ0FBQztBQUFBLE1BQzFDLENBQUM7QUFFRCxZQUFNZ0IsT0FBTyxNQUFNUCxTQUFTUSxLQUFLO0FBRWpDLFVBQUksQ0FBQ1IsU0FBU1MsSUFBSTtBQUNoQixjQUFNLElBQUlDLE1BQU1ILEtBQUtaLFNBQVMsY0FBYztBQUFBLE1BQzlDO0FBRUFnQixjQUFRQyxJQUFJLHFCQUFxQkwsSUFBSTtBQUNyQ2IsWUFBTWEsS0FBS00sSUFBSTtBQUNmcEIsZUFBUyxZQUFZO0FBQUEsSUFDdkIsU0FBU3FCLEtBQUs7QUFDWmxCLGVBQVNrQixJQUFJQyxPQUFPO0FBQUEsSUFDdEI7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUscUJBQ2IsaUNBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsdUJBQ2IsaUNBQUMsU0FBTSxNQUFNLE1BQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnQixLQURsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFFBQUcsV0FBVSxjQUFhLDRCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVDO0FBQUEsTUFDdkMsdUJBQUMsT0FBRSxXQUFVLGlCQUFnQixtREFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnRTtBQUFBLFNBTGxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQTtBQUFBLElBRUNwQixTQUFTLHVCQUFDLFNBQUksT0FBTyxFQUFFcUIsT0FBTyxXQUFXQyxpQkFBaUIsMEJBQTBCQyxTQUFTLFdBQVdDLGNBQWMsT0FBT0MsY0FBYyxRQUFRQyxVQUFVLFVBQVVDLFFBQVEsbUNBQW1DLEdBQUkzQixtQkFBN007QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtTjtBQUFBLElBRTdOLHVCQUFDLFVBQUssV0FBVSxhQUFZLFVBQVVFLGNBQ3BDO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSwrQkFBQyxXQUFNLFdBQVUsY0FBYSxTQUFRLFNBQVEsNkJBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkQ7QUFBQSxRQUMzRCx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxpQ0FBQyxRQUFLLFdBQVUsY0FBYSxNQUFNLE1BQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNDO0FBQUEsVUFDdEM7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLElBQUc7QUFBQSxjQUNILFdBQVU7QUFBQSxjQUNWLGFBQVk7QUFBQSxjQUNaLE9BQU9SO0FBQUFBLGNBQ1AsVUFBVSxDQUFDUyxNQUFNUixTQUFTUSxFQUFFeUIsT0FBT0MsS0FBSztBQUFBLGNBQ3hDLFVBQVE7QUFBQTtBQUFBLFlBUFY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT1U7QUFBQSxhQVRaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFdBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWNBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLCtCQUFDLFdBQU0sV0FBVSxjQUFhLFNBQVEsWUFBVyx3QkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5RDtBQUFBLFFBQ3pELHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLGlDQUFDLFFBQUssV0FBVSxjQUFhLE1BQU0sTUFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0M7QUFBQSxVQUN0QztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsSUFBRztBQUFBLGNBQ0gsV0FBVTtBQUFBLGNBQ1YsYUFBWTtBQUFBLGNBQ1osT0FBT2pDO0FBQUFBLGNBQ1AsVUFBVSxDQUFDTyxNQUFNTixZQUFZTSxFQUFFeUIsT0FBT0MsS0FBSztBQUFBLGNBQzNDLFVBQVE7QUFBQTtBQUFBLFlBUFY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT1U7QUFBQSxhQVRaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFdBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWNBO0FBQUEsTUFFQSx1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLGNBQVksdUJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBbkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvQ0E7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxlQUFhO0FBQUE7QUFBQSxNQUUxQix1QkFBQyxRQUFLLElBQUcsYUFBWSxXQUFVLGFBQVksMEJBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUQ7QUFBQSxTQUZ2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxPQXBERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBcURBLEtBdERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1REE7QUFFSjtBQUFFcEMsR0EzRklELE9BQUs7QUFBQSxVQUdRTCxhQUNDSSxPQUFPO0FBQUE7QUFBQSxLQUpyQkM7QUE2Rk4sZUFBZUE7QUFBTSxJQUFBc0M7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJMaW5rIiwidXNlTmF2aWdhdGUiLCJNYWlsIiwiTG9jayIsIkxvZ0luIiwidXNlQXV0aCIsIkxvZ2luIiwiX3MiLCJlbWFpbCIsInNldEVtYWlsIiwicGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsIm5hdmlnYXRlIiwibG9naW4iLCJlcnJvciIsInNldEVycm9yIiwiaGFuZGxlU3VibWl0IiwiZSIsInByZXZlbnREZWZhdWx0IiwicmVzcG9uc2UiLCJmZXRjaCIsIm1ldGhvZCIsImhlYWRlcnMiLCJib2R5IiwiSlNPTiIsInN0cmluZ2lmeSIsImRhdGEiLCJqc29uIiwib2siLCJFcnJvciIsImNvbnNvbGUiLCJsb2ciLCJ1c2VyIiwiZXJyIiwibWVzc2FnZSIsImNvbG9yIiwiYmFja2dyb3VuZENvbG9yIiwicGFkZGluZyIsImJvcmRlclJhZGl1cyIsIm1hcmdpbkJvdHRvbSIsImZvbnRTaXplIiwiYm9yZGVyIiwidGFyZ2V0IiwidmFsdWUiLCJfYyJdLCJzb3VyY2VzIjpbIkxvZ2luLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IExpbmssIHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyBNYWlsLCBMb2NrLCBMb2dJbiB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vQXBwJztcblxuY29uc3QgTG9naW4gPSAoKSA9PiB7XG4gIGNvbnN0IFtlbWFpbCwgc2V0RW1haWxdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuICBjb25zdCB7IGxvZ2luIH0gPSB1c2VBdXRoKCk7XG5cbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZSgnJyk7XG5cbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgc2V0RXJyb3IoJycpO1xuICAgIFxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKCdodHRwOi8vbG9jYWxob3N0OjUwMDAvYXBpL2xvZ2luJywge1xuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgZW1haWwsIHBhc3N3b3JkIH0pXG4gICAgICB9KTtcblxuICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcblxuICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoZGF0YS5lcnJvciB8fCAnTG9naW4gZmFpbGVkJyk7XG4gICAgICB9XG5cbiAgICAgIGNvbnNvbGUubG9nKCdMb2dpbiBzdWNjZXNzZnVsOicsIGRhdGEpO1xuICAgICAgbG9naW4oZGF0YS51c2VyKTtcbiAgICAgIG5hdmlnYXRlKCcvZGFzaGJvYXJkJyk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBzZXRFcnJvcihlcnIubWVzc2FnZSk7XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLXBhZ2Utd3JhcHBlclwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLWNvbnRhaW5lclwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImF1dGgtaGVhZGVyXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLWljb24tY29udGFpbmVyXCI+XG4gICAgICAgICAgICA8TG9nSW4gc2l6ZT17Mjh9IC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGgxIGNsYXNzTmFtZT1cImF1dGgtdGl0bGVcIj5XZWxjb21lIEJhY2s8L2gxPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImF1dGgtc3VidGl0bGVcIj5TaWduIGluIHRvIGNvbnRpbnVlIHRvIHlvdXIgYWNjb3VudDwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAge2Vycm9yICYmIDxkaXYgc3R5bGU9e3sgY29sb3I6ICcjZWY0NDQ0JywgYmFja2dyb3VuZENvbG9yOiAncmdiYSgyMzksIDY4LCA2OCwgMC4xKScsIHBhZGRpbmc6ICcwLjc1cmVtJywgYm9yZGVyUmFkaXVzOiAnOHB4JywgbWFyZ2luQm90dG9tOiAnMXJlbScsIGZvbnRTaXplOiAnMC45cmVtJywgYm9yZGVyOiAnMXB4IHNvbGlkIHJnYmEoMjM5LCA2OCwgNjgsIDAuMyknIH19PntlcnJvcn08L2Rpdj59XG5cbiAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwiYXV0aC1mb3JtXCIgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9ybS1sYWJlbFwiIGh0bWxGb3I9XCJlbWFpbFwiPkVtYWlsIEFkZHJlc3M8L2xhYmVsPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbnB1dC13cmFwcGVyXCI+XG4gICAgICAgICAgICAgIDxNYWlsIGNsYXNzTmFtZT1cImlucHV0LWljb25cIiBzaXplPXsyMH0gLz5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcbiAgICAgICAgICAgICAgICBpZD1cImVtYWlsXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb3JtLWlucHV0XCJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIm5hbWVAZXhhbXBsZS5jb21cIlxuICAgICAgICAgICAgICAgIHZhbHVlPXtlbWFpbH1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEVtYWlsKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXBcIj5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmb3JtLWxhYmVsXCIgaHRtbEZvcj1cInBhc3N3b3JkXCI+UGFzc3dvcmQ8L2xhYmVsPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbnB1dC13cmFwcGVyXCI+XG4gICAgICAgICAgICAgIDxMb2NrIGNsYXNzTmFtZT1cImlucHV0LWljb25cIiBzaXplPXsyMH0gLz5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICBpZD1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb3JtLWlucHV0XCJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIuKAouKAouKAouKAouKAouKAouKAouKAolwiXG4gICAgICAgICAgICAgICAgdmFsdWU9e3Bhc3N3b3JkfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UGFzc3dvcmQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIGNsYXNzTmFtZT1cInN1Ym1pdC1idG5cIj5cbiAgICAgICAgICAgIFNpZ24gSW5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9mb3JtPlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXV0aC1mb290ZXJcIj5cbiAgICAgICAgICBEb24ndCBoYXZlIGFuIGFjY291bnQ/IFxuICAgICAgICAgIDxMaW5rIHRvPVwiL3JlZ2lzdGVyXCIgY2xhc3NOYW1lPVwiYXV0aC1saW5rXCI+Q3JlYXRlIG9uZTwvTGluaz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IExvZ2luO1xuIl0sImZpbGUiOiJEOi9SZWFjdF90ZXN0XzE5XzA1XzIwMjYvc3JjL2NvbXBvbmVudHMvTG9naW4uanN4In0=