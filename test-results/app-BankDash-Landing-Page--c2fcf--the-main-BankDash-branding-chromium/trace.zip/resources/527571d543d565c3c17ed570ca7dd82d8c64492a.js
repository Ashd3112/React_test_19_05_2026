import {
  require_react
} from "/node_modules/.vite/deps/chunk-WQMOH32Y.js?v=01f90aba";
import "/node_modules/.vite/deps/chunk-5WWUZCGV.js?v=01f90aba";
export default require_react();
//# sourceMappingURL=react.js.map
