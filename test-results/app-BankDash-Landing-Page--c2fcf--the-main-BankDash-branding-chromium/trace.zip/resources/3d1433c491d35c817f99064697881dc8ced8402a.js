import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/QrScannerTab.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=01f90aba"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/React_test_19_05_2026/src/components/QrScannerTab.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=01f90aba"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import __vite__cjsImport4_jsqr from "/node_modules/.vite/deps/jsqr.js?v=01f90aba"; const jsQR = __vite__cjsImport4_jsqr.__esModule ? __vite__cjsImport4_jsqr.default : __vite__cjsImport4_jsqr;
import __vite__cjsImport5_qrcode from "/node_modules/.vite/deps/qrcode.js?v=01f90aba"; const QRCode = __vite__cjsImport5_qrcode.__esModule ? __vite__cjsImport5_qrcode.default : __vite__cjsImport5_qrcode;
import { Camera, Upload, QrCode, ArrowLeftRight, Check, X, ShieldAlert, Sparkles, Download, Volume2, VolumeX } from "/node_modules/.vite/deps/lucide-react.js?v=01f90aba";
const QrScannerTab = ({ userSession, cards, onAddTransaction, onUpdateCardBalance, onAddNotification }) => {
  _s();
  const [activeSubTab, setActiveSubTab] = useState("scan");
  const [scanMethod, setScanMethod] = useState("camera");
  const [hasCamera, setHasCamera] = useState(true);
  const [cameraActive, setCameraActive] = useState(false);
  const [devices, setDevices] = useState([]);
  const [selectedDevice, setSelectedDevice] = useState("");
  const [scanError, setScanError] = useState("");
  const [scanMessage, setScanMessage] = useState("Ready to scan. Align the QR code in the frame.");
  const [soundEnabled, setSoundEnabled] = useState(true);
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);
  const animationFrameRef = useRef(null);
  const [paymentData, setPaymentData] = useState(null);
  const [selectedCardId, setSelectedCardId] = useState(cards[0]?.id || "");
  const [customAmount, setCustomAmount] = useState("");
  const [transferInProgress, setTransferInProgress] = useState(false);
  const [transferSuccess, setTransferSuccess] = useState(false);
  const [qrAmount, setQrAmount] = useState("");
  const [qrPurpose, setQrPurpose] = useState("Personal Transfer");
  useEffect(() => {
    if (activeSubTab === "scan" && scanMethod === "camera") {
      navigator.mediaDevices.enumerateDevices().then((deviceList) => {
        const videoDevices = deviceList.filter((device) => device.kind === "videoinput");
        setDevices(videoDevices);
        if (videoDevices.length > 0) {
          setSelectedDevice(videoDevices[0].deviceId);
          setHasCamera(true);
        } else {
          setHasCamera(false);
          setScanMethod("upload");
        }
      }).catch((err) => {
        console.error("Error enumerating devices:", err);
        setHasCamera(false);
        setScanMethod("upload");
      });
    }
  }, [activeSubTab, scanMethod]);
  useEffect(() => {
    if (activeSubTab === "scan" && scanMethod === "camera" && selectedDevice) {
      startCamera();
    } else {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [activeSubTab, scanMethod, selectedDevice]);
  const startCamera = async () => {
    setScanError("");
    setCameraActive(false);
    stopCamera();
    try {
      const constraints = {
        video: { deviceId: selectedDevice ? { exact: selectedDevice } : void 0 }
      };
      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.setAttribute("playsinline", "true");
        videoRef.current.play();
        setCameraActive(true);
        animationFrameRef.current = requestAnimationFrame(scanFrame);
      }
    } catch (err) {
      console.error("Webcam access failed:", err);
      setScanError("Unable to access camera. Please check permissions or try file upload.");
      setScanMethod("upload");
    }
  };
  const stopCamera = () => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setCameraActive(false);
  };
  const scanFrame = () => {
    if (videoRef.current && videoRef.current.readyState === videoRef.current.HAVE_ENOUGH_DATA) {
      const canvas = canvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext("2d");
        canvas.width = videoRef.current.videoWidth;
        canvas.height = videoRef.current.videoHeight;
        ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(imageData.data, imageData.width, imageData.height, {
          inversionAttempts: "dontInvert"
        });
        if (code) {
          handleDecodedData(code.data);
          return;
        }
      }
    }
    if (activeSubTab === "scan" && scanMethod === "camera") {
      animationFrameRef.current = requestAnimationFrame(scanFrame);
    }
  };
  const playBeep = () => {
    if (!soundEnabled)
      return;
    try {
      const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      const oscillator = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();
      oscillator.connect(gainNode);
      gainNode.connect(audioCtx.destination);
      oscillator.type = "sine";
      oscillator.frequency.setValueAtTime(880, audioCtx.currentTime);
      gainNode.gain.setValueAtTime(0.1, audioCtx.currentTime);
      oscillator.start();
      oscillator.stop(audioCtx.currentTime + 0.15);
    } catch (e) {
      console.warn("Audio Context beep failed:", e);
    }
  };
  const handleDecodedData = (dataStr) => {
    playBeep();
    stopCamera();
    try {
      const parsed = JSON.parse(dataStr);
      if (parsed.recipient || parsed.name || parsed.email) {
        setPaymentData({
          recipient: parsed.recipient || parsed.name || parsed.email,
          amount: parseFloat(parsed.amount) || null,
          email: parsed.email || "scanned.recipient@bankdash.com",
          purpose: parsed.purpose || "QR Scan Payment"
        });
        if (parsed.amount) {
          setCustomAmount(parsed.amount.toString());
        } else {
          setCustomAmount("");
        }
      } else {
        setPaymentData({
          recipient: dataStr,
          amount: null,
          email: "scanned.recipient@bankdash.com",
          purpose: "QR Scan Payment"
        });
        setCustomAmount("");
      }
    } catch (e) {
      setPaymentData({
        recipient: dataStr,
        amount: null,
        email: dataStr.includes("@") ? dataStr : "scanned.recipient@bankdash.com",
        purpose: "QR Scan Payment"
      });
      setCustomAmount("");
    }
  };
  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (!file)
      return;
    setScanError("");
    setScanMessage("Processing file...");
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        const ctx = canvas.getContext("2d");
        canvas.width = img.width;
        canvas.height = img.height;
        ctx.drawImage(img, 0, 0);
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(imageData.data, imageData.width, imageData.height);
        if (code) {
          handleDecodedData(code.data);
        } else {
          setScanError("No QR Code found in this image. Try another picture.");
          setScanMessage("Scanning failed. Please make sure the QR is clear and well-lit.");
        }
      };
      img.src = event.target.result;
    };
    reader.readAsDataURL(file);
  };
  const handleConfirmPayment = (e) => {
    e.preventDefault();
    const amountVal = parseFloat(customAmount);
    if (isNaN(amountVal) || amountVal <= 0) {
      alert("Please enter a valid amount.");
      return;
    }
    const selectedCard = cards.find((c) => c.id === selectedCardId);
    if (!selectedCard) {
      alert("Please select a card to pay from.");
      return;
    }
    if (selectedCard.balance < amountVal) {
      alert("Insufficient funds in the selected card account!");
      return;
    }
    setTransferInProgress(true);
    setTimeout(() => {
      onUpdateCardBalance(selectedCard.id, selectedCard.balance - amountVal);
      const txId = `TX${Math.floor(1e3 + Math.random() * 9e3)}`;
      onAddTransaction({
        id: txId,
        desc: `Scan Pay to ${paymentData.recipient}`,
        date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
        type: "expense",
        method: "QR Scan Code",
        category: "Transfer",
        amount: amountVal,
        status: "Success"
      });
      onAddNotification({
        id: Date.now(),
        text: `Scan & Pay: Sent $${amountVal.toLocaleString()} to ${paymentData.recipient} from card ending ${selectedCard.number.slice(-4)}.`,
        time: "Just now",
        type: "success",
        unread: true
      });
      setTransferInProgress(false);
      setTransferSuccess(true);
    }, 1500);
  };
  const [myQrUrl, setMyQrUrl] = useState("");
  useEffect(() => {
    const myQrObject = {
      name: userSession.name,
      email: userSession.email,
      purpose: qrPurpose,
      amount: qrAmount ? parseFloat(qrAmount) : null
    };
    const myQrString = JSON.stringify(myQrObject);
    QRCode.toDataURL(myQrString, { margin: 1, width: 250 }).then((url) => setMyQrUrl(url)).catch((err) => console.error("Local QR generation failed:", err));
  }, [userSession.name, userSession.email, qrPurpose, qrAmount]);
  const handleCloseDrawer = () => {
    setPaymentData(null);
    setTransferSuccess(false);
    setCustomAmount("");
    if (activeSubTab === "scan" && scanMethod === "camera") {
      startCamera();
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "qr-scanner-tab", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "section-header", style: { borderBottom: "1px solid var(--ld-border)", paddingBottom: "1rem", marginBottom: "1.5rem" }, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "filter-tabs", style: { marginBottom: 0, borderBottom: "none" }, children: [
        /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: `filter-tab ${activeSubTab === "scan" ? "active" : ""}`,
            onClick: () => setActiveSubTab("scan"),
            children: [
              /* @__PURE__ */ jsxDEV(Camera, { size: 16, style: { marginRight: "0.4rem", verticalAlign: "middle" } }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
                lineNumber: 333,
                columnNumber: 13
              }, this),
              "Scan QR Code"
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 329,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: `filter-tab ${activeSubTab === "my-qr" ? "active" : ""}`,
            onClick: () => setActiveSubTab("my-qr"),
            children: [
              /* @__PURE__ */ jsxDEV(QrCode, { size: 16, style: { marginRight: "0.4rem", verticalAlign: "middle" } }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
                lineNumber: 340,
                columnNumber: 13
              }, this),
              "Receive Money (My QR)"
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 336,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
        lineNumber: 328,
        columnNumber: 9
      }, this),
      activeSubTab === "scan" && scanMethod === "camera" && /* @__PURE__ */ jsxDEV(
        "button",
        {
          className: "icon-btn",
          onClick: () => setSoundEnabled(!soundEnabled),
          title: soundEnabled ? "Mute scan sound" : "Unmute scan sound",
          style: { margin: 0, padding: "0.5rem", background: "var(--panel-bg)", borderRadius: "50%" },
          children: soundEnabled ? /* @__PURE__ */ jsxDEV(Volume2, { size: 18 }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 352,
            columnNumber: 29
          }, this) : /* @__PURE__ */ jsxDEV(VolumeX, { size: 18 }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 352,
            columnNumber: 53
          }, this)
        },
        void 0,
        false,
        {
          fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
          lineNumber: 346,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
      lineNumber: 327,
      columnNumber: 7
    }, this),
    activeSubTab === "scan" ? /* @__PURE__ */ jsxDEV("div", { className: "scanner-container-row", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "col-7", children: /* @__PURE__ */ jsxDEV("div", { className: "panel", style: { minHeight: "420px", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", position: "relative", overflow: "hidden" }, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "scanner-header-controls", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              className: `scanner-toggle-btn ${scanMethod === "camera" ? "active" : ""}`,
              onClick: () => {
                setScanMethod("camera");
                setScanError("");
              },
              children: "Live Webcam"
            },
            void 0,
            false,
            {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 365,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              className: `scanner-toggle-btn ${scanMethod === "upload" ? "active" : ""}`,
              onClick: () => {
                setScanMethod("upload");
                stopCamera();
                setScanError("");
              },
              children: "Upload Image"
            },
            void 0,
            false,
            {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 371,
              columnNumber: 17
            },
            this
          ),
          scanMethod === "camera" && devices.length > 1 && /* @__PURE__ */ jsxDEV(
            "select",
            {
              className: "camera-selector-select",
              value: selectedDevice,
              onChange: (e) => setSelectedDevice(e.target.value),
              children: devices.map(
                (device, idx) => /* @__PURE__ */ jsxDEV("option", { value: device.deviceId, children: [
                  "Camera ",
                  idx + 1,
                  " (",
                  device.label.slice(0, 15) || "Device",
                  ")"
                ] }, device.deviceId, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
                  lineNumber: 385,
                  columnNumber: 17
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 379,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
          lineNumber: 364,
          columnNumber: 15
        }, this),
        scanMethod === "camera" ? /* @__PURE__ */ jsxDEV("div", { className: "webcam-viewport", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "scanner-overlay-guide", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "scanner-laser-line" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 397,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "corner-guide top-left" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 398,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "corner-guide top-right" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 399,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "corner-guide bottom-left" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 400,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "corner-guide bottom-right" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 401,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 396,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("video", { ref: videoRef, className: "webcam-video-feed", playsInline: true }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 404,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("canvas", { ref: canvasRef, style: { display: "none" } }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 405,
            columnNumber: 19
          }, this),
          !cameraActive && !scanError && /* @__PURE__ */ jsxDEV("div", { className: "scanner-loader-overlay", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "premium-spinner" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 409,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("span", { style: { marginTop: "1rem", fontSize: "0.9rem", color: "rgba(255,255,255,0.7)" }, children: "Starting camera feed..." }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 410,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 408,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
          lineNumber: 394,
          columnNumber: 13
        }, this) : (
          /* Upload Drag Drop Zone */
          /* @__PURE__ */ jsxDEV("div", { className: "upload-dropzone-wrapper", children: /* @__PURE__ */ jsxDEV("label", { htmlFor: "qr-file-upload", className: "dropzone-label", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "upload-icon-circle", children: /* @__PURE__ */ jsxDEV(Upload, { size: 32 }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 419,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 418,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("h4", { children: "Upload payment QR code" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 421,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("p", { children: "Drag and drop image file, or click to browse" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 422,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "file-formats-label", children: "Supports PNG, JPG, JPEG" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 423,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "file",
                id: "qr-file-upload",
                accept: "image/*",
                style: { display: "none" },
                onChange: handleFileUpload
              },
              void 0,
              false,
              {
                fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
                lineNumber: 424,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 417,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 416,
            columnNumber: 13
          }, this)
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "scanner-status-footer", style: scanError ? { background: "rgba(255, 75, 74, 0.1)", color: "#FF4B4A" } : {}, children: scanError ? /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", gap: "0.5rem" }, children: [
          /* @__PURE__ */ jsxDEV(ShieldAlert, { size: 16 }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 439,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: scanError }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 440,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
          lineNumber: 438,
          columnNumber: 15
        }, this) : /* @__PURE__ */ jsxDEV("span", { children: scanMessage }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
          lineNumber: 443,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
          lineNumber: 436,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
        lineNumber: 361,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
        lineNumber: 360,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "col-5", children: /* @__PURE__ */ jsxDEV("div", { className: "panel", style: { minHeight: "420px", padding: "2rem" }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", gap: "0.6rem", marginBottom: "1.25rem" }, children: [
          /* @__PURE__ */ jsxDEV(Sparkles, { size: 20, color: "var(--accent-primary)" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 454,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("h3", { className: "section-title", style: { margin: 0 }, children: "Scan to Pay" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 455,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
          lineNumber: 453,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { style: { color: "#718EBF", fontSize: "0.9rem", lineHeight: "1.6", marginBottom: "1.5rem" }, children: "Quickly transfer funds to any other BankDash member. You can scan their profile QR code either by opening your camera or uploading a picture of the QR code." }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
          lineNumber: 457,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "instruction-steps", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "step-item", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "step-badge", children: "1" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 463,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h5", { children: "Select Scan Option" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
                lineNumber: 465,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("p", { children: "Use your camera to scan a QR code in real-time or upload a screenshot/image of the QR." }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
                lineNumber: 466,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 464,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 462,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "step-item", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "step-badge", children: "2" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 470,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h5", { children: "Review Details" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
                lineNumber: 472,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("p", { children: "Verify the recipient's name, email, and input the amount you wish to transfer." }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
                lineNumber: 473,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 471,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 469,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "step-item", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "step-badge", children: "3" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 477,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h5", { children: "Confirm Transaction" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
                lineNumber: 479,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("p", { children: "Select your source payment card, slide/confirm, and your funds are transferred instantly." }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
                lineNumber: 480,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 478,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 476,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
          lineNumber: 461,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
        lineNumber: 452,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
        lineNumber: 451,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
      lineNumber: 358,
      columnNumber: 7
    }, this) : (
      /* My QR tab - generates dynamic personal QR code to receive money */
      /* @__PURE__ */ jsxDEV("div", { className: "scanner-container-row", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "col-7", children: /* @__PURE__ */ jsxDEV("div", { className: "panel", style: { minHeight: "440px", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "2.5rem" }, children: [
          /* @__PURE__ */ jsxDEV("div", { className: "premium-qr-envelope", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "qr-envelope-chip" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 495,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "qr-envelope-logo-brand", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "logo-icon", style: { width: "18px", height: "18px" }, children: /* @__PURE__ */ jsxDEV("svg", { width: "12", height: "12", viewBox: "0 0 24 24", fill: "none", children: /* @__PURE__ */ jsxDEV("path", { d: "M12 2L2 7L12 12L22 7L12 2Z", fill: "white", stroke: "white", strokeWidth: "2" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
                lineNumber: 499,
                columnNumber: 23
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
                lineNumber: 498,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
                lineNumber: 497,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: "BankDash." }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
                lineNumber: 502,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 496,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "qr-code-canvas-frame", style: { minWidth: "180px", minHeight: "180px" }, children: myQrUrl ? /* @__PURE__ */ jsxDEV("img", { src: myQrUrl, alt: "My QR Code", className: "generated-qr-image" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 507,
              columnNumber: 17
            }, this) : /* @__PURE__ */ jsxDEV("div", { className: "premium-spinner", style: { width: "32px", height: "32px" } }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 509,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 505,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "qr-envelope-holder-row", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("div", { className: "envelope-holder-lbl", children: "Account Holder" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
                  lineNumber: 515,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "envelope-holder-val", children: userSession.name }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
                  lineNumber: 516,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
                lineNumber: 514,
                columnNumber: 19
              }, this),
              qrAmount && /* @__PURE__ */ jsxDEV("div", { style: { textAlign: "right" }, children: [
                /* @__PURE__ */ jsxDEV("div", { className: "envelope-holder-lbl", children: "Requested Amount" }, void 0, false, {
                  fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
                  lineNumber: 520,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "envelope-holder-val", style: { color: "var(--success)" }, children: [
                  "$",
                  parseFloat(qrAmount).toLocaleString()
                ] }, void 0, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
                  lineNumber: 521,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
                lineNumber: 519,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 513,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 494,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { marginTop: "1.5rem", display: "flex", gap: "1rem" }, children: /* @__PURE__ */ jsxDEV("a", { href: myQrUrl, target: "_blank", rel: "noreferrer", download: `bankdash_qr_${userSession.name}.png`, className: "settings-save-btn", style: { textDecoration: "none", display: "flex", alignItems: "center", gap: "0.5rem", padding: "0.6rem 1.5rem", margin: 0 }, children: [
            /* @__PURE__ */ jsxDEV(Download, { size: 16 }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 529,
              columnNumber: 19
            }, this),
            "Download QR Code"
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 528,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 527,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
          lineNumber: 491,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
          lineNumber: 490,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "col-5", children: /* @__PURE__ */ jsxDEV("div", { className: "panel", style: { minHeight: "440px", padding: "2rem" }, children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "section-title", style: { marginBottom: "1.25rem" }, children: "Customize QR Request" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 539,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { style: { color: "#718EBF", fontSize: "0.9rem", lineHeight: "1.6", marginBottom: "1.5rem" }, children: "Set an optional amount or transfer description below to embed them directly into your personal QR code." }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 540,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "qr-customizer-form", onSubmit: (e) => e.preventDefault(), children: [
            /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", children: [
              /* @__PURE__ */ jsxDEV("label", { children: "Request Specific Amount ($)" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
                lineNumber: 546,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "number",
                  className: "settings-form-input",
                  placeholder: "e.g. 150.00 (Leave empty for any amount)",
                  value: qrAmount,
                  onChange: (e) => setQrAmount(e.target.value)
                },
                void 0,
                false,
                {
                  fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
                  lineNumber: 547,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 545,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", children: [
              /* @__PURE__ */ jsxDEV("label", { children: "Transfer Purpose / Note" }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
                lineNumber: 557,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  className: "settings-form-input",
                  placeholder: "e.g. Split Dinner Bill",
                  value: qrPurpose,
                  onChange: (e) => setQrPurpose(e.target.value)
                },
                void 0,
                false,
                {
                  fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
                  lineNumber: 558,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 556,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 544,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "qr-info-pills", style: { marginTop: "1.5rem", padding: "1rem", background: "rgba(57, 106, 255, 0.05)", borderRadius: "12px", border: "1px solid rgba(57, 106, 255, 0.1)" }, children: /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: "0.5rem", alignItems: "flex-start" }, children: [
            /* @__PURE__ */ jsxDEV(QrCode, { size: 18, color: "var(--accent-primary)", style: { flexShrink: 0, marginTop: "0.1rem" } }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 570,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "0.8rem", color: "#343C6A", fontWeight: 500, lineHeight: "1.5" }, children: "When another BankDash app scans this QR, it will pre-fill your name, email, and the requested details automatically!" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 571,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 569,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 568,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
          lineNumber: 538,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
          lineNumber: 537,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
        lineNumber: 489,
        columnNumber: 7
      }, this)
    ),
    paymentData && /* @__PURE__ */ jsxDEV("div", { className: "payment-drawer-backdrop", children: /* @__PURE__ */ jsxDEV("div", { className: "payment-drawer-container", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "drawer-header-row", children: [
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", gap: "0.75rem" }, children: [
          /* @__PURE__ */ jsxDEV("div", { className: "drawer-badge-circle", children: /* @__PURE__ */ jsxDEV(ArrowLeftRight, { size: 20 }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 588,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 587,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h3", { style: { margin: 0, color: "#343C6A", fontSize: "1.2rem", fontWeight: 700 }, children: "Confirm QR Transfer" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 591,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { style: { margin: 0, fontSize: "0.78rem", color: "#718EBF" }, children: "Verify transaction details before completing the payment" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 592,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 590,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
          lineNumber: 586,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "drawer-close-btn", onClick: handleCloseDrawer, children: /* @__PURE__ */ jsxDEV(X, { size: 20 }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
          lineNumber: 596,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
          lineNumber: 595,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
        lineNumber: 585,
        columnNumber: 13
      }, this),
      transferSuccess ? /* @__PURE__ */ jsxDEV("div", { className: "drawer-success-view", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "success-lottie-mock", children: /* @__PURE__ */ jsxDEV(Check, { size: 36, color: "white", strokeWidth: 3 }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
          lineNumber: 603,
          columnNumber: 19
        }, this) }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
          lineNumber: 602,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("h3", { children: "Transfer Successful!" }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
          lineNumber: 605,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: [
          "Sent ",
          /* @__PURE__ */ jsxDEV("b", { children: [
            "$",
            parseFloat(customAmount).toLocaleString()
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 606,
            columnNumber: 25
          }, this),
          " to ",
          /* @__PURE__ */ jsxDEV("b", { children: paymentData.recipient }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 606,
            columnNumber: 80
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
          lineNumber: 606,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "settings-save-btn", style: { margin: "1.5rem 0 0 0" }, onClick: handleCloseDrawer, children: "Done" }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
          lineNumber: 607,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
        lineNumber: 601,
        columnNumber: 11
      }, this) : /* @__PURE__ */ jsxDEV("form", { onSubmit: handleConfirmPayment, className: "drawer-form-content", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "drawer-breakdown-box", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "breakdown-item", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "lbl", children: "Recipient" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 617,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "val", style: { fontWeight: 700 }, children: paymentData.recipient }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 618,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 616,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "breakdown-item", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "lbl", children: "Recipient Email" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 621,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "val", style: { color: "#718EBF" }, children: paymentData.email }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 622,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 620,
            columnNumber: 19
          }, this),
          paymentData.purpose && /* @__PURE__ */ jsxDEV("div", { className: "breakdown-item", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "lbl", children: "Purpose" }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 626,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "val", style: { fontStyle: "italic" }, children: paymentData.purpose }, void 0, false, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 627,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 625,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
          lineNumber: 615,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", children: [
          /* @__PURE__ */ jsxDEV("label", { style: { fontSize: "0.82rem", fontWeight: 600 }, children: "Select Debit Card Account" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 634,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            "select",
            {
              className: "settings-form-input",
              value: selectedCardId,
              onChange: (e) => setSelectedCardId(e.target.value),
              required: true,
              children: cards.map(
                (card) => /* @__PURE__ */ jsxDEV("option", { value: card.id, children: [
                  card.type.toUpperCase(),
                  " Card ending ",
                  card.number.slice(-4),
                  " (Bal: $",
                  card.balance.toLocaleString(),
                  ")"
                ] }, card.id, true, {
                  fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
                  lineNumber: 642,
                  columnNumber: 17
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 635,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
          lineNumber: 633,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "settings-input-group", children: [
          /* @__PURE__ */ jsxDEV("label", { style: { fontSize: "0.82rem", fontWeight: 600 }, children: "Transfer Amount ($)" }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 651,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "number",
              className: "settings-form-input",
              placeholder: "Enter amount to pay",
              value: customAmount,
              onChange: (e) => setCustomAmount(e.target.value),
              disabled: paymentData.amount !== null,
              required: true,
              step: "0.01"
            },
            void 0,
            false,
            {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 652,
              columnNumber: 19
            },
            this
          ),
          paymentData.amount !== null && /* @__PURE__ */ jsxDEV("span", { className: "input-helper-note", children: "Amount locked by QR Code request." }, void 0, false, {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 663,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
          lineNumber: 650,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { marginTop: "1.5rem" }, children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "submit",
            className: "settings-save-btn",
            style: { width: "100%", margin: 0, padding: "1rem", display: "flex", justifyContent: "center", gap: "0.5rem" },
            disabled: transferInProgress,
            children: transferInProgress ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV("div", { className: "premium-spinner", style: { width: "18px", height: "18px", borderWidth: "2px", borderColor: "white" } }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
                lineNumber: 677,
                columnNumber: 25
              }, this),
              "Processing Secure Transfer..."
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 676,
              columnNumber: 17
            }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV(ArrowLeftRight, { size: 18 }, void 0, false, {
                fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
                lineNumber: 682,
                columnNumber: 25
              }, this),
              "Confirm & Send $",
              parseFloat(customAmount || 0).toLocaleString()
            ] }, void 0, true, {
              fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
              lineNumber: 681,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
            lineNumber: 669,
            columnNumber: 19
          },
          this
        ) }, void 0, false, {
          fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
          lineNumber: 668,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
        lineNumber: 612,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
      lineNumber: 584,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
      lineNumber: 583,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/React_test_19_05_2026/src/components/QrScannerTab.jsx",
    lineNumber: 325,
    columnNumber: 5
  }, this);
};
_s(QrScannerTab, "Na17jqVfCl1b0kD/Wr5c6slnbiQ=");
_c = QrScannerTab;
export default QrScannerTab;
var _c;
$RefreshReg$(_c, "QrScannerTab");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/React_test_19_05_2026/src/components/QrScannerTab.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/React_test_19_05_2026/src/components/QrScannerTab.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeVRZLFNBdVZVLFVBdlZWOzs7Ozs7Ozs7Ozs7Ozs7OztBQXpUWixTQUFTQSxVQUFVQyxXQUFXQyxjQUFjO0FBQzVDLE9BQU9DLFVBQVU7QUFDakIsT0FBT0MsWUFBWTtBQUNuQixTQUFTQyxRQUFRQyxRQUFRQyxRQUFRQyxnQkFBZ0JDLE9BQU9DLEdBQUdDLGFBQWFDLFVBQVVDLFVBQVVDLFNBQVNDLGVBQWU7QUFFcEgsTUFBTUMsZUFBZUEsQ0FBQyxFQUFFQyxhQUFhQyxPQUFPQyxrQkFBa0JDLHFCQUFxQkMsa0JBQWtCLE1BQU07QUFBQUMsS0FBQTtBQUN6RyxRQUFNLENBQUNDLGNBQWNDLGVBQWUsSUFBSXhCLFNBQVMsTUFBTTtBQUN2RCxRQUFNLENBQUN5QixZQUFZQyxhQUFhLElBQUkxQixTQUFTLFFBQVE7QUFHckQsUUFBTSxDQUFDMkIsV0FBV0MsWUFBWSxJQUFJNUIsU0FBUyxJQUFJO0FBQy9DLFFBQU0sQ0FBQzZCLGNBQWNDLGVBQWUsSUFBSTlCLFNBQVMsS0FBSztBQUN0RCxRQUFNLENBQUMrQixTQUFTQyxVQUFVLElBQUloQyxTQUFTLEVBQUU7QUFDekMsUUFBTSxDQUFDaUMsZ0JBQWdCQyxpQkFBaUIsSUFBSWxDLFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUNtQyxXQUFXQyxZQUFZLElBQUlwQyxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDcUMsYUFBYUMsY0FBYyxJQUFJdEMsU0FBUyxnREFBZ0Q7QUFDL0YsUUFBTSxDQUFDdUMsY0FBY0MsZUFBZSxJQUFJeEMsU0FBUyxJQUFJO0FBR3JELFFBQU15QyxXQUFXdkMsT0FBTyxJQUFJO0FBQzVCLFFBQU13QyxZQUFZeEMsT0FBTyxJQUFJO0FBQzdCLFFBQU15QyxZQUFZekMsT0FBTyxJQUFJO0FBQzdCLFFBQU0wQyxvQkFBb0IxQyxPQUFPLElBQUk7QUFHckMsUUFBTSxDQUFDMkMsYUFBYUMsY0FBYyxJQUFJOUMsU0FBUyxJQUFJO0FBQ25ELFFBQU0sQ0FBQytDLGdCQUFnQkMsaUJBQWlCLElBQUloRCxTQUFTa0IsTUFBTSxDQUFDLEdBQUcrQixNQUFNLEVBQUU7QUFDdkUsUUFBTSxDQUFDQyxjQUFjQyxlQUFlLElBQUluRCxTQUFTLEVBQUU7QUFDbkQsUUFBTSxDQUFDb0Qsb0JBQW9CQyxxQkFBcUIsSUFBSXJELFNBQVMsS0FBSztBQUNsRSxRQUFNLENBQUNzRCxpQkFBaUJDLGtCQUFrQixJQUFJdkQsU0FBUyxLQUFLO0FBRzVELFFBQU0sQ0FBQ3dELFVBQVVDLFdBQVcsSUFBSXpELFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUMwRCxXQUFXQyxZQUFZLElBQUkzRCxTQUFTLG1CQUFtQjtBQUc5REMsWUFBVSxNQUFNO0FBQ2QsUUFBSXNCLGlCQUFpQixVQUFVRSxlQUFlLFVBQVU7QUFDdERtQyxnQkFBVUMsYUFBYUMsaUJBQWlCLEVBQ3JDQyxLQUFLLENBQUFDLGVBQWM7QUFDbEIsY0FBTUMsZUFBZUQsV0FBV0UsT0FBTyxDQUFBQyxXQUFVQSxPQUFPQyxTQUFTLFlBQVk7QUFDN0VwQyxtQkFBV2lDLFlBQVk7QUFDdkIsWUFBSUEsYUFBYUksU0FBUyxHQUFHO0FBQzNCbkMsNEJBQWtCK0IsYUFBYSxDQUFDLEVBQUVLLFFBQVE7QUFDMUMxQyx1QkFBYSxJQUFJO0FBQUEsUUFDbkIsT0FBTztBQUNMQSx1QkFBYSxLQUFLO0FBQ2xCRix3QkFBYyxRQUFRO0FBQUEsUUFDeEI7QUFBQSxNQUNGLENBQUMsRUFDQTZDLE1BQU0sQ0FBQUMsUUFBTztBQUNaQyxnQkFBUUMsTUFBTSw4QkFBOEJGLEdBQUc7QUFDL0M1QyxxQkFBYSxLQUFLO0FBQ2xCRixzQkFBYyxRQUFRO0FBQUEsTUFDeEIsQ0FBQztBQUFBLElBQ0w7QUFBQSxFQUNGLEdBQUcsQ0FBQ0gsY0FBY0UsVUFBVSxDQUFDO0FBRzdCeEIsWUFBVSxNQUFNO0FBQ2QsUUFBSXNCLGlCQUFpQixVQUFVRSxlQUFlLFlBQVlRLGdCQUFnQjtBQUN4RTBDLGtCQUFZO0FBQUEsSUFDZCxPQUFPO0FBQ0xDLGlCQUFXO0FBQUEsSUFDYjtBQUVBLFdBQU8sTUFBTTtBQUNYQSxpQkFBVztBQUFBLElBQ2I7QUFBQSxFQUNGLEdBQUcsQ0FBQ3JELGNBQWNFLFlBQVlRLGNBQWMsQ0FBQztBQUU3QyxRQUFNMEMsY0FBYyxZQUFZO0FBQzlCdkMsaUJBQWEsRUFBRTtBQUNmTixvQkFBZ0IsS0FBSztBQUNyQjhDLGVBQVc7QUFFWCxRQUFJO0FBQ0YsWUFBTUMsY0FBYztBQUFBLFFBQ2xCQyxPQUFPLEVBQUVSLFVBQVVyQyxpQkFBaUIsRUFBRThDLE9BQU85QyxlQUFlLElBQUkrQyxPQUFVO0FBQUEsTUFDNUU7QUFDQSxZQUFNQyxTQUFTLE1BQU1yQixVQUFVQyxhQUFhcUIsYUFBYUwsV0FBVztBQUNwRWxDLGdCQUFVd0MsVUFBVUY7QUFDcEIsVUFBSXhDLFNBQVMwQyxTQUFTO0FBQ3BCMUMsaUJBQVMwQyxRQUFRQyxZQUFZSDtBQUM3QnhDLGlCQUFTMEMsUUFBUUUsYUFBYSxlQUFlLE1BQU07QUFDbkQ1QyxpQkFBUzBDLFFBQVFHLEtBQUs7QUFDdEJ4RCx3QkFBZ0IsSUFBSTtBQUNwQmMsMEJBQWtCdUMsVUFBVUksc0JBQXNCQyxTQUFTO0FBQUEsTUFDN0Q7QUFBQSxJQUNGLFNBQVNoQixLQUFLO0FBQ1pDLGNBQVFDLE1BQU0seUJBQXlCRixHQUFHO0FBQzFDcEMsbUJBQWEsdUVBQXVFO0FBQ3BGVixvQkFBYyxRQUFRO0FBQUEsSUFDeEI7QUFBQSxFQUNGO0FBRUEsUUFBTWtELGFBQWFBLE1BQU07QUFDdkIsUUFBSWhDLGtCQUFrQnVDLFNBQVM7QUFDN0JNLDJCQUFxQjdDLGtCQUFrQnVDLE9BQU87QUFDOUN2Qyx3QkFBa0J1QyxVQUFVO0FBQUEsSUFDOUI7QUFDQSxRQUFJeEMsVUFBVXdDLFNBQVM7QUFDckJ4QyxnQkFBVXdDLFFBQVFPLFVBQVUsRUFBRUMsUUFBUSxDQUFBQyxVQUFTQSxNQUFNQyxLQUFLLENBQUM7QUFDM0RsRCxnQkFBVXdDLFVBQVU7QUFBQSxJQUN0QjtBQUNBckQsb0JBQWdCLEtBQUs7QUFBQSxFQUN2QjtBQUdBLFFBQU0wRCxZQUFZQSxNQUFNO0FBQ3RCLFFBQUkvQyxTQUFTMEMsV0FBVzFDLFNBQVMwQyxRQUFRVyxlQUFlckQsU0FBUzBDLFFBQVFZLGtCQUFrQjtBQUN6RixZQUFNQyxTQUFTdEQsVUFBVXlDO0FBQ3pCLFVBQUlhLFFBQVE7QUFDVixjQUFNQyxNQUFNRCxPQUFPRSxXQUFXLElBQUk7QUFDbENGLGVBQU9HLFFBQVExRCxTQUFTMEMsUUFBUWlCO0FBQ2hDSixlQUFPSyxTQUFTNUQsU0FBUzBDLFFBQVFtQjtBQUVqQ0wsWUFBSU0sVUFBVTlELFNBQVMwQyxTQUFTLEdBQUcsR0FBR2EsT0FBT0csT0FBT0gsT0FBT0ssTUFBTTtBQUNqRSxjQUFNRyxZQUFZUCxJQUFJUSxhQUFhLEdBQUcsR0FBR1QsT0FBT0csT0FBT0gsT0FBT0ssTUFBTTtBQUNwRSxjQUFNSyxPQUFPdkcsS0FBS3FHLFVBQVVHLE1BQU1ILFVBQVVMLE9BQU9LLFVBQVVILFFBQVE7QUFBQSxVQUNuRU8sbUJBQW1CO0FBQUEsUUFDckIsQ0FBQztBQUVELFlBQUlGLE1BQU07QUFDUkcsNEJBQWtCSCxLQUFLQyxJQUFJO0FBQzNCO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsUUFBSXBGLGlCQUFpQixVQUFVRSxlQUFlLFVBQVU7QUFDdERtQix3QkFBa0J1QyxVQUFVSSxzQkFBc0JDLFNBQVM7QUFBQSxJQUM3RDtBQUFBLEVBQ0Y7QUFHQSxRQUFNc0IsV0FBV0EsTUFBTTtBQUNyQixRQUFJLENBQUN2RTtBQUFjO0FBQ25CLFFBQUk7QUFDRixZQUFNd0UsV0FBVyxLQUFLQyxPQUFPQyxnQkFBZ0JELE9BQU9FLG9CQUFvQjtBQUN4RSxZQUFNQyxhQUFhSixTQUFTSyxpQkFBaUI7QUFDN0MsWUFBTUMsV0FBV04sU0FBU08sV0FBVztBQUNyQ0gsaUJBQVdJLFFBQVFGLFFBQVE7QUFDM0JBLGVBQVNFLFFBQVFSLFNBQVNTLFdBQVc7QUFDckNMLGlCQUFXTSxPQUFPO0FBQ2xCTixpQkFBV08sVUFBVUMsZUFBZSxLQUFLWixTQUFTYSxXQUFXO0FBQzdEUCxlQUFTUSxLQUFLRixlQUFlLEtBQUtaLFNBQVNhLFdBQVc7QUFDdERULGlCQUFXVyxNQUFNO0FBQ2pCWCxpQkFBV3RCLEtBQUtrQixTQUFTYSxjQUFjLElBQUk7QUFBQSxJQUM3QyxTQUFTRyxHQUFHO0FBQ1Z0RCxjQUFRdUQsS0FBSyw4QkFBOEJELENBQUM7QUFBQSxJQUM5QztBQUFBLEVBQ0Y7QUFHQSxRQUFNbEIsb0JBQW9CQSxDQUFDb0IsWUFBWTtBQUNyQ25CLGFBQVM7QUFDVGxDLGVBQVc7QUFFWCxRQUFJO0FBRUYsWUFBTXNELFNBQVNDLEtBQUtDLE1BQU1ILE9BQU87QUFDakMsVUFBSUMsT0FBT0csYUFBYUgsT0FBT0ksUUFBUUosT0FBT0ssT0FBTztBQUNuRHpGLHVCQUFlO0FBQUEsVUFDYnVGLFdBQVdILE9BQU9HLGFBQWFILE9BQU9JLFFBQVFKLE9BQU9LO0FBQUFBLFVBQ3JEQyxRQUFRQyxXQUFXUCxPQUFPTSxNQUFNLEtBQUs7QUFBQSxVQUNyQ0QsT0FBT0wsT0FBT0ssU0FBUztBQUFBLFVBQ3ZCRyxTQUFTUixPQUFPUSxXQUFXO0FBQUEsUUFDN0IsQ0FBQztBQUNELFlBQUlSLE9BQU9NLFFBQVE7QUFDakJyRiwwQkFBZ0IrRSxPQUFPTSxPQUFPRyxTQUFTLENBQUM7QUFBQSxRQUMxQyxPQUFPO0FBQ0x4RiwwQkFBZ0IsRUFBRTtBQUFBLFFBQ3BCO0FBQUEsTUFDRixPQUFPO0FBRUxMLHVCQUFlO0FBQUEsVUFDYnVGLFdBQVdKO0FBQUFBLFVBQ1hPLFFBQVE7QUFBQSxVQUNSRCxPQUFPO0FBQUEsVUFDUEcsU0FBUztBQUFBLFFBQ1gsQ0FBQztBQUNEdkYsd0JBQWdCLEVBQUU7QUFBQSxNQUNwQjtBQUFBLElBQ0YsU0FBUzRFLEdBQUc7QUFFVmpGLHFCQUFlO0FBQUEsUUFDYnVGLFdBQVdKO0FBQUFBLFFBQ1hPLFFBQVE7QUFBQSxRQUNSRCxPQUFPTixRQUFRVyxTQUFTLEdBQUcsSUFBSVgsVUFBVTtBQUFBLFFBQ3pDUyxTQUFTO0FBQUEsTUFDWCxDQUFDO0FBQ0R2RixzQkFBZ0IsRUFBRTtBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUdBLFFBQU0wRixtQkFBbUJBLENBQUNkLE1BQU07QUFDOUIsVUFBTWUsT0FBT2YsRUFBRWdCLE9BQU9DLE1BQU0sQ0FBQztBQUM3QixRQUFJLENBQUNGO0FBQU07QUFFWDFHLGlCQUFhLEVBQUU7QUFDZkUsbUJBQWUsb0JBQW9CO0FBRW5DLFVBQU0yRyxTQUFTLElBQUlDLFdBQVc7QUFDOUJELFdBQU9FLFNBQVMsQ0FBQ0MsVUFBVTtBQUN6QixZQUFNQyxNQUFNLElBQUlDLE1BQU07QUFDdEJELFVBQUlGLFNBQVMsTUFBTTtBQUNqQixjQUFNbkQsU0FBU3VELFNBQVNDLGNBQWMsUUFBUTtBQUM5QyxjQUFNdkQsTUFBTUQsT0FBT0UsV0FBVyxJQUFJO0FBQ2xDRixlQUFPRyxRQUFRa0QsSUFBSWxEO0FBQ25CSCxlQUFPSyxTQUFTZ0QsSUFBSWhEO0FBQ3BCSixZQUFJTSxVQUFVOEMsS0FBSyxHQUFHLENBQUM7QUFFdkIsY0FBTTdDLFlBQVlQLElBQUlRLGFBQWEsR0FBRyxHQUFHVCxPQUFPRyxPQUFPSCxPQUFPSyxNQUFNO0FBQ3BFLGNBQU1LLE9BQU92RyxLQUFLcUcsVUFBVUcsTUFBTUgsVUFBVUwsT0FBT0ssVUFBVUgsTUFBTTtBQUVuRSxZQUFJSyxNQUFNO0FBQ1JHLDRCQUFrQkgsS0FBS0MsSUFBSTtBQUFBLFFBQzdCLE9BQU87QUFDTHZFLHVCQUFhLHNEQUFzRDtBQUNuRUUseUJBQWUsaUVBQWlFO0FBQUEsUUFDbEY7QUFBQSxNQUNGO0FBQ0ErRyxVQUFJSSxNQUFNTCxNQUFNTCxPQUFPVztBQUFBQSxJQUN6QjtBQUNBVCxXQUFPVSxjQUFjYixJQUFJO0FBQUEsRUFDM0I7QUFHQSxRQUFNYyx1QkFBdUJBLENBQUM3QixNQUFNO0FBQ2xDQSxNQUFFOEIsZUFBZTtBQUNqQixVQUFNQyxZQUFZckIsV0FBV3ZGLFlBQVk7QUFDekMsUUFBSTZHLE1BQU1ELFNBQVMsS0FBS0EsYUFBYSxHQUFHO0FBQ3RDRSxZQUFNLDhCQUE4QjtBQUNwQztBQUFBLElBQ0Y7QUFFQSxVQUFNQyxlQUFlL0ksTUFBTWdKLEtBQUssQ0FBQUMsTUFBS0EsRUFBRWxILE9BQU9GLGNBQWM7QUFDNUQsUUFBSSxDQUFDa0gsY0FBYztBQUNqQkQsWUFBTSxtQ0FBbUM7QUFDekM7QUFBQSxJQUNGO0FBRUEsUUFBSUMsYUFBYUcsVUFBVU4sV0FBVztBQUNwQ0UsWUFBTSxrREFBa0Q7QUFDeEQ7QUFBQSxJQUNGO0FBRUEzRywwQkFBc0IsSUFBSTtBQUcxQmdILGVBQVcsTUFBTTtBQUNmakosMEJBQW9CNkksYUFBYWhILElBQUlnSCxhQUFhRyxVQUFVTixTQUFTO0FBRXJFLFlBQU1RLE9BQU8sS0FBS0MsS0FBS0MsTUFBTSxNQUFPRCxLQUFLRSxPQUFPLElBQUksR0FBSSxDQUFDO0FBQ3pEdEosdUJBQWlCO0FBQUEsUUFDZjhCLElBQUlxSDtBQUFBQSxRQUNKSSxNQUFNLGVBQWU3SCxZQUFZd0YsU0FBUztBQUFBLFFBQzFDc0MsT0FBTSxvQkFBSUMsS0FBSyxHQUFFQyxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxRQUMzQ3JELE1BQU07QUFBQSxRQUNOc0QsUUFBUTtBQUFBLFFBQ1JDLFVBQVU7QUFBQSxRQUNWeEMsUUFBUXNCO0FBQUFBLFFBQ1JtQixRQUFRO0FBQUEsTUFDVixDQUFDO0FBRUQ1Six3QkFBa0I7QUFBQSxRQUNoQjRCLElBQUkySCxLQUFLTSxJQUFJO0FBQUEsUUFDYkMsTUFBTSxxQkFBcUJyQixVQUFVc0IsZUFBZSxDQUFDLE9BQU92SSxZQUFZd0YsU0FBUyxxQkFBcUI0QixhQUFhb0IsT0FBT0MsTUFBTSxFQUFFLENBQUM7QUFBQSxRQUNuSUMsTUFBTTtBQUFBLFFBQ045RCxNQUFNO0FBQUEsUUFDTitELFFBQVE7QUFBQSxNQUNWLENBQUM7QUFFRG5JLDRCQUFzQixLQUFLO0FBQzNCRSx5QkFBbUIsSUFBSTtBQUFBLElBQ3pCLEdBQUcsSUFBSTtBQUFBLEVBQ1Q7QUFHQSxRQUFNLENBQUNrSSxTQUFTQyxVQUFVLElBQUkxTCxTQUFTLEVBQUU7QUFDekNDLFlBQVUsTUFBTTtBQUNkLFVBQU0wTCxhQUFhO0FBQUEsTUFDakJyRCxNQUFNckgsWUFBWXFIO0FBQUFBLE1BQ2xCQyxPQUFPdEgsWUFBWXNIO0FBQUFBLE1BQ25CRyxTQUFTaEY7QUFBQUEsTUFDVDhFLFFBQVFoRixXQUFXaUYsV0FBV2pGLFFBQVEsSUFBSTtBQUFBLElBQzVDO0FBQ0EsVUFBTW9JLGFBQWF6RCxLQUFLMEQsVUFBVUYsVUFBVTtBQUM1Q3ZMLFdBQU8wTCxVQUFVRixZQUFZLEVBQUVHLFFBQVEsR0FBRzVGLE9BQU8sSUFBSSxDQUFDLEVBQ25EcEMsS0FBSyxDQUFBaUksUUFBT04sV0FBV00sR0FBRyxDQUFDLEVBQzNCekgsTUFBTSxDQUFBQyxRQUFPQyxRQUFRQyxNQUFNLCtCQUErQkYsR0FBRyxDQUFDO0FBQUEsRUFDbkUsR0FBRyxDQUFDdkQsWUFBWXFILE1BQU1ySCxZQUFZc0gsT0FBTzdFLFdBQVdGLFFBQVEsQ0FBQztBQUc3RCxRQUFNeUksb0JBQW9CQSxNQUFNO0FBQzlCbkosbUJBQWUsSUFBSTtBQUNuQlMsdUJBQW1CLEtBQUs7QUFDeEJKLG9CQUFnQixFQUFFO0FBQ2xCLFFBQUk1QixpQkFBaUIsVUFBVUUsZUFBZSxVQUFVO0FBQ3REa0Qsa0JBQVk7QUFBQSxJQUNkO0FBQUEsRUFDRjtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGtCQUViO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGtCQUFpQixPQUFPLEVBQUV1SCxjQUFjLDhCQUE4QkMsZUFBZSxRQUFRQyxjQUFjLFNBQVMsR0FDakk7QUFBQSw2QkFBQyxTQUFJLFdBQVUsZUFBYyxPQUFPLEVBQUVBLGNBQWMsR0FBR0YsY0FBYyxPQUFPLEdBQzFFO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFdBQVcsY0FBYzNLLGlCQUFpQixTQUFTLFdBQVcsRUFBRTtBQUFBLFlBQ2hFLFNBQVMsTUFBTUMsZ0JBQWdCLE1BQU07QUFBQSxZQUVyQztBQUFBLHFDQUFDLFVBQU8sTUFBTSxJQUFJLE9BQU8sRUFBRTZLLGFBQWEsVUFBVUMsZUFBZSxTQUFTLEtBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFKOUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFXLGNBQWMvSyxpQkFBaUIsVUFBVSxXQUFXLEVBQUU7QUFBQSxZQUNqRSxTQUFTLE1BQU1DLGdCQUFnQixPQUFPO0FBQUEsWUFFdEM7QUFBQSxxQ0FBQyxVQUFPLE1BQU0sSUFBSSxPQUFPLEVBQUU2SyxhQUFhLFVBQVVDLGVBQWUsU0FBUyxLQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSjlFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsV0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZUE7QUFBQSxNQUVDL0ssaUJBQWlCLFVBQVVFLGVBQWUsWUFDekM7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFdBQVU7QUFBQSxVQUNWLFNBQVMsTUFBTWUsZ0JBQWdCLENBQUNELFlBQVk7QUFBQSxVQUM1QyxPQUFPQSxlQUFlLG9CQUFvQjtBQUFBLFVBQzFDLE9BQU8sRUFBRXdKLFFBQVEsR0FBR1EsU0FBUyxVQUFVQyxZQUFZLG1CQUFtQkMsY0FBYyxNQUFNO0FBQUEsVUFFekZsSyx5QkFBZSx1QkFBQyxXQUFRLE1BQU0sTUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrQixJQUFNLHVCQUFDLFdBQVEsTUFBTSxNQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtCO0FBQUE7QUFBQSxRQU41RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFPQTtBQUFBLFNBMUJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E0QkE7QUFBQSxJQUVDaEIsaUJBQWlCLFNBQ2hCLHVCQUFDLFNBQUksV0FBVSx5QkFFYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxTQUNiLGlDQUFDLFNBQUksV0FBVSxTQUFRLE9BQU8sRUFBRW1MLFdBQVcsU0FBU0MsU0FBUyxRQUFRQyxlQUFlLFVBQVVDLFlBQVksVUFBVUMsZ0JBQWdCLFVBQVVDLFVBQVUsWUFBWUMsVUFBVSxTQUFTLEdBR3JMO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVcsc0JBQXNCdkwsZUFBZSxXQUFXLFdBQVcsRUFBRTtBQUFBLGNBQ3hFLFNBQVMsTUFBTTtBQUFFQyw4QkFBYyxRQUFRO0FBQUdVLDZCQUFhLEVBQUU7QUFBQSxjQUFHO0FBQUEsY0FBRTtBQUFBO0FBQUEsWUFGaEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFXLHNCQUFzQlgsZUFBZSxXQUFXLFdBQVcsRUFBRTtBQUFBLGNBQ3hFLFNBQVMsTUFBTTtBQUFFQyw4QkFBYyxRQUFRO0FBQUdrRCwyQkFBVztBQUFHeEMsNkJBQWEsRUFBRTtBQUFBLGNBQUc7QUFBQSxjQUFFO0FBQUE7QUFBQSxZQUY5RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLFVBRUNYLGVBQWUsWUFBWU0sUUFBUXNDLFNBQVMsS0FDM0M7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLE9BQU9wQztBQUFBQSxjQUNQLFVBQVUsQ0FBQzhGLE1BQU03RixrQkFBa0I2RixFQUFFZ0IsT0FBT2tFLEtBQUs7QUFBQSxjQUVoRGxMLGtCQUFRbUw7QUFBQUEsZ0JBQUksQ0FBQy9JLFFBQVFnSixRQUNwQix1QkFBQyxZQUE2QixPQUFPaEosT0FBT0csVUFBUztBQUFBO0FBQUEsa0JBQzNDNkksTUFBTTtBQUFBLGtCQUFFO0FBQUEsa0JBQUdoSixPQUFPaUosTUFBTTlCLE1BQU0sR0FBRyxFQUFFLEtBQUs7QUFBQSxrQkFBUztBQUFBLHFCQUQ5Q25ILE9BQU9HLFVBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxjQUNEO0FBQUE7QUFBQSxZQVRIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVVBO0FBQUEsYUF6Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTJCQTtBQUFBLFFBRUM3QyxlQUFlLFdBQ2QsdUJBQUMsU0FBSSxXQUFVLG1CQUViO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHlCQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHdCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9DO0FBQUEsWUFDcEMsdUJBQUMsU0FBSSxXQUFVLDJCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVDO0FBQUEsWUFDdkMsdUJBQUMsU0FBSSxXQUFVLDRCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdDO0FBQUEsWUFDeEMsdUJBQUMsU0FBSSxXQUFVLDhCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBDO0FBQUEsWUFDMUMsdUJBQUMsU0FBSSxXQUFVLCtCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJDO0FBQUEsZUFMN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLFVBRUEsdUJBQUMsV0FBTSxLQUFLZ0IsVUFBVSxXQUFVLHFCQUFvQixhQUFXLFFBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStEO0FBQUEsVUFDL0QsdUJBQUMsWUFBTyxLQUFLQyxXQUFXLE9BQU8sRUFBRWlLLFNBQVMsT0FBTyxLQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRDtBQUFBLFVBRWxELENBQUM5SyxnQkFBZ0IsQ0FBQ00sYUFDakIsdUJBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHFCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlDO0FBQUEsWUFDakMsdUJBQUMsVUFBSyxPQUFPLEVBQUVrTCxXQUFXLFFBQVFDLFVBQVUsVUFBVUMsT0FBTyx3QkFBd0IsR0FBRyx1Q0FBeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0c7QUFBQSxlQUZqSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFqQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1CQTtBQUFBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2IsaUNBQUMsV0FBTSxTQUFRLGtCQUFpQixXQUFVLGtCQUN4QztBQUFBLG1DQUFDLFNBQUksV0FBVSxzQkFDYixpQ0FBQyxVQUFPLE1BQU0sTUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpQixLQURuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxRQUFHLHNDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBCO0FBQUEsWUFDMUIsdUJBQUMsT0FBRSw0REFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErQztBQUFBLFlBQy9DLHVCQUFDLFVBQUssV0FBVSxzQkFBcUIsdUNBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTREO0FBQUEsWUFDNUQ7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsSUFBRztBQUFBLGdCQUNILFFBQU87QUFBQSxnQkFDUCxPQUFPLEVBQUVaLFNBQVMsT0FBTztBQUFBLGdCQUN6QixVQUFVOUQ7QUFBQUE7QUFBQUEsY0FMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLNkI7QUFBQSxlQVovQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWNBLEtBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQkE7QUFBQTtBQUFBLFFBSUYsdUJBQUMsU0FBSSxXQUFVLHlCQUF3QixPQUFPMUcsWUFBWSxFQUFFcUssWUFBWSwwQkFBMEJlLE9BQU8sVUFBVSxJQUFJLENBQUMsR0FDckhwTCxzQkFDQyx1QkFBQyxTQUFJLE9BQU8sRUFBRXdLLFNBQVMsUUFBUUUsWUFBWSxVQUFVVyxLQUFLLFNBQVMsR0FDakU7QUFBQSxpQ0FBQyxlQUFZLE1BQU0sTUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0I7QUFBQSxVQUN0Qix1QkFBQyxVQUFNckwsdUJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUI7QUFBQSxhQUZuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0EsSUFFQSx1QkFBQyxVQUFNRSx5QkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1CLEtBUHZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFdBcEZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFzRkEsS0F2RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXdGQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2IsaUNBQUMsU0FBSSxXQUFVLFNBQVEsT0FBTyxFQUFFcUssV0FBVyxTQUFTSCxTQUFTLE9BQU8sR0FDbEU7QUFBQSwrQkFBQyxTQUFJLE9BQU8sRUFBRUksU0FBUyxRQUFRRSxZQUFZLFVBQVVXLEtBQUssVUFBVXBCLGNBQWMsVUFBVSxHQUMxRjtBQUFBLGlDQUFDLFlBQVMsTUFBTSxJQUFJLE9BQU0sMkJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlEO0FBQUEsVUFDakQsdUJBQUMsUUFBRyxXQUFVLGlCQUFnQixPQUFPLEVBQUVMLFFBQVEsRUFBRSxHQUFHLDJCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRDtBQUFBLGFBRmpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsT0FBRSxPQUFPLEVBQUV3QixPQUFPLFdBQVdELFVBQVUsVUFBVUcsWUFBWSxPQUFPckIsY0FBYyxTQUFTLEdBQUUsNEtBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsY0FBYSxpQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkI7QUFBQSxZQUM3Qix1QkFBQyxTQUNDO0FBQUEscUNBQUMsUUFBRyxrQ0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzQjtBQUFBLGNBQ3RCLHVCQUFDLE9BQUUsc0dBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUY7QUFBQSxpQkFGM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLGVBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsY0FBYSxpQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkI7QUFBQSxZQUM3Qix1QkFBQyxTQUNDO0FBQUEscUNBQUMsUUFBRyw4QkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrQjtBQUFBLGNBQ2xCLHVCQUFDLE9BQUUsOEZBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUY7QUFBQSxpQkFGbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLGVBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsY0FBYSxpQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkI7QUFBQSxZQUM3Qix1QkFBQyxTQUNDO0FBQUEscUNBQUMsUUFBRyxtQ0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1QjtBQUFBLGNBQ3ZCLHVCQUFDLE9BQUUseUdBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEY7QUFBQSxpQkFGOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLGVBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLGFBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzQkE7QUFBQSxXQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0NBLEtBakNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrQ0E7QUFBQSxTQS9IRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0lBO0FBQUE7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSx5QkFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxTQUNiLGlDQUFDLFNBQUksV0FBVSxTQUFRLE9BQU8sRUFBRU0sV0FBVyxTQUFTQyxTQUFTLFFBQVFDLGVBQWUsVUFBVUMsWUFBWSxVQUFVQyxnQkFBZ0IsVUFBVVAsU0FBUyxTQUFTLEdBRzlKO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHVCQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHNCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtDO0FBQUEsWUFDbEMsdUJBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLGFBQVksT0FBTyxFQUFFcEcsT0FBTyxRQUFRRSxRQUFRLE9BQU8sR0FDaEUsaUNBQUMsU0FBSSxPQUFNLE1BQUssUUFBTyxNQUFLLFNBQVEsYUFBWSxNQUFLLFFBQ25ELGlDQUFDLFVBQUssR0FBRSw4QkFBNkIsTUFBSyxTQUFRLFFBQU8sU0FBUSxhQUFZLE9BQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdGLEtBRGxGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsY0FDQSx1QkFBQyxVQUFLLHlCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWU7QUFBQSxpQkFOakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLHdCQUF1QixPQUFPLEVBQUVxSCxVQUFVLFNBQVNoQixXQUFXLFFBQVEsR0FDbEZqQixvQkFDQyx1QkFBQyxTQUFJLEtBQUtBLFNBQVMsS0FBSSxjQUFhLFdBQVUsd0JBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtFLElBRWxFLHVCQUFDLFNBQUksV0FBVSxtQkFBa0IsT0FBTyxFQUFFdEYsT0FBTyxRQUFRRSxRQUFRLE9BQU8sS0FBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkUsS0FKL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFNQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUEscUNBQUMsU0FDQztBQUFBLHVDQUFDLFNBQUksV0FBVSx1QkFBc0IsOEJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW1EO0FBQUEsZ0JBQ25ELHVCQUFDLFNBQUksV0FBVSx1QkFBdUJwRixzQkFBWXFILFFBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVEO0FBQUEsbUJBRnpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNDOUUsWUFDQyx1QkFBQyxTQUFJLE9BQU8sRUFBRW1LLFdBQVcsUUFBUSxHQUMvQjtBQUFBLHVDQUFDLFNBQUksV0FBVSx1QkFBc0IsZ0NBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFEO0FBQUEsZ0JBQ3JELHVCQUFDLFNBQUksV0FBVSx1QkFBc0IsT0FBTyxFQUFFSixPQUFPLGlCQUFpQixHQUFHO0FBQUE7QUFBQSxrQkFBRTlFLFdBQVdqRixRQUFRLEVBQUU0SCxlQUFlO0FBQUEscUJBQS9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlIO0FBQUEsbUJBRm5IO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxpQkFUSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVdBO0FBQUEsZUE5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkErQkE7QUFBQSxVQUVBLHVCQUFDLFNBQUksT0FBTyxFQUFFaUMsV0FBVyxVQUFVVixTQUFTLFFBQVFhLEtBQUssT0FBTyxHQUM5RCxpQ0FBQyxPQUFFLE1BQU0vQixTQUFTLFFBQU8sVUFBUyxLQUFJLGNBQWEsVUFBVSxlQUFleEssWUFBWXFILElBQUksUUFBUSxXQUFVLHFCQUFvQixPQUFPLEVBQUVzRixnQkFBZ0IsUUFBUWpCLFNBQVMsUUFBUUUsWUFBWSxVQUFVVyxLQUFLLFVBQVVqQixTQUFTLGlCQUFpQlIsUUFBUSxFQUFFLEdBQzNQO0FBQUEsbUNBQUMsWUFBUyxNQUFNLE1BQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1CO0FBQUE7QUFBQSxlQURyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLGFBekNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEyQ0EsS0E1Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTZDQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLFNBQ2IsaUNBQUMsU0FBSSxXQUFVLFNBQVEsT0FBTyxFQUFFVyxXQUFXLFNBQVNILFNBQVMsT0FBTyxHQUNsRTtBQUFBLGlDQUFDLFFBQUcsV0FBVSxpQkFBZ0IsT0FBTyxFQUFFSCxjQUFjLFVBQVUsR0FBRyxvQ0FBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0Y7QUFBQSxVQUN0Rix1QkFBQyxPQUFFLE9BQU8sRUFBRW1CLE9BQU8sV0FBV0QsVUFBVSxVQUFVRyxZQUFZLE9BQU9yQixjQUFjLFNBQVMsR0FBRSx1SEFBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBRUEsdUJBQUMsVUFBSyxXQUFVLHNCQUFxQixVQUFVLENBQUNyRSxNQUFNQSxFQUFFOEIsZUFBZSxHQUNyRTtBQUFBLG1DQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLHFDQUFDLFdBQU0sMkNBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0M7QUFBQSxjQUNsQztBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsV0FBVTtBQUFBLGtCQUNWLGFBQVk7QUFBQSxrQkFDWixPQUFPckc7QUFBQUEsa0JBQ1AsVUFBVSxDQUFDdUUsTUFBTXRFLFlBQVlzRSxFQUFFZ0IsT0FBT2tFLEtBQUs7QUFBQTtBQUFBLGdCQUw3QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLK0M7QUFBQSxpQkFQakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFTQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEscUNBQUMsV0FBTSx1Q0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4QjtBQUFBLGNBQzlCO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ1YsYUFBWTtBQUFBLGtCQUNaLE9BQU92SjtBQUFBQSxrQkFDUCxVQUFVLENBQUNxRSxNQUFNcEUsYUFBYW9FLEVBQUVnQixPQUFPa0UsS0FBSztBQUFBO0FBQUEsZ0JBTDlDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtnRDtBQUFBLGlCQVBsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVNBO0FBQUEsZUFyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFzQkE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxpQkFBZ0IsT0FBTyxFQUFFSSxXQUFXLFVBQVVkLFNBQVMsUUFBUUMsWUFBWSw0QkFBNEJDLGNBQWMsUUFBUW9CLFFBQVEsb0NBQW9DLEdBQ3RMLGlDQUFDLFNBQUksT0FBTyxFQUFFbEIsU0FBUyxRQUFRYSxLQUFLLFVBQVVYLFlBQVksYUFBYSxHQUNyRTtBQUFBLG1DQUFDLFVBQU8sTUFBTSxJQUFJLE9BQU0seUJBQXdCLE9BQU8sRUFBRWlCLFlBQVksR0FBR1QsV0FBVyxTQUFTLEtBQTVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThGO0FBQUEsWUFDOUYsdUJBQUMsVUFBSyxPQUFPLEVBQUVDLFVBQVUsVUFBVUMsT0FBTyxXQUFXUSxZQUFZLEtBQUtOLFlBQVksTUFBTSxHQUFFLG9JQUExRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLGFBckNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzQ0EsS0F2Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdDQTtBQUFBLFdBeEZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF5RkE7QUFBQTtBQUFBLElBSUQ1SyxlQUNDLHVCQUFDLFNBQUksV0FBVSwyQkFDYixpQ0FBQyxTQUFJLFdBQVUsNEJBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSwrQkFBQyxTQUFJLE9BQU8sRUFBRThKLFNBQVMsUUFBUUUsWUFBWSxVQUFVVyxLQUFLLFVBQVUsR0FDbEU7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsdUJBQ2IsaUNBQUMsa0JBQWUsTUFBTSxNQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5QixLQUQzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsUUFBRyxPQUFPLEVBQUV6QixRQUFRLEdBQUd3QixPQUFPLFdBQVdELFVBQVUsVUFBVVMsWUFBWSxJQUFJLEdBQUcsbUNBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9HO0FBQUEsWUFDcEcsdUJBQUMsT0FBRSxPQUFPLEVBQUVoQyxRQUFRLEdBQUd1QixVQUFVLFdBQVdDLE9BQU8sVUFBVSxHQUFHLHdFQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3SDtBQUFBLGVBRjFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBQ0EsdUJBQUMsWUFBTyxXQUFVLG9CQUFtQixTQUFTdEIsbUJBQzVDLGlDQUFDLEtBQUUsTUFBTSxNQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBWSxLQURkO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUEsTUFFQzNJLGtCQUNDLHVCQUFDLFNBQUksV0FBVSx1QkFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSx1QkFDYixpQ0FBQyxTQUFNLE1BQU0sSUFBSSxPQUFNLFNBQVEsYUFBYSxLQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThDLEtBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsUUFBRyxvQ0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdCO0FBQUEsUUFDeEIsdUJBQUMsT0FBRTtBQUFBO0FBQUEsVUFBSyx1QkFBQyxPQUFFO0FBQUE7QUFBQSxZQUFFbUYsV0FBV3ZGLFlBQVksRUFBRWtJLGVBQWU7QUFBQSxlQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErQztBQUFBLFVBQUk7QUFBQSxVQUFJLHVCQUFDLE9BQUd2SSxzQkFBWXdGLGFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBCO0FBQUEsYUFBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2RjtBQUFBLFFBQzdGLHVCQUFDLFlBQU8sV0FBVSxxQkFBb0IsT0FBTyxFQUFFMEQsUUFBUSxlQUFlLEdBQUcsU0FBU0UsbUJBQWtCLG9CQUFwRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQSxJQUVBLHVCQUFDLFVBQUssVUFBVXJDLHNCQUFzQixXQUFVLHVCQUc5QztBQUFBLCtCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLG1DQUFDLFVBQUssV0FBVSxPQUFNLHlCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErQjtBQUFBLFlBQy9CLHVCQUFDLFVBQUssV0FBVSxPQUFNLE9BQU8sRUFBRW1FLFlBQVksSUFBSSxHQUFJbEwsc0JBQVl3RixhQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5RTtBQUFBLGVBRjNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLG1DQUFDLFVBQUssV0FBVSxPQUFNLCtCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxQztBQUFBLFlBQ3JDLHVCQUFDLFVBQUssV0FBVSxPQUFNLE9BQU8sRUFBRWtGLE9BQU8sVUFBVSxHQUFJMUssc0JBQVkwRixTQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRTtBQUFBLGVBRnhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNDMUYsWUFBWTZGLFdBQ1gsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsbUNBQUMsVUFBSyxXQUFVLE9BQU0sdUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZCO0FBQUEsWUFDN0IsdUJBQUMsVUFBSyxXQUFVLE9BQU0sT0FBTyxFQUFFc0YsV0FBVyxTQUFTLEdBQUluTCxzQkFBWTZGLFdBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJFO0FBQUEsZUFGN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBYko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWVBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSxpQ0FBQyxXQUFNLE9BQU8sRUFBRTRFLFVBQVUsV0FBV1MsWUFBWSxJQUFJLEdBQUcseUNBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlGO0FBQUEsVUFDakY7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLE9BQU9oTDtBQUFBQSxjQUNQLFVBQVUsQ0FBQ2dGLE1BQU0vRSxrQkFBa0IrRSxFQUFFZ0IsT0FBT2tFLEtBQUs7QUFBQSxjQUNqRCxVQUFRO0FBQUEsY0FFUC9MLGdCQUFNZ007QUFBQUEsZ0JBQUksQ0FBQWUsU0FDVCx1QkFBQyxZQUFxQixPQUFPQSxLQUFLaEwsSUFDL0JnTDtBQUFBQSx1QkFBS3hHLEtBQUt5RyxZQUFZO0FBQUEsa0JBQUU7QUFBQSxrQkFBY0QsS0FBSzVDLE9BQU9DLE1BQU0sRUFBRTtBQUFBLGtCQUFFO0FBQUEsa0JBQVMyQyxLQUFLN0QsUUFBUWdCLGVBQWU7QUFBQSxrQkFBRTtBQUFBLHFCQUR6RjZDLEtBQUtoTCxJQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsY0FDRDtBQUFBO0FBQUEsWUFWSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFXQTtBQUFBLGFBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSxpQ0FBQyxXQUFNLE9BQU8sRUFBRXFLLFVBQVUsV0FBV1MsWUFBWSxJQUFJLEdBQUcsbUNBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJFO0FBQUEsVUFDM0U7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQSxjQUNWLGFBQVk7QUFBQSxjQUNaLE9BQU83SztBQUFBQSxjQUNQLFVBQVUsQ0FBQzZFLE1BQU01RSxnQkFBZ0I0RSxFQUFFZ0IsT0FBT2tFLEtBQUs7QUFBQSxjQUMvQyxVQUFVcEssWUFBWTJGLFdBQVc7QUFBQSxjQUNqQztBQUFBLGNBQ0EsTUFBSztBQUFBO0FBQUEsWUFSUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRYTtBQUFBLFVBRVozRixZQUFZMkYsV0FBVyxRQUN0Qix1QkFBQyxVQUFLLFdBQVUscUJBQW9CLGlEQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRTtBQUFBLGFBYnpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxPQUFPLEVBQUU2RSxXQUFXLFNBQVMsR0FDaEM7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFdBQVU7QUFBQSxZQUNWLE9BQU8sRUFBRWxILE9BQU8sUUFBUTRGLFFBQVEsR0FBR1EsU0FBUyxRQUFRSSxTQUFTLFFBQVFHLGdCQUFnQixVQUFVVSxLQUFLLFNBQVM7QUFBQSxZQUM3RyxVQUFVcEs7QUFBQUEsWUFFVEEsK0JBQ0MsbUNBQ0U7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsbUJBQWtCLE9BQU8sRUFBRStDLE9BQU8sUUFBUUUsUUFBUSxRQUFROEgsYUFBYSxPQUFPQyxhQUFhLFFBQVEsS0FBbEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUg7QUFBQSxjQUFLO0FBQUEsaUJBRDVIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0EsSUFFQSxtQ0FDRTtBQUFBLHFDQUFDLGtCQUFlLE1BQU0sTUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUI7QUFBQTtBQUFBLGNBQ1IzRixXQUFXdkYsZ0JBQWdCLENBQUMsRUFBRWtJLGVBQWU7QUFBQSxpQkFGaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBO0FBQUEsVUFmSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFpQkEsS0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1CQTtBQUFBLFdBM0VGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE2RUE7QUFBQSxTQXpHSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNEdBLEtBN0dGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4R0E7QUFBQSxPQWhYSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbVhBO0FBRUo7QUFBRTlKLEdBanFCSU4sY0FBWTtBQUFBLEtBQVpBO0FBbXFCTixlQUFlQTtBQUFhLElBQUFxTjtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInVzZVJlZiIsImpzUVIiLCJRUkNvZGUiLCJDYW1lcmEiLCJVcGxvYWQiLCJRckNvZGUiLCJBcnJvd0xlZnRSaWdodCIsIkNoZWNrIiwiWCIsIlNoaWVsZEFsZXJ0IiwiU3BhcmtsZXMiLCJEb3dubG9hZCIsIlZvbHVtZTIiLCJWb2x1bWVYIiwiUXJTY2FubmVyVGFiIiwidXNlclNlc3Npb24iLCJjYXJkcyIsIm9uQWRkVHJhbnNhY3Rpb24iLCJvblVwZGF0ZUNhcmRCYWxhbmNlIiwib25BZGROb3RpZmljYXRpb24iLCJfcyIsImFjdGl2ZVN1YlRhYiIsInNldEFjdGl2ZVN1YlRhYiIsInNjYW5NZXRob2QiLCJzZXRTY2FuTWV0aG9kIiwiaGFzQ2FtZXJhIiwic2V0SGFzQ2FtZXJhIiwiY2FtZXJhQWN0aXZlIiwic2V0Q2FtZXJhQWN0aXZlIiwiZGV2aWNlcyIsInNldERldmljZXMiLCJzZWxlY3RlZERldmljZSIsInNldFNlbGVjdGVkRGV2aWNlIiwic2NhbkVycm9yIiwic2V0U2NhbkVycm9yIiwic2Nhbk1lc3NhZ2UiLCJzZXRTY2FuTWVzc2FnZSIsInNvdW5kRW5hYmxlZCIsInNldFNvdW5kRW5hYmxlZCIsInZpZGVvUmVmIiwiY2FudmFzUmVmIiwic3RyZWFtUmVmIiwiYW5pbWF0aW9uRnJhbWVSZWYiLCJwYXltZW50RGF0YSIsInNldFBheW1lbnREYXRhIiwic2VsZWN0ZWRDYXJkSWQiLCJzZXRTZWxlY3RlZENhcmRJZCIsImlkIiwiY3VzdG9tQW1vdW50Iiwic2V0Q3VzdG9tQW1vdW50IiwidHJhbnNmZXJJblByb2dyZXNzIiwic2V0VHJhbnNmZXJJblByb2dyZXNzIiwidHJhbnNmZXJTdWNjZXNzIiwic2V0VHJhbnNmZXJTdWNjZXNzIiwicXJBbW91bnQiLCJzZXRRckFtb3VudCIsInFyUHVycG9zZSIsInNldFFyUHVycG9zZSIsIm5hdmlnYXRvciIsIm1lZGlhRGV2aWNlcyIsImVudW1lcmF0ZURldmljZXMiLCJ0aGVuIiwiZGV2aWNlTGlzdCIsInZpZGVvRGV2aWNlcyIsImZpbHRlciIsImRldmljZSIsImtpbmQiLCJsZW5ndGgiLCJkZXZpY2VJZCIsImNhdGNoIiwiZXJyIiwiY29uc29sZSIsImVycm9yIiwic3RhcnRDYW1lcmEiLCJzdG9wQ2FtZXJhIiwiY29uc3RyYWludHMiLCJ2aWRlbyIsImV4YWN0IiwidW5kZWZpbmVkIiwic3RyZWFtIiwiZ2V0VXNlck1lZGlhIiwiY3VycmVudCIsInNyY09iamVjdCIsInNldEF0dHJpYnV0ZSIsInBsYXkiLCJyZXF1ZXN0QW5pbWF0aW9uRnJhbWUiLCJzY2FuRnJhbWUiLCJjYW5jZWxBbmltYXRpb25GcmFtZSIsImdldFRyYWNrcyIsImZvckVhY2giLCJ0cmFjayIsInN0b3AiLCJyZWFkeVN0YXRlIiwiSEFWRV9FTk9VR0hfREFUQSIsImNhbnZhcyIsImN0eCIsImdldENvbnRleHQiLCJ3aWR0aCIsInZpZGVvV2lkdGgiLCJoZWlnaHQiLCJ2aWRlb0hlaWdodCIsImRyYXdJbWFnZSIsImltYWdlRGF0YSIsImdldEltYWdlRGF0YSIsImNvZGUiLCJkYXRhIiwiaW52ZXJzaW9uQXR0ZW1wdHMiLCJoYW5kbGVEZWNvZGVkRGF0YSIsInBsYXlCZWVwIiwiYXVkaW9DdHgiLCJ3aW5kb3ciLCJBdWRpb0NvbnRleHQiLCJ3ZWJraXRBdWRpb0NvbnRleHQiLCJvc2NpbGxhdG9yIiwiY3JlYXRlT3NjaWxsYXRvciIsImdhaW5Ob2RlIiwiY3JlYXRlR2FpbiIsImNvbm5lY3QiLCJkZXN0aW5hdGlvbiIsInR5cGUiLCJmcmVxdWVuY3kiLCJzZXRWYWx1ZUF0VGltZSIsImN1cnJlbnRUaW1lIiwiZ2FpbiIsInN0YXJ0IiwiZSIsIndhcm4iLCJkYXRhU3RyIiwicGFyc2VkIiwiSlNPTiIsInBhcnNlIiwicmVjaXBpZW50IiwibmFtZSIsImVtYWlsIiwiYW1vdW50IiwicGFyc2VGbG9hdCIsInB1cnBvc2UiLCJ0b1N0cmluZyIsImluY2x1ZGVzIiwiaGFuZGxlRmlsZVVwbG9hZCIsImZpbGUiLCJ0YXJnZXQiLCJmaWxlcyIsInJlYWRlciIsIkZpbGVSZWFkZXIiLCJvbmxvYWQiLCJldmVudCIsImltZyIsIkltYWdlIiwiZG9jdW1lbnQiLCJjcmVhdGVFbGVtZW50Iiwic3JjIiwicmVzdWx0IiwicmVhZEFzRGF0YVVSTCIsImhhbmRsZUNvbmZpcm1QYXltZW50IiwicHJldmVudERlZmF1bHQiLCJhbW91bnRWYWwiLCJpc05hTiIsImFsZXJ0Iiwic2VsZWN0ZWRDYXJkIiwiZmluZCIsImMiLCJiYWxhbmNlIiwic2V0VGltZW91dCIsInR4SWQiLCJNYXRoIiwiZmxvb3IiLCJyYW5kb20iLCJkZXNjIiwiZGF0ZSIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsInNwbGl0IiwibWV0aG9kIiwiY2F0ZWdvcnkiLCJzdGF0dXMiLCJub3ciLCJ0ZXh0IiwidG9Mb2NhbGVTdHJpbmciLCJudW1iZXIiLCJzbGljZSIsInRpbWUiLCJ1bnJlYWQiLCJteVFyVXJsIiwic2V0TXlRclVybCIsIm15UXJPYmplY3QiLCJteVFyU3RyaW5nIiwic3RyaW5naWZ5IiwidG9EYXRhVVJMIiwibWFyZ2luIiwidXJsIiwiaGFuZGxlQ2xvc2VEcmF3ZXIiLCJib3JkZXJCb3R0b20iLCJwYWRkaW5nQm90dG9tIiwibWFyZ2luQm90dG9tIiwibWFyZ2luUmlnaHQiLCJ2ZXJ0aWNhbEFsaWduIiwicGFkZGluZyIsImJhY2tncm91bmQiLCJib3JkZXJSYWRpdXMiLCJtaW5IZWlnaHQiLCJkaXNwbGF5IiwiZmxleERpcmVjdGlvbiIsImFsaWduSXRlbXMiLCJqdXN0aWZ5Q29udGVudCIsInBvc2l0aW9uIiwib3ZlcmZsb3ciLCJ2YWx1ZSIsIm1hcCIsImlkeCIsImxhYmVsIiwibWFyZ2luVG9wIiwiZm9udFNpemUiLCJjb2xvciIsImdhcCIsImxpbmVIZWlnaHQiLCJtaW5XaWR0aCIsInRleHRBbGlnbiIsInRleHREZWNvcmF0aW9uIiwiYm9yZGVyIiwiZmxleFNocmluayIsImZvbnRXZWlnaHQiLCJmb250U3R5bGUiLCJjYXJkIiwidG9VcHBlckNhc2UiLCJib3JkZXJXaWR0aCIsImJvcmRlckNvbG9yIiwiX2MiXSwic291cmNlcyI6WyJRclNjYW5uZXJUYWIuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZVJlZiB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCBqc1FSIGZyb20gJ2pzcXInO1xuaW1wb3J0IFFSQ29kZSBmcm9tICdxcmNvZGUnO1xuaW1wb3J0IHsgQ2FtZXJhLCBVcGxvYWQsIFFyQ29kZSwgQXJyb3dMZWZ0UmlnaHQsIENoZWNrLCBYLCBTaGllbGRBbGVydCwgU3BhcmtsZXMsIERvd25sb2FkLCBWb2x1bWUyLCBWb2x1bWVYIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcblxuY29uc3QgUXJTY2FubmVyVGFiID0gKHsgdXNlclNlc3Npb24sIGNhcmRzLCBvbkFkZFRyYW5zYWN0aW9uLCBvblVwZGF0ZUNhcmRCYWxhbmNlLCBvbkFkZE5vdGlmaWNhdGlvbiB9KSA9PiB7XG4gIGNvbnN0IFthY3RpdmVTdWJUYWIsIHNldEFjdGl2ZVN1YlRhYl0gPSB1c2VTdGF0ZSgnc2NhbicpOyAvLyAnc2NhbicgfCAnbXktcXInXG4gIGNvbnN0IFtzY2FuTWV0aG9kLCBzZXRTY2FuTWV0aG9kXSA9IHVzZVN0YXRlKCdjYW1lcmEnKTsgLy8gJ2NhbWVyYScgfCAndXBsb2FkJ1xuICBcbiAgLy8gQ2FtZXJhIHNjYW5uaW5nIHN0YXRlc1xuICBjb25zdCBbaGFzQ2FtZXJhLCBzZXRIYXNDYW1lcmFdID0gdXNlU3RhdGUodHJ1ZSk7XG4gIGNvbnN0IFtjYW1lcmFBY3RpdmUsIHNldENhbWVyYUFjdGl2ZV0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtkZXZpY2VzLCBzZXREZXZpY2VzXSA9IHVzZVN0YXRlKFtdKTtcbiAgY29uc3QgW3NlbGVjdGVkRGV2aWNlLCBzZXRTZWxlY3RlZERldmljZV0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtzY2FuRXJyb3IsIHNldFNjYW5FcnJvcl0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtzY2FuTWVzc2FnZSwgc2V0U2Nhbk1lc3NhZ2VdID0gdXNlU3RhdGUoJ1JlYWR5IHRvIHNjYW4uIEFsaWduIHRoZSBRUiBjb2RlIGluIHRoZSBmcmFtZS4nKTtcbiAgY29uc3QgW3NvdW5kRW5hYmxlZCwgc2V0U291bmRFbmFibGVkXSA9IHVzZVN0YXRlKHRydWUpO1xuXG4gIC8vIFZpZGVvIGFuZCBDYW52YXMgcmVmc1xuICBjb25zdCB2aWRlb1JlZiA9IHVzZVJlZihudWxsKTtcbiAgY29uc3QgY2FudmFzUmVmID0gdXNlUmVmKG51bGwpO1xuICBjb25zdCBzdHJlYW1SZWYgPSB1c2VSZWYobnVsbCk7XG4gIGNvbnN0IGFuaW1hdGlvbkZyYW1lUmVmID0gdXNlUmVmKG51bGwpO1xuXG4gIC8vIFNjYW4gUmVzdWx0ICYgUGF5IERyYXdlclxuICBjb25zdCBbcGF5bWVudERhdGEsIHNldFBheW1lbnREYXRhXSA9IHVzZVN0YXRlKG51bGwpOyAvLyB7IHJlY2lwaWVudCwgYW1vdW50LCBlbWFpbCwgY2F0ZWdvcnkgfVxuICBjb25zdCBbc2VsZWN0ZWRDYXJkSWQsIHNldFNlbGVjdGVkQ2FyZElkXSA9IHVzZVN0YXRlKGNhcmRzWzBdPy5pZCB8fCAnJyk7XG4gIGNvbnN0IFtjdXN0b21BbW91bnQsIHNldEN1c3RvbUFtb3VudF0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFt0cmFuc2ZlckluUHJvZ3Jlc3MsIHNldFRyYW5zZmVySW5Qcm9ncmVzc10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFt0cmFuc2ZlclN1Y2Nlc3MsIHNldFRyYW5zZmVyU3VjY2Vzc10gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgLy8gTXkgUVIgc2V0dGluZ3NcbiAgY29uc3QgW3FyQW1vdW50LCBzZXRRckFtb3VudF0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtxclB1cnBvc2UsIHNldFFyUHVycG9zZV0gPSB1c2VTdGF0ZSgnUGVyc29uYWwgVHJhbnNmZXInKTtcblxuICAvLyBSZXF1ZXN0IGNhbWVyYXMgbGlzdFxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChhY3RpdmVTdWJUYWIgPT09ICdzY2FuJyAmJiBzY2FuTWV0aG9kID09PSAnY2FtZXJhJykge1xuICAgICAgbmF2aWdhdG9yLm1lZGlhRGV2aWNlcy5lbnVtZXJhdGVEZXZpY2VzKClcbiAgICAgICAgLnRoZW4oZGV2aWNlTGlzdCA9PiB7XG4gICAgICAgICAgY29uc3QgdmlkZW9EZXZpY2VzID0gZGV2aWNlTGlzdC5maWx0ZXIoZGV2aWNlID0+IGRldmljZS5raW5kID09PSAndmlkZW9pbnB1dCcpO1xuICAgICAgICAgIHNldERldmljZXModmlkZW9EZXZpY2VzKTtcbiAgICAgICAgICBpZiAodmlkZW9EZXZpY2VzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIHNldFNlbGVjdGVkRGV2aWNlKHZpZGVvRGV2aWNlc1swXS5kZXZpY2VJZCk7XG4gICAgICAgICAgICBzZXRIYXNDYW1lcmEodHJ1ZSk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHNldEhhc0NhbWVyYShmYWxzZSk7XG4gICAgICAgICAgICBzZXRTY2FuTWV0aG9kKCd1cGxvYWQnKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pXG4gICAgICAgIC5jYXRjaChlcnIgPT4ge1xuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBlbnVtZXJhdGluZyBkZXZpY2VzOlwiLCBlcnIpO1xuICAgICAgICAgIHNldEhhc0NhbWVyYShmYWxzZSk7XG4gICAgICAgICAgc2V0U2Nhbk1ldGhvZCgndXBsb2FkJyk7XG4gICAgICAgIH0pO1xuICAgIH1cbiAgfSwgW2FjdGl2ZVN1YlRhYiwgc2Nhbk1ldGhvZF0pO1xuXG4gIC8vIFN0YXJ0L3N0b3AgY2FtZXJhIGJhc2VkIG9uIHN0YXRlXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGFjdGl2ZVN1YlRhYiA9PT0gJ3NjYW4nICYmIHNjYW5NZXRob2QgPT09ICdjYW1lcmEnICYmIHNlbGVjdGVkRGV2aWNlKSB7XG4gICAgICBzdGFydENhbWVyYSgpO1xuICAgIH0gZWxzZSB7XG4gICAgICBzdG9wQ2FtZXJhKCk7XG4gICAgfVxuXG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHN0b3BDYW1lcmEoKTtcbiAgICB9O1xuICB9LCBbYWN0aXZlU3ViVGFiLCBzY2FuTWV0aG9kLCBzZWxlY3RlZERldmljZV0pO1xuXG4gIGNvbnN0IHN0YXJ0Q2FtZXJhID0gYXN5bmMgKCkgPT4ge1xuICAgIHNldFNjYW5FcnJvcignJyk7XG4gICAgc2V0Q2FtZXJhQWN0aXZlKGZhbHNlKTtcbiAgICBzdG9wQ2FtZXJhKCk7XG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgY29uc3RyYWludHMgPSB7XG4gICAgICAgIHZpZGVvOiB7IGRldmljZUlkOiBzZWxlY3RlZERldmljZSA/IHsgZXhhY3Q6IHNlbGVjdGVkRGV2aWNlIH0gOiB1bmRlZmluZWQgfVxuICAgICAgfTtcbiAgICAgIGNvbnN0IHN0cmVhbSA9IGF3YWl0IG5hdmlnYXRvci5tZWRpYURldmljZXMuZ2V0VXNlck1lZGlhKGNvbnN0cmFpbnRzKTtcbiAgICAgIHN0cmVhbVJlZi5jdXJyZW50ID0gc3RyZWFtO1xuICAgICAgaWYgKHZpZGVvUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgdmlkZW9SZWYuY3VycmVudC5zcmNPYmplY3QgPSBzdHJlYW07XG4gICAgICAgIHZpZGVvUmVmLmN1cnJlbnQuc2V0QXR0cmlidXRlKFwicGxheXNpbmxpbmVcIiwgXCJ0cnVlXCIpOyAvLyByZXF1aXJlZCB0byB0ZWxsIGlPUyBzYWZhcmkgd2UgZG9uJ3Qgd2FudCBmdWxsc2NyZWVuXG4gICAgICAgIHZpZGVvUmVmLmN1cnJlbnQucGxheSgpO1xuICAgICAgICBzZXRDYW1lcmFBY3RpdmUodHJ1ZSk7XG4gICAgICAgIGFuaW1hdGlvbkZyYW1lUmVmLmN1cnJlbnQgPSByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoc2NhbkZyYW1lKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJXZWJjYW0gYWNjZXNzIGZhaWxlZDpcIiwgZXJyKTtcbiAgICAgIHNldFNjYW5FcnJvcihcIlVuYWJsZSB0byBhY2Nlc3MgY2FtZXJhLiBQbGVhc2UgY2hlY2sgcGVybWlzc2lvbnMgb3IgdHJ5IGZpbGUgdXBsb2FkLlwiKTtcbiAgICAgIHNldFNjYW5NZXRob2QoJ3VwbG9hZCcpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBzdG9wQ2FtZXJhID0gKCkgPT4ge1xuICAgIGlmIChhbmltYXRpb25GcmFtZVJlZi5jdXJyZW50KSB7XG4gICAgICBjYW5jZWxBbmltYXRpb25GcmFtZShhbmltYXRpb25GcmFtZVJlZi5jdXJyZW50KTtcbiAgICAgIGFuaW1hdGlvbkZyYW1lUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgIH1cbiAgICBpZiAoc3RyZWFtUmVmLmN1cnJlbnQpIHtcbiAgICAgIHN0cmVhbVJlZi5jdXJyZW50LmdldFRyYWNrcygpLmZvckVhY2godHJhY2sgPT4gdHJhY2suc3RvcCgpKTtcbiAgICAgIHN0cmVhbVJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICB9XG4gICAgc2V0Q2FtZXJhQWN0aXZlKGZhbHNlKTtcbiAgfTtcblxuICAvLyBTY2FuIGZyYW1lIGJ5IHBhaW50aW5nIGl0IG9udG8gdmlydHVhbCBjYW52YXMgYW5kIGRlY29kaW5nXG4gIGNvbnN0IHNjYW5GcmFtZSA9ICgpID0+IHtcbiAgICBpZiAodmlkZW9SZWYuY3VycmVudCAmJiB2aWRlb1JlZi5jdXJyZW50LnJlYWR5U3RhdGUgPT09IHZpZGVvUmVmLmN1cnJlbnQuSEFWRV9FTk9VR0hfREFUQSkge1xuICAgICAgY29uc3QgY2FudmFzID0gY2FudmFzUmVmLmN1cnJlbnQ7XG4gICAgICBpZiAoY2FudmFzKSB7XG4gICAgICAgIGNvbnN0IGN0eCA9IGNhbnZhcy5nZXRDb250ZXh0KCcyZCcpO1xuICAgICAgICBjYW52YXMud2lkdGggPSB2aWRlb1JlZi5jdXJyZW50LnZpZGVvV2lkdGg7XG4gICAgICAgIGNhbnZhcy5oZWlnaHQgPSB2aWRlb1JlZi5jdXJyZW50LnZpZGVvSGVpZ2h0O1xuICAgICAgICBcbiAgICAgICAgY3R4LmRyYXdJbWFnZSh2aWRlb1JlZi5jdXJyZW50LCAwLCAwLCBjYW52YXMud2lkdGgsIGNhbnZhcy5oZWlnaHQpO1xuICAgICAgICBjb25zdCBpbWFnZURhdGEgPSBjdHguZ2V0SW1hZ2VEYXRhKDAsIDAsIGNhbnZhcy53aWR0aCwgY2FudmFzLmhlaWdodCk7XG4gICAgICAgIGNvbnN0IGNvZGUgPSBqc1FSKGltYWdlRGF0YS5kYXRhLCBpbWFnZURhdGEud2lkdGgsIGltYWdlRGF0YS5oZWlnaHQsIHtcbiAgICAgICAgICBpbnZlcnNpb25BdHRlbXB0czogXCJkb250SW52ZXJ0XCIsXG4gICAgICAgIH0pO1xuXG4gICAgICAgIGlmIChjb2RlKSB7XG4gICAgICAgICAgaGFuZGxlRGVjb2RlZERhdGEoY29kZS5kYXRhKTtcbiAgICAgICAgICByZXR1cm47IC8vIHN0b3AgbG9vcFxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChhY3RpdmVTdWJUYWIgPT09ICdzY2FuJyAmJiBzY2FuTWV0aG9kID09PSAnY2FtZXJhJykge1xuICAgICAgYW5pbWF0aW9uRnJhbWVSZWYuY3VycmVudCA9IHJlcXVlc3RBbmltYXRpb25GcmFtZShzY2FuRnJhbWUpO1xuICAgIH1cbiAgfTtcblxuICAvLyBCZWVwIFNvdW5kIGZvciBzY2FuIHN1Y2Nlc3NcbiAgY29uc3QgcGxheUJlZXAgPSAoKSA9PiB7XG4gICAgaWYgKCFzb3VuZEVuYWJsZWQpIHJldHVybjtcbiAgICB0cnkge1xuICAgICAgY29uc3QgYXVkaW9DdHggPSBuZXcgKHdpbmRvdy5BdWRpb0NvbnRleHQgfHwgd2luZG93LndlYmtpdEF1ZGlvQ29udGV4dCkoKTtcbiAgICAgIGNvbnN0IG9zY2lsbGF0b3IgPSBhdWRpb0N0eC5jcmVhdGVPc2NpbGxhdG9yKCk7XG4gICAgICBjb25zdCBnYWluTm9kZSA9IGF1ZGlvQ3R4LmNyZWF0ZUdhaW4oKTtcbiAgICAgIG9zY2lsbGF0b3IuY29ubmVjdChnYWluTm9kZSk7XG4gICAgICBnYWluTm9kZS5jb25uZWN0KGF1ZGlvQ3R4LmRlc3RpbmF0aW9uKTtcbiAgICAgIG9zY2lsbGF0b3IudHlwZSA9ICdzaW5lJztcbiAgICAgIG9zY2lsbGF0b3IuZnJlcXVlbmN5LnNldFZhbHVlQXRUaW1lKDg4MCwgYXVkaW9DdHguY3VycmVudFRpbWUpOyAvLyBBNSBub3RlXG4gICAgICBnYWluTm9kZS5nYWluLnNldFZhbHVlQXRUaW1lKDAuMSwgYXVkaW9DdHguY3VycmVudFRpbWUpO1xuICAgICAgb3NjaWxsYXRvci5zdGFydCgpO1xuICAgICAgb3NjaWxsYXRvci5zdG9wKGF1ZGlvQ3R4LmN1cnJlbnRUaW1lICsgMC4xNSk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc29sZS53YXJuKFwiQXVkaW8gQ29udGV4dCBiZWVwIGZhaWxlZDpcIiwgZSk7XG4gICAgfVxuICB9O1xuXG4gIC8vIERlY29kZSBsb2dpYyBmb3IgUVIgY29kZXNcbiAgY29uc3QgaGFuZGxlRGVjb2RlZERhdGEgPSAoZGF0YVN0cikgPT4ge1xuICAgIHBsYXlCZWVwKCk7XG4gICAgc3RvcENhbWVyYSgpO1xuICAgIFxuICAgIHRyeSB7XG4gICAgICAvLyBUcnkgdG8gcGFyc2UgSlNPTiBmb3JtYXQgKGUuZy4ge1wicmVjaXBpZW50XCI6IFwiUmFuZHkgUHJlc3NcIiwgXCJhbW91bnRcIjogMjUwLCBcImVtYWlsXCI6IFwicmFuZHkucHJlc3NAZ21haWwuY29tXCJ9KVxuICAgICAgY29uc3QgcGFyc2VkID0gSlNPTi5wYXJzZShkYXRhU3RyKTtcbiAgICAgIGlmIChwYXJzZWQucmVjaXBpZW50IHx8IHBhcnNlZC5uYW1lIHx8IHBhcnNlZC5lbWFpbCkge1xuICAgICAgICBzZXRQYXltZW50RGF0YSh7XG4gICAgICAgICAgcmVjaXBpZW50OiBwYXJzZWQucmVjaXBpZW50IHx8IHBhcnNlZC5uYW1lIHx8IHBhcnNlZC5lbWFpbCxcbiAgICAgICAgICBhbW91bnQ6IHBhcnNlRmxvYXQocGFyc2VkLmFtb3VudCkgfHwgbnVsbCxcbiAgICAgICAgICBlbWFpbDogcGFyc2VkLmVtYWlsIHx8ICdzY2FubmVkLnJlY2lwaWVudEBiYW5rZGFzaC5jb20nLFxuICAgICAgICAgIHB1cnBvc2U6IHBhcnNlZC5wdXJwb3NlIHx8ICdRUiBTY2FuIFBheW1lbnQnXG4gICAgICAgIH0pO1xuICAgICAgICBpZiAocGFyc2VkLmFtb3VudCkge1xuICAgICAgICAgIHNldEN1c3RvbUFtb3VudChwYXJzZWQuYW1vdW50LnRvU3RyaW5nKCkpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHNldEN1c3RvbUFtb3VudCgnJyk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIEZhbGxiYWNrIGlmIEpTT04gYnV0IG5vIHRhcmdldCBmaWVsZHNcbiAgICAgICAgc2V0UGF5bWVudERhdGEoe1xuICAgICAgICAgIHJlY2lwaWVudDogZGF0YVN0cixcbiAgICAgICAgICBhbW91bnQ6IG51bGwsXG4gICAgICAgICAgZW1haWw6ICdzY2FubmVkLnJlY2lwaWVudEBiYW5rZGFzaC5jb20nLFxuICAgICAgICAgIHB1cnBvc2U6ICdRUiBTY2FuIFBheW1lbnQnXG4gICAgICAgIH0pO1xuICAgICAgICBzZXRDdXN0b21BbW91bnQoJycpO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIC8vIFBsYWluIHRleHQgZmFsbGJhY2sgKGNvdWxkIGJlIGEgbmFtZSwgYWNjb3VudCBJRCwgb3IgZW1haWwgYWRkcmVzcylcbiAgICAgIHNldFBheW1lbnREYXRhKHtcbiAgICAgICAgcmVjaXBpZW50OiBkYXRhU3RyLFxuICAgICAgICBhbW91bnQ6IG51bGwsXG4gICAgICAgIGVtYWlsOiBkYXRhU3RyLmluY2x1ZGVzKCdAJykgPyBkYXRhU3RyIDogJ3NjYW5uZWQucmVjaXBpZW50QGJhbmtkYXNoLmNvbScsXG4gICAgICAgIHB1cnBvc2U6ICdRUiBTY2FuIFBheW1lbnQnXG4gICAgICB9KTtcbiAgICAgIHNldEN1c3RvbUFtb3VudCgnJyk7XG4gICAgfVxuICB9O1xuXG4gIC8vIEhhbmRsZSBsb2NhbCBmaWxlIFFSIHNjYW5cbiAgY29uc3QgaGFuZGxlRmlsZVVwbG9hZCA9IChlKSA9PiB7XG4gICAgY29uc3QgZmlsZSA9IGUudGFyZ2V0LmZpbGVzWzBdO1xuICAgIGlmICghZmlsZSkgcmV0dXJuO1xuXG4gICAgc2V0U2NhbkVycm9yKCcnKTtcbiAgICBzZXRTY2FuTWVzc2FnZSgnUHJvY2Vzc2luZyBmaWxlLi4uJyk7XG5cbiAgICBjb25zdCByZWFkZXIgPSBuZXcgRmlsZVJlYWRlcigpO1xuICAgIHJlYWRlci5vbmxvYWQgPSAoZXZlbnQpID0+IHtcbiAgICAgIGNvbnN0IGltZyA9IG5ldyBJbWFnZSgpO1xuICAgICAgaW1nLm9ubG9hZCA9ICgpID0+IHtcbiAgICAgICAgY29uc3QgY2FudmFzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnY2FudmFzJyk7XG4gICAgICAgIGNvbnN0IGN0eCA9IGNhbnZhcy5nZXRDb250ZXh0KCcyZCcpO1xuICAgICAgICBjYW52YXMud2lkdGggPSBpbWcud2lkdGg7XG4gICAgICAgIGNhbnZhcy5oZWlnaHQgPSBpbWcuaGVpZ2h0O1xuICAgICAgICBjdHguZHJhd0ltYWdlKGltZywgMCwgMCk7XG4gICAgICAgIFxuICAgICAgICBjb25zdCBpbWFnZURhdGEgPSBjdHguZ2V0SW1hZ2VEYXRhKDAsIDAsIGNhbnZhcy53aWR0aCwgY2FudmFzLmhlaWdodCk7XG4gICAgICAgIGNvbnN0IGNvZGUgPSBqc1FSKGltYWdlRGF0YS5kYXRhLCBpbWFnZURhdGEud2lkdGgsIGltYWdlRGF0YS5oZWlnaHQpO1xuICAgICAgICBcbiAgICAgICAgaWYgKGNvZGUpIHtcbiAgICAgICAgICBoYW5kbGVEZWNvZGVkRGF0YShjb2RlLmRhdGEpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHNldFNjYW5FcnJvcihcIk5vIFFSIENvZGUgZm91bmQgaW4gdGhpcyBpbWFnZS4gVHJ5IGFub3RoZXIgcGljdHVyZS5cIik7XG4gICAgICAgICAgc2V0U2Nhbk1lc3NhZ2UoXCJTY2FubmluZyBmYWlsZWQuIFBsZWFzZSBtYWtlIHN1cmUgdGhlIFFSIGlzIGNsZWFyIGFuZCB3ZWxsLWxpdC5cIik7XG4gICAgICAgIH1cbiAgICAgIH07XG4gICAgICBpbWcuc3JjID0gZXZlbnQudGFyZ2V0LnJlc3VsdDtcbiAgICB9O1xuICAgIHJlYWRlci5yZWFkQXNEYXRhVVJMKGZpbGUpO1xuICB9O1xuXG4gIC8vIFByb2Nlc3MgdGhlIGZpbmFsIHRyYW5zYWN0aW9uXG4gIGNvbnN0IGhhbmRsZUNvbmZpcm1QYXltZW50ID0gKGUpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgY29uc3QgYW1vdW50VmFsID0gcGFyc2VGbG9hdChjdXN0b21BbW91bnQpO1xuICAgIGlmIChpc05hTihhbW91bnRWYWwpIHx8IGFtb3VudFZhbCA8PSAwKSB7XG4gICAgICBhbGVydChcIlBsZWFzZSBlbnRlciBhIHZhbGlkIGFtb3VudC5cIik7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3Qgc2VsZWN0ZWRDYXJkID0gY2FyZHMuZmluZChjID0+IGMuaWQgPT09IHNlbGVjdGVkQ2FyZElkKTtcbiAgICBpZiAoIXNlbGVjdGVkQ2FyZCkge1xuICAgICAgYWxlcnQoXCJQbGVhc2Ugc2VsZWN0IGEgY2FyZCB0byBwYXkgZnJvbS5cIik7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgaWYgKHNlbGVjdGVkQ2FyZC5iYWxhbmNlIDwgYW1vdW50VmFsKSB7XG4gICAgICBhbGVydChcIkluc3VmZmljaWVudCBmdW5kcyBpbiB0aGUgc2VsZWN0ZWQgY2FyZCBhY2NvdW50IVwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBzZXRUcmFuc2ZlckluUHJvZ3Jlc3ModHJ1ZSk7XG5cbiAgICAvLyBTaW11bGF0ZSBuZXR3b3JrIGRlbGF5IGZvciBwcmVtaXVtIHZpc3VhbCBmZWVsXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICBvblVwZGF0ZUNhcmRCYWxhbmNlKHNlbGVjdGVkQ2FyZC5pZCwgc2VsZWN0ZWRDYXJkLmJhbGFuY2UgLSBhbW91bnRWYWwpO1xuXG4gICAgICBjb25zdCB0eElkID0gYFRYJHtNYXRoLmZsb29yKDEwMDAgKyBNYXRoLnJhbmRvbSgpICogOTAwMCl9YDtcbiAgICAgIG9uQWRkVHJhbnNhY3Rpb24oe1xuICAgICAgICBpZDogdHhJZCxcbiAgICAgICAgZGVzYzogYFNjYW4gUGF5IHRvICR7cGF5bWVudERhdGEucmVjaXBpZW50fWAsXG4gICAgICAgIGRhdGU6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdCgnVCcpWzBdLFxuICAgICAgICB0eXBlOiAnZXhwZW5zZScsXG4gICAgICAgIG1ldGhvZDogJ1FSIFNjYW4gQ29kZScsXG4gICAgICAgIGNhdGVnb3J5OiAnVHJhbnNmZXInLFxuICAgICAgICBhbW91bnQ6IGFtb3VudFZhbCxcbiAgICAgICAgc3RhdHVzOiAnU3VjY2VzcydcbiAgICAgIH0pO1xuXG4gICAgICBvbkFkZE5vdGlmaWNhdGlvbih7XG4gICAgICAgIGlkOiBEYXRlLm5vdygpLFxuICAgICAgICB0ZXh0OiBgU2NhbiAmIFBheTogU2VudCAkJHthbW91bnRWYWwudG9Mb2NhbGVTdHJpbmcoKX0gdG8gJHtwYXltZW50RGF0YS5yZWNpcGllbnR9IGZyb20gY2FyZCBlbmRpbmcgJHtzZWxlY3RlZENhcmQubnVtYmVyLnNsaWNlKC00KX0uYCxcbiAgICAgICAgdGltZTogXCJKdXN0IG5vd1wiLFxuICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcbiAgICAgICAgdW5yZWFkOiB0cnVlXG4gICAgICB9KTtcblxuICAgICAgc2V0VHJhbnNmZXJJblByb2dyZXNzKGZhbHNlKTtcbiAgICAgIHNldFRyYW5zZmVyU3VjY2Vzcyh0cnVlKTtcbiAgICB9LCAxNTAwKTtcbiAgfTtcblxuICAvLyBHZW5lcmF0ZSBsb2NhbCBRUiBEYXRhIFVSTFxuICBjb25zdCBbbXlRclVybCwgc2V0TXlRclVybF0gPSB1c2VTdGF0ZSgnJyk7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgbXlRck9iamVjdCA9IHtcbiAgICAgIG5hbWU6IHVzZXJTZXNzaW9uLm5hbWUsXG4gICAgICBlbWFpbDogdXNlclNlc3Npb24uZW1haWwsXG4gICAgICBwdXJwb3NlOiBxclB1cnBvc2UsXG4gICAgICBhbW91bnQ6IHFyQW1vdW50ID8gcGFyc2VGbG9hdChxckFtb3VudCkgOiBudWxsXG4gICAgfTtcbiAgICBjb25zdCBteVFyU3RyaW5nID0gSlNPTi5zdHJpbmdpZnkobXlRck9iamVjdCk7XG4gICAgUVJDb2RlLnRvRGF0YVVSTChteVFyU3RyaW5nLCB7IG1hcmdpbjogMSwgd2lkdGg6IDI1MCB9KVxuICAgICAgLnRoZW4odXJsID0+IHNldE15UXJVcmwodXJsKSlcbiAgICAgIC5jYXRjaChlcnIgPT4gY29uc29sZS5lcnJvcihcIkxvY2FsIFFSIGdlbmVyYXRpb24gZmFpbGVkOlwiLCBlcnIpKTtcbiAgfSwgW3VzZXJTZXNzaW9uLm5hbWUsIHVzZXJTZXNzaW9uLmVtYWlsLCBxclB1cnBvc2UsIHFyQW1vdW50XSk7XG5cbiAgLy8gQ2xvc2UgcGF5bWVudCBkcmF3ZXIgYW5kIHJlc2V0IGNhbWVyYVxuICBjb25zdCBoYW5kbGVDbG9zZURyYXdlciA9ICgpID0+IHtcbiAgICBzZXRQYXltZW50RGF0YShudWxsKTtcbiAgICBzZXRUcmFuc2ZlclN1Y2Nlc3MoZmFsc2UpO1xuICAgIHNldEN1c3RvbUFtb3VudCgnJyk7XG4gICAgaWYgKGFjdGl2ZVN1YlRhYiA9PT0gJ3NjYW4nICYmIHNjYW5NZXRob2QgPT09ICdjYW1lcmEnKSB7XG4gICAgICBzdGFydENhbWVyYSgpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicXItc2Nhbm5lci10YWJcIj5cbiAgICAgIHsvKiBTdWIgVGFicyBOYXZpZ2F0aW9uICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWN0aW9uLWhlYWRlclwiIHN0eWxlPXt7IGJvcmRlckJvdHRvbTogJzFweCBzb2xpZCB2YXIoLS1sZC1ib3JkZXIpJywgcGFkZGluZ0JvdHRvbTogJzFyZW0nLCBtYXJnaW5Cb3R0b206ICcxLjVyZW0nIH19PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpbHRlci10YWJzXCIgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiAwLCBib3JkZXJCb3R0b206ICdub25lJyB9fT5cbiAgICAgICAgICA8ZGl2IFxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmlsdGVyLXRhYiAke2FjdGl2ZVN1YlRhYiA9PT0gJ3NjYW4nID8gJ2FjdGl2ZScgOiAnJ31gfVxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlU3ViVGFiKCdzY2FuJyl9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPENhbWVyYSBzaXplPXsxNn0gc3R5bGU9e3sgbWFyZ2luUmlnaHQ6ICcwLjRyZW0nLCB2ZXJ0aWNhbEFsaWduOiAnbWlkZGxlJyB9fSAvPlxuICAgICAgICAgICAgU2NhbiBRUiBDb2RlXG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBcbiAgICAgICAgICAgIGNsYXNzTmFtZT17YGZpbHRlci10YWIgJHthY3RpdmVTdWJUYWIgPT09ICdteS1xcicgPyAnYWN0aXZlJyA6ICcnfWB9XG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVTdWJUYWIoJ215LXFyJyl9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFFyQ29kZSBzaXplPXsxNn0gc3R5bGU9e3sgbWFyZ2luUmlnaHQ6ICcwLjRyZW0nLCB2ZXJ0aWNhbEFsaWduOiAnbWlkZGxlJyB9fSAvPlxuICAgICAgICAgICAgUmVjZWl2ZSBNb25leSAoTXkgUVIpXG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHthY3RpdmVTdWJUYWIgPT09ICdzY2FuJyAmJiBzY2FuTWV0aG9kID09PSAnY2FtZXJhJyAmJiAoXG4gICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImljb24tYnRuXCIgXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTb3VuZEVuYWJsZWQoIXNvdW5kRW5hYmxlZCl9XG4gICAgICAgICAgICB0aXRsZT17c291bmRFbmFibGVkID8gXCJNdXRlIHNjYW4gc291bmRcIiA6IFwiVW5tdXRlIHNjYW4gc291bmRcIn1cbiAgICAgICAgICAgIHN0eWxlPXt7IG1hcmdpbjogMCwgcGFkZGluZzogJzAuNXJlbScsIGJhY2tncm91bmQ6ICd2YXIoLS1wYW5lbC1iZyknLCBib3JkZXJSYWRpdXM6ICc1MCUnIH19XG4gICAgICAgICAgPlxuICAgICAgICAgICAge3NvdW5kRW5hYmxlZCA/IDxWb2x1bWUyIHNpemU9ezE4fSAvPiA6IDxWb2x1bWVYIHNpemU9ezE4fSAvPn1cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7YWN0aXZlU3ViVGFiID09PSAnc2NhbicgPyAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2Nhbm5lci1jb250YWluZXItcm93XCI+XG4gICAgICAgICAgey8qIE1haW4gU2Nhbm5pbmcgRnJhbWUgQ2FyZCAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC03XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBhbmVsXCIgc3R5bGU9e3sgbWluSGVpZ2h0OiAnNDIwcHgnLCBkaXNwbGF5OiAnZmxleCcsIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywganVzdGlmeUNvbnRlbnQ6ICdjZW50ZXInLCBwb3NpdGlvbjogJ3JlbGF0aXZlJywgb3ZlcmZsb3c6ICdoaWRkZW4nIH19PlxuICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgey8qIENhbWVyYSBzZWxlY3Rpb24gZHJvcGRvd24gYW5kIHRvZ2dsZXMgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2Nhbm5lci1oZWFkZXItY29udHJvbHNcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgc2Nhbm5lci10b2dnbGUtYnRuICR7c2Nhbk1ldGhvZCA9PT0gJ2NhbWVyYScgPyAnYWN0aXZlJyA6ICcnfWB9XG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7IHNldFNjYW5NZXRob2QoJ2NhbWVyYScpOyBzZXRTY2FuRXJyb3IoJycpOyB9fVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIExpdmUgV2ViY2FtXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHNjYW5uZXItdG9nZ2xlLWJ0biAke3NjYW5NZXRob2QgPT09ICd1cGxvYWQnID8gJ2FjdGl2ZScgOiAnJ31gfVxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRTY2FuTWV0aG9kKCd1cGxvYWQnKTsgc3RvcENhbWVyYSgpOyBzZXRTY2FuRXJyb3IoJycpOyB9fVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIFVwbG9hZCBJbWFnZVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAge3NjYW5NZXRob2QgPT09ICdjYW1lcmEnICYmIGRldmljZXMubGVuZ3RoID4gMSAmJiAoXG4gICAgICAgICAgICAgICAgICA8c2VsZWN0IFxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjYW1lcmEtc2VsZWN0b3Itc2VsZWN0XCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRGV2aWNlfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlbGVjdGVkRGV2aWNlKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge2RldmljZXMubWFwKChkZXZpY2UsIGlkeCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtkZXZpY2UuZGV2aWNlSWR9IHZhbHVlPXtkZXZpY2UuZGV2aWNlSWR9PlxuICAgICAgICAgICAgICAgICAgICAgICAgQ2FtZXJhIHtpZHggKyAxfSAoe2RldmljZS5sYWJlbC5zbGljZSgwLCAxNSkgfHwgJ0RldmljZSd9KVxuICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHtzY2FuTWV0aG9kID09PSAnY2FtZXJhJyA/IChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIndlYmNhbS12aWV3cG9ydFwiPlxuICAgICAgICAgICAgICAgICAgey8qIEdsb3dpbmcgQm94IC8gR3VpZGVzICovfVxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzY2FubmVyLW92ZXJsYXktZ3VpZGVcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzY2FubmVyLWxhc2VyLWxpbmVcIj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb3JuZXItZ3VpZGUgdG9wLWxlZnRcIj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb3JuZXItZ3VpZGUgdG9wLXJpZ2h0XCI+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29ybmVyLWd1aWRlIGJvdHRvbS1sZWZ0XCI+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29ybmVyLWd1aWRlIGJvdHRvbS1yaWdodFwiPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDx2aWRlbyByZWY9e3ZpZGVvUmVmfSBjbGFzc05hbWU9XCJ3ZWJjYW0tdmlkZW8tZmVlZFwiIHBsYXlzSW5saW5lIC8+XG4gICAgICAgICAgICAgICAgICA8Y2FudmFzIHJlZj17Y2FudmFzUmVmfSBzdHlsZT17eyBkaXNwbGF5OiAnbm9uZScgfX0gLz5cbiAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgeyFjYW1lcmFBY3RpdmUgJiYgIXNjYW5FcnJvciAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2Nhbm5lci1sb2FkZXItb3ZlcmxheVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJlbWl1bS1zcGlubmVyXCI+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgbWFyZ2luVG9wOiAnMXJlbScsIGZvbnRTaXplOiAnMC45cmVtJywgY29sb3I6ICdyZ2JhKDI1NSwyNTUsMjU1LDAuNyknIH19PlN0YXJ0aW5nIGNhbWVyYSBmZWVkLi4uPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgLyogVXBsb2FkIERyYWcgRHJvcCBab25lICovXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1cGxvYWQtZHJvcHpvbmUtd3JhcHBlclwiPlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJxci1maWxlLXVwbG9hZFwiIGNsYXNzTmFtZT1cImRyb3B6b25lLWxhYmVsXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidXBsb2FkLWljb24tY2lyY2xlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPFVwbG9hZCBzaXplPXszMn0gLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxoND5VcGxvYWQgcGF5bWVudCBRUiBjb2RlPC9oND5cbiAgICAgICAgICAgICAgICAgICAgPHA+RHJhZyBhbmQgZHJvcCBpbWFnZSBmaWxlLCBvciBjbGljayB0byBicm93c2U8L3A+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZpbGUtZm9ybWF0cy1sYWJlbFwiPlN1cHBvcnRzIFBORywgSlBHLCBKUEVHPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImZpbGVcIiBcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cInFyLWZpbGUtdXBsb2FkXCIgXG4gICAgICAgICAgICAgICAgICAgICAgYWNjZXB0PVwiaW1hZ2UvKlwiIFxuICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGRpc3BsYXk6ICdub25lJyB9fVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVGaWxlVXBsb2FkfSBcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgey8qIFN0YXR1cyBmb290ZXIgYmFyICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNjYW5uZXItc3RhdHVzLWZvb3RlclwiIHN0eWxlPXtzY2FuRXJyb3IgPyB7IGJhY2tncm91bmQ6ICdyZ2JhKDI1NSwgNzUsIDc0LCAwLjEpJywgY29sb3I6ICcjRkY0QjRBJyB9IDoge319PlxuICAgICAgICAgICAgICAgIHtzY2FuRXJyb3IgPyAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGdhcDogJzAuNXJlbScgfX0+XG4gICAgICAgICAgICAgICAgICAgIDxTaGllbGRBbGVydCBzaXplPXsxNn0gLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3NjYW5FcnJvcn08L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgPHNwYW4+e3NjYW5NZXNzYWdlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogUXVpY2sgaW5zdHJ1Y3Rpb25zIC8gSW5mbyBTaWRlYmFyICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLTVcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGFuZWxcIiBzdHlsZT17eyBtaW5IZWlnaHQ6ICc0MjBweCcsIHBhZGRpbmc6ICcycmVtJyB9fT5cbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBnYXA6ICcwLjZyZW0nLCBtYXJnaW5Cb3R0b206ICcxLjI1cmVtJyB9fT5cbiAgICAgICAgICAgICAgICA8U3BhcmtsZXMgc2l6ZT17MjB9IGNvbG9yPVwidmFyKC0tYWNjZW50LXByaW1hcnkpXCIgLz5cbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwic2VjdGlvbi10aXRsZVwiIHN0eWxlPXt7IG1hcmdpbjogMCB9fT5TY2FuIHRvIFBheTwvaDM+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8cCBzdHlsZT17eyBjb2xvcjogJyM3MThFQkYnLCBmb250U2l6ZTogJzAuOXJlbScsIGxpbmVIZWlnaHQ6ICcxLjYnLCBtYXJnaW5Cb3R0b206ICcxLjVyZW0nIH19PlxuICAgICAgICAgICAgICAgIFF1aWNrbHkgdHJhbnNmZXIgZnVuZHMgdG8gYW55IG90aGVyIEJhbmtEYXNoIG1lbWJlci4gWW91IGNhbiBzY2FuIHRoZWlyIHByb2ZpbGUgUVIgY29kZSBlaXRoZXIgYnkgb3BlbmluZyB5b3VyIGNhbWVyYSBvciB1cGxvYWRpbmcgYSBwaWN0dXJlIG9mIHRoZSBRUiBjb2RlLlxuICAgICAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbnN0cnVjdGlvbi1zdGVwc1wiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3RlcC1pdGVtXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN0ZXAtYmFkZ2VcIj4xPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8aDU+U2VsZWN0IFNjYW4gT3B0aW9uPC9oNT5cbiAgICAgICAgICAgICAgICAgICAgPHA+VXNlIHlvdXIgY2FtZXJhIHRvIHNjYW4gYSBRUiBjb2RlIGluIHJlYWwtdGltZSBvciB1cGxvYWQgYSBzY3JlZW5zaG90L2ltYWdlIG9mIHRoZSBRUi48L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN0ZXAtaXRlbVwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdGVwLWJhZGdlXCI+MjwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGg1PlJldmlldyBEZXRhaWxzPC9oNT5cbiAgICAgICAgICAgICAgICAgICAgPHA+VmVyaWZ5IHRoZSByZWNpcGllbnQncyBuYW1lLCBlbWFpbCwgYW5kIGlucHV0IHRoZSBhbW91bnQgeW91IHdpc2ggdG8gdHJhbnNmZXIuPC9wPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdGVwLWl0ZW1cIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3RlcC1iYWRnZVwiPjM8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxoNT5Db25maXJtIFRyYW5zYWN0aW9uPC9oNT5cbiAgICAgICAgICAgICAgICAgICAgPHA+U2VsZWN0IHlvdXIgc291cmNlIHBheW1lbnQgY2FyZCwgc2xpZGUvY29uZmlybSwgYW5kIHlvdXIgZnVuZHMgYXJlIHRyYW5zZmVycmVkIGluc3RhbnRseS48L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApIDogKFxuICAgICAgICAvKiBNeSBRUiB0YWIgLSBnZW5lcmF0ZXMgZHluYW1pYyBwZXJzb25hbCBRUiBjb2RlIHRvIHJlY2VpdmUgbW9uZXkgKi9cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzY2FubmVyLWNvbnRhaW5lci1yb3dcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC03XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBhbmVsXCIgc3R5bGU9e3sgbWluSGVpZ2h0OiAnNDQwcHgnLCBkaXNwbGF5OiAnZmxleCcsIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywganVzdGlmeUNvbnRlbnQ6ICdjZW50ZXInLCBwYWRkaW5nOiAnMi41cmVtJyB9fT5cbiAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgIHsvKiBQcmVtaXVtIER5bmFtaWMgUVIgRnJhbWUgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJlbWl1bS1xci1lbnZlbG9wZVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicXItZW52ZWxvcGUtY2hpcFwiPjwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicXItZW52ZWxvcGUtbG9nby1icmFuZFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsb2dvLWljb25cIiBzdHlsZT17eyB3aWR0aDogJzE4cHgnLCBoZWlnaHQ6ICcxOHB4JyB9fT5cbiAgICAgICAgICAgICAgICAgICAgPHN2ZyB3aWR0aD1cIjEyXCIgaGVpZ2h0PVwiMTJcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgZmlsbD1cIm5vbmVcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBkPVwiTTEyIDJMMiA3TDEyIDEyTDIyIDdMMTIgMlpcIiBmaWxsPVwid2hpdGVcIiBzdHJva2U9XCJ3aGl0ZVwiIHN0cm9rZVdpZHRoPVwiMlwiLz5cbiAgICAgICAgICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPkJhbmtEYXNoLjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicXItY29kZS1jYW52YXMtZnJhbWVcIiBzdHlsZT17eyBtaW5XaWR0aDogJzE4MHB4JywgbWluSGVpZ2h0OiAnMTgwcHgnIH19PlxuICAgICAgICAgICAgICAgICAge215UXJVcmwgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxpbWcgc3JjPXtteVFyVXJsfSBhbHQ9XCJNeSBRUiBDb2RlXCIgY2xhc3NOYW1lPVwiZ2VuZXJhdGVkLXFyLWltYWdlXCIgLz5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJlbWl1bS1zcGlubmVyXCIgc3R5bGU9e3sgd2lkdGg6ICczMnB4JywgaGVpZ2h0OiAnMzJweCcgfX0+PC9kaXY+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJxci1lbnZlbG9wZS1ob2xkZXItcm93XCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVudmVsb3BlLWhvbGRlci1sYmxcIj5BY2NvdW50IEhvbGRlcjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVudmVsb3BlLWhvbGRlci12YWxcIj57dXNlclNlc3Npb24ubmFtZX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAge3FyQW1vdW50ICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyB0ZXh0QWxpZ246ICdyaWdodCcgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJlbnZlbG9wZS1ob2xkZXItbGJsXCI+UmVxdWVzdGVkIEFtb3VudDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZW52ZWxvcGUtaG9sZGVyLXZhbFwiIHN0eWxlPXt7IGNvbG9yOiAndmFyKC0tc3VjY2VzcyknIH19PiR7cGFyc2VGbG9hdChxckFtb3VudCkudG9Mb2NhbGVTdHJpbmcoKX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IG1hcmdpblRvcDogJzEuNXJlbScsIGRpc3BsYXk6ICdmbGV4JywgZ2FwOiAnMXJlbScgfX0+XG4gICAgICAgICAgICAgICAgPGEgaHJlZj17bXlRclVybH0gdGFyZ2V0PVwiX2JsYW5rXCIgcmVsPVwibm9yZWZlcnJlclwiIGRvd25sb2FkPXtgYmFua2Rhc2hfcXJfJHt1c2VyU2Vzc2lvbi5uYW1lfS5wbmdgfSBjbGFzc05hbWU9XCJzZXR0aW5ncy1zYXZlLWJ0blwiIHN0eWxlPXt7IHRleHREZWNvcmF0aW9uOiAnbm9uZScsIGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGdhcDogJzAuNXJlbScsIHBhZGRpbmc6ICcwLjZyZW0gMS41cmVtJywgbWFyZ2luOiAwIH19PlxuICAgICAgICAgICAgICAgICAgPERvd25sb2FkIHNpemU9ezE2fSAvPlxuICAgICAgICAgICAgICAgICAgRG93bmxvYWQgUVIgQ29kZVxuICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtNVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYW5lbFwiIHN0eWxlPXt7IG1pbkhlaWdodDogJzQ0MHB4JywgcGFkZGluZzogJzJyZW0nIH19PlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwic2VjdGlvbi10aXRsZVwiIHN0eWxlPXt7IG1hcmdpbkJvdHRvbTogJzEuMjVyZW0nIH19PkN1c3RvbWl6ZSBRUiBSZXF1ZXN0PC9oMz5cbiAgICAgICAgICAgICAgPHAgc3R5bGU9e3sgY29sb3I6ICcjNzE4RUJGJywgZm9udFNpemU6ICcwLjlyZW0nLCBsaW5lSGVpZ2h0OiAnMS42JywgbWFyZ2luQm90dG9tOiAnMS41cmVtJyB9fT5cbiAgICAgICAgICAgICAgICBTZXQgYW4gb3B0aW9uYWwgYW1vdW50IG9yIHRyYW5zZmVyIGRlc2NyaXB0aW9uIGJlbG93IHRvIGVtYmVkIHRoZW0gZGlyZWN0bHkgaW50byB5b3VyIHBlcnNvbmFsIFFSIGNvZGUuXG4gICAgICAgICAgICAgIDwvcD5cblxuICAgICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJxci1jdXN0b21pemVyLWZvcm1cIiBvblN1Ym1pdD17KGUpID0+IGUucHJldmVudERlZmF1bHQoKX0+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZXR0aW5ncy1pbnB1dC1ncm91cFwiPlxuICAgICAgICAgICAgICAgICAgPGxhYmVsPlJlcXVlc3QgU3BlY2lmaWMgQW1vdW50ICgkKTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8aW5wdXQgXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzZXR0aW5ncy1mb3JtLWlucHV0XCJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIDE1MC4wMCAoTGVhdmUgZW1wdHkgZm9yIGFueSBhbW91bnQpXCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3FyQW1vdW50fVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFFyQW1vdW50KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNldHRpbmdzLWlucHV0LWdyb3VwXCI+XG4gICAgICAgICAgICAgICAgICA8bGFiZWw+VHJhbnNmZXIgUHVycG9zZSAvIE5vdGU8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNldHRpbmdzLWZvcm0taW5wdXRcIlxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gU3BsaXQgRGlubmVyIEJpbGxcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cXJQdXJwb3NlfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFFyUHVycG9zZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Zvcm0+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJxci1pbmZvLXBpbGxzXCIgc3R5bGU9e3sgbWFyZ2luVG9wOiAnMS41cmVtJywgcGFkZGluZzogJzFyZW0nLCBiYWNrZ3JvdW5kOiAncmdiYSg1NywgMTA2LCAyNTUsIDAuMDUpJywgYm9yZGVyUmFkaXVzOiAnMTJweCcsIGJvcmRlcjogJzFweCBzb2xpZCByZ2JhKDU3LCAxMDYsIDI1NSwgMC4xKScgfX0+XG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGdhcDogJzAuNXJlbScsIGFsaWduSXRlbXM6ICdmbGV4LXN0YXJ0JyB9fT5cbiAgICAgICAgICAgICAgICAgIDxRckNvZGUgc2l6ZT17MTh9IGNvbG9yPVwidmFyKC0tYWNjZW50LXByaW1hcnkpXCIgc3R5bGU9e3sgZmxleFNocmluazogMCwgbWFyZ2luVG9wOiAnMC4xcmVtJyB9fSAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFNpemU6ICcwLjhyZW0nLCBjb2xvcjogJyMzNDNDNkEnLCBmb250V2VpZ2h0OiA1MDAsIGxpbmVIZWlnaHQ6ICcxLjUnIH19PlxuICAgICAgICAgICAgICAgICAgICBXaGVuIGFub3RoZXIgQmFua0Rhc2ggYXBwIHNjYW5zIHRoaXMgUVIsIGl0IHdpbGwgcHJlLWZpbGwgeW91ciBuYW1lLCBlbWFpbCwgYW5kIHRoZSByZXF1ZXN0ZWQgZGV0YWlscyBhdXRvbWF0aWNhbGx5IVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBDT05GSVJNQVRJT04gUEFZIFNMSURFT1VUIERSQVdFUiAqL31cbiAgICAgIHtwYXltZW50RGF0YSAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGF5bWVudC1kcmF3ZXItYmFja2Ryb3BcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBheW1lbnQtZHJhd2VyLWNvbnRhaW5lclwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkcmF3ZXItaGVhZGVyLXJvd1wiPlxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGdhcDogJzAuNzVyZW0nIH19PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZHJhd2VyLWJhZGdlLWNpcmNsZVwiPlxuICAgICAgICAgICAgICAgICAgPEFycm93TGVmdFJpZ2h0IHNpemU9ezIwfSAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8aDMgc3R5bGU9e3sgbWFyZ2luOiAwLCBjb2xvcjogJyMzNDNDNkEnLCBmb250U2l6ZTogJzEuMnJlbScsIGZvbnRXZWlnaHQ6IDcwMCB9fT5Db25maXJtIFFSIFRyYW5zZmVyPC9oMz5cbiAgICAgICAgICAgICAgICAgIDxwIHN0eWxlPXt7IG1hcmdpbjogMCwgZm9udFNpemU6ICcwLjc4cmVtJywgY29sb3I6ICcjNzE4RUJGJyB9fT5WZXJpZnkgdHJhbnNhY3Rpb24gZGV0YWlscyBiZWZvcmUgY29tcGxldGluZyB0aGUgcGF5bWVudDwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiZHJhd2VyLWNsb3NlLWJ0blwiIG9uQ2xpY2s9e2hhbmRsZUNsb3NlRHJhd2VyfT5cbiAgICAgICAgICAgICAgICA8WCBzaXplPXsyMH0gLz5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAge3RyYW5zZmVyU3VjY2VzcyA/IChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkcmF3ZXItc3VjY2Vzcy12aWV3XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdWNjZXNzLWxvdHRpZS1tb2NrXCI+XG4gICAgICAgICAgICAgICAgICA8Q2hlY2sgc2l6ZT17MzZ9IGNvbG9yPVwid2hpdGVcIiBzdHJva2VXaWR0aD17M30gLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8aDM+VHJhbnNmZXIgU3VjY2Vzc2Z1bCE8L2gzPlxuICAgICAgICAgICAgICAgIDxwPlNlbnQgPGI+JHtwYXJzZUZsb2F0KGN1c3RvbUFtb3VudCkudG9Mb2NhbGVTdHJpbmcoKX08L2I+IHRvIDxiPntwYXltZW50RGF0YS5yZWNpcGllbnR9PC9iPjwvcD5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cInNldHRpbmdzLXNhdmUtYnRuXCIgc3R5bGU9e3sgbWFyZ2luOiAnMS41cmVtIDAgMCAwJyB9fSBvbkNsaWNrPXtoYW5kbGVDbG9zZURyYXdlcn0+XG4gICAgICAgICAgICAgICAgICBEb25lXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZUNvbmZpcm1QYXltZW50fSBjbGFzc05hbWU9XCJkcmF3ZXItZm9ybS1jb250ZW50XCI+XG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgey8qIFRyYW5zZmVyIEJyZWFrZG93biBDYXJkcyAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRyYXdlci1icmVha2Rvd24tYm94XCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJyZWFrZG93bi1pdGVtXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImxibFwiPlJlY2lwaWVudDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidmFsXCIgc3R5bGU9e3sgZm9udFdlaWdodDogNzAwIH19PntwYXltZW50RGF0YS5yZWNpcGllbnR9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJyZWFrZG93bi1pdGVtXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImxibFwiPlJlY2lwaWVudCBFbWFpbDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidmFsXCIgc3R5bGU9e3sgY29sb3I6ICcjNzE4RUJGJyB9fT57cGF5bWVudERhdGEuZW1haWx9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICB7cGF5bWVudERhdGEucHVycG9zZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYnJlYWtkb3duLWl0ZW1cIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJsYmxcIj5QdXJwb3NlPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInZhbFwiIHN0eWxlPXt7IGZvbnRTdHlsZTogJ2l0YWxpYycgfX0+e3BheW1lbnREYXRhLnB1cnBvc2V9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7LyogQ2FyZCBTZWxlY3Rpb24gKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZXR0aW5ncy1pbnB1dC1ncm91cFwiPlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIHN0eWxlPXt7IGZvbnRTaXplOiAnMC44MnJlbScsIGZvbnRXZWlnaHQ6IDYwMCB9fT5TZWxlY3QgRGViaXQgQ2FyZCBBY2NvdW50PC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxzZWxlY3QgXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNldHRpbmdzLWZvcm0taW5wdXRcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRDYXJkSWR9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VsZWN0ZWRDYXJkSWQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICB7Y2FyZHMubWFwKGNhcmQgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtjYXJkLmlkfSB2YWx1ZT17Y2FyZC5pZH0+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Y2FyZC50eXBlLnRvVXBwZXJDYXNlKCl9IENhcmQgZW5kaW5nIHtjYXJkLm51bWJlci5zbGljZSgtNCl9IChCYWw6ICR7Y2FyZC5iYWxhbmNlLnRvTG9jYWxlU3RyaW5nKCl9KVxuICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIEFtb3VudCBpbnB1dCAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNldHRpbmdzLWlucHV0LWdyb3VwXCI+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgc3R5bGU9e3sgZm9udFNpemU6ICcwLjgycmVtJywgZm9udFdlaWdodDogNjAwIH19PlRyYW5zZmVyIEFtb3VudCAoJCk8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic2V0dGluZ3MtZm9ybS1pbnB1dFwiXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgYW1vdW50IHRvIHBheVwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjdXN0b21BbW91bnR9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q3VzdG9tQW1vdW50KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3BheW1lbnREYXRhLmFtb3VudCAhPT0gbnVsbH0gLy8gTG9jayBpZiBhbW91bnQgd2FzIGJha2VkIGludG8gdGhlIFFSIENvZGVcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgICAgc3RlcD1cIjAuMDFcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIHtwYXltZW50RGF0YS5hbW91bnQgIT09IG51bGwgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbnB1dC1oZWxwZXItbm90ZVwiPkFtb3VudCBsb2NrZWQgYnkgUVIgQ29kZSByZXF1ZXN0Ljwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7LyogQ29uZmlybSBTbGlkZSAvIFNsaWRlciBCdXR0b24gKi99XG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW5Ub3A6ICcxLjVyZW0nIH19PlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiIFxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzZXR0aW5ncy1zYXZlLWJ0blwiIFxuICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogJzEwMCUnLCBtYXJnaW46IDAsIHBhZGRpbmc6ICcxcmVtJywgZGlzcGxheTogJ2ZsZXgnLCBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicsIGdhcDogJzAuNXJlbScgfX1cbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3RyYW5zZmVySW5Qcm9ncmVzc31cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge3RyYW5zZmVySW5Qcm9ncmVzcyA/IChcbiAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcmVtaXVtLXNwaW5uZXJcIiBzdHlsZT17eyB3aWR0aDogJzE4cHgnLCBoZWlnaHQ6ICcxOHB4JywgYm9yZGVyV2lkdGg6ICcycHgnLCBib3JkZXJDb2xvcjogJ3doaXRlJyB9fT48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIFByb2Nlc3NpbmcgU2VjdXJlIFRyYW5zZmVyLi4uXG4gICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxBcnJvd0xlZnRSaWdodCBzaXplPXsxOH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIENvbmZpcm0gJiBTZW5kICR7cGFyc2VGbG9hdChjdXN0b21BbW91bnQgfHwgMCkudG9Mb2NhbGVTdHJpbmcoKX1cbiAgICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBRclNjYW5uZXJUYWI7XG4iXSwiZmlsZSI6IkQ6L1JlYWN0X3Rlc3RfMTlfMDVfMjAyNi9zcmMvY29tcG9uZW50cy9RclNjYW5uZXJUYWIuanN4In0=